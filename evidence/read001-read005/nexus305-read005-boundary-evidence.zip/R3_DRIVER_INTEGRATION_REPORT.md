# R3 driver integration report

## Current Revision R2

Task completion is **DESIGN_CLARIFICATION_REQUIRED**; Driver Integration remains
**PARTIALLY_INTEGRATED**. See [R1-001 fix report](R3_R1_001_FIX_REPORT.md),
[Replay contract](R3_REPLAY_ENTITLEMENT_CONTRACT.md) and
[Finding disposition](R3_FINDING_DISPOSITION.md).

Normal stored events now require original/current Request, Session, Stream,
transport/connection, payload/ID/sequence and current Authority binding before
release/claim/write. Owner-local tickets are rechecked at the final Gate. Private
and Durable SDK EventStores share one implementation. All Replay entry points
fail-closed because no authenticated entitlement contract can be derived safely.
Case R1-001-04 is unresolved; this does not establish positive Replay integration.

DRV-001 and DRV-002 verification override were reported RESOLVED_STATIC_ONLY by
the independent reviewer; their original source invariants and static checks are
retained. Earlier R1 descriptions below are historical component coverage.

## Revision R1

Current revision details are in
[R3 Driver Integration Revision R1](R3_DRIVER_INTEGRATION_REVISION_R1_REPORT.md).
RG-305-R3-DRV-001 and RG-305-R3-DRV-002 are source-revised, static-only, pending
independent review. The descriptions below remain component coverage, not proof
that the previous implementation satisfied these two newly supplied Findings.

## Disposition

**PARTIALLY_INTEGRATED**. This is implementation-source delivery, not execution
evidence or an independent review decision. Execution Gate is **NOT_AUTHORIZED**;
R3 is **NOT_EXECUTED**; Section 4.1 is **BLOCKED**. Design Spec, Implementation
Plan and Nexus product implementation remain **NOT_APPROVED**.

Work is outside the Nexus repository. The fixed HEAD is
`4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`. The original provisioning ZIP is
preserved byte-for-byte as `inputs/provisioning-v3-original.zip`. Its SHA-256 is
`7e43da564c22979b249eaaf488909b0abef4ca7e927cae745a1fa225ec820042`.
`R3_INPUT_VERIFICATION.json` records recursive archive verification, the original
26 source hashes, five fixed-source comparisons and actual repository HEAD.

## Implemented source

| Task | Concrete source | Implemented boundary |
| --- | --- | --- |
| A | `src/adapters/native-lance.mjs` | Actual connections, tables, native query/vector readback, candidate optimize/prune, handle/pin tracking |
| B | `src/adapters/fixed-journal.mjs` | Actual metadata instance/schema, shared connection, atomic CAS/journal projection, legacy-call guard, readback |
| C | `src/adapters/sdk-drivers.mjs` | Real stdio transport, SDK Client private-pipe adapter, v1 Web Response, v2 factory/Node adapter, original Bridge function |
| D | `src/gate-owner.mjs` | One durable terminal claim, separate opaque sequential write permits, synchronous final admission |
| E | `src/drivers/cutover.mjs` | Actual pinned queries, stable request key, two attempts, fresh query rather than result relabeling |
| F | `preparation/freeze-integration.mjs` | Preserved 190+44 IDs/Oracles, component entry points, source hashes, argv, variant-specific input roots and blockers |

`src/drivers/integration.mjs` assembles the adapters and both final sinks. It is
callable source but is never called by the launcher. `src/adapters/frozen-runtime.mjs`
provides verified future imports of statically generated fixed-HEAD modules.
The 136 frozen TypeScript files and their generated runtime artifacts are
recorded in `R3_API_SIGNATURE_EVIDENCE.json`; generation did not import them.

## Completion limits

ENV-002 advanced from abstract callbacks to actual API-connected component
source. Full group/scenario contexts are still incomplete: `group-drivers.mjs`
requires named context methods, and `assembleDrivers` does not manufacture them.
Negative-control execution contexts are distinct and unimplemented. A component
source entry point for a Binding is not a completed executable scenario.

ENV-003 has a concrete finite JSON/SSE multiwrite mechanism. Header-before-C0 and
body-after-C0 follows the deny/abort path. Infinite live SSE, live cursor replay
composition and partial-frame scenario context remain unresolved; they are not
declared integrated merely because finite frames use permits.

ENV-001 remains administrator-owned. Real UID, mount, PID/TID, FD/device/inode,
durable filesystem, observer and dependency-runtime enrollment are absent.
`VENUE_BINDING_REQUIRED` is explicit, with no same-UID or checkout fallback.

## Verification and review handoff

Current results belong to `R3_STATIC_VERIFICATION.json`. The older
`STATIC_VERIFICATION.json` and `R3_HARNESS_IMPLEMENTATION_REPORT.md` are preserved
historical provisioning evidence, not the current integration verification.
Syntax, relative imports/exports, strict API probes, immutable original contracts,
binding coverage, hashes, schemas and hard execution denial are checked statically.
The JavaScript adapters are not fully semantically typechecked; typed API probes
and publication declarations do not prove every injected context implementation.

No experimental module, native library, SDK transport, recovery scenario, signal,
fault or crash was executed. No dependency was installed. No product source,
GitHub commit, push or PR was changed. Submit the complete ZIP to the independent
reviewer; no reviewer acceptance or delivery acknowledgement is invented here.

No static API impossibility or forbidden successful transition has been observed.
Thus this package does not assert DESIGN_REVISION_REQUIRED. The pending adapters
and runtime observations must be resolved before any stronger conclusion.
