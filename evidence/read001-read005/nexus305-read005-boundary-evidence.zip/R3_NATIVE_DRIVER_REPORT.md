# R3 native driver report

## API connection

`NativeLanceDriver` uses `connect`, `createTable`, `openTable`, `add`,
`query().toArray()`, `vectorSearch().limit().toArray()`, `version`, `countRows`,
`optimize`, `Table.close` and `Connection.close` from LanceDB 0.18.2.
Declaration files, versions and hashes are retained under `reference/api/`.
`preparation/api-probe.mts` compiles those actual signatures without loading them.

Pruning is `optimize({ cleanupOlderThan, deleteUnverified: false })`; there is no
invented `table.prune()` call. Candidate roots are separate for legacy and
structured databases, and published pair roots are supplied by the venue.
Writer-only methods refuse reader handles. They cannot mutate a published handle
through this adapter. This interface restriction is not OS write isolation.

## Isolation, retention and provenance

The venue must supply actor identity/mount evidence and independent pair topology
with no shared writable inodes. A published reader acquires a durable pin before
opening files. Failed opens retain the pin. Successful table/connection close is
only API closure: pin release additionally requires an independent no-FD/no-mapping
proof. It does not infer closure from a lease expiry or from `checkout()`.

Native readback enumerates actual rows from both tables and computes persisted
float32 vector digests. Provider receipts and expected inputs are separate inputs
to the original `validateBijection`. No provider binding is inferred from equal
dimensions, row counts or the synthetic fixture. Real query results and complete
physical artifact/hash retention still require authorized runtime evidence.

S01 copy/seal uses the existing Publisher/Seal interfaces; privileged safe path
copy and exhaustive mutation-route execution remain unbound. S02 combines the
existing observer with a venue-supplied Native TID/FD/syscall correlation interface.
An API entry event remains distinct from a native-I/O entry event. No kernel IDs,
signal delivery or observed syscalls have been fabricated.

## Remaining work

S01 attack matrix and enrolled safe-copy/Seal implementation; S02 actual observer
and pidfd controller; S03 old/fresh-reader retention scenario; S04 allowlisted
delete/crash context; S06 independent source enumeration, provider execution
binding and P1-P7 branch fixtures remain incomplete. These are listed per Binding.
Native runtime load, filesystem durability and FD ownership are **NOT_VERIFIED**.
All experiments remain **BLOCKED / NOT_EXECUTED**.
