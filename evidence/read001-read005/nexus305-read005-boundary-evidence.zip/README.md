# Nexus #305 READ-005 boundary evidence

Current revision: **PARTIALLY_INTEGRATED**. Start with
[closure report](BOUNDARY_CLOSURE_REPORT.md),
[blockers](BOUNDARY_REMAINING_BLOCKERS.md),
[execution ledger](BOUNDARY_EXECUTION_LEDGER.md), and
[review request](BOUNDARY_INDEPENDENT_REVIEW_REQUEST.md).

The [approved design](docs/superpowers/specs/2026-10-23-read005-capability-boundary-design.md)
and [implementation plan](docs/superpowers/plans/2026-10-23-read005-capability-boundary-plan.md)
are captured with their repository-relative paths. Their historical evidence
links refer to the original repository/extracted parent context.

`BOUNDARY_STATIC_COMMANDS.json`, `BOUNDARY_SOURCE_MANIFEST.json`,
`BOUNDARY_SOURCE_DIFF.patch`, `BOUNDARY_IMMUTABILITY_COMPARISON.json`, and
`BOUNDARY_ORACLE_MATRIX.json` describe this revision. All reports below are
historical. No runtime success, finding closure, or execution approval is claimed.

```sh
node preparation/run-boundary-suite.mjs "$REPO"
```

This runs preparation tooling only. Never run the source-only oracle modules.
The delivery omits nested historical inputs; retain the named parent evidence ZIP
alongside this revision. Execution Gate remains NOT_AUTHORIZED.

## Historical capability submission

Current submission: **DESIGN_CLARIFICATION_REQUIRED**. Start with
`READ_005_CAPABILITY_CLOSURE_REPORT.md`,
`READ_001_MAIN_OWNER_NONREGRESSION_REPORT.md`,
`CAPABILITY_ESCAPE_PATH_INVENTORY.json`, `READ005_ORACLE_MATRIX.json`,
`READ005_STATIC_VERIFICATION.json`, `READ005_IMMUTABILITY_COMPARISON.json`,
`READ005_SOURCE_DIFF.patch`, `READ005_SOURCE_MANIFEST.json`,
`READ005_REMAINING_BLOCKERS.md`, and
`READ005_INDEPENDENT_IMPLEMENTATION_REVIEW_REQUEST.md`.

Owner/Driver public capability paths are revised. Composition registry/provider
and caller-held Initialize Server paths remain explicit blockers. No global
capability-closure claim, finding CLOSE or Gate PASS is made.

Execution Gate **NOT_AUTHORIZED**; R3 **NOT_EXECUTED**; Section 4.1 **BLOCKED**;
R1-001-04 **UNRESOLVED**; 234 bindings **BLOCKED/NOT_EXECUTED**.
Test sources are **NOT_EXECUTED** and negative observations are **UNKNOWN**.

```sh
node preparation/verify-main-owner-capability.mjs "$REPO"
node preparation/verify-source-closure.mjs "$REPO"
node preparation/verify-frozen-api.mjs "$REPO"
```

These commands parse source, run syntax checks and compile fixed API probes;
they do not import Harness, test or SDK modules. Stop after evidence submission.
All earlier reports below are historical, not current capability attestations.

## Previous READ-001–004 submission

Current submission: **SDK_API_CONTRACT_BLOCKED**. Source edits are proposed for
independent review; READ-003/004 retain partial source integrations and missing
venue hooks. Execution Gate: **NOT_AUTHORIZED**. R3: **NOT_EXECUTED**.

Start with `READ_001_004_FINDING_DISPOSITION.md`, the four READ reports,
`READ_004_SCENARIO_RUNNER_MATRIX.json`, `WRITER_PATH_INVENTORY.json`,
`STATIC_VERIFICATION.json`, `FROZEN_API_STATIC_VERIFICATION.json`,
`SOURCE_CLOSURE_SOURCE_MANIFEST.json`, and `SOURCE_DIFF.patch`.

The external input archive remains byte-identical; its omission from this archive
avoids duplicating the entire preceding evidence. `SOURCE_CLOSURE_INPUT_VERIFICATION.json`
records its name and hash. Existing nested historical inputs are retained.
Historical reports below are not current source attestations.

## Current static checks

```sh
node preparation/verify-source-closure.mjs "$REPO"
node preparation/verify-frozen-api.mjs "$REPO"
```

These tools use the already installed compiler, parse/check source only, and do
not import or execute experimental Harness, test or SDK modules.

## Preserved previous README

**PARTIALLY_INTEGRATED**. This package contains concrete isolated harness source
and unexecuted test source. Execution Gate: **NOT_AUTHORIZED**.
R3: **NOT_EXECUTED**. Section 4.1: **BLOCKED**. R1-001-04: **UNRESOLVED**.

Current evidence entry points:

- `EXECUTION_READINESS_SOURCE_INTEGRATION_REPORT.md`
- `MAIN_SESSION_NODE_BRIDGE_INTEGRATION_REPORT.md`
- `TRUST_AND_CAPABILITY_BINDING_MATRIX.json`
- `SCENARIO_RUNNER_AND_ORACLE_MATRIX.json`
- `VENUE_CAPABILITY_REQUEST.md`
- `REMAINING_BLOCKERS_AND_HANDOFF.md`
- `SOURCE_DIFF_SHA256.json` and `SOURCE_DIFF.patch`
- `READINESS_STATIC_VERIFICATION.json` and command log

Historical reports below are preserved original evidence, not fresh attestations
of the changed files. Use the current source hash manifest for this revision.
The full original Evidence, Rev3 and execution-readiness handoff are preserved
under `inputs/readiness-*-original.zip`.

## Review entry points

1. `inputs/01_CODEX_IMPLEMENTATION_PROMPT.md` — complete work contract.
2. `R3_T05_OPTION_AR_IMPLEMENTATION_REPORT.md` and `R3_REMAINING_BLOCKERS.md`.
3. Authentication/grant, initialize/anchor and renderer lifecycle reports.
4. `src/replay/`, modified existing adapters/GateOwner and
   `tests/option-ar.test.mjs` (SOURCE ONLY, not executed).
5. `R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json`, source diff, source manifests,
   `R3_TRACEABILITY.json` and preserved 234 command bindings.
6. `R3_STATIC_VERIFICATION.json`, `R3_T05_STATIC_VERIFICATION.json` and checksums.

Original Rev3, R2 and complete handoff ZIPs are retained byte-for-byte in
`inputs/option-ar-*-original.zip`. Historic reports elsewhere retain their
original R2 statements; current Option A-R status is in the T05 reports above.
Rev5, R3 Plan, original Oracle IDs and launcher are unchanged.

## Static checks only

For this revision, use the non-executing current checker:

```sh
node preparation/verify-readiness.mjs "$REPO" "$ORIGINAL_EXTRACTION"
```

The historical commands below describe prior revisions. They check historical
frozen source hashes and must not be used to claim this revision passed them.

Using the already installed repository toolchain, run from that repository and
set `R3_PACKAGE` to this extracted directory. The scripts parse/check source and
hashes and never import the experimental modules:

```sh
node "$R3_PACKAGE/preparation/verify-revision.mjs" "$PWD" revised
node "$R3_PACKAGE/preparation/verify-r1-001.mjs" "$PWD" revised
node "$R3_PACKAGE/preparation/verify-integration.mjs" "$PWD"
node "$R3_PACKAGE/preparation/verify-option-ar.mjs" "$PWD"
```

No experiment launcher command is authorized. Do not run test source, SDK HTTP,
Native, fault, permission or crash scenarios under this handoff. The launcher
remains hard-blocked without an environment or CLI approval bypass.

## Evidence boundary and stop

Static success is not an SDK Replay PASS. Actual trust/session/FD/observer and
adversarial fixture bindings are missing. RP-19 has two real Broker calls with
falsifiable assertions, but neither was executed. Other cells require separately
enrolled scenario runners, explicitly listed in the Oracle matrix. No actual
runtime traces are fabricated. Submit for independent implementation review,
then stop before environment provisioning or R3 execution.
