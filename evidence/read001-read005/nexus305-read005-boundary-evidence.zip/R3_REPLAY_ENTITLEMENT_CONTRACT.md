# R3 Replay entitlement contract — unresolved, fail-closed

## Decision and scope

**DESIGN_CLARIFICATION_REQUIRED**. This document records required boundaries and
the missing decisions. It does not create an entitlement issuer, authorize a new
permission system, revise Rev5, or approve an Implementation Plan.

All Replay entry points in this revision reject with
`REPLAY_ENTITLEMENT_UNPROVEN`. A legitimate reconnect with another RequestKey is
not rejected merely for that difference; it is blocked because the authenticated
entitlement contract is undefined. Oracle R1-001-04 remains unresolved.

## Frozen evidence

| Source | Established fact | What it does not establish |
| --- | --- | --- |
| `reference/SECTION4_1_REV5_PROPOSAL.md`, sections 3.2–3.3 | Separate store/release/replay authorization, immutable original auth, Broker-owned final writes, session-bound RequestKey | An issuer, principal, grant scope, validation protocol or expiry policy for reconnect rights |
| SDK `webStandardStreamableHttp.d.ts`, lines 17–36 | EventStore callbacks accept stream/message or cursor/`send`; optional ID-to-stream lookup | Authenticated Request, Session or principal supplied to these callbacks |
| SDK `webStandardStreamableHttp.js`, lines 256–329 | Cursor lookup/conflict checks precede `replayEventsAfter`; returned stream is mapped to a private response | A cursor-holder's independent authorization to read that stream |
| SDK session API and `handleRequest` options | Transport Session support and an upstream auth-info integration surface exist | A Session ID is not automatically a Replay grant; the callback-to-owner-context bridge and rights policy are not defined here |

All referenced SDK/Rev5 sources retain their original hashes in the package.
No runtime API or Session behavior was exercised.

## Identities and provenance

Fresh `r3_bound_events_v2` rows bind generated Event ID and monotonic SQLite
sequence to Stream, Session, original RequestKey, transport instance, connection
incarnation, original Authority tuple/auth, Terminal attribute, original SDK JSON
wire text, payload digest and identity digest. State is separate from immutable
identity. A hash is an integrity binding, not an authentication grant or an
independent provider/source receipt.

R1 `r3_events` rows lack these bindings and are quarantined. No migration infers
Session or provenance from the reconnect request. A real future migration would
require independent evidence and separate authorization.

Owner `eventContext(message, streamId)` must resolve a previously enrolled request
and negotiated Session/Stream, not copy message fields or untrusted headers as
proof. That authenticated SDK-to-owner mapping is **UNENROLLED**. Missing context
blocks storage. No stateless/default Session is invented.

Current publication identity is separately supplied by the Owner. Stored auth is
projected to exactly Epoch/Generation/Pair/Publication Revision; it cannot replace
the current RequestKey, retrieval verdict, bytes digest, mode or write permit.

## Normal new publication

For every stored event, Terminal or otherwise:

1. Load the original row from the bound ledger and verify identity/payload hashes.
2. Compare the complete frame with the fixed SDK's saved wire representation and
   original Event ID. Unknown format, substituted payload/ID or partial frame denies.
3. Require original RequestKey == current RequestKey, matching Session, Stream,
   transport instance and connection incarnation, and unchanged original tuple.
4. Require current Authority and current request-owned retrieval verification.
   Original event eligibility is checked separately; stored `true` cannot promote
   current `false`. REVOKED rows never become RELEASED.
5. Mint an owner-local, ledger-specific opaque event ticket. Binding changes no
   release/claim state. Validate every frame in the complete private plan before
   any release; then release under the Authority connection's SQLite transaction.
6. Refuse an already claimed RequestKey before release. Retain R1 Owner/SQLite
   preclaim checks and unique terminal INSERT. Release is not a write permission.
7. Recheck the entire bound stored plan before each header/frame/end permit; then
   run the unchanged synchronous final Authority check and sink write with no
   intervening await/observer callback/ledger I/O. C0 can deny after release/header.

The same-request source path is conditional on genuine Owner context and exact
SDK conversion. No successful SDK/Session/OS binding or dynamic PASS is claimed.
Unbound SSE frames, raw stored auth and SSE body/continuation relabeling fail-closed.
Plain JSON/stdout source paths retain the existing R1 gates.

## Replay/reconnect

Genuine cursor diagnostic validation distinguishes unknown IDs, wrong Stream/
Session and inconsistent sequence from real same-scope ledger identities. It
returns no event/stream to a requester: even a valid cursor ends in
`REPLAY_ENTITLEMENT_UNPROVEN`.

`getStreamIdForEventId`, `replayEventsAfter`, the inherited PrivateEventStore
callbacks, explicit Web replay and cursor-bearing Web/Node capture requests are
closed before any private replay `send`, release, claim or external write. No
boolean/Fixture/header/Event ID can enable an exception. A ticket issued for NEW
publication cannot be reinterpreted as Replay rights.

The following decisions require the design/authorization owner:

- Which authenticated subject owns a Session/Stream and the original events?
- Which trusted component issues and verifies reconnect rights, and against what
  root of trust and independently validated evidence?
- How do transport/request callbacks bind a particular reconnect to that subject
  without concurrent SDK callbacks borrowing another request's context?
- What exact event/sequence range, Session/Stream, lifecycle and revocation state
  are covered, and when does the grant expire or get withdrawn?
- How will current entitlement be synchronously rechecked before every permit,
  including after a prior RELEASED state or accepted header?

These questions are deliberately not answered with a fabricated validator.
Terminal replay remains forbidden: no existing terminal is re-claimed or resent
under an old or reconnect key. An approved future non-terminal Replay contract
must additionally preserve original provenance, permanent C0/F1 closure, current
compatible cutover checks and one-use publication permits.

## Evidence boundary

The 15 new Oracle specifications state expected release/claim/write counts,
independent evidence and decision conditions. Their source inspector never awards
R3 PASS; it detects counterexamples or records BLOCKED/INCONCLUSIVE/NOT_EXECUTED.
Authenticated binding, exact SDK frame reachability, durable restart filtering,
entitlement withdrawal and positive reconnect behavior remain unproved.
