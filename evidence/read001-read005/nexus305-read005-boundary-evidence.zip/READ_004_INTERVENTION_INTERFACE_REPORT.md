# READ-004 Scenario と独立観測の接続

判定案: `PARTIALLY_INTEGRATED`。実 Venue は未登録で、全実験は `NOT_EXECUTED` です。

## 61セルの具体的なソース登録

`intervention-plans.mjs` に全 Scenario 名の介入 Action、Marker、Operation を定義しました。
`intervention-runner.mjs#executeIntervention` は Antecedent → Hook 登録 → 個別 Control → 実操作 → Hook 解放を接続します。
同じ介入が同じ意味になる Scenario のみ Action 定義を共有します。Cell Identity は caseId と scenario の組です。
Header 後 C0、write(false)、Disconnect は Marker index=1 に指定し、Header より前の介入と混同しません。

RECONNECT は既存の Genuine ReplayBroker を呼びます。
INITIALIZE は既存の `drivers.replay.initialize` を呼びます。
RP-19 は同じ Main Session／Stream／Grant Version の2回の nonempty Replay と、異なる private renderer を検証します。
いずれの経路も今回実行していません。

同時実行、Restart、直接 FD 攻撃などは `intervention.executeVenueOperation` に残ります。
これは明示的な未実装 Capability であり、実 Hook を作成済みとは扱いません。
`connectHooks` は固定コードの Barrier に実 Observer を接続したことの独立 Artifact を必要とします。
その実 Callback wiring の Provider Body は未接続です。

## 実 Provider の不足

- `establishAntecedent`: Current IdP、同じ Main Object、ACTIVE／Grant／Stream／Event の実整合性。
- `applyControl`: セル固有の失効、変異、C0／F1、Close／Abort／Partial Write 介入。
- `connectHooks/disconnectHooks`: SDK Callback／send Completion、close／EOF、Node P、DB／OS の観測点。
- `executeVenueOperation`: Concurrent lease、Restart／Crash、直接 FD access の実操作。個々の不足 Action は Matrix に記録しました。
- `verifyControlSync`: Run／Cell／Action の独立 Raw Artifact の検証。

原本234 Binding の storage／transport group は既存 Source Entry に対応付け、ID／variant／original oracle を保持しました。
各 branch の実 ctx Body、Native LanceDB prune／retention、FD／Tid、WAL／fsync、CAS fault、paired retrieval は未接続です。
そのため234/234の実 Runner 完成は主張しません。T06／T07 は SDK_API_BLOCKED、他は SOURCE_PARTIAL です。

## Raw Evidence と Oracle

Barrier reached は Run Identity、独立 Observer、Origin、実 Byte Artifact の SHA-256 と検証 proof がある場合だけ返します。
Collector は AUTH／SDK／NODE／OS／DB／AUTHORITY／BARRIER の独立 Raw Artifact を要求します。
正規化された全 Oracle Field の結合、Antecedent、Control、Forbidden Action の観測、Provider Separation を要求します。
欠落データを zero violations に変換しません。Harness Emit／自己申告だけでは PASS にしません。
stale409 と concurrent lease409 は既存 Broker／Oracle の別条件を保持しました。

## Matrix と検証

`READ_004_SCENARIO_RUNNER_MATRIX.json` に61 Cell と234 Binding を列挙します。
公式 `R3_FROZEN_COMMAND_MANIFEST.json` と原本 Oracle／Traceability はバイト不変です。
全 Cell の actual は null、Execution は NOT_EXECUTED、公式 Binding は BLOCKED です。
静的検証は Source Registration／Syntax／AST／ID 比較に限定しています。成功 Receipt や実測 Trace はありません。
