# R3 environment provisioning report

## Disposition

**PARTIALLY_BOUND_ENVIRONMENT_BLOCKED**. A real dedicated experiment venue has
not been provisioned. This package advances actual source and source/argv
bindings; it does not claim environment readiness or a Native/Transport PASS.

The fixed repository HEAD is `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`.
The input ZIP hash equals the required
`8e2205860789b99bb083f384022ea4bbe1d9d2a7e4ab522ccf7ffab7a017fbc1`.
All 23 outer manifest entries match. Nested Execution Package manifests and R2's
413 manifest entries also match. Revision 5's ZIP has no internal SHA256SUMS;
its enclosing manifest verifies the opaque ZIP. This absence is not claimed as
an internal manifest verification. CRC checks passed for all nested archives.

## Read-only observations

`R3_PREFLIGHT_READONLY.json` records actual commands, exit codes and observations.
Node is 26.10.0, npm 11.19.1, Linux 7.0.0-34-generic. UID/GID is 1000/1000;
effective capabilities are zero. Membership in sudo/lxd groups is not permission
to escalate or create resources. No escalation was attempted.

The preparation directory is on tmpfs. The host product filesystem is ext4 on
a block device. Host ext4 availability is not approval to use product paths.
Neither a dedicated disk root nor fsync/crash/restart behavior is verified.
tmpfs is excluded from all disk durability and host-stop claims.

Named experiment accounts are absent. strace, bpftrace, setpriv, systemd-run and
prlimit are present; tool presence is not a successful observer attach, namespace
operation, ownership transfer or limit enforcement. ACL inspection tools are
not installed on PATH. No attach, native load, signal, bind, namespace creation
or library initialization occurred.

## Ten required conditions

| ID | Requirement | Classification | Resolution |
| --- | --- | --- | --- |
| 1 | Node >=24 | AVAILABLE_AND_VERIFIED | Freeze experiment executable hash after relocation. |
| 2 | Pinned dependencies | AVAILABLE_NOT_CONFIGURED | Approve R2 lock install in dedicated root; inspect actual native/export hashes. |
| 3 | Independent principals | ADMIN_ACTION_REQUIRED | A01: seven non-login accounts, no supplemental groups. |
| 4 | OS-enforced write restrictions | ADMIN_ACTION_REQUIRED | A02/A03: private mount/path topology and deny backing paths. |
| 5 | Post-seal immutability | ADMIN_ACTION_REQUIRED | A03: Publisher FD withdrawal, owner transfer and RO views. |
| 6 | FD/IPC/parent/shared metadata inspection | ADMIN_ACTION_REQUIRED | A04: scoped observer, ACL inspector, complete inode/FD inventory. |
| 7 | Native I/O progress observer | ADMIN_ACTION_REQUIRED | A04: approved ptrace child or scoped kernel probes with drop accounting. |
| 8 | Persistent filesystem | AVAILABLE_NOT_CONFIGURED | A02: dedicated ext4/xfs disk; no tmpfs. |
| 9 | Final-write exclusivity | AVAILABLE_NOT_CONFIGURED | A05: GateOwner only external pipe/socket, real SDK adapters still unbound. |
| 10 | Resource and communication scope | ADMIN_ACTION_REQUIRED | A06: dedicated VM, cgroup v2, disk quota, loopback-only clients. |

None of the missing conditions is inferred from executable presence or historical
R2 observations. No alternative cloud/Object Store or same-UID fallback is used.

## Preparation venue versus experiment venue

The current host supports source creation and static inspection only. An
administrator must nominate a dedicated existing Linux VM or explicitly approve
its creation, supply host identity/boot ID and enroll its disk-backed root.
The proposed account numbers and root layout in the request are reservation
requests, not asserted existing host resources. Until receipts exist, every
environment-dependent binding stays BLOCKED.

## Stop and withdrawal

No experiment starts from this package. After a future approved start, observer
loss, identity mismatch, unexpected external FD, cap violation or a forbidden
safe-variant transition closes Semantic admission immediately. Preserve causal
traces, database/WAL relationship, receipts and all failure evidence. Unknown
writers or reader FDs cause quarantine, not deletion. Pre-CAS abort affects only
the candidate; post-CAS recovery is finalize-only. Permanent revocation cannot
be cleared during cleanup. Administration removes only enrolled resources after
exporting evidence and checking nonce/device/inode; product state is never used.
