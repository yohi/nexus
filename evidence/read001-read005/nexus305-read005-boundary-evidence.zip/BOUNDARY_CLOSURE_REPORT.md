# READ-005 boundary source integration

Submission: **PARTIALLY_INTEGRATED**. This is source-only evidence for review,
not runtime capability closure, product completion, or a finding disposition.

## Integrated source paths

- Trusted `assembleCaseBoundary` assembles drivers and issues a trusted shell;
  only `issueCase()`'s four-operation facade is an ordinary Case Context.
- Server construction/configuration is internal. Observer enrollment precedes
  connect, Initialize, ACTIVE readback, and opaque owner registration.
- Request handles use a private WeakMap and are claimed by one facade issuance.
  Main handles additionally use an issuance-local WeakSet. A serialized ID is
  not authority; every operation re-enters current admission.
- Case results and errors are explicitly projected. No private plan, stream,
  response writer, raw provider receipt, or arbitrary error cause is returned.
- The Observer's Registry is private. Actual object equality remains internal;
  the owner's final verify/guard/SDK-dispatch sequence remains synchronous.
- Public identity metadata requires independent artifact bytes, SHA-256,
  provenance, context binding, and enrolled `verifyArtifactSync` verification.
  Missing provider/context yields `IDENTITY_EVIDENCE_UNAVAILABLE`.
- Scenario provider runs, outcomes, Registry, barriers, and collector remain
  private. Prepared scenarios expose only an execution closure; RP-19 retains
  two real nonempty Broker calls and revalidates authorization between them.
- Main close stays denied. Replay cleanup does not close the main Transport.

No global Registry API semantics or SDK private state were substituted. The
legacy `assembleDrivers` result remains trusted-only, not safe for case delivery.
The `src/cases.mjs` external orchestration contracts remain unresolved; they are
not reclassified as isolated cases simply to claim closure.

## Static evidence and limits

`BOUNDARY_STATIC_COMMANDS.json` records the four preparation commands. The new
boundary checker passed 23 structural conditions; the existing owner checker
passed 20 conditions, with a documented mapping for the private observer call
and metadata-only `snapshotIdentity` method. Source syntax and import/export
inspection and captured public API probes also completed successfully.

The red baseline is `BOUNDARY_BASELINE_STATIC.json`: the prior candidate fails
14 expected missing-boundary conditions. Stage artifacts record static green
after integration. Static checks can inspect guarded structure and syntax;
they cannot establish behavior, runtime non-reachability, object identity,
actual artifact provenance, or venue isolation.

One fresh-context read-only source review was completed. The sparse-array
projection finding was corrected with an additional static red/green check.
The import-free singleton fixture checker naming limitation is deferred as a
minor item. See `BOUNDARY_FRESH_SOURCE_REVIEW.md`; this does not close a finding.

`BOUNDARY_ORACLE_MATRIX.json` maps the nine design verification classes and five
review-focus items to source-only oracle exports. Every oracle is
**NOT_EXECUTED**, every negative observation **UNKNOWN**. No SDK, harness,
scenario, or oracle module was imported/executed for verification.

## Compatibility and scope

The ordinary main interface is exactly Initialize, route, reconnect, and
snapshot. It consumes opaque request/session handles, not raw targets or SDK
objects. Trusted composition must enroll requests and supply the same synchronous
execution authorizer before assembly and facade issuance.

Main initialization now consumes trusted `mainServerSetup` rather than a
caller-held Server. Scenario consumers now execute the prepared operation and
collect its internally retained outcome rather than read `run.broker` or pass
an arbitrary outcome. These are intentional harness interface changes.

The new identity evidence context must contain the real enrolled run, fixture,
and verifier enrollment reference. Existing providers that cannot produce and
verify identity-specific artifacts remain blocked; no provider is fabricated.
Captured declarations do not include McpServer, so the new construction path
retains `SDK_API_CONTRACT_BLOCKED:MAIN_SERVER_CONSTRUCTION`.

See `BOUNDARY_REMAINING_BLOCKERS.md` for the unresolved acceptance conditions and
`BOUNDARY_EXECUTION_LEDGER.md` for implementation rulings and their costs.

## Delivery chain

The new archive omits nested historical `inputs/` archives. They remain in the
unchanged parent `nexus305-read001-read005-capability-evidence.zip`, SHA-256
`fbdf5cc1a89beda640b041af85731b40e471aa421d9486c9688b967d71bc92bd`.
`BOUNDARY_DELIVERY_INPUTS.json` records the parent linkage. The original
READ-001–004 archive remains unchanged as well.

Historical `READ005_*` reports are retained as prior attestations. New reports,
source hashes, source diff, and archive checksums attest this revision; older
reports are not evidence of this revision's source validity.

## Stop state

READ-005 remains open pending independent adjudication. READ-001's actual
identity proof remains unresolved. READ-002 remains `SDK_API_CONTRACT_BLOCKED`.
READ-003/004 and ENV-001–003 retain their venue/FD/provider evidence gaps.

**Execution Gate=NOT_AUTHORIZED; R3=NOT_EXECUTED; Section4.1=BLOCKED;
R1-001-04=UNRESOLVED; 234 Binding=BLOCKED/NOT_EXECUTED.**
