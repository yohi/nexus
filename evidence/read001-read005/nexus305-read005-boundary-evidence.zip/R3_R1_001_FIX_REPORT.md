# R3 R1-001 fix report — Revision R2

## Final disposition

**DESIGN_CLARIFICATION_REQUIRED**. The known foreign non-Terminal event source
path is revised. A normal same-request source path remains. Genuine reconnect
Replay is deliberately blocked until its authenticated entitlement contract is
defined; R1-001 is not declared resolved or ready-for-review as a complete fix.

Driver Integration remains **PARTIALLY_INTEGRATED**. Verification is
**PASS_STATIC_ONLY**, not dynamic R3 PASS or independent reviewer acceptance.

Input R1 ZIP SHA-256:
`dd8fe5ac588ad9642709c9e3ad311a9eaaf3afc9a7098d3b443a483f95288cbe`.
It is retained byte-for-byte as `inputs/driver-integration-r1-original.zip`.
The full supplied work contract is retained under `inputs/`, with its hash.
Fixed HEAD remains `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`.

## Counterexample and changes

The R1 chain checked RequestKey mismatch only for Terminal events in
`bindStoredFrames`, then `release` checked stored Authority alone. The final Gate
discarded Request identity during four-field projection. Thus E_B from Request B
could be released/published for A under an otherwise matching tuple. This was a
source-permitted path; SDK reachability was not dynamically demonstrated.

| Boundary | R1 source | R2 source |
| --- | --- | --- |
| Durable identity | Stream/auth/message plus ID/sequence | Session/original Request/transport/connection, wire payload and identity digests also bound |
| Binding | Terminal-only RequestKey rejection; immediate release | Every NEW event requires original/current identity match; exact frame and opaque ticket; no state transition |
| Release | Stored Authority only | Whole plan validated before updates; current/original eligibility, durable current tuple/revocations, existing-claim rejection |
| Gate preclaim | Four-field stored tuple match | Independently enrolled ledger ticket/provenance validation before release and claim |
| Each final permit | Current Authority | Stored plan recheck, then unchanged IO-free synchronous Authority check/write |
| Private EventStore | Separate replay loop and incompatible ledger call | Inherits the single DurableSDKEventStore implementation |
| Replay | Cursor-only lookup/send/filter route | Web/Node/SDK/Private callbacks fail-closed; no send or rights minted |

`src/stored-event-binding.mjs` owns identity/payload/NEW authorization checks and
generic, non-disclosing errors. `DurableEventLedger` mints and checks ledger-local
WeakMap tickets. The HTTP driver actually binds stored frame plans to the ledger
enrolled in `assembleDrivers`; missing authenticated context blocks the path.
The venue-await boundary preserves the R1 known-no-claim cutover result before
event binding, and SQLite release rejects a changed tuple before event updates.
Explicit Replay modes are closed even for an empty/header-only plan.

New rows use a fresh additive experiment table. Old R1 rows are not relabeled or
implicitly assigned the current request's Session. Hash checks do not claim that
a writable compromised ledger becomes trusted; OS ownership remains ENV-001.

Unknown/unsupported SDK frame conversion is rejected, not normalized into a
claimed success. All affected Bindings remain BLOCKED pending real independent
context/format/runtime evidence.

## Replay and verification boundary

The [Replay entitlement contract](R3_REPLAY_ENTITLEMENT_CONTRACT.md) records the
Rev5 and hashed SDK evidence. The EventStore callback supplies only cursor/`send`;
SDK Session validation and optional upstream auth-info do not themselves define
which authenticated subject may read stored events. No grant issuer, validator,
scope, expiry or safe callback-to-owner binding is established in Rev5/Harness.

Consequently legitimate different-RequestKey reconnects are blocked as
`REPLAY_ENTITLEMENT_UNPROVEN`, not deemed unauthorized merely because keys differ.
This intentionally leaves R1-001-04 unresolved. Caller booleans, cursor knowledge,
Session header knowledge and matching tuple cannot unlock Replay.

Existing Terminal claims are neither recycled nor re-sent. DRV-002's four-field
projection is byte-identical; current verification is still request-owned. Both
stored/original eligibility and current Authority must hold, so stored `true`
cannot promote a current `false` verdict.

## Oracles and static evidence

- `R3_R1_001_ORACLE_MATRIX.json` specifies exactly R1-001-01 through R1-001-15,
  Given/When/Then, release/claim/write expectations, evidence and decision rules.
  Fixtures are synthetic inputs, not evidence. Oracle execution is NOT_EXECUTED.
- `src/r1-001-oracles.mjs` provides additive counterexample inspection. It cannot
  award acceptance PASS or establish the missing Replay contract.
- `preparation/verify-r1-001.mjs` rejects the original R1 source and checks the
  revised source without importing/evaluating any harness or Oracle module.
- The R1 13 Oracle fixtures, R1 15-item verifier, original A–F/B2 Oracles, launcher,
  Authority, SQLite preclaim adapter, bounded query and projection helper are
  compared byte-for-byte against the retained R1 archive.
- The same R1 15 regression checks run against the current source. Strict API/
  declaration probes and the additional ID-as-ticket negative type probe run
  compile-only. JS adapters are syntax/AST checked, not fully semantically typed.
- Source/type/tooling hashes, source-before/after hashes, all 234 preserved IDs,
  Safe 117/Negative 117, driver entry points and Oracle supplements are updated.
- Evidence ZIP packaging independently rereads CRC, all member/Source/Manifest
  hashes, original archive, frozen Oracles and regression/Binder coverage.

`R3_R1_001_INPUT_VERIFICATION.json`, `R3_R1_001_BASELINE_STATIC.json`,
`R3_R1_001_STATIC_REGRESSION.json`, `R3_R1_001_SOURCE_CHANGES.json`, and
`R3_STATIC_VERIFICATION.json` contain current evidence. Older R1 change/input/
baseline records remain historical; current R1 regression output is refreshed.

## Remaining work and stop state

Resolve the entitlement decisions with the design owner before implementing any
positive Replay path. Authenticate and enroll actual SDK Session/Stream/request
context. Establish positive same-request/reconnect behavior, exact frame
conversion, restart and revocation behavior in a separately authorized venue.
All prior live SSE, source/provider, recovery and scenario gaps remain explicit
under ENV-002/ENV-003, not reassigned to ENV-001.

No Native/MCP communication, fault/signal/crash experiment, Oracle execution,
dependency installation, OS permission change, product source change, GitHub
write or Implementation Plan creation occurred.

Execution Gate **NOT_AUTHORIZED**; R3 **NOT_EXECUTED**; Section 4.1 **BLOCKED**;
234 Bindings **BLOCKED / NOT_EXECUTED**; product implementation **NOT_APPROVED**.
Submit the R2 package and stop. Another ChatGPT performs independent review.
