# Main session and Node/Bridge integration

Status: **PARTIALLY_INTEGRATED**, never a dynamic session success claim.

## Trust chain and target selection

The only source registration entrance is owner composition:
`CapabilityRegistry(root)` then `enroll(name, provider, receipt)`. The root must
independently verify provider enrollment, boot, expiry and revocation. HTTP data
cannot install the root, clock or provider. The registry does not know an IdP
trust store or OS topology by itself; none is supplied in this package.

`IngressBridge.bindWeb` obtains external capture provenance; `fromNode` builds
an exact private Request from raw headers and the enrolled origin/path policy.
AUTH must bind method, URL, Request Identity, issuer/tenant/subject, credential
family/digest/key generation/policy/revocation, trust root, clock and rotation
receipts. Credential values and private keys are not recorded. Context expiry
and downgrade are checked by the real provider on each revalidation.

`targetForSync({request, context})` returns an owner object from the enrollment
domain. An externally supplied target must be that exact object, not a clone.
`resolveOwnerGrant` gets the verified principal, owner envelope and cursor
selector; it must perform durable owner-side lookup. Its receipt binds principal,
request, session and cursor digest. Header grant IDs are not lookup authority.

## Routing and private body

- Singleton Session/Cursor/Protocol/Authorization/Host/Length duplicates are
  rejected before normalization. Hop headers and principal/grant assertions are
  rejected. URL origin/path and protocol version are policy inputs from owner.
- GET/DELETE have no body. POST is bounded JSON, serialized into a private
  Request; stale Content-Length is removed. Real wire/body authenticity remains
  the external capture provider's responsibility.
- Cursor-bearing Node or Web traffic is GET only and goes to Broker before the
  main handler. Node-to-Web conversion is local source, not a target property.
- Disconnect signal propagates into private Request and SDK/render operations.
- Final Node response is held by owner target and the FD boundary, not passed
  to SDK. The raw Node handler is no longer exported from the driver object.

## Initialize and lifecycle

`initializeMainSession` authenticates enrolled ingress, creates the real pinned
main stateful transport and enrolls a real dispatch observer. SDK session-created
callback only stages the owner record. `MainSessionObserver.verifyCompletion`
requires processing and actual SDK send-completion artifacts correlated to the
attempt, transport and result. Private SSE body/result parsing is unchanged.

After complete header/result/end Node P, the original transition is retained:
`STAGED -> VERIFIED -> PUBLISHED -> ACTIVE`. `confirmActive` requires independently
observed durable ACTIVE readback with WAL/fsync/boot evidence. Each active-session
lookup also calls an external lifecycle observer. Token-like nonces already in
the ledger are CAS identity values, not independent durability receipts.

SDK `onsessionclosed`, explicit owner close and failure synchronously deny the
observer before durable invalidation. Missing lifecycle observer, session expiry,
credential revocation, stale boot or unknown readback cannot restore eligibility.
An ordinary HTTP disconnect after ACTIVE must not be reported as main Session
termination; the external observer must distinguish these events.

## Remaining integration work

The generic SDK Web factory's fresh transport is not automatically the object
created by successful initialize. Its normal route is now gated by real owner
session admission, but object reuse/attachment still needs source completion.
Modern server/node v2 completion and Bridge main-session attachment are separate
unimplemented boundaries. Generic initialize requests fail closed and must not
serve as a shortcut around the receipt flow. Public API declarations passing a
compile-only probe do not settle these integration semantics.

FD/Authority and normalized raw evidence provider call shapes are described in
`VENUE_CAPABILITY_REQUEST.md` and the capability/scenario matrices.
