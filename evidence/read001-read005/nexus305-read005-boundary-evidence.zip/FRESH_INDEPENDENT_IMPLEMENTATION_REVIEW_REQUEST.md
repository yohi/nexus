# 新しい独立実装レビュー依頼

対象: Nexus Issue #305 READ-001〜004 の改訂 Harness Source。
提出状態: SDK_API_CONTRACT_BLOCKED。独立レビューは未実施です。

## 読取専用の審査範囲

1. 外部 SHA／Manifest／CRC と内部 SHA256SUMS、固定 SDK／Rev5／Plan を再確認してください。
2. SOURCE_DIFF.patch と SOURCE_CLOSURE_SOURCE_MANIFEST.json から、唯一の最新入力に対する改訂を確認してください。
3. READ-001 の同じ Object／Server、Current Principal／ACTIVE／Boot／Lifecycle／Authority の結合を審査してください。
4. READ-002 の公開 API 制約と反例を確認してください。手動 routing の公開構成余地と固定 T06／T07 Acceptance を区別してください。
5. READ-003 の Writer Inventory と Case Publication の登録境界、未実装 ctx 経路を確認してください。
6. READ-004 の61 Source Mapping、234 Immutable ID、Barrier／Raw hash／Antecedent／Negative observation を確認してください。
7. Source-only Test と静的ログの限界を確認し、Finding ごとに新しい Disposition を独立に決定してください。

## 審査時の固定境界

Source Closure の可否と実 Venue の認定は別です。静的検証は実験 PASS ではありません。
未接続 Source／Provider を完成扱いにしないでください。
この依頼書は実験、GitHub 書込み、SDK／Native／Fault 実行を承認するものではありません。
Execution Gate NOT_AUTHORIZED、R3 NOT_EXECUTED、Section 4.1 BLOCKED、R1-001-04 UNRESOLVED を維持してください。
