# READ-001〜004 Venue Capability Request

現在の提出判定は `SDK_API_CONTRACT_BLOCKED` です。
新しい `ownerContext.verifyMainDispatchSync`、`casePublication`、`privatePipes`、`intervention` と
強化した Initialize／Lifecycle／Final Writer／Barrier／Raw Evidence Receipt の実 Provider は未登録です。
対象、入力、所有主体、観測点、未接続条件は `TRUST_CAPABILITY_AND_VENUE_GAPS.md` と
`READ_004_SCENARIO_RUNNER_MATRIX.json` を参照してください。
実操作の許可は要求一覧にあるだけで、今回付与・使用されていません。
現在は Execution Gate NOT_AUTHORIZED、R3 NOT_EXECUTED です。

## 保存された要求履歴

No capability is enrolled and no execution authorization is requested or granted
by this artifact. The following inputs are needed for a later independent review
and separately approved venue handoff. Do not place secrets in this package.

## Identity and enrollment owner — ENV-001

Supply an independently auditable enrollment root with `verifyEnrollmentSync`,
`currentBootSync` and a monotonic trusted clock. Enrollment receipts must bind the
exact provider instance, capability, owner, issuer, verifier, boot, expiry and
raw artifact. Revoked enrollment must fail immediately at revalidation. Never
accept a client-supplied enrollment receipt or a provider's own success flag.

For ingress, supply `capture({request, externalContext})`,
`verify({request, context})`, `revalidateSync(principal)`. Independently prove
TLS/IdP or mTLS verification, issuer/audience/tenant/subject, peer/proxy trust,
one-time Request Identity, signature/chain, family/expiry/key rotation/revocation
and clock source. Provide at least two genuinely distinct principals/tenants for
parallel and foreign-owner controls. The package contains no private keys,
certificate generation, production token acquisition or TLS configuration.

## Session/SDK and bridge owner — ENV-002

Supply actual pinned SDK source-load receipts, genuine server processing/send
completion instrumentation, exact attempt/request/transport/session/result
correlation, independent final header/result/end P and lifecycle observations.
`initialize` methods are `enrollMainTransport`, `verifyCompletion`,
`verifyFinalInitializeP`, `observeActiveSync`, `observeLifecycleSync`.
They must distinguish SDK close/DELETE/termination from an ordinary HTTP socket
disconnect after ACTIVE. No private SDK-field mutation or synthetic initialize.

Supply `ownerContext.targetForSync` and `resolveOwnerGrant` from the same owner
domain as ingress, using durable lookup rather than Header Grant IDs. Required
selection fields include requestIdentity, principalKey, sessionId, cursorDigest,
stream/grant version/event IDs and independently verified rawArtifactRef.
Complete the outstanding main-stateful-object reuse and modern v2/Bridge
initialize attachment source before describing these paths as integrated.

## GateOwner/OS/authority and durability owner — ENV-001/003

Provide isolated single Final Writer and independently observed FD/topology
ownership. No actual UID/PID/FD/inode values are prescribed or changed here.
`finalWriter` supplies `verifyActor`, `proveFinalWriteOwnership`,
`inspectFinalSync`, `observeWriteSync`. FD receipt must bind actual sink identity,
boot, exclusive gateowner, topology/raw evidence and expiry. Synchronous check
must bind confirmed F1/current authority/C0 and same-owner gate order. Observer
must distinguish writeHead, write(true/false), complete frame, end, partial,
disconnect and UNKNOWN; accepted Node write is not peer ACK.

`authority` methods receive `{args}` preserving the original positional call
arguments: verifySync, authorityReceiptSync, ownerReceiptSync, finalOwnershipSync,
maximumGrantExpirySync, liveWriterFencedSync and tombstoneReceiptSync. Prove
store/release/retrieval authority independently and never promote Stored Auth.

`durability.verifyCommitReadbackSync({kind,id,result})` must return actual
commitToken correlation, independent readback, WAL/fsync and boot artifacts.
`verifyActiveReadbackSync({row,attempt})` must bind activeCommitToken, real ACTIVE
status and genuine durable readback. Random tokens are not fsync receipts.
Provide live-stream drain/fence proof before admitting a replay lease. Unknown
or quarantined resources cannot be auto-reopened.

## Scenario and evidence owners

Provide scenario prepare/execute providers for the exact 61 catalog cells. Bind
real actors, setup antecedents and each named intervention; foreign-session,
wrong-stream, same-stream conflicts, cancel-only, close failure/timeout, late
callbacks, C0 and restart are distinct controls. Register Barrier receipt and
reach observations for each run/cell/marker. Harness `emit` is not an independent
observer. Sources can describe a fault without executing it in this handoff.

`rawEvidence.collectIndependentRaw` supplies byte artifacts and normalized fields.
`verifyArtifactSync` must independently validate bytes/hash/run/source correlation
and every normalized field against those artifacts. Require AUTH, SDK, NODE,
OS, DB, AUTHORITY and BARRIER roles, at least four distinct independent observer
identities, no self-asserted/default zero counters. An unavailable negative
observation is BLOCKED or INCONCLUSIVE, never PASS.

RP-19 requires the same genuine ACTIVE Session/logical Stream/Grant version/main
transport, two sequential nonempty Broker replays, actual callbacks, two close
successes, two EOFs, final frames/end P and different renderer instances. Stale
second SDK409 is FAIL. RP-19A/B inputs are specified separately in the catalog.

Any future dynamic authorization must come from the independent execution owner
with exact scope/boot/expiry/approval artifact. Capability enrollment and source
readiness do not constitute Execution Gate approval. The current launcher stays
NOT_AUTHORIZED. Human OS provisioning, dependencies, keys and experiment execution
remain separate activities, not commands provided by this request.
