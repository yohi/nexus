# R3 publication gate implementation report

## Current Revision R2 stored-event boundary

Normal stored frames require an enrolled ledger and owner-local event ticket.
The complete copied plan is checked before release/claim; every final permit
rechecks provenance/current request eligibility before the unchanged synchronous
Authority check/write. Existing RequestKey claims cannot trigger another release.
SSE frames without provenance, stored metadata on other write kinds and SSE body/
continuation relabeling are rejected. Replay is fail-closed, not a RequestKey
equality exception. See [R1-001 fix report](R3_R1_001_FIX_REPORT.md).

## Revision R1 admission and provenance fixes

`prepareTerminal` checks an existing claim, then current Owner Authority, before
durable claim admission. The SQLite transaction separately checks current tuple,
revocations and claim uniqueness. Only a proven preclaim denial is retryable;
claim/write uncertainty and postclaim cutover are not. Stored frame auth is
projected to four identity fields and never overwrites request retrieval
verification. See the [R1 report](R3_DRIVER_INTEGRATION_REVISION_R1_REPORT.md).

## Claim and permit separation

`GateOwner.prepareTerminal` makes a durable unique RequestKey claim. Its token is
registered in a private WeakMap; a caller-created or copied receipt is invalid.
`openPublication` copies a finite byte plan and binds its digest and authority tuple
to that claim. It does not reuse a consumed terminal receipt for each write.

`nextPermit` creates a distinct opaque token for the next Header, Body, End,
SSE Frame or continuation. A token can be consumed once, only on its channel,
at its expected sequence. The first claim moves into channel ownership. Completion
never creates a second claim. A fresh process cannot recreate that claim because
the durable terminal table still owns the RequestKey.

The typed declarations distinguish TerminalClaim and PublicationPermit. They
are compile checked, while JS state transitions are AST inspected. This is not
a full semantic TypeScript proof of the JS implementation.

## C0 and final admission

For every permit, current Epoch/Generation/physical Pair/publication Revision and
retrieval-pair verification are checked by the same Authority object that owns C0
and CUTOVER_HOLD. No await or observer callback occurs between that check and the
synchronous final sink call. The actual Node response/stdout capability is captured
by owner-only closures, never passed to SDK handlers or candidate workers.

The B2 SQLite transaction and compatible CAS use that owner. Pending CAS sets
HOLD before asynchronous barrier waiting; durable confirmed readback updates the
pointer before reopening compatible publication. C0 closure and unresolved F1
remain monotone. A new epoch cannot rescue a permanently closed generation.

## Partial publication matrix

| Prefix/outcome | Result |
| --- | --- |
| C0 before first permit | Claim retained; no old final write; no resend |
| Header P before C0, Body attempt after C0 | Body denied; response destroyed; delivery unknown |
| Body/frame P before C0, later continuation after C0 | Later permit denied; no additional old semantic bytes admitted |
| write returns false | P accepted; bounded drain outside gate; later peer arrival is a separate observation |
| Throw/promise-shaped final write | Unknown delivery; channel closed; no retry |
| Abort/close/drain timeout after partial P | Internal unknown-delivery record and isolation; no guaranteed peer error |
| Compatible replacement before claim | Old result discarded; fresh pinned computation within two attempts |
| Replacement/C0 after claim | No replacement terminal or second claim |

`publishPlan` places injection barriers outside final admission, including the
Header/Body boundary. End is gated too: it cannot flush new old semantic bytes
after C0. Destroy is isolation, not a successful publication of a fallback.

## ENV-003 status

The single-receipt multiwrite defect has concrete finite-response source coverage.
Original HTTP wrappers now consume permits. ENV-003 is **PARTIALLY_INTEGRATED**,
not a dynamic PASS: unbounded live SSE, per-event terminal association in an open
stream, genuine replay/restart scenario context and OS-exclusive capability
ownership still need completion. Existing A-F/B2 acceptance Oracles are unchanged.
