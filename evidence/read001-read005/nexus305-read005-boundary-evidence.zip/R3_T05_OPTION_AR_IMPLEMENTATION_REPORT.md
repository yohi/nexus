# R3-T05 Option A-R implementation report

## Disposition

**PARTIALLY_INTEGRATED**. Concrete isolated harness implementation is supplied;
venue-backed driver and adversarial scenario integration are incomplete. This is
not an independent implementation approval or a runtime feasibility PASS.

Fixed product HEAD: `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`.
Product repository, GitHub, Requirements, Rev5 and R3 Plan are unchanged.
Execution Gate: **NOT_AUTHORIZED**. Experiments: **NOT_EXECUTED**.
R1-001-04: **UNRESOLVED**. Section 4.1: **BLOCKED**.

## Concrete source

| Boundary | Source / entry |
| --- | --- |
| Owner assembly | `src/replay/assembly.mjs:assembleOptionAR`, `src/drivers/integration.mjs:assembleDrivers` |
| Trusted per-request authentication | `src/replay/trusted-ingress.mjs:TrustedIngress` |
| Additive SQLite schema/CAS/readback | `src/replay/schema.mjs`, `src/replay/ledger.mjs:ReplayLedger` |
| Real initialize/private result/P/ACTIVE | `src/replay/initialize-driver.mjs:initializeMainSession`, `src/replay/initialize.mjs:InitializeReceipts` |
| Grant issue/verify/store/release | `src/replay/authorizer.mjs:ReplayAuthorizer` |
| Cursor anchor and successor | `src/replay/lineage.mjs`, `src/replay/event-authorization.mjs` |
| Owner ingress/lease/reconnect | `src/replay/broker.mjs:ReplayBroker.reconnect` |
| Real SDK GET/callback/public close/EOF | `src/replay/renderer.mjs:renderReplay` |
| Final header/frame/end permits | `src/gate-owner.mjs:openReplayPublication,publishPermit` |
| Web/Node/Bridge routing | `src/adapters/sdk-drivers.mjs:route,routeNode,actualBridgeDriver` |
| Executable source-only RP-19 test | `tests/option-ar.test.mjs:testOptionAR` |
| Four-value future evidence classifier | `src/replay/oracle.mjs:classifyReplayEvidence` |

The renderer calls the fixed SDK constructor, `start()`, `handleRequest(GET)` and
public `close()`. Its EventStore implements both genuine callbacks. It never
manufactures a replay response or forwards the final Node response to the SDK.
Immutable wire data is reloaded from the durable event ledger, not trusted from
the grant resolver. Per-invocation closure/IDs isolate both callbacks.

## Preservation

Existing NEW event authorization, four-field stored auth projection, original
at-most-once Terminal claims, current Authority/fence logic, cutover and bounded
retry are retained. Replay uses a separate no-Terminal-claim channel. The main
SDK EventStore callbacks remain denied; only the private Broker facade admits
Replay. The existing launcher is byte-identical and has no new bypass.
234 IDs, original Oracle objects, 117 Safe and 117 Negative variants and all
S01-S06/T01-T09 groups are retained. Source hashes are refreshed and additional
T05 source/oracle mapping is additive.

## Reachability versus proof

The owner assembly is callable with genuine enrolled providers. It is never
called by the blocked launcher. `route` and `routeNode` intercept cursor-bearing
GET before main SDK dispatch. The Node conversion remains injectable and
unregistered. Independent provider/FD/durability receipts are required; unknown
bindings fail closed.

RP-19 contains two actual Broker calls and assertions on both SDK200/nonempty P,
close/EOF, fresh renderer identities, fixed real Session/Stream/Grant and distinct
RequestKeys. Other scenario cells have named tests, barriers and classifier
assertions, but require the independent venue's `prepareRealScenario` and
`executeWithRegisteredBarriers` implementations. These are **not implemented
scenario fixtures**, and this prevents a READY disposition.

## Verification limits

Static checks never import or execute the experimental modules or tests.
`R3_STATIC_VERIFICATION.json` and `R3_T05_STATIC_VERIFICATION.json` contain actual
static outcomes. Full JS semantic typechecking, SQL migration execution, genuine
SDK callbacks, two reconnects, public close/EOF behavior, Node client wire,
powerloss, credential and FD isolation have **not** been tested. No runtime trace
files or measured scenario outcomes are created.

## Stop

Submit immutable Evidence Package and stop. Independent implementation review,
venue provisioning and Execution Gate approval belong to separate owners.
