# READ-005 Capability 修正案と残存境界

提出候補: **DESIGN_CLARIFICATION_REQUIRED**。
Severity: **Major**。Finding の自己 CLOSE は行いません。
Execution Gate: **NOT_AUTHORIZED**。R3: **NOT_EXECUTED**。
Section 4.1: **BLOCKED**。独立実装レビュー: **NOT_PERFORMED**。

## 原因と限定修正

元の `MainSessionOwners.register()` は Transport、Server、Attempt、Session、
無認可 close を含む Handle を返していました。`reference()` と公開 `admit()`
も Binding を返し、`actualSDKWeb()` は Transport を Driver に再公開していました。
`Object.freeze` は Capability の撤去になりません。

| 公開経路 | 今回の対応 |
| --- | --- |
| register の Handle | 空の null-prototype Object。WeakMap の同一性で登録 |
| reference の Binding | 公開メソッドを削除。private `#binding` に限定 |
| admit の Binding、Ticket | private `#admit` に限定。公開 admit は値を返さない |
| Driver.transport | 削除。route、plan、replay、close の限定 API のみ |
| Handle.close | 削除 |
| Driver.close | `MAIN_OWNER_CLOSE_AUTHORITY_UNSPECIFIED` で fail-closed |
| Owner の依存差替え | private fields と frozen instance に変更 |
| clone、spread、JSON、ID、prototype | WeakMap 未登録のため拒否するソース経路 |

通常の Owner Handle と Web Driver の公開戻り値には生 Capability を返す
ソース経路がありません。後続 Dispatch は private Binding を利用します。
この静的主張は全 Composition API の安全性を意味しません。

## 残存する具体的な反例

`assembleDrivers()` は `registry` を返します。`assembleOptionAR()` は
`receipts` を返し、その `observer.registry` も公開されています。
`CapabilityRegistry.entry()` は登録 Provider と methods を返し、`sync()` は
Provider の結果をそのまま返します。現在の `MainSessionObserver.assertActive()`
契約は `observeActiveSync` の結果に実 Transport と Server を要求します。

したがって、普通の Case Context にこの Driver 全体を渡した場合、次の
未実行ソース反例が残ります。

```js
const row = ctx.drivers.replay.receipts.ledger.read('session', sessionId);
const proof = ctx.drivers.registry.sync('initialize', 'observeActiveSync', { row });
proof.transport.handleRequest(request);
```

`entry('initialize').methods.observeActiveSync({ row })` と
`replay.receipts.observer.registry` も代替経路です。また Initialize の呼出元は
入力 `server` を保持できます。Server の公開 send、close、接続 Transport への
参照を通常 Context に渡さないための Owner-side Server 構築契約は未定義です。
この反例は実 SDK 呼出しで実証していません。外部 P 成功も不明です。

全外部経路の生 Capability ゼロという必須条件は **NOT_PROVEN** です。
Composition root の権限配布、独立 Observer の生同一性交換と公開 Receipt の
分離、Server の生成と所有権移管を明確にしないまま、Registry の規範的 API を
変更したり新規の私的 Venue API を発明したりしません。
この拡張部分は `DESIGN_CLARIFICATION_REQUIRED` として提出します。

## 静的証拠と限界

`READ005_STATIC_VERIFICATION.json` は Owner/Web の20構造条件を検査します。
元ソースは14条件が FAIL、修正ソースは20条件が PASS_STATIC_ONLY です。
全 Harness と Test の AST、`node --check`、固定 API の型 Probe を実施しました。
動的 Oracle、SDK、実通信、実験、Native、Fault は実行していません。
Negative observation は **UNKNOWN**、各 Oracle execution は **NOT_EXECUTED**。
全 Harness の意味的 JS 型検査、実 Object Identity、実 Venue の権限分離は
静的検査だけでは証明できません。

`CAPABILITY_ESCAPE_PATH_INVENTORY.json`、`READ005_ORACLE_MATRIX.json`、
`READ005_SOURCE_DIFF.patch` と `READ005_SOURCE_MANIFEST.json` を参照してください。
