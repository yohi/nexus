# SDD ledger — plan: docs/superpowers/plans/2026-10-23-read005-capability-boundary-plan.md

Execution: Native; source-only. Branch: `fix/read005-capability-boundary`.
Baseline HEAD: `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`.

## Pre-flight

- Tasks 2 → 4/5/6: shared data projections; use the plan's exact result and error contracts.
- Tasks 3 → 4: internally constructed Server precedes initialization; no ordinary callback/factory input.
- Tasks 4 → 5: facade snapshot requires independently enrolled identity evidence; unavailable evidence blocks, not fabricated success.
- Tasks 4/5 → 6: request/session identities remain private; scenario raw outcome remains trusted.
- Tasks 1–6 → 7: checkers parse source only, packaging compares against immutable prior candidate.

## Rulings

- Ruling: Keep this ledger in the evidence candidate rather than create `.superpowers/` — global instructions prohibit new agent configuration directories — cost if wrong: skill helper automation is unavailable, so task bookkeeping is explicit.
- Ruling: Use the approved static red/green cycle and unexecuted oracle sources, not runtime TDD or full product tests — the approved handoff forbids harness/test/SDK execution — cost if wrong: runtime correctness remains unproven and must remain a blocker.
- Ruling: Keep the ledger and worktree without commits — no commit authorization exists — cost if wrong: recovery depends on preserved files rather than Git commits.

## Evidence

- Input archive SHA-256 and CRC verified; all 509 internal checksums match.
- All 99 prior source-manifest entries match; new candidate copy is byte-identical.
- Existing source workspace, baseline, prior candidate, and original archives are unchanged.
- Task 1: complete — new AST checker against PREVIOUS exited 1 with 14 expected missing-boundary conditions; frozen-file and 234/61 checks passed. Recorded in `BOUNDARY_BASELINE_STATIC.json`.
- Ruling: Bound projected data nesting to 64 levels — avoid unbounded recursion on result data while preserving the small versioned evidence schema — cost if wrong: unusually deep legitimate data is rejected as CASE_RESULT_UNSAFE.
- Task 2: complete — projection section static checks 10/10 PASS_STATIC_ONLY; source-only tests and ordinary import-free fixture added, not executed.
- Task 3: complete (source integration) — server section static checks 9/9 PASS_STATIC_ONLY. Captured declarations lack McpServer; retain SDK_API_CONTRACT_BLOCKED:MAIN_SERVER_CONSTRUCTION rather than import a live SDK or fabricate declarations.
- Ruling: Do not pass a resolver-produced target snapshot back as a supplied target — IngressBridge compares supplied targets to the provider's original object — cost if wrong: target/request correlation could fail. Internal driver and initialization resolve canonically without a supplied target; trusted publication separately resolves and correlates the same request.
- Ruling: Add trusted `snapshotIdentity` returning only independently verified projected metadata, plus trusted `identityEvidenceContext` carrying the real enrolled run/fixture — the existing code has no safe owner-handle-to-evidence integration — cost if wrong: unavailable or incompatible venue bindings leave identity evidence blocked. No new venue method is invented and no raw getter is exposed.
- Ruling: Preserve the original 20-check suite with a mapped observer verification call and additional metadata-only owner method — private Registry removal changes that call's syntax — cost if wrong: structural checks could miss runtime errors; behavior remains NOT_EXECUTED.
- Task 4: complete (source integration) — facade section 9/9 PASS_STATIC_ONLY; original owner suite 20/20 PASS_STATIC_ONLY. Opaque request claims are bound to one facade issuance; main handles use an issuance-local WeakSet.
- Task 5: complete (source integration) — evidence section 9/9 PASS_STATIC_ONLY; private observer authorization remains synchronous before final dispatch verification. Actual run/fixture/artifact provider not supplied: identity runtime verification remains blocked.
- Task 6: complete (source integration) — all four static preparation commands exit 0; new boundary checks 22/22 and original owner checks 20/20 PASS_STATIC_ONLY. Provider run/outcome are private; RP-19 retains two actual Broker calls with authorization between them. All oracle source remains NOT_EXECUTED.
- Ruling: Package a delta delivery without duplicating nested historical `inputs/` archives — the verified 202 MB parent archive already preserves them — cost if wrong: reviewers need the named parent archive alongside the new evidence, rather than a single self-contained ZIP.
- Ruling: Preserve the worktree and ledger after completion — uncommitted source and evidence are the only authorized recovery record — cost if wrong: the user must later decide retention/cleanup.
- Final review: one fresh-context read-only explore reviewer; model selection unsupported by the dispatch tool. No execution or formal finding adjudication.
- Final: fixed sparse-array Data acceptance — supplementary dense-index check observed static RED before adding the guard; behavioral oracle remains NOT_EXECUTED. See BOUNDARY_SPARSE_RED.json and final suite.
- Final: minor (deferred): import-closure checker is an import-free singleton fixture check, not a general module graph resolver; report scope and real-loader blocker remain explicit.
- Final: Ruling: Retain replay revocation timing as an unresolved runtime acceptance condition — the reviewer declined to certify the interval between a synchronous check and actual internal dispatch — cost if wrong: an unmeasured race could permit an unauthorized action; runtime approval remains blocked pending genuine venue evidence.
- Final: Ruling: Do not infer runtime identity, handle resistance, observer independence, or loader isolation from this review — the reviewer declined to certify missing venue evidence — cost if wrong: source-only closure could be overstated; submission stays PARTIALLY_INTEGRATED.
- Final fix verification: all four preparation commands exit 0; 23 boundary conditions and 20 owner conditions PASS_STATIC_ONLY after the sparse-array guard. No behavioral tests or SDK execution.
- Task 7: source/report preparation complete; final archive CRC/checksum/diff verification and delivery completion are recorded externally in `nexus305-read005-boundary-evidence.zip.verification.json` to keep this archive snapshot immutable.
