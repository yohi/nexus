# Execution readiness source integration report

Submission: **PARTIALLY_INTEGRATED**. Verification: **PASS_STATIC_ONLY**.
Execution Gate: **NOT_AUTHORIZED**. Experiments: **NOT_EXECUTED**.
Independent implementation review: **NOT_PERFORMED**. Experiment evidence: **NONE**.

## Implemented source boundaries

- `src/adapters/capability-registry.mjs`: composition-root enrollment, method
  inventory, independent enrollment verifier, expiry/revocation revalidation,
  monotonic clock and boot checks. No default capability or positive receipt.
- `src/adapters/ingress-bridge.mjs`: external ingress capture and immutable request
  provenance; real authentication provider linkage; Node raw-header conversion,
  duplicate singleton rejection, method/path/protocol/body/disconnect checks;
  owner-only target and grant lookup. Client target methods are never invoked.
- `src/replay/session-observer.mjs`: real SDK processing/send completion, Node
  header/result/end P, ACTIVE readback and lifecycle observer interfaces.
- `src/replay/initialize*.mjs`, `ledger.mjs`, `assembly.mjs`: those boundaries are
  called from the existing initialize flow. Callback remains STAGED only. ACTIVE
  requires external durability confirmation; close/revocation/boot/unknown deny
  before further grants. A nonce is only a CAS correlation token, never fsync proof.
- `src/adapters/final-owner-boundary.mjs`: external FD/topology ownership proof,
  synchronous current C0/F1/authority check and independent Node acceptance trace.
  `write(false)` remains accepted with backpressure, never peer ACK. Unknown
  delivery never becomes successful retry. Missing observation after a write
  becomes UNKNOWN_DELIVERY; already enqueued bytes cannot be undone.
- `src/gate-owner.mjs`, `http-publication.mjs`, `drivers/integration.mjs`: opaque
  final sink enrollment is required. Arbitrary legacy callback writers fail
  closed. GateOwner has no await; replay still creates no terminal claim.
- `src/readiness/`: exact 61-cell descriptor catalog, barrier registration,
  separate-authorization scenario binding and independently hashed raw collection.
  Descriptors have no fabricated IDs, principals, grants, FD or results.
- `tests/readiness-boundaries.test.mjs`: unexecuted test source for missing
  registry, owner-target substitution and enrolled sequential reconnects.

## Explicit source integration deficits

1. Main transport reuse is not complete across the generic `actualSDKWeb`
   factory and `initializeMainSession`. The generic factory still constructs its
   own transport; it must not be represented as the successful initialized main
   object. Owner/session admission now denies unproved mappings. A venue adapter
   must supply real transport identity/lifecycle mapping; further source work is
   needed to unify factory ownership without closing the main session.
2. The modern v2/Bridge normal initialize path is intentionally rejected with
   `OWNER_INITIALIZE_RECEIPTS_ROUTE_REQUIRED`. Its genuine server-side completion
   interface and stateful-session attachment are not implemented here. No v2
   success is inferred from the v1 pinned SDK observer.
3. Case-specific real interventions, SDK independent instrumentation, OS/native
   operations and recovery remain external provider implementations. The catalog
   and runner are concrete contracts, not 61 completed adversarial executors.
4. Legacy `GateOwner.publish` callback case drivers now stop until migrated to
   enrolled sinks. This closes a guard-bypass interface; it does not establish
   those original 234 bindings as executable. Their IDs, variants and oracles
   remain byte-identical, and all are BLOCKED/NOT_EXECUTED.

These source deficits justify PARTIALLY_INTEGRATED rather than claiming full
SOURCE_INTEGRATED_VENUE_BLOCKED readiness. Missing real venue enrollment alone
would not prove these deficits resolved.

## Acceptance accounting

| Acceptance | Source-only assessment |
| --- | --- |
| AR-READ-01 | Dependency graph, registry and target/authority entrances supplied |
| AR-READ-02 | Independent completion/durability/lifecycle checks added; unexecuted |
| AR-READ-03 | Replay routing connected; normal main/v2 attachment still partial |
| AR-READ-04 | Original renderer close/EOF/fresh-instance source byte-identical |
| AR-READ-05 | Exact 61 cells and 234 historical bindings mapped; runners blocked |
| AR-READ-06 | External authentication/FD/durability inputs explicit, no PROVEN claim |
| AR-READ-07 | Launcher original bytes and all denial statuses preserved |
| AR-READ-08 | Static-only logs and hashes supplied; separate review not performed |

## Preservation and verification

`SOURCE_DIFF_SHA256.json` owns current source hashes. Historical manifests and
reports retain their original assertions and hashes; they are not fresh
verification of changed files. The full original Evidence and Rev3 ZIP are
retained byte-for-byte under `inputs/readiness-*-original.zip`. No product,
GitHub, Rev5 or R3 Plan changes. No dependencies installed and no runtime tests.

Static checks: `preparation/verify-readiness.mjs`, using the existing TypeScript
parser and public declaration compile probe, plus `node --check`. These never
import the experimental modules or SDK runtime. See
`READINESS_STATIC_VERIFICATION.json` and `READINESS_STATIC_COMMAND_LOG.json`.
