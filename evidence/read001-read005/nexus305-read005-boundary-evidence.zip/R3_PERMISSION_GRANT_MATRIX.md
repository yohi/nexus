# R3 permission grant matrix

Every grant is requested only. Administrator readiness, real target enrollment
and explicit user experiment authorization are independent requirements.

| Permission | Administrator action | Ordinary actor scope | Current grant |
| --- | --- | --- | --- |
| PERM-UID | A01 distinct accounts and launcher | No setuid/setgid privileges | NOT_GRANTED |
| PERM-SEAL | A03 protected topology and scoped broker | No mount/chown to Writer/Publisher | NOT_GRANTED |
| PERM-OBSERVE | A04 target-scoped observer | Read-only enrolled processes | NOT_GRANTED |
| PERM-SIGNAL | A06 pidfd/starttime supervisor | Only enrolled experiment target | NOT_GRANTED |
| PERM-FAULT | Named barrier/transaction/ACK/crash points | Approved variant and root only | NOT_GRANTED |
| PERM-DEPS | A02 exact R2 install | Dedicated deps only | NOT_GRANTED |
| PERM-NET | A05 private IPC and loopback peers | No external egress at runtime | NOT_GRANTED |
| PERM-GC | A03/A06 receipt-scoped deletion | Retired allowlisted pair, no pins/writers | NOT_GRANTED |
| PERM-LIMIT | A06 cgroup/quota | Enforced aggregate unit | NOT_GRANTED |

## Separation of authority

Writer: candidate RW only. Publisher: private import RW, Candidate RO after
quiescence, no post-seal RW. Seal: narrowly scoped ownership/publication broker.
Reader: published RO with durable pin. GC: one delete-intent capability, never
Active/Prepared/pinned/live-writer roots. GateOwner: authority SQLite and sole
final write. Observer: enrolled process/FD/kernel observations and evidence output.

Actual UID/GID, mounts, service units, FD/socket identity and IPC endpoints remain
null in command bindings. Proposed UID/GID 62001 through 62007 are explicitly
reservation requests. No principal, permission or venue is fabricated.
