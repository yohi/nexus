# Authentication and grant binding report

`TrustedIngress` accepts verifier output, constructs a principal digest from
issuer/tenant/subject/realm/assurance and retains opaque object receipts in a
private WeakMap. Client principal/grant headers are not authentication. No bearer
credential is persisted. Providers must return credential digests, key generation,
family, revocation version, policy, expiry and independent raw references.
Clock rollback denies, and synchronous credential revalidation precedes every
final permit. No real provider is currently enrolled: **VENUE_TRUST_BINDING_REQUIRED**.

`ReplayLedger` installs only additive isolated tables, using the existing
Authority store's synchronous transaction implementation. Indexed columns and
complete JSON contracts are cross-checked on readback. Session transitions use
version plus full-record CAS. Grants, revocations, anchor bindings, invocations,
renderer lifecycles, frame decisions, lineage, stream owners and leases are
durable records. The schema is source-checked, not executed in this session.

Grant issuance requires ACTIVE receipts, authenticated owner, current Authority,
bounded expiry, physical stream, range and immutable digest allowlist. Normal
grants require the original session; anchor grants require explicit lineage.
Grant IDs are owner-side lookup keys. Each GET revalidates credential, session,
grant/version/expiry/revocations, cursor/anchor, original Event and current Pair.
The resolver's payload/sequence copies are discarded and real rows reloaded.

`enrollStream` and `enrollEvent` require independent SDK-to-owner receipts.
`storeAdmission` permits STAGED priming only with the matching init nonce; it does
not issue stream ownership or grant. `releaseAdmission` requires ACTIVE and
fresh independent verification. Priming before ACTIVE stays PRIVATE and must be
enrolled after successful initialization. Legacy R1 event rows are not migrated.

Grant revocation closes owner-local eligibility before durable commit. C0/F1
remain the original Authority's same-process closure/fence; compatible cutover
denies old P without reclassifying it as permanent C0. Final GateOwner performs
fresh synchronous verification and then its original Authority/write gate.
No await is added to GateOwner. External authoritative SQLite writers or delayed
IPC revocation decisions are unsupported. Ordering/ACL/trusted boot/single-writer
ownership remain **AUTHORITY_BINDING_BLOCKED** until independently demonstrated.

Publication receipts use unique invocation/permit numbers; an unknown P or
receipt commit error consumes the attempt and never retries it. Failure closes
the Grant and quarantines the lease. Resource recovery/reopening requires an
additional owner proof; no automatic safety inference is supplied.
