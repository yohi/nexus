# Private renderer lifecycle report

`renderReplay` creates a fresh fixed-SDK private stateless transport for each
GET. The main stateful transport is absent from its closure. One immutable plan
is used by `getStreamIdForEventId` and `replayEventsAfter`; cursor, stream,
invocation/version and deadline are revalidated at callback entry and before
each awaited private send. Lookup/replay are one-shot; late callbacks are sealed.
Only finite, preapproved nonTerminal progress rows are sent.

Success order in source:

1. Auth/ACTIVE/Grant/current authority readback and logical lease.
2. Fresh renderer, public start, exact-cursor private GET.
3. Both SDK callbacks, awaited sends, callback settlement, SDK200 response.
4. Public close on that private instance only.
5. Bounded body read to actual EOF and exact frame count/bytes/ID validation.
6. Renderer discarded, then external header/frame/end through GateOwner.
7. Durable one-attempt P decisions, final end, lease seal.

`bufferPrivateResponse` returns only after `reader.read().done=true`; the caller
records that completion, not an inferred timeout. Cancellation alone is never a
mapping cleanup receipt. `closeSSEStream(GET requestId)` and SDK private fields
are not used. The frozen SDK source and declarations have the required hashes.
Fixed source lines 256-324 and 630-639 justify the API sequence, not runtime PASS.

Error/timeout/cancel/Abort/close failure fences new P, attempts bounded private
close, quarantines the lease and revokes the Grant. Failed cleanup never reopens
an old invocation. If the SDK call times out and settles late, sealed callbacks
deny; resource cleanup is still **INCONCLUSIVE**, not declared successful.

Sequential success discards R1 and seals the logical lease before R2 constructs
fresh SDK mapping state. The real session and physical stream remain unchanged.
Concurrent same-stream requests conflict at the Broker lease, whereas R2 after
successful cleanup is allowed by source. This is falsifiable by RP-19, not
experimentally established. Different streams have separate closure/leases.

Raw hooks record SDK constructor/start/GET/callback/send/close/EOF/discard stages,
body digest/count, lease versions and final P types. Trusted independent raw
observer enrollment and client wire capture remain missing. All runtime actual
traces are absent by design because experiments were not authorized.
