# R3 evidence schema and preparation records

The accepted original contract is byte-preserved in
`reference/R3_EVIDENCE_SCHEMA.md`. Its event/result/causal/durable requirements
remain normative; this document adds preparation and machine-schema bindings.
No runtime trace or R3-RESULTS.json is produced during preparation.

## Machine schemas

`schemas/command-manifest.schema.json`, `schemas/source-manifest.schema.json`,
`schemas/preflight.schema.json`, `schemas/gate.schema.json` validate preparation
documents. Existing installed Ajv validates Draft-07 schemas without new installs.
`schemas/event.schema.json` specifies runtime common identity/correlation fields;
it is compiled statically only, since no real runtime events exist yet.

Original 234 Binding IDs and original Oracle text must match the input archive.
Preparation must distinguish sourceBindingStatus from environment/authorization
status. Null OS bindings are explicit unresolved resources, never invented grants.
The proposed argv names a real launcher that currently refuses execution.

## Runtime observation requirements

An event binds PID+starttime+boot ID, actual UID/GID/groups/capabilities, actor
sequence, GateOwner sequence or null, causal parents, operation/request/attempt,
epoch/generation/pair, revisions and raw observer artifacts. Timestamps are
diagnostic only. Cross-process causality requires barriers/IPC/kernel evidence.

IDENTITY_RECOGNIZED and C0 share the synchronous owner decision. CAS_BEGIN is
not commit. B2 requires begin -> C0 -> final commit attempt causality. F1 outcome
does not reopen the closed epoch. Five-way readback reconciles pointer, revision,
journal, receipt and revocation in one consistent transaction snapshot, with
boot/pin/delete/terminal ledgers retained.

P is actual final Node queue/FD acceptance, not private SDK framing or send
intent. `write(false)` is already accepted. Header-only acceptance does not permit
old body continuation after C0. A durable claim is not P; claim-after-crash
cannot create a new terminal or assert delivery. Event replay must genuinely
complete with valid cursor; AbortError remains INCONCLUSIVE.

Native in-flight proof requires actual enter/delivery/exit, TID/FD inode mapping
and observer loss accounting. Quiescence is separately proven across descendant
writers, writable FDs, dirfds, IPC and future capabilities. Source expected ledger
must be frozen before observed vector readback; independent provider receipts
are joined to it, not guessed from count/dimension.

## Classification

FAIL dominates real forbidden transitions. Missing prerequisites are BLOCKED;
attempted but unobservable branches are INCONCLUSIVE. No attempted experiment is
NOT_EXECUTED. PASS requires all mandatory reachable branches and independent
semantic evidence; filenames, schemas or source syntax alone cannot award PASS.
Proven unreachable crash cells are retained with proof, not counted as samples.
Negative controls and independent models never confer safe/product PASS.

## Hash closure

SHA256SUMS covers all packaged files except itself, sorted by relative path.
The external sidecar hashes ZIP and SHA256SUMS. Verify CRC, exact member set and
every member byte digest after creating the ZIP. Original archives stay opaque
and byte-identical; historical embedded machine paths are not rewritten.
