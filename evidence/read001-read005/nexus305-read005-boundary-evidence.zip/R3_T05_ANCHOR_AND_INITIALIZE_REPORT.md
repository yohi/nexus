# Anchor and initialize report

## DES-001

`enrollAnchor` binds durable old origin RequestKey/Session/Stream/Epoch/Generation/
Pair/Revision/sequence/digest to an independently verified permanent
ORIGIN_EPOCH_SUPERSEDED tombstone. Successor attachment compares principal,
tenant and credential family and requires explicit migration and monotonic
sequence receipts. Grant plus anchor binding are committed in one transaction.
Lookup and replay revalidate the same anchor, current G2 version, successor
ACTIVE receipt, lineage/range and unchanged original physical stream.

Old REVOKED rows are metadata-only; the event plan starts strictly after their
sequence. ANCHOR_ONLY has an empty plan and ceiling equal to anchor sequence.
ANCHOR_WITH_NEW_EVENTS is source-supported only where actual same-stream,
new-Epoch/original-K2 and monotonic sequence proofs exist. Such provenance is
not synthesized and this optional branch remains venue-blocked. Compromise or
unknown tombstone reason/authority denies. Unreceived cursors are not labeled
client-observed.

## DES-002

`initializeMainSession` uses a real stateful SDK initialize POST with SSE mode.
The callback only creates STAGED. Completion verifies one successful JSON-RPC
result, request ID, session header, capabilities/serverInfo, full private EOF
and trusted actual server-send completion. It commits VERIFIED before Node P.
The GateOwner publishes original priming (if present) and complete result once;
then verified raw P receipts advance PUBLISHED and durable ACTIVE with readback.

The PUBLISHED-to-ACTIVE barrier is explicit. Abort/C0/credential changes/unknown
P suspend or fence before ACTIVE. Grant issuance is impossible in STAGED,
VERIFIED or PUBLISHED. Restart suspends every historical live session; no private
SDK initialized/session state is restored. A fresh POST and explicit successor
CAS are necessary after restart.

## Remaining bindings

Actual server completion and final-P observers, enrolled authenticated transport
context, priming provenance enrollment, main transport lifecycle ownership and
lineage/sequence receipts are injectable contracts, not configured identities.
No independent runtime proof of S-01-S-05 or A-01-A-06 is supplied. These facts
remain blockers, despite concrete source transitions and SQL schema.
