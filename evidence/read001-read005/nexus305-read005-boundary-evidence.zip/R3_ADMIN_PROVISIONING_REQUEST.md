# R3 administrator provisioning request

Status: **REQUESTED, NOT APPROVED, NOT PERFORMED**.

Target: administrator-nominated dedicated Linux VM, referred to as `R3_HOST`.
Actual host identity is unresolved. Do not perform these operations on the current
development host or product paths merely because the user belongs to sudo/lxd.
An existing dedicated VM is preferred; VM/container/cloud creation requires a
separate explicit grant. Supply host identity, boot ID, disk device/inode,
mount namespace and administrator receipt before freezing execution commands.

## A01: accounts and principal enrollment

Required permission: administrator user/group management on `R3_HOST`.
Reserve the following UID=GID values after collision checks; if unavailable,
return actual allocated values and regenerate/review the command manifest.

| Account | Proposed UID/GID | Role |
| --- | --- | --- |
| r3-writer | 62001 | Candidate native worker |
| r3-publisher | 62002 | Private physical copy |
| r3-seal | 62003 | Seal-owned artifacts |
| r3-reader | 62004 | Pinned read-only pair |
| r3-gc | 62005 | Receipt-scoped retired deletion |
| r3-gateowner | 62006 | Coordinator, DB and external final write |
| r3-observer | 62007 | Read-only scoped observation |

Allow: non-login accounts with locked authentication; administrator launch only.
Forbid: sudo, lxd, shared supplemental write groups, login credentials, host root
capabilities for ordinary actors. Security impact: cross-UID boundary becomes
enforceable, but incorrectly shared groups or inherited FDs defeat it.
Read-only verification: `getent passwd`, `getent group`, `/proc/<enrolled-pid>/status`,
UID maps, supplementary groups, executable hashes and service sandbox properties.
Withdrawal: after all enrolled processes/FDs stop, remove only created accounts
and groups; preserve receipt evidence and check no preexisting UID was removed.

## A02: dedicated persistent root and dependency tree

Required permission: dedicated disk allocation/mount/ownership/quota and separately
approved dependency installation. Target: `R3_HOST`, administrator-assigned
`$R3_ROOT` on ext4 or xfs backed by a persistent block disk.

Layout: `package/` read-only source, `deps/` read-only after installation,
`runs/<nonce>/candidate/`, `import/`, `published/`, `authority/`, `ipc/`,
`evidence/`. Realpath, ancestor symlinks, mount/device/inode and owner must be
recorded. Reject `.nexus`, product roots, reused nonce and tmpfs scratch.

Allow: install exactly the unchanged R2 package/lock pair using
`npm ci --ignore-scripts --no-audit --no-fund` in `deps/` only after PERM-DEPS
approval. This command is a request, not performed preparation. Keep registry
egress separate from runtime network policy. The original package.json must be
retrieved from the preserved R2 ZIP alongside its lock; do not invent one.
Pin LanceDB 0.18.2, SDK 1.29.0, server/node 2.0.0 and Arrow 18.1.0.
Forbid: product writes, latest-version substitution, native install scripts,
secret logging and global package changes. Installation/runtime exports/native
binary checks require fresh evidence; historical R2 load success is insufficient.

Security impact: native library load and dependency retrieval run third-party
code; provision without product data or credentials. Verification: mount/profile,
package/lock hashes and JSON dependency metadata read-only; actual native load is
a later explicitly approved executor action. Withdrawal: unmount only enrolled
disk roots after evidence export and proven quiescence; delete only disposable
enrolled directories under a separate cleanup grant.

## A03: mount topology, Seal and mutation capability withdrawal

Required permission: administrator mount-namespace setup and narrowly scoped
ownership transfer (CAP_SYS_ADMIN at setup, CAP_CHOWN in approved Seal broker).
Target: A01 actors and A02 run root. Ordinary runtime actors have no capabilities.

Allow Writer RW candidate only. Publisher gets Candidate RO after proven
quiescence and its private import RW. Reader gets published RO. Published parent,
table registry, data, `_versions`, `_transactions`, indexes, manifests, Catalog,
Coverage and Merkle must share one seal-owned protected topology. Hide writable
backing paths, host roots and alternate mounts from ordinary actors.

Before transfer, terminate/drain the import Publisher through an enrolled
supervisor and independently prove every inherited write FD/dirfd/IPC capability
gone. Ownership/chmod alone does not invalidate a previously opened writable FD.
Seal broker validates nonce and physical ID, moves an independently byte-copied
pair to its own protected parent, fsyncs parent and exposes RO views. It must not
accept arbitrary paths or delegate mounts/chown to Writer/Publisher. Published
parent permission must deny rename/unlink to Publisher and Writer, not merely
deny opening children. GC broker obtains only one durable delete-intent receipt.

Forbid: same-UID fallback, hardlinks, unchecked symlink resolution, retained
Publisher FD, SCM_RIGHTS transfer of external/published mutation FDs, general
privileged write/delete RPC. Security impact: mount/chown brokers are privileged
boundaries; argument validation and process escape must be independently reviewed.
Read-only verification: per-actor mountinfo, path/ACL/owner/inode inventories,
open FD access modes and backing-path visibility. Mutation rejection itself is
an authorized R3-S01 experiment later, not this read-only check.
Withdrawal: close every enrolled FD, revoke broker receipts, unmount only enrolled
views; unknown liveness means keep quarantined roots rather than force-delete.

## A04: Native observer and read-only inspection tools

Required permission: install ACL inspectors if absent; approved cross-UID child
ptrace or administrator-launched scoped BPF observer. Target: enrolled cgroup,
PID+kernel starttime+boot ID, TID, FD inode and operation nonce only.

Allow probes for syscall enter/exit, write/fsync/fdatasync/rename, signal delivery,
native operation mapping and observation drops. Record actual probe source/hash,
ptrace/BPF grants and raw trace references. Reject time-only Native-kill claims.
Forbid: global ptrace_scope/BPF-policy relaxation, unrelated process tracing,
unbounded kernel capture or signal privileges for the observer. Security impact:
observer can expose process memory/paths; use synthetic data and strict target
filtering. Read-only verification: policy files, tool hashes, service grants and
probe target configuration; successful attach/native-inflight correlation is
later approved work. Withdrawal: stop exact observer unit, detach its probes and
remove only grants established for this venue; retain drop/loss evidence.

## A05: final-write and communication topology

Required permission: administrator launcher FD policy and approved loopback test
network. GateOwner alone inherits external stdout or HTTP ServerResponse/socket.
SDK, Bridge and Worker receive private IPC only; no direct external FD or listener.
Target: `$R3_ROOT/runs/<nonce>/ipc/` and assigned private/loopback sockets.

Allow only synthetic dedicated peers. C0 and CAS final decision are GateOwner
operations. F1 runs outside the synchronous gate; private frame/claim preparation
does not authorize a later final write. Restrict IPC to enumerated requests,
not arbitrary filesystem commands. Forbid external endpoints, public bind,
credentials, inherited final FD and worker authoritative C0 assertions.
Security impact: accidental FD inheritance or Node adapter writes can bypass the
gate. Read-only verification: enrolled PID FD tables, socket inode map,
listener ownership and launcher inheritance policy. Withdrawal: close enrolled
listeners/peers and IPC only; retain unknown-delivery terminal claims.

## A06: limits, stop controller and cleanup grants

Required permission: administrator cgroup v2 and disk quota/service management.
Target: dedicated run unit on `R3_HOST`; actual unit ID unresolved.
Request: 4 GiB aggregate memory, one CPU (CPUQuota=100%), 8 GiB fixture disk,
2 GiB trace cap, 12 processes, 300 s/run, 30 s/barrier, 10 s/send isolation,
30 s/request deadline, 2 total search attempts, 8 h/session.

Allow administrator-created MemoryMax/CPUQuota/TasksMax/RuntimeMaxSec and disk
quota, with an evidence monitor that stops at trace/disk limits. Freeze actual
unit properties and exact stop command in a subsequent package. Signal driver
must use pidfd or PID+starttime+nonce and check enrolled descendants/FDs.
Forbid pkill/killall, global mount changes, host reboot/powerloss, OOM testing
outside the unit and recursive unvalidated deletion. Security impact: kill/crash
leaves partial fixtures; preserve WAL and quarantine them. Read-only verification:
`systemctl show` for exact unit and cgroup files, quota profile and stop target
identity. Withdrawal: close admission, capture evidence, stop exact unit, verify
all descendants/FDs gone, then remove only created unit/quota/network resources
under explicit cleanup permission. No experiment or cleanup grant is yet issued.
