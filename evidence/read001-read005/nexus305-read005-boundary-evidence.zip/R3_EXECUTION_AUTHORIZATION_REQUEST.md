# R3 execution authorization request

**HOLD: NOT_AUTHORIZED**. This package is a partial source/environment handoff,
not a request to start an experiment immediately. Final state:
PARTIALLY_BOUND_ENVIRONMENT_BLOCKED.

## Required next receipts

1. Administrator names `R3_HOST`, approves A01-A06 and supplies real UID/GID,
   durable root/mount/device/inode, service units, observer rights, FD/socket
   ownership, resource enforcement and exact stop targets.
2. Preparation executor binds the remaining real Native, fixed-HEAD journal/API,
   SDK/v2/Bridge and replay contexts listed per group and per record. Preserve
   all existing contracts and negative-control separation. No product changes.
3. Static review rechecks new source, dependency/export hashes, reachable Case F
   matrix, argv, evidence schemas, manifests and authorization target scope.
4. An independent reviewer reviews the resulting exact ZIP hash and command
   manifest. This package's author does not act as that independent reviewer.
5. User explicitly authorizes the named executor, venue, exact frozen commands,
   fault points, principals, observations, limits and stopping/cleanup scope.

A review acceptance or environment setup is not execution authorization. An
environment variable, manifest approved flag or shell access must not bypass
this boundary. The supplied launcher has no execution approval shortcut.

## Proposed scope for a later request

Original 15 groups and 6 additive cases, including B2, both real stdout and
HTTP-v2 paths for T09, actual pinned libraries, synthetic data and isolated roots.
Controls have distinct roots/peers and expected unsafe behavior; no real product
data or external provider credentials. Signal/crash/GC/recovery grants must be
named explicitly, not inferred from generic preparation permission.

Stop on first safe forbidden transition, target identity mismatch, unexpected
FD/authority owner, observer loss, resource cap or unknown durable authority.
Unknown delivery cannot be retried. Unknown liveness cannot permit deletion.
CAS-before-C0 remains a legitimate prior commit; C0-winning commit attempts deny.
Post-CAS recovery only finalizes, never rewinds old authority.

R3 remains NOT_EXECUTED. Section 4.1 remains BLOCKED. Design Spec overall,
Implementation Plan, product implementation and Bedrock Automatic Mode remain
unapproved. No implementation plan is included.
