# R3 permission and environment matrix

Status: execution NOT_AUTHORIZED; all experiment outcomes NOT_EXECUTED.
This document distinguishes existing read-only observations from requested
capabilities. INPUT_VERIFICATION.md contains the observed baseline.

## Current host versus required venue

| Capability | Observed now | Required before an approved run |
| --- | --- | --- |
| Runtime | Node 26.10.0, npm 11.19.1 | Pin full lockfile, actual native binding/load hashes and adapter version. |
| Principal separation | EUID/EGID 1000; no effective/ambient capabilities | Provision distinct Writer, Publisher, Reader, GC, Seal Actor and GateOwner roles; record UIDs/GIDs/groups/caps/launcher. |
| UID switch / ownership | No effective CAP_SETUID/SETGID/CHOWN | Administrator setup with no runtime administrator bypass for actors. |
| RO mount / namespace | Tools exist, actual ability NOT_VERIFIED | Approved administrator-managed mount profile; backing-path access also denied; no same-UID fallback. |
| ACL inspection/change | getfacl/setfacl not found by PATH probe | Pre-provision inspector/tool or approved installation separately; ACL changes require PERM-SEAL. |
| Native tracing | strace/bpftrace exist; ptrace_scope=1; unprivileged BPF disabled=2 | Approved child trace access or narrowly scoped kernel observer. Verify TID/FD/op and signal causality. No probe attach performed. |
| Signals | Ordinary own-UID child signal rights expected, not tested | Explicit PERM-SIGNAL and pidfd or PID+starttime+nonce check. Cross-UID delivery needs approved launcher/controller rights. |
| Durable storage | Preparation root tmpfs rw,nosuid,nodev | Real durable local filesystem; WAL FULL, file/dir fsync/rename visibility and actual trace. Host power loss remains separate. |
| stdout/HTTP writes | No experiment FD or response exists | GateOwner sole external pipe/socket/ServerResponse owner; SDK/Bridge have private channels only. |
| Resource limits | NOT_VERIFIED | Approve limits in request; record enforcement mechanism and stop monitor; cgroup changes require separate approval. |
| Container venue | No image provisioned or inspected | Optional administrator-prepared disposable venue; image digest, host FS, user mapping, caps, seccomp, mounts all audited. Container names alone prove no isolation. |

Current-run readiness is BLOCKED for every group: there is no execution
authorization and no frozen R3 protected harness. Storage groups additionally
lack demonstrated principal separation/durable venue. Review preparation can be
READY_FOR_EXECUTION_REVIEW with those explicit blockers; it is not executable.

## Proposed actor access topology

All directories below are relative to $R3_ROOT/run-<nonce>. Published roots
must not share writable inodes with candidate/import. Hardlinks are forbidden.

| Actor | Allowed access | Forbidden access / post-seal check |
| --- | --- | --- |
| Writer | candidate/op-<nonce> RW; private submission IPC | published/import parents and registry; authority DB writes; external stdout/socket; Publisher/GC mutation proxy. |
| Publisher | Candidate RO after quiescence; private import RW | Post-seal published files/parents/registry RW, retained write FD/dirfd or alternate mount path. |
| Seal Actor | Approved transfer/seal operations on enumerated pair | Arbitrary path RPC or capability delegation to Writer/Publisher. |
| Reader | Published RO plus Coordinator-managed durable pin | Native mutations, authority direct writes, Pin bypass, GC. |
| GC Actor | Delete-intent receipt for one allowlisted retired pair | Active/prepared/pinned/live-writer roots; arbitrary delete; reopen authority as owner. |
| GateOwner | Single Coordinator decision, authority transactions and final writes | Grant-after-check asynchronous external writer; old owner reconciliation; gate await blocking C0. |
| Observer | Approved read-only PID/FD/syscall/receipt observation; evidence writes | Product mutation or signals outside authorized injection driver. |

Strip supplementary groups/capabilities and prevent /proc FD leaks, inherited
FDs, SCM_RIGHTS leaks, shared registry paths and unrestricted broker RPC. Seal
tests must attempt mutation from Publisher too. RO bind mounts alone are not
sufficient if the backing path/open FD remains writable. GC capability is
delete-intent scoped; runtime actors cannot hold unrestricted root privileges.

## Per-test readiness and hazardous scope

Common to every row: frozen source/lock/harness/oracle hashes, synthetic fixture,
approved principals, resource caps, root inode/nonce inventory, and results plus
traces under evidence/results/Sxx or Txx. Exact original evidence filenames and
criteria are retained in R3_ORACLE_MATRIX.json. P IDs refer to PERM-* in the
request. All named operations below are proposed, not performed.

| Test / target | Required environment, owner and permission | Dangerous side effect / stop condition | Required evidence |
| --- | --- | --- | --- |
| S01 / actual native pair and every metadata path | UID, SEAL, OBSERVE; distinct Writer/Publisher/Reader/GC; post-seal Actor; ACL/mount/FD inventory | Append/open/rename/unlink/prune/link and IPC bypass attempts only on fixture. Stop safe variant on any published change or owner write capability. | Principals/caps, path/ACL/mount map, retained FD/dirfd/IPC attempts, syscall denial, full hashes and old/fresh reads. |
| S02 / in-flight native Writer and quiescence | S01 topology; OBSERVE, SIGNAL, LIMIT; native TID/FD map; separate TERM/KILL runs | Crash can leave partial candidate and descendant writes. Stop/quarantine if any mutation authority remains; never seal merely because parent exited. | Native enter/signal-delivery/exit causal proof; full process tree, open write FD/IPC revocation, separate in-flight and quiescence results. |
| S03 / independent G1/G2 native pair | S01 isolation; UID, SEAL, OBSERVE, GC; durable pin before opening; Reader owns RO handles | G2 optimize/compact/prune and attempted GC. Stop on G1 loss, shared writable inode or mixed generation. | Old and fresh readers/searches, pair hashes, physical independence map, pin ledger and GC deny/release records. |
| S04 / GC native paths and authority DB | S03 native artifacts; GC, FAULT, SIGNAL, OBSERVE; allowed GC identity and SQLite owner | Delete-intent/Pin race, unknown Writer, partial delete and crash. Stop on active/pinned/live-writer deletion or tombstone revival. | Intent transaction, pin/FD liveness, actual unlink path/inode, WAL readback, irreversible revocation after restart. |
| S05 / actual six-phase journal and protected CAS fixture | Durable FS/SQLite; UID, FAULT, SIGNAL, OBSERVE; GateOwner and guarded legacy APIs | Rename/commit/ACK faults and six-phase crashes; C0/CAS in-flight race. Stop on stale activation, split tuple, legacy swap/rollback effects. | Slot/revision receipts, linked merkle phase commit, fsync trace, old recovery denial, owner migration, Cases A/B/C/F readback. |
| S06 / full and incremental provenance | Native pair plus independent expected enumerator/Verifier; FAULT, UID, OBSERVE; local synthetic embedding receipts | Missing/duplicate/extra/swapped vectors, watcher gaps and Unicode/provider mismatch. Stop on invalid activation or Semantic leakage. | Frozen expected ledger, all native persisted rows/vectors including inherited rows, roots/join differences, P1-P7 controls, Exact/Grep independent authorization. |
| T01 / real SDK stdio | NET, OBSERVE, FAULT; GateOwner owns external stdout; SDK owns private pipe | C0 between SDK completion/private queue and write; possible leaked bytes. Stop on old post-C0 accept or SDK direct FD. | OS FD/process inventory, wire byte digest, barrier/C0/write correlation, terminal receipt. |
| T02 / actual pipe backpressure | T01 fixture; NET, FAULT, OBSERVE, LIMIT; dedicated paused peer | write(false), cancel/close, delayed drain and unresolved send. Stop at isolation deadline or duplicate/new stale acceptance. | Node write-return and OS acceptance/peer-byte correlation; P<C0 vs C0<P classification; promise disposition. |
| T03 / SDK JSON to Node response | NET, OBSERVE, FAULT; GateOwner owns ServerResponse/socket | Buffer/header-first closure; partial HTTP body. Stop old new header/body accept, isolate partial response. | writeHead/write/end sequence, actual status/length/body at client, safe replacement authorization before claim. |
| T04 / real SSE private queue | NET, OBSERVE, FAULT; per-event final-write owner | Partial frame/event abort and next-event race. Stop on post-C0 old continuation/new event, preserve delivery unknown. | Per-frame/Event ID accept ranges, raw client bytes, terminal and isolation reason. |
| T05 / future durable EventStore, genuine replay | Durable FS; NET, FAULT, SIGNAL, OBSERVE; private store and GateOwner replay path | Pending store, old release/replay, restart. Stop old event acceptance. AbortError cannot count as safe replay. | Actual cursor and successful reconnect response, durable private/revoked ledger, release deny, restart replay check. |
| T06 / server and node adapter 2.0.0 | NET, FAULT, OBSERVE; legitimate handshake/_meta; sole external response owner | v2 response/write race and partial commit. Stop hidden SDK/adapter write; invalid handshake is not a safe result. | Valid protocol request, adapter/write trace, exclusive socket ownership and external client body. |
| T07 / frozen HEAD Bridge with real v2 output | NET, FAULT, OBSERVE; read-only bridge fixture and synthetic handler | Internal success/private await then C0 before external write. Stop if internal success bypasses broker. | Baseline bridge file hash, actual bridge path/queue trace, v2 Node writes/client body and terminal claims. |
| T08 / RequestKey and compatible cutover | NET, FAULT, OBSERVE; S03/S05 pins and authority; SDK/server as used | Duplicate pending ingress/ID reuse, delayed completion, S43/S44 retry and claim-after-crash. Stop duplicate terminal/semantic-in-Grep. | Stable ingress identity, one claim per key, new incarnation legitimacy, 2-attempt budget/deadline, fresh pair and pin/cutover/P trace. |
| T09 / same-owner C0/F1/CAS/write | UID, NET, FAULT, SIGNAL, OBSERVE; durable SQLite/boot marker and S03 pair; stdout AND HTTP v2 | F1 delay/FAILED/UNKNOWN, all A-F races, worker FD leak and crash. Stop reopened gate, stale activation/P, boot-owner conflict. | GateOwner seq+barrier causal graph, real final FD writes, WAL/fsync+readback tuple, marker/recovery/terminal and Cases A-F artifacts. |

## Alternative environment requirements

The administrator may supply an already provisioned disposable Linux VM or
equivalent host with a durable filesystem and separate accounts. Container use
requires the same host-kernel permission, mapping and FD proof, not less proof.
No container pull/build or namespace attempt was made during preparation.
macOS/Windows profiles are NOT_VERIFIED and receive no support claim.
Object Store B and real host-powerloss are excluded and need separate gates.
