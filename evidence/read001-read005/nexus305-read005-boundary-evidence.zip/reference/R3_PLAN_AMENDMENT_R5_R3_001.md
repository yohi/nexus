# R3 plan amendment: RG-305-R5-R3-001

Status: PROPOSED / NOT_EXECUTED. Execution Gate: NOT_AUTHORIZED.
Section 4.1: BLOCKED. INV-01 through INV-07 are unchanged.

## Scope and precedence

This is an additive experiment-oracle amendment, not an implementation plan.
The four original Rev5 documents remain byte-for-byte unchanged in the input
archive. Their pre-review status statements are historical. The later handoff
decision is ACCEPT_FOR_R3_FEASIBILITY at design-contract level only.

Append the following cases to R3-S05 and R3-T09; retain every original scenario,
including S05 J1-J6 and T09-A through T09-E. Names below do not replace those IDs.
R3-T08-CUTOVER supplies the retry/terminal suboracle for Case E.
The machine-readable amendment IDs are RG-305-R5-R3-001-A through -F.

## Common fixture and observation contract

S42/G42 is initially active at publicationRevision 20, authorityRevision 50,
slotRevision 10. S43/G43 is SEALED, VERIFIED, PREPARED, with the same parent.
Full and incremental candidates compete in separate runs. Use the actual
fixed-HEAD six-phase journal schema and recovery API entry points, not only an
independent substitute schema. Bind authorityOwner and protocolVersion to the
Coordinator authority. GateOwner owns identity recognition, closure and final
stdio/HTTP write. CAS outcome and pointer-cache update use that same authority.

Freeze fixture, oracle, harness, adapter, lockfile and baseline hashes before
execution. Run safe variants and deliberately unsafe negative controls under
different run IDs and roots. Controls send only synthetic payloads to dedicated
test pipes/loopback clients. A control failure is expected evidence, not a safe
variant failure or an R2 fact.

The difficult CAS-in-flight window is mandatory: pause after ACTIVE_CAS_BEGIN
and before the actual commit decision, then let authoritative identity
recognition establish C0. It is insufficient to test only a later CAS call.
The feasibility experiment must prove the final fenced commit cannot succeed
after C0. It must not block identity recognition on SQLite I/O or call the CAS
begin event the commit linearization point. An inability to provide this
serialization is a counterexample or an unresolved observation, not permission
to defer C0 until F1. No new implementation mechanism is prescribed here.

Use a single sequencer with causal edges to database barriers and real write
acceptance. Record IDENTITY_RECOGNIZED, C0_GATE_SYNC, ACTIVE_CAS_BEGIN,
ACTIVE_CAS_COMMIT_OR_UNKNOWN, F1_BEGIN/ACK/FAILED/UNKNOWN,
P_WRITE_ACCEPT_OR_DENY, BOOT_UNCLEAN, RECOVERY_READBACK. Normalize original
event spellings in the evidence contract without discarding raw names.

## Case matrix

| Case / coverage | Injection and required causal order | PASS | FAIL | INCONCLUSIVE | BLOCKED |
| --- | --- | --- | --- | --- | --- |
| A / S05, T09 | Release CAS commit barrier, confirm receipt/readback, then recognize identity and C0. Inject queued old semantic results immediately after C0 and while F1 is pending. CAS_COMMIT < IDENTITY_RECOGNIZED == C0 < P_ATTEMPT. | CAS is classified as a legitimate prior commit; every old-epoch/generation new P after C0 is denied; a now-revoked active pointer grants nothing. | Prior commit is mislabeled stale, or any old P is accepted after C0, or active pointer overrides closure. | Actual CAS commit/C0/P order or final FD ownership is unobservable. | No isolated native pair, real final-write path, approval or durable fixture. |
| B / S05, T09 | B1: C0 before CAS attempt. B2: CAS_BEGIN < C0 < fenced commit attempt, with transaction held at the last commit barrier. F1 may still be pending. | Both stale candidates reject; no active pointer/revision, activation journal phase or success receipt mutation caused by that CAS. | Revoked candidate becomes active after C0, or CAS_BEGIN is treated as success, or C0 waits on DB commit. | Only start/response times are known, final commit predicate is unobserved, or causal barrier cannot place C0 in flight. | Missing authority serialization/injection access or permission. |
| C / S05, T09 | Lose commit acknowledgement after COMMIT; separate pre-commit rollback/connection-loss and crash runs. Establish C0 before readback as a separate branch. CAS_UNKNOWN -> SEMANTIC_DENY -> RECOVERY_READBACK. | Semantic stops until pointer/revision/journal/receipt/revocation agree; committed and not-committed branches classified separately; no old permit revival after C0. | Semantic sent while unknown, receipt invented, journal split, or old permit reopened. | Only one durable outcome exercised, WAL/fsync or readback causal completeness absent. | No isolated ack-loss/connection/crash fixture or durable filesystem. |
| D / T09, S05 | C0 -> F1_BEGIN -> pending, FAILED or UNKNOWN; attempt old P from SDK completion/private queue/worker IPC and stale CAS during each window. Also include successful F1. | Old new P=0 in all branches; FAILED/UNKNOWN keep all new Semantic denied; F1 ACK never reopens old epoch; IPC cannot bypass owner. | Any old P/CAS succeeds after C0 or F1 state reopens C0. | F1 was not actually delayed, signal/queue/write causality missing. | Private-envelope isolation, sink control or permission unavailable. |
| E / T08-CUTOVER, T09, S05 | Pin S42; private query in flight -> CUTOVER_HOLD -> CAS_S43 -> durable readback -> S42 result arrival -> deny -> fresh S43 search. Repeat with S44, timeout, identity C0 and post-claim cutover. | Old reader computes under pin, no old P after HOLD/CAS; at most two total attempts, fresh pair checks, one terminal maximum; permanent revocation never retries old Semantic. | Old result relabeled S43, pin GC, old P accepted, unlimited retry or duplicate terminal. | HOLD/CAS/final P not causally connected, request identity or pin liveness unclear. | Real protected transport/native pins or permissions unavailable. |
| F / S05, T09 | Crash/restart at every journal phase and immediately before/after C0, CAS commit and F1 outcome; also terminal claim-before-P and P-before-ACK. Observe durable BOOT_UNCLEAN before admission. | Startup closed, readback coherent, only new recovery owner runs; pre-CAS quarantine, post-CAS finalize only; no revoked permits, replay or duplicate terminal. | Auto-activate PREPARED, legacy rollback/swap reaches new authority, pointer/journal split, absent marker permits Semantic, old permit revived. | Crash target/starttime, durable marker, fsync or recovery API coverage cannot be proven. | Separate crash approval, observer, durable filesystem or owner guard fixture missing. |

## Durable readback per case

Read one consistent authority view; save before/after records and WAL transaction
identity, not a set of unrelated SELECT responses. Always bind operationId,
parentSnapshotId, epoch, generation, physicalPairId, owner/version and revisions.

| Case | Required durable reconciliation |
| --- | --- |
| A | S43 pointer, publicationRevision 21, unique receipt, journal merkle-activated in the same transaction (or later idle with linked receipt), retired S42; subsequent F1 adds irreversible revocation without erasing the legitimate receipt. |
| B | Activation projection equals the pre-attempt projection. F1 may independently update authorityRevision/revocation records; compare by transaction ID, not a blanket claim that the entire journal/database never changes. No CAS success receipt or publicationRevision increment. |
| C | Committed: A's atomic tuple. Not committed: old pointer/revision and no activation receipt; candidate quarantined. Any mixed tuple remains Semantic DENY. Read revocation ledger, boot marker and terminal claims too; successful readback never overrides C0. |
| D | C0 nonce bound to F1 result; UNKNOWN reconciled by nonce, not blind replay. Closure survives ledger write failure. F1 ACK alone does not authorize any Semantic. |
| E | S43 tuple, S42 retention pin, no permanent revocation solely due to compatible replacement, fresh retrieval-pair receipt and monotone revision; new S43 terminal receipt only if no earlier claim. |
| F | Journal owner/version/phase, pointer/revision/receipt, seal/hash tree, durable revocation/delete intents/pins/terminal ledger and BOOT_UNCLEAN/boot incarnation all reconcile before external admission. |

## F: bounded crash/restart coverage

Enumerate legal event prefixes, not all factorial permutations. C0 precedes F1
by contract; C0 winning forbids a later successful stale CAS.

1. CAS success -> crash before C0; restart unclean and closed.
2. CAS success -> C0 -> crash before F1 begin/commit.
3. CAS success -> C0 -> F1 ACK -> crash.
4. C0 -> attempted CAS rejected -> crash before F1.
5. CAS begin -> C0 -> stale commit denied -> crash.
6. CAS unknown -> crash; both committed and not-committed durable branches.
7. C0 -> F1 FAILED or UNKNOWN -> crash; UNKNOWN committed/not-committed branches.
8. C0 -> F1 ACK -> attempted CAS rejected -> crash.

Cross these prefixes with each reachable phase: building, legacy-swapped,
structured-swapped, catalog-activated, merkle-activated, idle. Mark unreachable
cells with a proof and never count them as PASS. Test failed as an additional
failure state: the fixed-HEAD type includes failed beyond the six normal phases.
For every reachable crash cell, attempt legacy reconcile/rollback before new
owner recovery and prove rejection before native swap/SQL pointer effects.
Also cover owner-absent legacy intermediate journals, mode mismatch and duplicate
owner startup. Preserve per-cell outcomes; aggregate cannot hide an unobserved cell.

## Minimal append-only edit proposal

At the end of original S05's injection/oracle/evidence bullets, append references
to Cases A/B/C/F and the B2 in-flight window, with
S05/c0-cas-cases.json, S05/c0-cas-order.jsonl and
S05/c0-cas-durable-readback.json. Do not remove slot/J1-J6/migration checks.

At the end of original T09's bullets, append Cases A-F, tested on real stdout
and HTTP v2 final writes, with T09/c0-cas-order.jsonl,
T09/c0-cas-readback.json and T09/c0-cas-final-writes.jsonl.

In T08-CUTOVER add a cross-reference to Case E; retain attemptBudget=2, deadline,
stable RequestKey and terminal claim constraints. CUTOVER_HOLD is temporary
compatible replacement protection, whereas C0 closes a revoked epoch
irreversibly. After HOLD only a confirmed new active may publish; after C0 a
permanently revoked result is never reauthorized.

## Judgment rules

All cases are currently NOT_EXECUTED. PASS requires every reachable required
safe-variant branch and evidence item. A demonstrated forbidden transition is
FAIL even if other observations are missing. Missing preconditions are BLOCKED;
an attempted but unobservable experiment is INCONCLUSIVE. Receiving bytes after
C0 is not itself a failure if their irreversible acceptance is proven before
C0. A partial event cannot receive newly accepted old semantic continuation
bytes after C0. No PASS here proves product integration or host power loss.
