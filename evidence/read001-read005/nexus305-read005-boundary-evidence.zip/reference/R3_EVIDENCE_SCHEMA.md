# R3 evidence contract

Schema version: r3-execution-evidence/1. Status: proposed, NOT_EXECUTED.
No fabricated experimental events or PASS results are included in this package.

## Sources of truth

The untouched Rev5 plan owns original tests. R3_ORACLE_MATRIX.json contains their
exact source blocks and parsed criteria plus additive case references.
R3_PLAN_AMENDMENT_R5_R3_001.md owns extra A-F obligations. This document owns
field semantics. EXECUTION_GATE_STATUS.json owns preparation/authorization state.
No document authorizes implementation or changes INV-01 through INV-07.

## JSONL event record

Every actual event is one UTF-8 JSON object per line. Required common fields:

| Field | Type / rule |
| --- | --- |
| schemaVersion | Literal r3-execution-evidence/1. |
| runId, testId, variant, caseId | Nonempty strings; variant safe/control/model; caseId null only for original unamended cases. |
| eventId, event, rawEvent | Unique ID, normalized event name, original observer spelling. |
| actorId, processIdentity | Role plus pid, starttime, bootId, euid, egid, groups, capabilities; no PID-only identity. |
| seq, ownerSeq | Monotone actor sequence; authoritative GateOwner sequence when applicable, otherwise null. |
| causalParents | Array of existing event IDs; cross-process edge needs barrier/IPC/observer proof. No inferred clock-only edge. |
| barrierId, operationId, requestKey, attemptId | Correlation identifiers; null only with documented non-applicability. |
| epoch, generation, physicalPairId | Bound authorization identities, never relabeled old payloads. |
| publicationRevision, authorityRevision, slotRevision | Separate integer axes and before/after values where changed. |
| monoNs, wallTime | String nanoseconds and ISO timestamp for diagnostics only. |
| observation | Structured OS/Node/DB evidence object; must include observer ID and raw artifact reference. |
| artifactRefs | Relative path plus SHA-256 and byte/line span, no absolute machine paths. |

Normalized events: IDENTITY_RECOGNIZED, C0_GATE_SYNC, CUTOVER_HOLD,
ACTIVE_CAS_BEGIN, ACTIVE_CAS_COMMIT_OR_UNKNOWN, F1_BEGIN, F1_ACK, F1_FAILED,
F1_UNKNOWN, P_WRITE_ACCEPT_OR_DENY, BOOT_UNCLEAN, RECOVERY_READBACK,
NATIVE_ENTER, NATIVE_EXIT, SIGNAL_DELIVERY, TERMINAL_CLAIM, GC_INTENT.
Original C0_SYNC_GATE_COMMIT/C0_SYNC and WRITE_ACCEPT are retained in rawEvent.

IDENTITY_RECOGNIZED and C0 must share the same synchronous gate decision/nonce;
there is no asynchronous recognition-to-C0 gap. External MISMATCH_OBSERVED is
not authoritative recognition. C0 versus CAS needs actual commit-decision
causality; CAS begin and returned response timestamps do not prove commit order.

## Actual final-write acceptance

P observation binds FD/socket inode and incarnation, owner, request/event ID,
bytesDigest, byte offset/length, Node writeHead/write/end or stdout call,
write-return value, underlying syscall evidence and peer-byte range/digest.
Distinguish final Node irreversible queue acceptance from later kernel send and
peer receipt. A write(false) may already accept all bytes; it is not a denial.
Capture thrown error/partial acceptance/UNKNOWN independently. SDK buffering,
handler completion and IPC acknowledgements are private events, not P.

The gate authorization and real final acceptance have no intervening await or
independent writer. A denial proves the old payload's final-write call was not
entered, with owner/FD coverage and client bytes as corroboration. Peer silence
alone is insufficient. Every newly accepted old continuation/frame after C0 is
forbidden; already accepted P<C0 bytes may arrive later without becoming a FAIL.
Header-only partial response is not permission for post-C0 old body writes.

Claim receipt precedes P but is not P. At most one durable terminal claim per
stable RequestKey; unknown delivery is not success and cannot be resent. New
connection incarnations or legitimate completed-ID reuse are distinct keys.

## SQLite and durable state

Record DB/WAL device+inode, engine/binding version, schema SHA, journal mode,
synchronous setting, transaction ID and WAL frame/commit identity, errors,
acknowledgement loss point, observer fsync/fdatasync events and fsync return.
Manifest durable sequence is file fsync -> directory fsync -> rename -> parent
fsync -> atomic SQLite activation tuple. Record actual filesystem/mount/device
profile. Successful fsync syscall is not proof of host-powerloss survival.

RECOVERY_READBACK contains a consistent snapshot of active pointer,
publicationRevision, phase/owner/version, operation/parent/slot, linked unique
commit receipt, retire parent, seal/provenance roots, revocation ledger/F1 nonce,
BOOT_UNCLEAN and terminal/delete-intent/pin ledgers. Save before/after and query
transaction identity. merkle-activated + CAS + revision + receipt must share
one commit; idle is only a subsequent finalize linked to that receipt.
F1 changes can coexist with a rejected CAS, so isolate activation projection
from independent authority/revocation changes in Case B.

## Native I/O, principals and collection completeness

Record actual executable/native binding SHA, PID/TID/starttime, native op ID,
path/inode/FD access mode, syscall enter/exit/return and signal-delivery event.
API_ENTER, artifact mutation, signal-send return or process exit alone do not
prove in-flight signal delivery. Quiescence is a separate result requiring all
descendants, writable FDs, IPC mutation routes and future capabilities revoked.

Preserve observation drops/gaps and observer permissions/configuration hashes.
Use complete path/hash trees including metadata, registry and parents, plus
old/fresh Reader results. S06 expected ledger derives independently from source
before native readback; compare all keys/vectors in both tables and full/new
incremental pair, not only changed rows. Expected and observed schema roots
need not equal each other: the independent join/completeness receipt must agree
with each corresponding recomputed root and manifest binding.

## Per-run result object

Required: schemaVersion, runId, testId, variant, caseIds, oracleSha256,
harnessSha256, adapterSha256, sourceHead, lockfileSha256, environmentRef,
authorizationRef, actual, expected, counterexample, classification, limitations,
subresults, artifactHashes, causalGraphRef, reachableCells, skippedCellsWithProof,
startedAt, endedAt, resourcePeaks and cleanupState. Hashes are lowercase 64 hex;
unbound future hashes are null with NOT_VERIFIED, never placeholder successes.

| Classification | Meaning |
| --- | --- |
| PASS | All mandatory reachable safe-variant branches satisfy oracle, evidence complete; limited to observed independent Spike. |
| FAIL | A real forbidden safe-variant transition/counterexample demonstrated. Missing ancillary data does not erase the counterexample. |
| INCONCLUSIVE | Execution attempted but essential causality/coverage/observation unavailable or ambiguous. |
| BLOCKED | Run cannot start or continue because precondition/permission/fixture is missing. |
| NOT_EXECUTED | No experiment attempted; preparation status, not a safety result. |

Aggregate never hides subresults: FAIL dominates; otherwise BLOCKED or
INCONCLUSIVE prevents PASS; NOT_EXECUTED mandatory branch prevents PASS. S02
in-flight and quiescence stay separate. T05 replay AbortError is INCONCLUSIVE.
Controls are reported separately with expected unsafe behavior; they do not
confer product PASS. Crash cells proved unreachable are not PASS samples.

## Evidence paths, confidentiality and integrity

Use environment/, oracles/, traces/<runId>.jsonl,
results/Sxx|Txx/<runId>/ and the original per-test artifact names. Emit
R3-RESULTS.json and R3-FAILURE-MATRIX.json only after approved experiments.
Log synthetic payload digests, scoped identities and error codes. Never log
tokens, real source/provider credentials, full environment dumps or unrelated
process data. Logger sinks are evidence files/private stderr, never an external
MCP stdout stream. Preserve raw synthetic wire data when needed to prove P.

SHA256SUMS hashes every packaged file except itself, sorted by relative path.
ZIP excludes its own sidecar. External <archive>.sha256 stores ZIP SHA and
SHA256SUMS SHA, eliminating recursive self-hashes. Verify ZIP CRC, member set,
manifest coverage and readback SHA before handoff. Supplied original evidence is
opaque and byte-preserved; do not alter it to sanitize historical paths.

Preparation checks use a separate SELF_CHECK_REPORT.md, not fabricated
R3-RESULTS.json. Missing input sidecar/internal manifest is recorded explicitly.
