# Nexus #305 Independent Spike R2 実行報告

## 1. 判定と権限

固定依存版による実試験と独立モデルを実行した。Section 4.1 の残存契約を全面的に証明できたとは判定しない。
Gate 1 / Gate 4 の製品統合は BLOCKED。Gate 2 は旧 Snapshot 保持および Namespace 名だけの隔離が FAIL。
Gate 3 は追加 Fence のない実 SDK 経路の Negative Control が FAIL。設計全体の正式承認は行わない。
INV-01〜07、Design Spec 全体、Bedrock Automatic Mode、Implementation Plan、製品実装の未承認状態を維持する。

## 2. Baseline と原本監査

- Review HEAD: `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`。初期および最終の追跡対象差分は空。
- GitHub Issue #305 は読み取りのみ実施。本文は `evidence/issue-305.json`。
- 指定 ZIP `nexus305_ep41_independent_spike_20261012.zip` は未提供または探索範囲内に存在しなかった。
- 期待 SHA-256: `6841d510dc6381a3c33dd07415d0033eb62b232b5eb4a512e00fa64a206a032a`。
- 実 Checksum は未計算。Checksum 不一致ではなく原本不在による BLOCKED。ZIP Manifest、各ファイル Hash、既存テスト監査は NOT_EXECUTED。
- 探索範囲: Nexus 作業領域、ホーム配下、/tmp。/mnt/data の検索はパスに到達できず、監査済みとは扱わない。
- 無関係の Spike ZIP は証拠に採用していない。原本との変更差分は証明不能。
- 固定 HEAD ソースは `git show` で取得。`evidence/source-audit.json` と `evidence/baseline-source/` に保存。
- CodeGraph が HTTP v2 の指定ファイルを返さなかったため、そのファイルは直接取得した。
- 本報告の INV と契約は依頼文を基準とする。Issue 本文には Section 4.1 全文がなく、原本設計の版同一性は未確認。

## 3. 実行環境と固定依存

| 項目 | 実測 |
| --- | --- |
| OS / Kernel | Linux / 7.0.0-34-generic |
| Architecture | x64 |
| Node.js / npm | v26.10.0 / 11.19.1 |
| SQLite / Binding | 3.53.4 / node:sqlite DatabaseSync |
| LanceDB | 0.18.2、Native ロード成功 |
| MCP v1 SDK | 1.29.0、ロード成功 |
| MCP v2 Server / Node adapter | 2.0.0 / 2.0.0、ロード成功 |
| Apache Arrow | 18.1.0、LanceDB peer requirement を満たす |
| Lockfile SHA-256 | `19be4560ec6e0dcb9404d24cce40a03bf0a9f6efebcb18b336bdc77fa78b30f7` |

依存は Nexus 外部の `environment/` に固定インストール。最後に `npm ci --ignore-scripts --no-audit --no-fund` を実行し、ロードと依存ツリーを再検証した。
再現に不要な Native install script は実行していない。最初の `npm ls` は Arrow peer 不足を報告したため、Baseline と同じ Arrow 18.1.0 を明示固定した。
初期依存ツリー失敗は `evidence/phase0-install-notes.json` に記録する。最終ツリーは `environment/dependency-tree.json`。
SQLite は Nexus の better-sqlite3 ではなく Node 組み込み SQLite。モデルの成功を製品 Binding の成功として扱わない。
実験は専用ディレクトリと専用子プロセスで隔離したが、同一 UID であり OS セキュリティ Sandbox ではない。
追加の bubblewrap 分離は権限エラーで BLOCKED。クラウド資源は作成していない。

## 4. ハーネス変更

原本を入手できなかったため、前回コードの修正差分ではなく新規の使い捨て Spike ハーネスである。

- 各試験実行前に `evidence/oracles/<Test ID>.json` を固定し、初期状態、注入位置、禁止遷移、成功・失敗・観測不能条件を保存。
- Retention は Boolean の型確認を廃止し、旧 Reader と fresh Checkout の Rows / 内容 Hash / Vector 検索結果を比較。
- Native Kill は Native API 呼び出しに加えて data artifact の変化を親プロセスで観測。厳密な Kill 到達位置は証明しない。
- stdio / HTTP v1 / HTTP v2 / Bridge を別経路で実行。Node Writable 単独、SDK double、実 OS stdout pipe を区別。
- 初回 v2 は必要な per-request _meta 不足で 400。次の Bridge 試験は inputSchema 不足で callback extras が未設定。両者の結果は履歴に保存した。
- 最終 v2 は実 SDK 定数による _meta / MCP headers と inputSchema を使用し、200 と旧 Payload の受信を確認。
- 最終 Event Store の Replay は実通知を cursor とし、cursor より後の同一 stream イベントだけを返す。初期の単純 Replay fixture は履歴として残し、最終証拠には採用しない。
- Bridge は固定 HEAD の実ソースを Node stripTypeScriptTypes で型除去して使用。製品コードは変更していない。v2 外部経路と Handler は最小の合成 Fixture。
- Storage / Model の Scratch は実行ごとに新規ディレクトリ。過去結果は `results/history/` と prior-results に保存。

## 5. 固定依存版の試験結果

| Test ID | 判定 | 証拠ファイル | 範囲 |
| --- | --- | --- | --- |
| STORAGE-01 | PASS | `results/gate2/results.json` | separate physical pair, observed run only |
| STORAGE-02-SIGTERM | INCONCLUSIVE | `results/gate2/results.json` | 当該 Oracle と本文に限定 |
| STORAGE-02-SIGKILL | INCONCLUSIVE | `results/gate2/results.json` | 当該 Oracle と本文に限定 |
| STORAGE-03 | FAIL | `results/gate2/results.json` | library same-UID control, not Nexus integration |
| STORAGE-04 | FAIL | `results/gate2/results.json` | 当該 Oracle と本文に限定 |
| STORAGE-05 | BLOCKED | `results/gate2/results.json` | 当該 Oracle と本文に限定 |
| TRANSPORT-01-STDIO-RAW | FAIL | `results/gate3/results.json` | raw SDK negative control |
| TRANSPORT-02-SDK-BACKPRESSURE | FAIL | `results/gate3/results.json` | real SDK send with controlled output double; not OS stdout pipe |
| TRANSPORT-04-cancel | PASS | `results/gate3/results.json` | real SDK delayed handler |
| TRANSPORT-04-close | PASS | `results/gate3/results.json` | real SDK delayed handler |
| TRANSPORT-03-HTTP-JSON | FAIL | `results/gate3/results.json` | raw SDK negative control |
| TRANSPORT-03-HTTP-SSE | FAIL | `results/gate3/results.json` | raw SDK negative control |
| TRANSPORT-03-SSE-STORE | FAIL | `results/gate3/results.json` | future EventStore negative control, NOT current Nexus configuration |
| TRANSPORT-05-V2 | FAIL | `results/gate3/results.json` | same createMcpHandler legacy reject / toNodeHandler libraries as Nexus, standalone probe |
| TRANSPORT-05-NEXUS-BRIDGE-V2 | FAIL | `results/gate3/results.json` | exact fixed-HEAD bridge source with synthetic handler + actual v2 external HTTP; not full Nexus runtime |
| TRANSPORT-02-OS-STDOUT | FAIL | `results/gate3/extra-results.json` | real SDK protocol and child stdout OS pipe |
| STORAGE-03-BWRAP | BLOCKED | `results/gate3/extra-results.json` | 当該 Oracle と本文に限定 |
| TRANSPORT-04-DUPLICATE-REQUESTKEY | FAIL | `results/gate3/duplicate-results.json` | raw SDK negative control; RequestKey dedup needs application ownership |

FAIL は安全性 Oracle に対する判定である。Negative Control が危険な方式を正しく検出したことは、安全方式の PASS を意味しない。
SDK は独自の Compatibility Coordinator / Epoch / Durable Fence を自動提供しない。閉鎖フラグを注入した試験の FAIL は、追加実装なしで当該契約を満たすという仮説への反例である。

## 6. 独立モデルおよび混合コントロールの結果

| Test ID | 判定 | 証拠ファイル | 範囲 |
| --- | --- | --- | --- |
| MODEL-G1-CONCURRENT | PASS | `results/gate1/results.json` | independent SQLite coordinator model |
| MODEL-G1-IDEMPOTENCY | PASS | `results/gate1/results.json` | 当該 Oracle と本文に限定 |
| MODEL-G1-STALE-FENCE | PASS | `results/gate1/results.json` | 当該 Oracle と本文に限定 |
| MODEL-G1-REVOCATION | PASS | `results/gate1/results.json` | model activation predicate, not product integration |
| MODEL-G1-SELF-CONFLICT | PASS | `results/gate1/results.json` | 当該 Oracle と本文に限定 |
| MODEL-G1-RECOVERY | PASS | `results/gate1/results.json` | connection restart, concurrent writer processes previously SIGKILLed; not host-power-loss |
| TRANSPORT-01-STDIO-GUARD | PASS | `results/gate3/results.json` | throwaway adapter with real SDK |
| TRANSPORT-02-NODE-WRITABLE | PASS | `results/gate3/results.json` | Node Writable only |
| TRANSPORT-05-BRIDGE | FAIL | `results/gate3/results.json` | real v1 Client/McpServer/InMemoryTransport; downstream publication is MODEL, not actual Nexus v2 bridge |
| MODEL-REQUEST-LIFECYCLE | PASS | `results/gate3/extra-results.json` | independent state model only; no SDK queue safety proof |
| MODEL-G4-SNAPSHOT | PASS | `results/gate4/results.json` | SQLite manifest model and real source files, not LanceDB pipeline |
| MODEL-G4-RECONCILIATION | PASS | `results/gate4/results.json` | model state classification and rescan retry; no product search availability claim |
| MODEL-GC-INTENT-CRASH | PASS | `results/gate4/results.json` | durable SQLite model intent, not native GC |
| MODEL-GC-PIN-RACE | PASS | `results/gate4/gc-model-results.json` | coordinator SQLite lease model, not LanceDB retention |
| MODEL-GC-WRITER-RACE | PASS | `results/gate4/gc-model-results.json` | model writers counter only; not OS writer isolation proof |
| MODEL-GC-PARTIAL-CRASH | PASS | `results/gate4/gc-model-results.json` | synthetic physical pair files and SQLite intent; not native LanceDB GC |

SQLite モデルは複数の実 Connection / 子プロセスで Commit し、WAL、Receipt、Slot Revision、Stale Parent / Fence、永久失効を試験した。
Snapshot 先行更新は SQLite Coverage モデルと実ソースファイルで検証。LanceDB 製品 Pipeline の検証ではない。
Reconciliation は Publication に相当する Slot 更新と Obligation を同一 Transaction で保存し、接続再開、失敗状態、再スキャン、再試行完了を検証した。
GC は SQLite Intent と合成の物理 Pair ファイルに対して、Reader / Writer lease による拒否、削除途中の専用子プロセス SIGKILL、残存ファイル照合・再削除を検証した。
モデルの Lease Counter は実 OS Writer 停止の証拠ではない。MODEL-REQUEST-LIFECYCLE の Terminal Map は製品 Request Lifecycle ではない。
STDIO-GUARD は実 SDK に接続した独立 Adapter の限定 PASS。全 Queue / Durable Fence / Replay の保証には拡張しない。
TRANSPORT-05-BRIDGE は実 v1 SDK の内部転送と下流のモデル Write を組み合わせた試験。外部実 Write の証拠は別の TRANSPORT-05-NEXUS-BRIDGE-V2 にある。

## 7. 観測専用試験

| Test ID | 判定 | 証拠ファイル | 範囲 |
| --- | --- | --- | --- |
| TRANSPORT-03-PARTIAL-ABORT | PASS | `results/gate3/http-abort-results.json` | partial/abort observation only, NOT safe revocation guarantee |

Partial / Abort 試験は、巨大 SSE Response の最初の一部をクライアントが受信した後に Connection を破棄し、Transport を閉じた。
これは部分送信を観測した PASS であり、失効時の安全性 PASS には集計しない。既に受信済みの Bytes は回収できない。

## 8. 障害注入と観測順序

### Native Writer

各親 Controller で READY の IPC 受信、GO 送信、API_ENTER の IPC 受信、候補 data artifact 変化の観測、Signal 送信、exit の観測、再接続後の Reader 検証を記録。
実 Writer PID は今回 SIGTERM=1559688、SIGKILL=1559742。
プロセス子孫一覧、Native を含む全 Thread ID、Operation ID、対象 Artifact と Hash は `evidence/process-tree.json`。
Native I/O の開始は候補 data file の変化で支持される。しかしその観測と Signal delivery の間には Race があり、厳密な Native I/O 中の Kill は INCONCLUSIVE。
Writer 終了は exit signal で確認し、公開 Pair の File Hash / inode / Rows / 検索を確認。Project Lock の再取得を停止証拠に使っていない。
Native が同一プロセス内で動作し、観測時の子プロセス一覧は空だった。終了後に Native Thread が残存しないことは Linux process exit の観測に限定する。

### Transport

stdio は Handler Return、SDK が構築した Response の send 呼び出し、Admission Closure、Writable/実 OS stdout write の順を観測。
HTTP は SDK send、Response/Stream Construction、Node writeHead / write / end、クライアント受信を記録。
SSE Event Store は storeEvent 開始、Admission Closure、保存完了、Stream Write、epoch 2 として再開するクライアントへの旧 Event Replay を記録。
epoch は Spike のラベルであり SDK に Coordinator を注入していない。実ライブラリ自身に epoch-aware replay の契約があるとは扱わない。
v2 は createMcpHandler の Response を得た後、toNodeHandler の write/end に入る前に閉鎖し、旧 Payload の外部受信を確認。
Header の受理・Body のキュー投入が不可逆境界である。write(false) は未受理ではなく、受理済み Backpressure である。
実 OS stdout の試験では Close 後に読み取りを開始して旧 Payload を受信した。未解決 Send を Durable Fence がそのまま待つ方式は無期限待機を避けられない。

### 時系列の扱い

`traces/timeline.jsonl` は Controller PID とそのローカル Sequence でまとめた因果記録であり、全プロセスの単一物理時系列ではない。
子の monotonic timestamp を比較していない。IPC 受信と親の観測順に根拠を限定する。
各 trace の Generation / Epoch / Fence / Snapshot の既定値は合成 Fixture の識別子である。実 Slot の変化は各結果内の snapshot / slot / receipt に記録。

## 9. Retention / Isolation / Publication の技術判定

- Retention: **RETENTION_UNSUPPORTED**。Prune が旧 version を削除し、Pin 済み Reader の旧 data file と新たな Checkout の旧 manifest が Not found になった。
- Version Checkout は保持 Lease ではない。物理的に独立した Pair の保存と、Coordinator が Reader Lease を考慮してから行う GC が必要。
- STORAGE-01 の PASS は、独立ディレクトリを用いた観測上の不変性。ディレクトリに OS 強制の Immutable 属性を設定した保証ではない。
- Namespace 分離: **FAIL**。同一 UID の Connection が別の公開領域へ接続し、100 Rows を101 Rowsに変更できた。
- Native Kill: Writer Process 終了は確認したが、厳密な注入契約は **INCONCLUSIVE**。
- SDK Publication: 追加 Fence のない raw stdio / HTTP JSON / SSE / v2 と Bridge 外部送信は **FAIL**。現行 Nexus 全体の動的保証は BLOCKED。
- stdio Backpressure: SDK double と実 OS Pipe の双方で close が未解決 send を清算しない挙動を確認。
- Cancel / Close: Handler が遅延している間の抑止のみ PASS。既に受理した Write を取り消す保証ではない。
- Duplicate RequestKey: raw SDK に同一 key を二度投入すると Terminal Publication が二回。製品側で一回性を所有する必要がある。
- 現行 v1 Event Store は未設定。将来 Event Store Negative Control の保存・Replay の FAIL を現行設定の動的 FAIL と混同しない。

## 10. 未証明契約

| Test ID | 判定 | 証拠ファイル | 範囲 |
| --- | --- | --- | --- |
| PHASE0-ORIGINAL-ZIP | BLOCKED | `evidence/baseline.json` | original evidence audit |
| RG-305-SPIKE-003 | PASS | `environment/runtime.json` | fixed environment |
| RG-305-SPIKE-001 | FAIL | `results/gate2/results.json` | fixed native retention safety |
| RG-305-SPIKE-002 | INCONCLUSIVE | `results/gate2/results.json` | exact native injection boundary |
| PRODUCT-GATE1 | BLOCKED | `evidence/failure-matrix.json` | product integration |
| PRODUCT-GATE4 | BLOCKED | `evidence/failure-matrix.json` | product integration |
| NATIVE-GC-RECOVERY | BLOCKED | `evidence/failure-matrix.json` | native product GC |
| SAFE-OS-WRITER-ISOLATION | BLOCKED | `evidence/failure-matrix.json` | alternative native isolation |
| FULL-NEXUS-RUNTIME-PUBLICATION | BLOCKED | `evidence/failure-matrix.json` | product integration |
| JSON-BUFFER-TO-FENCE-SAFE-ADAPTER | NOT_EXECUTED | `evidence/failure-matrix.json` | safe transport implementation |
| SSE-EPOCH-AWARE-STORE-AND-REPLAY | NOT_EXECUTED | `evidence/failure-matrix.json` | safe future EventStore |
| CANCEL-AFTER-STDIO-WRITE-FALSE | NOT_EXECUTED | `evidence/failure-matrix.json` | cancellation after enqueue |
| HOST-POWERLOSS-RECOVERY | NOT_EXECUTED | `evidence/failure-matrix.json` | physical durability |
| NATIVE-PIN-GC-AND-OLD-WRITER-GC-RACES | BLOCKED | `evidence/failure-matrix.json` | native races |

RG-305-SPIKE-003 は固定版取得、Lockfile 保存、実ロード、npm ci による再現まで実施。
RG-305-SPIKE-001 は弱い Boolean 試験に代わる Safety Oracle を実行したが Retention が FAIL。
RG-305-SPIKE-002 は API_ENTER より強い証拠を追加したが厳密な Injection Placement は未成立。

## 11. INV-01〜07 対応

| 不変条件 | 証拠と限界 |
| --- | --- |
| INV-01 | 独立 Coordinator Model のみ。実製品 Coordinator の Admission 判定は BLOCKED。SDK 自身の互換性判断に委譲できない。 |
| INV-02 | Native Kill 位置は INCONCLUSIVE。raw Transport は失効ラベル後に送信。最終 Write と失効の線形化 Adapter は未証明。 |
| INV-03 | STORAGE-01 の別物理 Pair は観測上不変。Checkout Pin の保持は FAIL。実 Active Generation の Pair Admission は未証明。 |
| INV-04 | Concurrent CAS / Receipt / Coverage / GC Journal は独立モデル PASS。実 Native Artifact Activation は BLOCKED。 |
| INV-05 | 別の Durable Revocation Transaction、Rollback、再接続、GC Tombstone は独立モデル PASS。製品統合は未証明。 |
| INV-06 | 旧 Payload 公開を実 SDK Negative Control で検出。独立 Error Adapter の局所 PASS のみ。全経路の実製品抑止は未証明。 |
| INV-07 | 旧 Pair が Candidate 構築中に読めることと Availability Model を確認。互換/非互換 Full Rebuild の製品統合は BLOCKED。 |

## 12. 失敗方式の代替設計

不変条件は弱めない。以下は検証結果に基づく提案であり、承認済み実装ではない。

1. Checkout 依存をやめ、Generation ごとの物理 Legacy / Structured Pair を完成後に凍結。Manifest はその物理 ID と Fingerprint/Profile/Coverage/Journal/Fence を結び付ける。
2. Candidate Writer は別 UID または read-only Published mount を持つ OS Sandbox とし、Published の Parent Directory と共有 Metadata も書けない構成にする。Namespace 名だけに依存しない。
3. Durable Revocation を Rollback 可能な Activation と別に保存し、Active Slot CAS と Receipt の整合を検査する。Crash 復旧は Intent/Manifest/物理 Artifact を照合する。
4. stdio は Bytes を Writable に渡す前の Gate と RequestKey の Terminal CAS を設ける。write(false) 後の Queue は回収不能な Publication として扱い、未解決 Promise を Fence の無期限待機条件にしない。
5. HTTP JSON は Buffered Response を Node Adapter に渡す直前、SSE は保存完了後の Write と Replay 前にも Epoch を検査する。Gate が成立しなければ Stream/Connection を隔離して TRANSPORT_FAILED を確定する。
6. Event Store には Generation/Epoch と Durable Revocation を保存し、失効済み Event を Replay 対象から永久除外する。保存開始時の検査だけでは不足する。
7. Bridge 内部の成功は外部 Publication の成功と区別し、v2 の最終 Node Write にも同じ Coordinator Admission と Terminal 一回性を適用する。
8. GC は Durable Delete Intent と Reader/Writer Lease、再起動時の Tombstone 検査を持ち、部分削除を冪等回復する。永久失効を可用な Generation に戻さない。

## 13. 成果物、Hash、再現方法

`README.md` のコマンドで固定環境と試験を再実行できる。全実行コマンドの stdout/stderr/exit は `results/execution-log.json`。
`SHA256SUMS` はそれ自身を除く全同梱ファイルを対象にする。自己 Hash と ZIP Hash は再帰参照を避けるため ZIP 外部の `nexus305-spike-r2-hashes.json` に記録する。
包装処理は全ファイル再読込、Python 標準 zipfile の CRC 検査、ZIP 再展開後の全ファイル再 Hash を実行する。最終数値は引渡しメッセージおよび同 Sidecar にある。
最初の包装は zip コマンド不在で失敗したため、固定依存を変更せず Python 標準 CLI に切り替えた。この失敗は `evidence/packaging-notes.json` に保存した。
node_modules は同梱しない。固定 Lockfile と Registry integrity で再取得する。Native Artifact / SQLite Fixture は `scratch/` に同梱する。
日本語文書は Hangul と CP932 で表現できない漢字を検査する。

## 14. 独立レビュアーへの引渡し

1. 原本 ZIP とその報告書の提供後、期待 Hash と Manifest を別途監査する。本 R2 と前回成果物の差分はまだ認定できない。
2. Gate 2 の Retention と Namespace Negative Control の反例を評価し、物理 Immutable Pair と OS 強制隔離の代替契約を検討する。
3. Native syscall/ptrace 等の強い観測が許可された環境で、Mutation 中の Signal delivery を立証する追加試験が必要。
4. Gate 3 は raw SDK に Compatibility Fence がない反例。製品の線形化機構、Queue/Replay 失効、Terminal 一回性は製品実装後の別 Gate が必要。
5. モデルの PASS、観測専用 PASS、実 SDK Negative Control、安全 Adapter の局所 PASS を別々に評価する。
6. Spike 結果を正式な Section 4.1 承認または次工程への移行許可と解釈しない。
