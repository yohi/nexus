# Nexus #305 — Section 4.1 Revision 5：Storage / Transport 安全境界の代替設計提案

> **文書の地位:** Architectural Design **修正提案**（Rev4独立レビューの4件を反映、Rev5独立レビュー前）。**Section 4.1 Review Gate = BLOCKED**。製品実装・GitHub操作・R3実験・Implementation Plan・Design Spec全体承認は含まない。Bedrock Automatic Mode個別保証も未承認。

## Rev4独立レビュー → Rev5最小修正の境界

**入力:** 独立Review判定 `REVISION_REQUIRED`（`RG-305-R4-REVIEW-001〜004`：Major 3、Moderate 1）。本Rev5はレビュー結果に対する**設計担当の回答**であって、Reviewerの代理判定・R3実行許可ではない。

| Finding | Rev5の規範的差分 | R3追加/変更 |
|---|---|---|
| `RG-305-R4-REVIEW-001` | **同期C0 → 非同期F1**を分離。C0と最終Pは同一所有プロセスの同期Gate、Fの不明/失敗・再起動もfail-closed | `T01/T09`：C0後F1前の送出競合、F失敗/結果不明、IPCレース |
| `RG-305-R4-REVIEW-002` | 既存6段階Full Rebuild Journalを**version付きCoordinator単一Authorityの投影**として対応付け。`merkle-activated`とActive CASは同一SQLite commit | `S05`：全6段階のcrash/restart・旧reconcile遮断 |
| `RG-305-R4-REVIEW-003` | 互換切替で旧Reader **計算継続**と旧結果の**Publication拒否**を分離。新Activeでbounded retry、未Claim時だけerror/Grep-only | `T08/T09`：S42 pin→S43 active→旧Publishと再検索競合 |
| `RG-305-R4-REVIEW-004` | `expected chunk/input` 集合と `persisted vector receipt` 集合を独立に作成し、bijection + deterministic root + completenessを検証 | `S06`：欠落/余剰/複製/入替/異Provider/単一manifest捏造の負例 |

**未変更:** 方式A/Bの採否、R2 negative controlのFAIL、STORAGE-02とReplayのINCONCLUSIVE、INV-01〜07、Fingerprint/Provider Identity、Exact/Grep独立、Bedrock Automatic Mode未承認。R3を未実行のままにする。

## 0. Baseline、出典、証拠の強度

- Repository: `yohi/nexus`、Issue #305、提供された固定Review HEAD `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`。**本設計作業ではGitHubへアクセスしていないためHEADの現在性を再検証したとは主張しない。** 固定HEADのソース抜粋はR2パッケージ内 `evidence/baseline-source/`、`evidence/source-audit.json` に依拠する。
- 依存固定: `@lancedb/lancedb@0.18.2`、`@modelcontextprotocol/sdk@1.29.0`、Local HTTP v2では `@modelcontextprotocol/server@2.0.0`、Node.js `>=24`。R2実測Node `26.10.0`。R1はNode `22.16.0` で固定SDK/Native動的試験を実行できなかった。
- 引き継ぎZIPの `HANDOFF_SHA256SUMS` **10件一致**。R2 ZIP SHA `086aa7a1c8b69b2684755f7c8b56f61a796bd0f29d012904dff27900e77170be`、内部 `SHA256SUMS` の**413ファイル全件一致**、ZIP CRC正常。Sidecar `R2-hashes.json` と一致。外側 `R2-SPIKE-REPORT.md`、`R2-failure-matrix.json` はZIP内部原本とbyte一致。
- R1 ZIP SHA `6841d510dc6381a3c33dd07415d0033eb62b232b5eb4a512e00fa64a206a032a`、内部 Manifest **23/23一致**、ZIP CRC正常、添付R1レポートは内部原本とbyte一致。ただしR2実行時の原本不在は遡及的に解消されず、R1→R2のハーネス差分を承認済みの試験差分として扱わない。
- **根拠の種別:** 【R2実測】固定依存版のNegative Control / Trace；【R2モデル】独立SQLite/GC/Queue等；【R1モデル】前回モデル；【提案】本書で追加する実装可能性未検証の仕様。内部証拠のファイルはすべて `R2-EVIDENCE.zip/nexus305-spike-r2/` を基点に記す。

### 0.1 R2反例・限定PASSを設計要件へ結び付ける

| 観測ID / 原本 | 観測（承認済み保証ではない） | Rev5でも維持する変更・必要な反証試験 |
|---|---|---|
| `STORAGE-03` / `results/gate2/results.json`、`evidence/oracles/STORAGE-03.json` | 【R2実測・FAIL】同一UIDで別の公開ディレクトリへ接続し100→101 rows変更 | WriterがPublishedの本体・親・共有メタデータへ**OS能力上到達不能**、R3-S01 |
| `STORAGE-04` / 同上、`traces/STORAGE-04.jsonl` | 【R2実測・FAIL】Optimize/Prune後に旧Reader data / Manifest不在 | Version checkoutをPinとして使用禁止、物理Snapshot PairとGC Pin、R3-S03 |
| `STORAGE-02-{SIGTERM,SIGKILL}` / `results/gate2/results.json`、`evidence/process-tree.json` | 【R2実測・INCONCLUSIVE】data変更・Writer exitは観測、Signal時点のNative I/O中は未証明 | Sealの停止保証と「Native I/O中kill」の可観測性を**別契約**にする、R3-S02 |
| `STORAGE-01` / 同上 | 【R2実測・限定PASS】別物理Pairが実行中維持された。強制Immutableではない | 公開領域への攻撃試験と完全性検証が必要 |
| `TRANSPORT-01-STDIO-RAW`,`02-OS-STDOUT`,`02-SDK-BACKPRESSURE` / `results/gate3/*results.json` | 【R2実測・FAIL】`write(false)`は受理済み、Close後も旧Byteが届き未解決sendが残る | 外部stdout所有のPublication Broker、キュー投入直前P、bounded isolate、R3-T01/02 |
| `TRANSPORT-03-HTTP-JSON`,`03-HTTP-SSE`,`05-V2`,`05-NEXUS-BRIDGE-V2` / `results/gate3/results.json` | 【R2実測・FAIL】Closure後Node `write/end`で旧Semantic受信。Bridgeは固定HEADソース+合成Handler/実v2外部HTTPであり全製品ではない | SDK Response全体を私的に保持し最終Node送信AdapterでP、R3-T03/T04/T06 |
| `TRANSPORT-03-SSE-STORE` / 同上 | 【R2実測・FAIL】`storeEvent()`後の旧Event保存と旧Semantic初回送出。**最終Replay欄は`AbortError`であり旧Event再配信成功は未立証**。現行Nexus v1 Event Store未設定 | 永続Event失効と実再接続ReplayをR3-T05で検証 |
| `TRANSPORT-04-DUPLICATE-REQUESTKEY` / `results/gate3/duplicate-results.json` | 【R2実測・FAIL】raw SDKは同じkeyでTerminalを2回公開 | RequestKey durable Terminal Claim、R3-T07 |
| `TRANSPORT-01-STDIO-GUARD` / `results/gate3/results.json` | 【R2実測・局所PASS】使い捨てAdapterが遅延失効を拒否 | 全Queue/FD/Restartの保証に拡張不可 |
| `MODEL-G1-*`,`MODEL-G4-*`,`MODEL-GC-*` / `results/gate{1,4}/` | 【R2独立モデル・限定PASS】CAS/Recovery/Coverage/GCモデル | 製品統合・Native IO・実OS/SDK境界を未証明として保留 |
| `STORAGE-03-BWRAP` / `results/gate3/extra-results.json` | 【R2実測・BLOCKED】network namespace設定時 `RTM_NEWADDR: Operation not permitted` | Sandbox不可環境のFail-closedを明示。bwrapで保証済みとはしない |

## 1. 非交渉の不変条件と保証の境界

`INV-01` 単一Compatibility Coordinator認可、`INV-02` Runtime Epoch失効と実Mutation/Publicationの線形化、`INV-03` Legacy/Structured同一Active Compatibility Generation、`INV-04` Fingerprint/Profile/Coverage/Journal/Fenceに基づくActivation、`INV-05` Durable Revocationの不可逆性、`INV-06` Retrieval Pair CompatibilityなしのSemantic公開禁止、`INV-07` 同一互換性Full Rebuild中の旧検索継続・非互換Full Rebuild中のSemantic停止を**すべて維持**。

Compatibility Fingerprint = RFC 8785 canonical JSON + SHA-256によるEmbedding Space・Effective Prepared Input（Role/Task/Unicode）・Index Coverageの独立した規範スキーマを維持する。`Runtime Epoch`/Generationはキャッシュキーに混入しない。Provider Identity（Execution Bindingが証明されたAutomaticとDeclared Compatibility ID）とRuntime Permitを混同しない。Bedrock Automatic Modeは未承認。Dimension/row count一致のみはProvenanceではない。

`Availability` は独立のExact Structured Retrieval / Grep経路を侵食しない。Semantic不許可時は構造化Reason `COMPATIBILITY_REVOKED` / `RETRIEVAL_PAIR_INCOMPATIBLE` / `COVERAGE_INVALID` / `TRANSPORT_FAILED`（必要に応じ粒度を細分）を返す。Hybridは**再認可した**Grep-onlyへ縮退できる場合だけ縮退し、旧Semanticを混ぜない。

## 2. Storage代替方式比較・選択

| 方式 | 権限・不変性の実現 | 長所 | 危険/運用条件 | 判定 |
|---|---|---|---|---|
| **A. Separate UID Worker + Privileged Snapshot Publisher（推奨）** | Candidate Workerは専用UID/制限されたMount Namespaceで候補のみRW。Publisherは別PrincipalのPrivate Import領域へ**byte-copy**しHash/耐久化後に物理独立Pairを発行。ReaderはRO、GCは専用Actor。 | ローカル、LanceDB 0.18.2の物理Pairを利用でき、過去Version Checkoutに依存しない | POSIX UID/ACL・path/mount/inherited FD・親dir・shared registry・別プロセスサービス・OS境界の強制が必要。Windows/macOS/Linux rootlessは環境別証拠必須 | **R3優先**、未証明 |
| **B. Immutable Object-store Snapshot Pair + Private Verified Read Cache** | CandidateにObject Store資格情報を渡さず、独立Publisherがcontent hashの別物理Object KeyにPUT; Versioning単独ではなくWORM/Object Lock相当またはdeny-overwrite/delete IAM。Local reader cacheもOS隔離されたRO copy。GCはRetention解除後に別認可Actor。 | Runtimeが専用UIDに対応できない場合の物理保護、remote durabilityを個別証明可能 | Object Lock、資格情報分離、listing整合、cloud/offline運用、LanceDB local-download後のRO mountとCache GC、Object Retentionと要求GC期間の不一致。Provider権限が漏れれば不適合 | **代替**、採用には別R3相当の試験 |
| C. 同一UID別path + `checkout(version)` + `prune` | OS ACLで旧Writerを排除できず過去Manifestが消える | 単純 | STORAGE-03/04の反例 | **不適合・再採用禁止** |

**Fail-closed:** Aの実効OS境界（専用Principal、アクセス禁止、Publisher/Reader/GCのFD・Mount分離）が作れず、Bの同等の強制能力も試験できないホストは**Semantic Activation / Mutation / PublicationをDENY**。既に安全性を証明済みのRO Active Pairだけについては継続可能性を別に検証し、証明できなければSemantic検索も停止。Exact/Grepは独立運転。OS `chmod`のみ、コンテナの見かけ上の別path、同UID mountの単なる操作規約をIsolationの証拠としない。Linuxのroot/capabilities、`/proc/*/fd`、open dirfd、hardlink/symlink、socket越し書き込み、共有tmp、無制限な管理者権限等の横道を含めて調べる。

### 2.1 推奨Aの具体的権限トポロジ

```text
Compatibility Coordinator (唯一の認可、SQLite authority + durable ledger)
   ├─ Writer launcher / Candidate UID (private /candidate/op-{nonce}/RW のみ)
   │     └─ LanceDB 0.18.2 native Writer (Legacy + Structuredを新規生成)
   ├─ Publisher UID/daemon (Candidateを制限付きROで読み、private importへCOPY)
   │     └─ /snapshots/<physical-id>/{legacy.lance,structured.lance,catalog,coverage,merkle,manifest} [immutable]
   ├─ Reader UID (published root RO、検索用Reader Pin必須)
   └─ GC capability actor (SQLite delete-intent認可を都度取得、列挙されたphysical-idのみ削除)
```

全LanceDBデータ、`_versions`,`_transactions`,indices、table registry、database metadata、Catalog/Merkle/Coverageを**Snapshot固有の物理名前空間に閉じ込める**。CandidateがPublished rootやその親を操作できる場合、子ディレクトリに対するRO/ACLだけでは防御不成立。Publisherは独立UIDの非公開親に公開用ディレクトリを新規生成し、**hardlink禁止**（Candidate inodeとの共有回避）、symlink/device/socket/FIFOやpath traversalを拒否、`openat2`等の安全なpath解決は環境依存につき別検証。ReflinkはCoW挙動と誤実装に依存するため標準設計では使用しない。Publisherを除くプロセスが公開物理Fileを書けるようなprivileged broker RPCも禁止。**さらにPublisherもSeal後のPublished rootに対してMutation権を保持してはいけない。** Import専用領域からSeal Actor（別の限定OS principal）が最終公開Parentへownershipを移し、PublishedはReader/Publisher両方にROとなるようmount/ACL/強制Immutable相当の保護を構成する。GC ActorはDelete Intentの対象物理IDだけを操作できる専用認可を得る。Linuxの`fs-verity`等による検出は書込み拒否と同義ではなく、root権限やmount外の別path等からのbypassを含めてR3で否定する。

Publisherの保護は**OS capabilityと開いたFDの両方**で成立させる。WriterはPublished dirfd、PublisherのIPC command capability、Object Store credential、Active SQLite直接write、GC capabilityを保有しない。ReaderがLanceDBのROアクセスを実際に実行でき、書き込み試行が全て失敗するかR3で確かめる。Publisher、GC、Coordinatorの高権限主体はAPI呼び出し元Epoch・Operation・対象Path・認可Receiptを毎回検証し、path自由指定のwrite/deleteを受け付けない。

### 2.2 Candidate / Snapshot Pair状態機械（プロトコル提案）

`NEW -> BUILDING -> DRAINING -> QUIESCED -> IMPORTING -> SEALED -> VERIFIED -> PREPARED -> ACTIVE -> RETIRED -> DELETE_INTENT -> DELETED`。異常系は `QUARANTINED` / `ABORTED` / `RECOVERY_REQUIRED`。

1. `NEW/BUILDING`: Coordinatorが非再利用Operation nonce・Candidate UID/dir・source baseline、fingerprint、親 `parentSnapshotId`、`basePublicationRevision`、File Generation/Fence、`slotRevision` と `authorityRevision` を記録。CandidateだけでNative write/compaction/prune可能。公開領域へのwriteなし。
2. `DRAINING`: Writerにstop-admission。In-flight native operationを列挙し、期限まで終了待機。**timeoutならcandidateを隔離/killし、その時点ではSeal未成立**。別Principalの子孫・外部サービス・FDが残るなら `QUARANTINED`。
3. `QUIESCED`: 同一Candidateの**すべての**Mutation Principal / PID/TID / cgroup / open write FD / 外部RPC writerが停止・権限剥奪され、将来再開できないことをOS監視とController台帳で立証。signal delivery時点にNative I/O中だったかどうかの試験的立証は**別項目**。SIGKILLのみでは保証しない。
4. `IMPORTING`: PublisherがcandidateをROから読み取り、**新たな物理バイト列**をprivate import rootにcopyし両Table+全metadata+Catalog+Coverage/Merkleを構築/Hash再照合。Copy前/後の候補Hash比較も要求。失敗時は破棄・非公開。`fsync(files)`, `fsync(directories)`、Seal Actorへの所有権/書換え能力移管、atomic rename後の親directory `fsync`、Published rootの実効RO保護を要求。Seal後のPublisherは旧Import dirfd含む書込能力を失い、GC Actor以外に公開物理File削除能力を渡さない。Filesystem/Storageがそれらを保証しなければ未承認。
5. `SEALED/VERIFIED`: Artifact Pair rootのWriter到達可能性ゼロ、内容をHash Manifest/Merkle、semantic metadata revision、retrieval pair lookup/Provenance/Dimension/Prepared identity、Journal/Coverage確定と照合。`SEALED`はbyte不変の主張、`VERIFIED`は意味論までの合致。**File HashだけではEmbedding一致を保証しない**。
6. `PREPARED`: Durable prepared manifest/physical-id/verification receiptを登録（非Active）。`ACTIVE`: 下記**単一SQLite CAS**でLogical Active pointerを切り替える。旧SnapshotはPin中Retain、既存検索を実行し続ける。`RETIRE`後もGC until safe。
7. `DELETE_INTENT`: CoordinatorがActive/Prepared/Pin/Writer/Revocation Ledger参照を確認し、SQLite durable delete intentを先にcommit。GC Actorが**物理IDホワイトリスト**の所有ディレクトリのみ削除。途中Crashはidempotent再開し、Active復帰させない。

Snapshot Pair Manifestは `physicalPairId`, `logicalGenerationId`, `legacyPhysicalRoot`, `structuredPhysicalRoot`, `catalogRevision`, `coverageRoot`, `merkleRoot`, `documentProfile`, `spaceFingerprint`, `effectiveInputIdentity`, `providerProvenance`, `fileGeneration`, `fenceId`, `journalId`, `parentSnapshotId`, `fileHashTree`, `sealReceipt`, `status` を不可分にbindingする。**Rev5ではさらに** `provenanceSchemaVersion`, `expectedPreparedInputRoot`, `observedPersistedVectorRoot`, `completenessReceiptRoot`, `legacyVectorRoot`, `structuredVectorRoot`, `sourceBaselineRoot` を加える。Legacy/Structured検索APIは**一度取得した同一ManifestとPin**から両方を開き、片方だけ新Generationへrefreshしない。

### 2.2.1 Vector単位のProvenanceとSnapshot集合的完全性（Review-004）

**異なる二系統の証拠を独立に導出**し、単一の`effectiveInputIdentity`、dimension、row countだけで`VERIFIED`にしない。構造は次のとおり（具体的な正規化形式はR3前にversion固定、検証不能ならSemantic Activation禁止）。

1. **Expected ledger**: Source baseline + scan watermark + canonical Chunker/Profileから、LegacyとStructuredそれぞれの`(tableKind, sourceKey, sourceVersion, chunkOrdinal, chunkId, preparedInputDigest, role, taskType, canonicalizationVersion, effectiveInputIdentity, spaceFingerprint, expectedStatus)`を作る。`expectedStatus=SKIP`は、公開された除外根拠と入力証拠を**明示的な別record**に持ち、黙示の欠落には使わない。LedgerはVector生成・行の実読取より**前**に内容固定し、別の検証経路がsource inventoryから再導出する。Expected rootを観測Vectorだけから作ってはならない。
2. **Per-vector receipt**: 各実Vectorについて、上記の唯一のChunk key、prepared input SHA-256、effective role/task/Unicode、プロバイダ実行識別または承認済みDeclared ID、provider execution-binding receipt ID（可能な場合）、embedding response digest、persisted vector bytes digest（byte orderとdtypeをversion固定）、dimension、physical row key、tableKindをbinding。`vectorDigest`は**LanceDBから読み戻したpersisted value**と検証する。実際のProvider実行証明が無い場合は証明不足と明記し、Automatic identityへ格上げしない。
3. **Bijection+completeness**: Expectedの`INCLUDE`全キーについて**exactly one**のPersisted row+receiptが存在し、Observedにexpected外の行・duplicate key・不一致のvector digestが**0**。SKIPキーも理由・許可規則まで一致させる。旧generationと新generation、LegacyとStructuredの混合を禁ずる。Fullは全source、Incrementalは**不変引継ぎ分を含む新物理Pairの全行**で照合し、変更分だけの数え上げを不可とする。
4. **Deterministic roots**: Domain separationされたSHA-256 + RFC8785正規化JSONでkey昇順（`tableKind, sourceKey, sourceVersion, chunkOrdinal, chunkId`、同Keyは即FAIL）に配列またはMerkle treeを構築する。`expectedPreparedInputRoot`、`observedPersistedVectorRoot`、`completenessReceiptRoot`、Legacy/Structured個別rootと`combinedPairRoot`をバージョン付きで作成。期待と観測の**異なるschemaのroot値自体は等しくなくてよい**。それぞれの集合をkeyでjoinした検証receiptに結果、件数、差集合ハッシュ、例外リストrootを記録し、Manifestへbindする。Tree rootが自己申告のみで再算出不能ならINCONCLUSIVEではなくActivation DENY。
5. **Independent validation**: Publisher側とVerifier側の独立したread-only enumeratorでSource/Prepared Input ledgerとLanceDB全永続行を列挙し、Manifest自体の自己証明循環を防止。Hash一致は「保存時点で行が同じ」ことの証拠であり、未検証のProvider動作やruntime identityの真実性まで証明しない。Source mismatch、scan gap、unknown provider binding、Merkle検証失敗は`COVERAGE_INVALID`/`PROVENANCE_INVALID`でFail-closed。Exact/Grepは別Authority。


### 2.3 Full/Incremental共通Snapshot CAS

`publicationRevision`, `authorityRevision`, `slotRevision` は別軸。`AcquireSlot`が`slotRevision`/`authorityRevision`を進めても、所有者が正当な親`basePublicationRevision`に基づくCommitを失敗させない。例:

```text
BEGIN IMMEDIATE (SQLite)
 assert operation/slot ownership + expected slotRevision/fence/fileGeneration;
 assert authorityRevision == recorded authorized revision (必要な遷移規則を適用);
 assert active.snapshotId == parentSnapshotId;
 assert active.publicationRevision == basePublicationRevision;
 assert candidate VERIFIED + SEALED + DURABLE physicalPairId;
 assert Fingerprint/Profile/RetrievalPair/Coverage/Merkle/Journal/Fence all valid;
 assert !permanentlyRevoked(candidateGeneration) && !closed(runtimeEpoch);
 swap active (new physicalPairId, logicalGenerationId, publicationRevision+1);
 record commitReceipt (unique operationId), journal/coverage obligation, retired parent;
COMMIT (WAL synchronous FULL、実ストレージ耐久性前提はR3で確認)
```

`Commit` は**同一SQLite Transaction**以外に分割しない。CAS失敗のCandidateは `ABORTED/QUARANTINED`、新しい親名に付け替えて公開しない。Retryは新しいOperation・新規検証が必要。Duplicate Commit Receiptは保存済み結果を返し二重公開しない。Publicationはbyte移動でなく**Active pointer CAS**が線形化点。FullもIncrementalも**新しい物理Pair全体**を構築し、Incrementalで片側だけin-place mutateは禁止。Copy成本が許容できない場合は本Rev5下で性能要件を再評価、妥協でin-placeへ戻さない。

**同一互換性Rebuild:** 旧Active（かつ非revoked）PairのPin/検索を維持、Candidate構築を別領域で実行。CASで切替後もPin済み旧ReaderをGCしない。ただし**旧Readerが完成した結果の最終Publicationは§3.5の新Active照合によって拒否し、必要なら再検索**する。**非互換Rebuild:** 不一致をCoordinatorが認定した時点で旧Semantic Permitを同期C0でClosure、完全な新PairのVERIFIED+CASまではSemantic DENY。Identity verification failureによる一時Permit失効と、Identity ChangeによるGeneration永久失効を別のReason/台帳で管理する。Rollbackはrevocation ledgerを戻さない。

### 2.3.1 既存Full Rebuild JournalとのAuthority統合（Review-002）

**固定HEADの既存Phase名**は `building → legacy-swapped → structured-swapped → catalog-activated → merkle-activated → idle`（ユーザー提供の独立Reviewerによるソース照合結果）。本設計は旧`reconcileOnStartup()`の既存分岐を**そのまま新Snapshotに適用しない**。設計提案としてCoordinator管理の`protocolVersion = snapshot-cas-v2`/`authorityOwner = compatibility-coordinator`を**SQLiteにdurable登録**し、既存phaseは以下の`compatibility journal projection`として保存する。これは旧phase名を隠して削除するのではなく、古い物理`swap`の副作用を禁止し、同じJournalのRecovery入口を**Ownerで明示的に分岐**させる契約である。

| 既存6段階Journal | Snapshot状態/Authority | このPhaseで許される操作・禁止事項 | Crash/Recovery |
|---|---|---|---|
| `building` | `NEW/BUILDING/DRAINING/QUIESCED/IMPORTING` | CandidateのみMutable。新Pairは非Active。旧Active Pointer不変 | 未完成Candidateを隔離。旧Activeの検証済み許可状態のみ維持 |
| `legacy-swapped` | 新**独立物理**Legacyが`SEALED`、Structuredはまだ準備中 | **既存Active Legacyの物理swap禁止**。Shadow readiness receiptのみJournalへ追記 | 新Pairを非Active隔離、旧Legacy/Structured Pairは原子的に維持 |
| `structured-swapped` | Legacy+Structured双方`SEALED`（各root固定） | **既存Active Structuredのswap禁止**。同じphysicalPairIdへの準備記録 | 新Pairは非Active。片側だけActive化禁止 |
| `catalog-activated` | `VERIFIED/PREPARED`。Catalog/Coverage/Merkle/Provenanceは新Pairへbind済み | この名前は**shadow catalog ready**。Global Active Catalog、Search Permit、Pointerの更新禁止 | PREPAREDの孤児は非Activeのまま、再検証またはabort |
| `merkle-activated` | `ACTIVE` | **Active Pointer CAS + `publicationRevision`増分 + journal phase遷移 + commit receipt + retire parentを同じSQLite commit**。旧ファイルの置換は行わない | CASとphase両方あり→Finalizeのみ。片方しかなければ整合性違反でSemantic DENY |
| `idle` | `ACTIVE`の後処理完了（または旧Operationが安全にabort済み） | Finalizeのみ。**独立の2度目Activation権限なし**。Revocation/Pointerを書き換えない | 新Owner Recoveryがdurable receiptで再実行可能な後処理だけ実施 |

**単一Authorityの規範:** `Snapshot CAS`、Journalのowner/version/phase、Operation/Parent、Coverage/Merkle/Provenance root、Revocation Ledger、commitReceiptは**同じCoordinator SQLite authority**に属する。`merkle-activated`の状態とActive Pointer変更を**分割COMMITしてはならない**。§2.3のCAS例には `assert journal.owner/version && journal.phase == catalog-activated; update journal.phase=merkle-activated; record journal.linkedActivePointerReceipt=commitReceipt` を同一トランザクションに追加する。`idle`への移行は認可効果なし。Incrementalも同じ`phase`/CASを使い、既存Full Rebuild APIのin-place swapを呼ばない。

**Migration/Startup切替（未実装・R3で可否検証）:** 旧mode (`legacy-journal-v1` またはowner未設定) の**進行中**`building/legacy-swapped/structured-swapped/catalog-activated/merkle-activated`は、Rev5 Ownerへ黙って解釈変換しない。移行開始前はSemantic Admission停止、旧Modeの整合性を隔離環境で検査し、既存承認済みLegacy Recoveryの安全な完了が**確認された場合に限り**mode変更を独立したdurable migration receiptとしてCommitする。既存phaseが不整合・Legacy Recovery実行が安全に確定できない場合は`MIGRATION_BLOCKED` + Semantic fail-closed。Mode変更後は旧`reconcileOnStartup()`、旧`swap`/rollback/finalize APIが新authorityファイルを触る操作を**起動前Dispatcher Guardで禁止**。Guard不能なら新Modeを有効化しない。新専用`reconcileCoordinatorJournal()`だけがphase+Pointer+Sealの同一Authorityを回復する。起動時に未登録mode、二重Owner、phase/Pointer矛盾がある場合は外部MCP Publicationを開く前に停止。旧Recoveryと新Recoveryを並列に起動しない。

**Rollback境界:** CAS**前**のOperation abortはCandidate/PREPAREDのみ撤去し、旧Activeへ一切変更しない。CAS**後**は旧snapshotをjournal rewindやin-place legacy swapで戻す操作は禁止。万一巻き戻し相当が必要なら**新しいOperation・新しい物理Pair・新しいVERIFY・新しいCAS**として審査し、過去に永久失効したGenerationを復活させず、`publicationRevision`を単調増加する。`merkle-activated`後のcrashは`idle` finalizeのみ実施、旧Reconcileのrollback分岐を使わない。


### 2.4 Reader Pin / GC / Recovery

ReaderはSnapshot PointerをSQLiteで`ACTIVE & !DELETE_INTENT & !revoked`と検証し、**同じSerializable gate transactionでDurable Reader Pinを取得**したのち実FileをOpenする（GC intent取得とPin取得を直列化）。Pinは`physicalPairId, connectionIncarnation, processIdentity, expiry, openHandles, leaseEpoch`を含み、Pin取得に失敗した場合Fileを開かない。Lease expiryだけで削除を許すのは危険: ReaderがOS FD/マップを保持し得るため、終了/FD閉鎖/隔離確認がなければ`GC_BLOCKED`。プロセス死やhost再起動の不確かな状況では保持を優先し、リソース上限超過時はSemantic拒否（安全性優先）。Active PairはGC対象外。

Crash Recoveryは (a) SQLite WAL/commit receipts/revocation ledger/slot+GC intents再読込、(b) 親Snapshotのread-only byte/hash/Provenance照合、(c) 未完了IMPORTを非Activeに維持、(d) PREPAREDで非Activeの物理Pairは決して暗黙Active化しない、(e) ACTIVE参照欠落/Hash差異はSemantic fail-closed、(f) DELETE_INTENTはActor限定で再開、(g) Durable Revocation LedgerはRollbackや同Fingerprintで復活しない、の順で実施。Manifestの順序はFile fsync→dir fsync→rename+parent fsync→SQLite CAS（同一信頼可能FS、WAL設定の前提）。SQLiteとFilesystemの異なる障害領域を単一Atomic Transactionと偽らず、Recoveryで安全側へ収束させる。Powerloss後の実証は別ゲート。

## 3. Transport代替と共通のPublication Authority

### 3.1 定義と線形化

- **C0（Synchronous Admission Closure）**: Coordinatorが**Identity Changeを権威として認識した瞬間**、最終Pの同一**同期Gate**に`CLOSED(epoch, reason, identityChangeNonce)`をpublishする**volatile線形化点**。既に準備済みPrivateEnvelopeと新規Terminal/Mutation Admissionを旧Permitでは許可しない。**Fを待たない**。C0はdurable writeの完了やIPC acknowledgementとは別。F待機中も旧Pは0件。`C0`以後の閉鎖は同一ProcessのGate Ownerが生存中に単調で解除不能。
- **F1（Durable Fence）**: C0後にRevocation Ledger / runtimeEpoch / fenceRevision /原因 / nonceをSQLite WAL `synchronous=FULL`等のdurable commitへ非同期に送る点。`C0 < F1`。F1成功後も旧Generationは永久失効。F1 `FAILED` または結果`UNKNOWN`はGateを**閉じたまま**`FENCE_UNRESOLVED`に固定し、旧Pも新Semantic Pも許可しない。F1の再試行は同じnonceでidempotent、UNKNOWNはreadback/ledger照合で確定するまで再認可しない。Storageが書込不能ならSemanticをfail-closed（構造化エラーもP可能な新安全Authorityが無ければConnection isolate）。
- **P（Publication Commit）**: payloadが**最終externally owned byte stream/HTTP response queueに取り消し不能に受理される**瞬間。BrokerはAuthority/Terminal前条件を確定した後、Gateを解放せず**同期的に最終`write`を実施**する。SDK `send()`/Handler return/IPC ackはPでない。`stdout.write(false)`も既受理P。Node HTTPの最初の`writeHead/write/end`がPになり、その後は部分送信を取り戻せない。Durable Terminal ClaimはP前に確定させるが、Claim≠P、Claim後にC0が起きた場合は旧PayloadのPを拒否し同Keyを再送しない（内部 `UNKNOWN_DELIVERY`/`TRANSPORT_FAILED`、相手へのError到達を保証しない）。
- **同期順序:** 同じGate上でPがC0より先に最終accept済みなら`P<C0`（C0後のpeer受信を許容）。C0が先なら`C0<=P`の旧Generation/Epoch Semanticは**必ずDENY**。`C0 < F1`であってもPを待つ必要はない。Gate内に`await`/IPC/send Promiseを入れない。Terminal Claim durable処理・長時間I/Oは**Gate外のprivate prepare**段階で行い、C0が到着するとGateが即座に閉じる。ただしGateOwnerの同期P callが既に進入した場合、そのPが先行するものとする。Gate取得待ちのidentity observationを「C0成立」と見なさない。
- **Process所有制約（Review-001）:** **Compatibility CoordinatorのIdentity recognition/decisionと、単一Final Publication BrokerのOS stdout FD/Node ServerResponse書込を同一孤立ProcessのGateOwnerで実行**する。Worker/SDK/Bridgeは外部FD/Socketを保有できず、署名済みPermitや別Workerの`READY_TO_SEND`をP許可として流用しない。外部Workerの`MISMATCH_OBSERVED`は**まだCoordinator認識ではなく**private入力であり、GateOwnerに到着して同期判定・C0を確立するまで非同期IPCレースが残る。したがって**Workerが独立にIdentityの権威判断を行う構成は禁止**。Coordinator決定を外部Processに置かねばならない構成は、同期C0/Pの共通所有を証明できる別方式がない限りSemanticをfail-closedとする。疑義を検知したWorker自身は直ちに局所出力を保留するが、**その保留を全BrokerのC0保証と偽らない**。
- **Crash durability条件:** 運転前にdurable `BOOT_UNCLEAN` / active authority epoch markerをセットし、Publication許可中は保持する。C0後F1前にProcess/crashまたは媒体障害なら、再起動は**全外部FDを閉じた状態**から始め、`BOOT_UNCLEAN` marker / fence結果 / Identityを検査し、F1未確認の旧epoch/Generationを**自動再開しない**。未解消のときはpre-crash epochを保守的に永久閉鎖し、新Generation/再検証+新CASがない限りSemantic不可。`BOOT_UNCLEAN`が無い/破損/耐久未証明の場合もfail-closed。これは電源断を実証したという主張ではなくR3/別Powerloss Gateで確認すべき設計条件。永久失効の監査台帳自体が物理的に失われた事象まで「耐久済み」とは主張しない。
- **保証不能な範囲:** `P<C0`受理済みByteがC0後にpeerへ到達すること、送信途中abort後の受領有無、Remote peer ACKの取消しは保証不能。規範上の禁止は**C0後の新規旧Semantic P**のみ。単にRuntime Epochを再発行して永久失効GenerationのResultを再認可することは不可。

`Publication Broker` はCoordinatorのCapabilityで認可される**最終FD/HTTP Socket/Node Response owner**。SDK/Handler/BridgeはBroker直前まで`PrivateEnvelope`のみ作り、外部FDへのwrite権限を持たない。`Envelope`は `(requestKey, transportInstance, connectionIncarnation, sessionId, ingressSequence, requestId, logicalGeneration, runtimeEpoch, snapshotPhysicalId, retrievalPairReceipt, payloadKind, terminalKind, durableFenceRevision, bytesDigest)` を保持。Ingress時のチェックは必要だが不十分で、BrokerがP直前に**最新権威とC0/Active Snapshot Pointerを再検査**。Clock/TTLのみのPermitは再検査の代替不可。

`terminalKind = semantic_result | structured_error | hybrid_grep_only | transport_failed`。`at-most-once` は同一RequestKeyについて**Terminal Claimの永続一回性**。予約後にCrashし実delivery不明の時は `TRANSPORT_FAILED/INDETERMINATE_DELIVERY` に安全側確定し、旧結果を再送しない（exactly-once配送や必ずエラー送信は保証しない）。新Connectionの同じJSON-RPC IDは新RequestKey。Proxy再試行時は元のidempotency identityの重複排除を定義する必要がある。

### 3.2 Transportごとの不可逆境界・Adapter

| 経路 | Pの位置、Adapter所有者 | Closure時に必要な動作 / 不適合時 |
|---|---|---|
| **MCP stdio v1.29.0** | SDKがフレーミングした完全JSONLを**Broker専有の実stdout FD**に`write()`で受け付ける瞬間。SDK側stdioのstdoutは外部peerではなくBrokerへのprivate pipe/virtual writable | Handler→SDK Responseは未公開。`write(false)`後の受理済Byteは撤回せず、未解決`drain` Promiseはbounded isolation・terminal failedで止める。外部FDをSDK/他Workerが保持する構成は禁止。BrokerがSDK internal queueを迂回/完全隔離できなければstdIO Semantic無効 |
| **Streamable HTTP JSON v1.29.0** | SDK Web Response/bodyをBrokerが完全bufferし、Nodeの`writeHead/write/end`の**最初のirreversible enqueue**直前に一回の認可+Terminal Claim。外部ServerResponseをBrokerが所有 | SDK response buffering中/await後は再認可。Content-Length/status/errorを再生成し、旧Bodyを一Byteも送らず新Authority下で構造化Error/Hybrid Grep-onlyへ置換可能な時のみ置換。すでにheaders/body開始したら旧semantic置換不可、abort/isolateでDelivery unknown |
| **SSE / streaming v1.29.0** | **各Event**のprivate→released commitと、各Event frameがNode response queueへ入る直前のP。Stream wrapper/Brokerが実書込を所有 | `storeEvent()`開始/完了後、SSE reconnect/replay時の独立新規認可。部分Event開始後はabortのみ、semanticの途中差し替え禁止。EventStore未設定の現行v1と将来EventStoreの試験を分離。Guardできないstore/replay経路はSSE Semantic/replay停止 |
| **Local HTTP v2 server@2.0.0** | `createMcpHandler` 内部ではなく **`toNodeHandler`→最終ServerResponse受理**直前。Node Adapter/Brokerが所有 | SDK v2からのWeb Responseは未公開Buffer扱い、Event/streamに同様のgate。SDK内部で先に不可逆Node writeしてしまうAPI形状はアダプト不可としてv2 Semantic停止 |
| **Nexus v1→v2 Bridge** | v1 Client/McpServer/InMemoryTransport等の**内部successは非P**。最終v2 Node HTTP ServerResponseの最初のenqueueでP | Bridge内部で許可されてから外部SDK/adapterまでの全 `await` の後に再判定。固定HEADのBridgeソースと実外部HTTPの組み合わせをR3で再検証。二重Terminalを外側Brokerで排除。内部SDKが外部socketを持つなら隔離/disable |

**API制御不能箇所の扱い:** 特に SDK内部が外部ServerResponse / stdoutへwriteできる場合、外側で`transport.send()`を包んでも安全ではない。Socket/FDの所有をBrokerへ移し、Web Responseや私的streamとして受け取るAdapterが必要。`storeEvent`を内部から呼ぶ経路はPrivate Store Wrapperで認可し、外部Replay APIもBrokerのみ実行可能にする。固定SDKでこの取り回しができるかは**R3で実証**。不可能な場合は該当transport modeをfail-closedする。SDK改造を暗黙の前提にしない。

### 3.3 Queue / Replay / Handler / Isolation の状態機械

`INGRESSED -> ADMITTED -> COMPUTING -> PRIVATE_BUFFERED -> PUBLICATION_PENDING -> CLAIMED -> P_ACCEPTED -> TERMINAL_RECORDED`。`C0` 競合時は`REVOKED_PENDING -> ERROR_PRIVATE -> (new authority re-admission) -> CLAIMED/P_ACCEPTED`、輸送不明時は`ISOLATED/TRANSPORT_FAILED`。`CLAIMED`以降の再公開は禁止。

- `admission`は計算権限でありPublication権限ではない。SDK handler遅延完了は旧Epoch envelopeとして破棄、新Epochの同一RequestKeyから自動Semantic再開しない。EventStoreは `PRIVATE(stored, epoch, gen, reason)`→`RELEASED`をCoordinator gateで管理し、`REVOKED` Eventを再度`RELEASED`へ戻さない。`storeEvent`のawait終了時には元Epochが失効していればreplay-ineligibleのまま。
- Replayは保存時/リリース時/リプレイ時の3段階で権威確認し、cursor/stream/sessionが新Epochを名乗っても**古いEventのauthを更新しない**。保存済み旧Eventの永続Tombstoneと安全なevent filteringを設定。SDK EventStoreがPrivate/Released状態を隠蔽できない場合、既存EventStoreを無効にしてSSE Semantic停止。
- `RequestKey`は transport instance + connection incarnation + session + protocol ID + **安定した論理ingress sequence**をbinding。新規到着時にconnection内in-flight ID mapから既存論理Requestを先に照合し、**同じpending IDのduplicateには同じsequenceを再使用**する。完全に終了した後の正当な同ID再利用は新sequenceとする。ただし完了後のネットワーク再送と新しい合法Requestは外部idempotency tokenなしには区別不能なので、跨接続/完了後の重複排除は明示tokenがある場合だけ保証。Terminal Claimはpayload bytesと一緒に唯一のbrokerで所有し、error/degradedへの置換は**CLAIM前**のみ。
- Transport Isolationは原因/FD/Queue/未解決Promiseを観測し、bounded drain成功なら確定、期限超過ならconnection破棄・fenceを保持する。`TRANSPORT_FAILED`を内部Durable記録するが、ClientにErrorが届いたと偽らない。**未解決Send PromiseがC0もF1も無期限阻止してはならない**。C0後の旧sendはF1の成否にかかわらずP不可とする。
- Multithread/multiprocess間のC0/Pは**Coordinator Identity DecisionとFinal Brokerを共存させた唯一のGateOwner**で同期排他する。F1 durable commitはGate外で非同期処理し、`await`をGate内に含めない。Broker故障/分離時はすべての新Pを拒否。ネットワーク分断したWorkerが旧FDを所有しているなら保証不成立、Semantic終了。SQLiteで「Claimだけ先行して外部writeが別Workerから遅延実行される」構成は不可。

### 3.4 `C0, F1, Mutation, P`の関係（Review-001）

```text
Authority GateOwner (= Coordinator Identity Decision + Final Write Broker)
  Identity recognition:  [Gate lock] C0:=CLOSED(epoch,nonce) [unlock]
      | no await / no SQLite / no cross-process IPC in critical section
      v
  private async durable work: F1 := SQLite commit(revocation nonce, epoch, ledger)
      | SUCCESS -> permanently closed; FAILED/UNKNOWN -> FENCE_UNRESOLVED (still CLOSED)

Worker: SDK handler -> PrivateEnvelope -> Broker private queue -> candidate terminal prepare
P attempt: [Gate lock] C0/epoch/activePair/revocation/check -> final write() [unlock]
       old + C0 present: reject, no final write
```

1. **Recognize → C0:** 最終Brokerと同一GateOwnerのみが権威ある`IDENTITY_MISMATCH_RECOGNIZED`を決定し、**同期的・優先的にAdmission CLOSED**へ状態更新する。ここで長時間F1を待たない。すべての新Mutation認可/Publication PのGate entryが閉鎖を確認する。変更検知を外部Workerへ権威移譲しない。
2. **C0 → F1:** Gate解放後にdurable ledger更新を試す。commit SUCCESS/FAILED/UNKNOWNのすべてで**旧Permitは閉鎖済み**。FAILED/UNKNOWN時は全新Semanticを停止しF1 readback/recovery必須、旧Generationを再有効化しない。DB復旧前のTransport/listenerは閉じる。`BOOT_UNCLEAN`のpreflight未成立ならそもそもSemantic P禁止。C0/F1が別トランザクションであることは意図的であり、F1をC0の線形化点と偽らない。
3. **Mutation:** Native Candidate I/Oの停止はC0によるAdmission拒否とは別。旧Candidateの残存I/Oはprivate領域から隔離し、Seal/Publisher/GC/Active CASはF1とOwner最新Authorityを検証する。公表済み物理Pairを変更できる権限は持たせない。
4. **P:** SDK非公開Envelopeをバイト完全化、Commit前にpin/Pair/coverage/vector receiptとterminal候補を評価。Durable Terminal Claimはprivate段階で記録、C0/Active CASをまたいでfinal送出する**事前許可ではない**。最終Gate内で現在のGeneration/Epoch/`activePhysicalPairId`/`publicationRevision`を確認し、非await final writeを実施。DB/Terminal前処理で長時間待機中のMismatchはGateのC0を先に通す。Claim後C0やPointer変更で失効したTerminalは**sendなし消費**（at-most-onceを優先）し、クライアントへの構造化Errorを偽装しない。
5. **Crash:** F1 commit unknownは照合までCLOSED。`BOOT_UNCLEAN`の保守的Recoveryではpre-crash Permitを全破棄し、復帰には新Epoch/Generation検証とdurable seal/ledgerが必要。Claim後P前killはunknown-deliveryとして旧Semantic再送禁止。SDK queue/stream/BridgeはBrokerへの新RequestKeyとして勝手に作り直さない。

### 3.5 Compatible Cutover時のSearch Result Publication（Review-003）

**区別すべき状態:** `COMPATIBLE_REPLACED` は正常なActive pointer変更であり、Identity Changeによる`PERMANENTLY_REVOKED`ではない。前者は旧Readerの**Pin/計算継続**を許すが、Cutover以降に旧Resultを**新規Pする権限は失効**する。後者は旧Generation/epochのすべての旧Semantic結果・旧snapshot再検索・Replayを永久拒否し、同一Fingerprint/巻き戻しでは復活させない。

| Search状態 | Active Pointer CASの前後 | 最終Pの規則 |
|---|---|---|
| S42がActive、S42検索進行中 | compatible S43のCAS前 | S42が現Active、Pin・Receipt・Authority有効、C0未成立ならP可 |
| S42 Pin済み、compatible S43がActive化 | CAS後（S42=`RETIRED`） | **S42 ResultのPは拒否**。Pinは旧I/O完了まで維持、旧結果はPRIVATEとして廃棄。永続Revocationは**付けない** |
| S43へ再検索中 | Fresh S43 Pin取得/新RetrievalPair Receipt | 同じ論理RequestKeyの**新attempt ID**。新Prepared Input、Query/Doc Identity、Coverage/Provenance、Deadlineを再検査。S43がまだActiveのときだけP可 |
| 再検索前または途中でIdentity ChangeのC0 | C0/F1成功・失敗・不明を問わない | 旧S42 Resultも旧GenerationのS43 ResultもP禁止。**旧Requestを別generationの旧Semanticとして再認可しない**。Error/隔離のみ |
| S43検索中さらにS44へcompatible cutover | retry budgetを消費 | 無制限ループせずdeadlineと最大attempt数で打ち切り、安全なError/Hybridへ移行 |

**Request lifecycle:** 初回Ingressで `RequestKey`/deadline、mode、attemptBudgetを固定する。`SNAPSHOT_SUPERSEDED`を内部で受けたら、**Terminal Claim前に限り**同じRequestKeyで`attemptId+1`（既定上限は最初の計算+1再検索、R3で固定）を開始。新Active Snapshotと別Pin、fresh runtimeEpochとRetrieval Pair Compatibilityを照合し、旧PinはOS FD/GC保全条件が揃ってからrelease。`attemptBudget`枯渇/Timeout/新Active非許可なら、**まだClaimがないときだけ**構造化`SNAPSHOT_SUPERSEDED`/`COMPATIBILITY_RETRY_EXHAUSTED`/`COMPATIBILITY_REVOKED`を最終Broker経由で一つ発行できる。HybridのGrep-onlyは**Working Treeを正本とする独立の新認可**が成立した場合だけ候補化し、旧Semantic Chunk/Vector Scoreは一切持ち込まない。Claim後cutoverなら結果再送・fallback claimし直しは禁止、内部`UNKNOWN_DELIVERY/TRANSPORT_FAILED`として保守的に閉じる。

**線形化:** S43 Active切替のCAS Commitと、P直前の`activePhysicalPairId + publicationRevision`検査は、**同じAuthority直列化に属する**。SQLite active確認と実Pの間に別process/awaitを挟むことは禁止。推奨構成はGateOwnerが**CAS開始前に全Semantic final-P Gateを一時 `CUTOVER_HOLD` として同期遮断**し、その状態を保持したまま唯一のAuthority queueでSQLite CASを実行する。CASのdurable結果をGateOwner自身がreadback確認して新Active Pointerを更新した**後**にのみ新SnapshotのPを再開する（通常のcompatible cutoverに永久Revocation C0は付けない）。この間にCAS以前のS42に対するPを通してはならず、CAS後に旧Pointer cacheから旧Pしてもならない。SQLite Commitが非同期で長時間かかっても、`CUTOVER_HOLD`はGate上で即時設定されており、結果UNKNOWNなら全Semanticを停止してDB再読込まで解除しない。`P`とActive CASが別Authority processの非同期通知だけで競う構成は不適合。R3-T08/T09で順序を反証する。

## 4. Crash/GC/AvailabilityのAcceptanceとFailure Matrix（新方式はまだ未実証）

| 障害 | 必要な応答 | 本Rev5での検証地位 |
|---|---|---|
| 同UID旧WriterがPublished/親/registryをopen・rename・prune | OSでdeny、公開Pair Hash不変 | R2 FAIL（旧方式）→A/B未証明 |
| Native API中SIGKILL、遅延I/O、残存FD | QuiescenceなければSeal不可、未知ならQUARANTINE | R2 INCONCLUSIVE → R3 |
| Pruneしながら旧Reader検索 / GCと新Pin同時 | published Versionをin-place pruneしない。Pin中物理Pair保持 | R2 FAIL（Version Pin）→ R3 |
| CAS親競合、Slot自競合、revoke/rollback | unique receipt、stale reject、永久Ledger保持 | R2 SQLite独立モデル限定PASS → 製品未証明 |
| `stdout.write(false)` / `drain`遅延 | `P<C0`なら配送遅延を認容、`C0<=P`なら旧Semantic Pを拒否、無限待ちなし | R2旧方式FAIL → R3 |
| SDK JSON buffer / SSE store/replay / Bridge await | 最終Broker gate、Replay永続失効、再送禁止 | R2旧方式FAIL、最終Replay INCONCLUSIVE → R3 |
| Partially sent SSE / crash during JSON body | 取り消さずisolate。Terminal delivery不明、Semanticを再送しない | R2観測専用、保証未証明 |
| Source watcher gap / baseline mismatch | `BASELINE_COMPLETE`、`RECONCILIATION_PENDING`（期限付き）、`COVERAGE_INVALID`を独立管理。安全性不明ならSemantic停止 | R2 Coverage独立モデル限定PASS |
| Startup directory/WAL/Manifest corruption | Semantic DENY、Legacy/Structuredを分離公開しない。Exact/Grep維持 | 未証明 |
| IdentityをC0として認識してからF1完了まで旧P競合 | 同期Gateで旧P拒否、F1 Failed/Unknownも再開不可 | **R4-REVIEW-001** → R3-T09未実証 |
| 6段階旧Journalと新CASが二重Recovery | owner/versionで旧Recovery遮断、`merkle-activated`+Pointer同一Commit、phase不一致Fail-closed | **R4-REVIEW-002** → R3-S05未実証 |
| S42 pin中、compatible S43がActive、旧検索が完成 | S42 Result P拒否、未ClaimのみS43 retry/error/Grep-only、永久失効を混同しない | **R4-REVIEW-003** → R3-T08/T09未実証 |
| 同dimension+同row countのVectorが欠落/入替/異provenance | ExpectedとPersistedの全Chunk keys/Vector receiptのbijection不一致でActivation拒否 | **R4-REVIEW-004** → R3-S06未実証 |

### 4.1 Coverageの規範的扱い

Source scan baselineは完了フラグのみでなく `root, revision, fileGeneration, hash, observed watch watermark, scan gaps` を含む。Watcherのイベント欠落は**最終再走査（working tree基準）**で検出し、Activationと同一SQLite transactionでreconciliation obligationをdurable保存。既に検証済み同一互換性Activeでは期限内・既知の安全ギャップなしに限り`RECONCILIATION_PENDING`として検索継続可能。未知ギャップ・scan error・Observed mismatch・期限超過・非互換Activation前の既知未処理変更では`COVERAGE_INVALID`としSemantic fail-closed。Exact/GrepのWorking Tree権威は変更しない。

## 5. R3へ渡す決定事項（提案、承認ではない）

1. 第一候補Aを実効OS別UID + private Publisher + 完全物理Pair + RO Reader + GC Actorとして試す。Aが実証不能ならBを別ゲートで検証し、単純namespace案へ戻さない。
2. MCP publicationは最終外部FD/Node response ownerで線形化するSingle Broker方式を試す。v1/v2 SDK/Bridgeの制御不能なpathが1つでも残ればそのpathをSemantic無効にする。
3. Storage/Transport共通のCoordinator authority、immutable Generation、durable revocationの不変条件を変更しない。R3はfeasibilityだけを評価し、製品統合Gateを自動通過させない。

**現在の結論：設計候補A + Publication Brokerを独立レビューへ提出。R3未実行、Section 4.1 GateはBLOCKED。**
