import { spawn } from "node:child_process";
import { readFile, mkdir, readdir, rename } from "node:fs/promises";
import { createWriteStream } from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { setTimeout as sleep } from "node:timers/promises";
import { finished } from "node:stream/promises";
import picomatch from "picomatch";

import { normalizeIgnorePaths } from "../utils/path-normalization.js";
import { buildNexusRuntime, type NexusRuntime } from "./index.js";
import { PathSanitizer } from "./path-sanitizer.js";
import { acquireProjectLock, type ProjectLockHandle } from "../utils/project-lock.js";
import { SemanticSearch } from "../search/semantic.js";
import { SearchOrchestrator } from "../search/orchestrator.js";
import { PluginRegistry } from "../plugins/registry.js";
import { IndexPipeline } from "../indexer/pipeline.js";
import { Chunker } from "../indexer/chunker.js";
import { TypeScriptLanguagePlugin } from "../plugins/languages/typescript.js";
import { PythonLanguagePlugin } from "../plugins/languages/python.js";
import { GoLanguagePlugin } from "../plugins/languages/go.js";
import { CLanguagePlugin } from "../plugins/languages/c.js";
import { CppLanguagePlugin } from "../plugins/languages/cpp.js";
import { CSharpLanguagePlugin } from "../plugins/languages/csharp.js";
import { JavaLanguagePlugin } from "../plugins/languages/java.js";
import { RustLanguagePlugin } from "../plugins/languages/rust.js";
import { OllamaEmbeddingProvider, resolveLocalOllamaBaseUrl } from "../plugins/embeddings/ollama.js";
import { InstrumentedEmbeddingProvider } from "../plugins/embeddings/instrumented.js";
import { OpenAICompatEmbeddingProvider } from "../plugins/embeddings/openai-compat.js";
import { BedrockEmbeddingProvider } from "../plugins/embeddings/bedrock.js";
import { SqliteMetadataStore } from "../storage/metadata-store.js";
import { LanceVectorStore } from "../storage/vector-store.js";
import { LocalContentStoreFactory } from "../storage/local/local-content-store.js";
import { RipgrepEngine } from "../search/grep.js";
import { FileWatcher } from "../indexer/watcher.js";
import { EventQueue } from "../indexer/event-queue.js";
import { MetricsCollector } from "../observability/metrics-collector.js";
import type { Config, GrepMatch, IndexEvent, ReindexOptions } from "../types/index.js";
import { DEFAULT_OLLAMA_NUM_THREAD } from "../config/index.js";
import { SymbolRetrievalService } from "../structured/retrieval-service.js";
import { StructuredIndexCoordinator } from "../indexer/structured-index-coordinator.js";
import { ProjectWriteCoordinator } from "../indexer/project-write-coordinator.js";

/**
 * Type-safe interface for ripgrep JSON output.
 */
interface RipgrepMatchData {
  type: "match" | "begin" | "end" | "summary";
  data: {
    path: { text: string };
    line_number: number;
    lines: { text: string };
    submatches: Array<{
      start: number;
      end: number;
      match: { text: string };
    }>;
  };
}

/**
 * Handles directory scanning and file discovery.
 */
class DirectoryScanner {
  private static scanCounter = 0;
  private static readonly LOG_THROTTLE_THRESHOLD = 100;

  static async scan(
    dir: string,
    projectRoot: string,
    ignorePaths: string[],
    onProgress?: (msg: string) => void,
    isInitial = true,
    isIgnored?: (path: string) => boolean,
  ): Promise<IndexEvent[]> {
    if (isInitial) {
      this.scanCounter = 0;
      const patterns = normalizeIgnorePaths(ignorePaths);
      isIgnored = picomatch(patterns, { windows: true });
    }

    const entries = await readdir(resolve(dir), { withFileTypes: true });
    const events: IndexEvent[] = [];

    for (const entry of entries) {
      const fullPath = join(dir, entry.name);
      const relPath = relative(projectRoot, fullPath);
      const relPathForMatch = relPath.split(sep).join("/");

      if (isIgnored?.(relPathForMatch)) {
        continue;
      }

      this.scanCounter += 1;
      if (onProgress && this.scanCounter % this.LOG_THROTTLE_THRESHOLD === 0) {
        onProgress(
          `Scanning progress: ${this.scanCounter} entries reached (currently at ${relPath})`,
        );
      }

      if (entry.isDirectory()) {
        events.push(
          ...(await this.scan(
            fullPath,
            projectRoot,
            ignorePaths,
            onProgress,
            false,
            isIgnored,
          )),
        );
      } else if (entry.isFile()) {
        events.push({
          type: "added",
          filePath: relPath,
          detectedAt: new Date().toISOString(),
        });
      }
    }
    return events;
  }
}

/**
 * Manages storage initialization and directory creation.
 */
class StorageManager {
  static async ensureDirectories(config: Config): Promise<void> {
    const root = resolve(config.storage.rootDir);
    const meta = dirname(resolve(config.storage.metadataDbPath));
    const vector = resolve(config.storage.vectorDbPath);

    await mkdir(root, { recursive: true });
    await mkdir(meta, { recursive: true });
    if (!config.storage.vectorDbPath.startsWith("memory://")) {
      await mkdir(vector, { recursive: true });
    }
  }

  static initializeStores(config: Config) {
    const metadataStore = new SqliteMetadataStore({
      databasePath: config.storage.metadataDbPath,
      batchSize: config.storage.batchSize,
      deferFullRebuildRecovery: true,
    });

    const vectorStore = new LanceVectorStore({
      dbPath: config.storage.vectorDbPath,
      dimensions: config.embedding.dimensions,
      deferRebuildCleanup: true,
      rebuildJournal: metadataStore,
    });

    return { metadataStore, vectorStore };
  }
}

/**
 * Orchestrates background event processing and file watching.
 */
class EventProcessingManager {
  private abortController = new AbortController();
  private drainTask?: Promise<void>;
  private fullScanPromise?: Promise<void>;

  constructor(
    private config: Config,
    private projectRoot: string,
    private ignorePaths: string[],
    private pipeline: IndexPipeline,
    private loadFileContent: (path: string) => Promise<string>,
    private onLog?: (msg: string) => void,
    private metricsCollector?: MetricsCollector,
  ) {}

  setup(): { eventQueue: EventQueue; watcher: FileWatcher; onClose: () => Promise<void> } {
    const eventQueue = new EventQueue({
      debounceMs: this.config.watcher.debounceMs,
      maxQueueSize: this.config.watcher.maxQueueSize,
      fullScanThreshold: this.config.watcher.fullScanThreshold,
      concurrency: 4,
      metricsHooks: this.metricsCollector,
      onFullScanRequired: () => {
        const p = this.triggerFullScan('overflow-recovery').finally(() => {
          if (this.fullScanPromise === p) {
            this.fullScanPromise = undefined;
          }
        });
        this.fullScanPromise = p;
        return Promise.resolve();
      },
    });
    this.pipeline.setEventQueue(eventQueue);

    const watcher = new FileWatcher(
      { projectRoot: this.projectRoot, ignorePaths: this.ignorePaths },
      eventQueue,
    );

    this.drainTask = this.startDrainLoop(eventQueue);

    return { eventQueue, watcher, onClose: () => this.stop() };
  }

  private async stop() {
    this.abortController.abort();
    await Promise.allSettled([
      this.drainTask ?? Promise.resolve(),
      this.fullScanPromise ?? Promise.resolve(),
    ]);
  }

  private async triggerFullScan(
    reason: ReindexOptions['reason'] = 'overflow-recovery',
    retryCount = 3,
    baseDelayMs = 1000,
  ) {
    for (let attempt = 0; attempt < retryCount; attempt += 1) {
      if (this.abortController.signal.aborted) {
        return;
      }

      try {
        const result = await this.pipeline.reindex(
          () =>
            DirectoryScanner.scan(
              this.projectRoot,
              this.projectRoot,
              this.ignorePaths,
              this.onLog,
            ),
          this.loadFileContent,
          true,
          reason,
        );

        if ("status" in result) {
          if (result.status === "already_running") {
            throw new Error("already_running");
          }

          this.onLog?.("[Nexus] Background full scan incomplete; dead-letter queue entries remain.");
          return;
        }

        if (this.onLog) {
          this.onLog("[Nexus] Background full scan completed successfully.");
        }
        return;
      } catch (err) {
        const isAlreadyRunning = (err as Error).message === "already_running";
        const msg = `[Nexus] Background full scan ${isAlreadyRunning ? "skipped" : "failed"} (attempt ${attempt + 1}/${retryCount})`;

        console.error(msg, err);
        if (this.onLog) {
          this.onLog(`${msg}: ${err}`);
        }

        // Use a dynamic check to prevent static analysis from falsely claiming this is always truthy
        const shouldWait = attempt < retryCount - 1;
        if (shouldWait && !this.abortController.signal.aborted) {
          const delay = baseDelayMs * Math.pow(2, attempt);
          try {
            await sleep(delay, undefined, {
              signal: this.abortController.signal,
            });
          } catch {
            // AbortError is expected
          }
        }
      }
    }
  }

  private async startDrainLoop(eventQueue: EventQueue) {
    while (!this.abortController.signal.aborted) {
      try {
        await eventQueue.drain(async (event) => {
          if (event.type === "reindex") {
            await this.triggerFullScan(event.options.reason ?? 'manual');
          } else {
            await this.pipeline.processEvents([event], this.loadFileContent, { trackProgress: false });
          }
        });
      } catch (error) {
        console.error("[Nexus] Error in event queue drain loop:", error);
        if (this.onLog) {
          this.onLog(`[Nexus] Error in event queue drain loop: ${error}`);
        }
      }

      try {
        await sleep(500, undefined, { signal: this.abortController.signal });
      } catch {
        // AbortError is expected when the loop should terminate
      }
    }
  }
}

/**
 * Enforces NEXUS_PACKAGE_MODE constraints. In package mode the embedding
 * provider is hard-locked to "bedrock"; any other provider fails fast.
 * model / dimensions / region remain deploy-variable and are NOT validated here.
 */
export function assertPackageModeConstraints(config: Config): void {
  if (!config.packageMode) {
    return;
  }
  if (config.embedding.provider !== "bedrock") {
    throw new Error(
      `NEXUS_PACKAGE_MODE requires embedding.provider="bedrock", ` +
        `but received "${config.embedding.provider}". ` +
        `The packaged plugin only supports AWS Bedrock embeddings.`,
    );
  }
}

export class NexusServerFactory {
  /**
   * Creates and initializes a NexusRuntime based on the provided configuration.
   */
  static async createRuntime(config: Config): Promise<NexusRuntime> {
    const { projectRoot } = config;
    await StorageManager.ensureDirectories(config);

    // Acquire project-level lock to prevent multiple Nexus instances on the same project
    let projectLock: ProjectLockHandle | undefined;
    try {
      projectLock = await acquireProjectLock(config.storage.rootDir);
    } catch (lockError) {
      console.error('[Nexus] Failed to acquire project lock:', lockError);
      throw lockError;
    }

    try {

    const { metadataStore, vectorStore } =
      StorageManager.initializeStores(config);
    const pluginConfig =
      config.http !== undefined && config.embedding.provider === "ollama"
        ? {
            ...config,
            embedding: {
              ...config.embedding,
              baseUrl: await resolveLocalOllamaBaseUrl(config.embedding.baseUrl),
            },
          }
        : config;
    const pluginRegistry = this.setupPluginRegistry(pluginConfig);
    const metricsCollector = new MetricsCollector({ projectName: config.projectName || basename(projectRoot) });
    let embeddingProvider = pluginRegistry.getEmbeddingProvider();

    if (!embeddingProvider) {
      throw new Error("No embedding provider configured.");
    }

    embeddingProvider = new InstrumentedEmbeddingProvider(
      embeddingProvider,
      metricsCollector,
      config.embedding.provider,
    );

    const LOG_MAX_BYTES = 10 * 1024 * 1024;
    const LOG_MAX_FILES = 5;

    const logFilePath = join(config.storage.rootDir, "indexer.log");
    let logStream = createWriteStream(logFilePath, { flags: "w" });
    logStream.on("error", (err) => {
      console.error("[Nexus] Log stream error:", err);
    });
    let isBackedUp = false;
    let drainListener: (() => void) | null = null;
    const logQueue: string[] = [];
    let isRotating = false;
    let writtenBytes = 0;

    const rotateLog = async () => {
      if (isRotating) return;
      isRotating = true;

      if (drainListener) {
        logStream.off("drain", drainListener);
        drainListener = null;
      }

      logStream.end();
      await finished(logStream).catch(() => {});

      for (let i = LOG_MAX_FILES - 1; i >= 1; i--) {
        const oldPath = join(config.storage.rootDir, `indexer.log.${i}`);
        const newPath = join(config.storage.rootDir, `indexer.log.${i + 1}`);
        try {
          await rename(oldPath, newPath);
        } catch {
          // Ignore if file doesn't exist
        }
      }
      try {
        await rename(
          logFilePath,
          join(config.storage.rootDir, "indexer.log.1"),
        );
      } catch (err) {
        if ((err as NodeJS.ErrnoException).code !== "ENOENT") {
          console.error("[Nexus] Failed to rotate log:", err);
        }
      }
      logStream = createWriteStream(logFilePath, { flags: "w" });
      logStream.on("error", (err) => {
        console.error("[Nexus] Log stream error:", err);
      });
      writtenBytes = 0;
      isBackedUp = false;
      isRotating = false;
      flushLogQueue();
    };

    const flushLogQueue = () => {
      while (logQueue.length > 0 && !isBackedUp && !isRotating) {
        const line = logQueue.shift()!;
        const byteLength = Buffer.byteLength(line, "utf8");

        if (!logStream.write(line)) {
          isBackedUp = true;
          drainListener = () => {
            isBackedUp = false;
            drainListener = null;
            flushLogQueue();
          };
          logStream.once("drain", drainListener);
        }

        writtenBytes += byteLength;

        if (writtenBytes >= LOG_MAX_BYTES) {
          void rotateLog();
          // The loop will exit on next iteration because isRotating is now true
        }
      }
    };

    const onLog = (msg: string) => {
      const timestamp = new Date().toISOString();
      const line = `[${timestamp}] ${msg}\n`;
      try {
        if (writtenBytes >= LOG_MAX_BYTES) {
          void rotateLog();
        }

        if (isRotating || isBackedUp) {
          logQueue.push(line);
          return;
        }

        const byteLength = Buffer.byteLength(line, "utf8");
        if (!logStream.write(line)) {
          isBackedUp = true;
          drainListener = () => {
            isBackedUp = false;
            drainListener = null;
            flushLogQueue();
          };
          logStream.once("drain", drainListener);
        }

        writtenBytes += byteLength;
        if (writtenBytes >= LOG_MAX_BYTES) {
          void rotateLog();
        }
      } catch (e) {
        console.error(
          `[Indexer Log Error] Failed to write to ${logFilePath}:`,
          e,
        );
        console.error(`Original message: ${msg}`);
      }
    };

    const semanticSearch = new SemanticSearch({
      vectorStore,
      embeddingProvider,
      activeGenerationResolver: {
        resolveActiveGenerations: async (filePaths) => {
          return await metadataStore.getActiveGenerationMap(filePaths);
        },
      },
    });
    const grepEngine = this.createGrepEngine(projectRoot);
    const orchestrator = new SearchOrchestrator({
      semanticSearch,
      grepEngine,
      projectRoot,
    });



    const structuredIndexCoordinator = new StructuredIndexCoordinator({
      metadataStore,
      vectorStore,
      chunker: new Chunker(pluginRegistry, { maxChunkChars: config.indexing.maxChunkChars }),
      projectWriteCoordinator: new ProjectWriteCoordinator(),
      config: { embedding: { dimensions: config.embedding.dimensions } },
    });

    const loadFileBytes = (filePath: string) =>
      readFile(resolve(projectRoot, filePath));
    const loadFileContent = (filePath: string) =>
      readFile(resolve(projectRoot, filePath), "utf8");
    const pipeline = new IndexPipeline({
      metadataStore,
      vectorStore,
      chunker: new Chunker(pluginRegistry, { maxChunkChars: config.indexing.maxChunkChars }),
      embeddingProvider,
      pluginRegistry,
      structuredIndexCoordinator,
      loadFileBytes,
      maxFileBytes: config.indexing.maxFileBytes,
      chunkConcurrency: config.indexing.chunkConcurrency,
      embedBatchWindowSize: config.indexing.embedBatchWindowSize,
      onProgress: (msg) => onLog(msg),
      metricsHooks: metricsCollector,
    });

    const ignorePaths = config.watcher.ignorePaths ?? [];
    const eventManager = new EventProcessingManager(
      config,
      projectRoot,
      ignorePaths,
      pipeline,
      loadFileContent,
      onLog,
      metricsCollector,
    );
    const { eventQueue, watcher, onClose } = eventManager.setup();
    try {
      const sanitizer = await PathSanitizer.create(projectRoot);
      const workspaceId = config.projectName ?? projectRoot.split(/[\\/]/).findLast(Boolean) ?? 'unknown';
      const contentStore = new LocalContentStoreFactory({
        projectRoot,
        sanitize: (filePath) => sanitizer.resolveExisting(filePath),
      }).getStore(workspaceId, 'local');

      const symbolIgnoreMatcher = picomatch(normalizeIgnorePaths(ignorePaths), { windows: true });
      const symbolRetrievalService = new SymbolRetrievalService({
        catalog: metadataStore,
        sanitizer,
        isExcluded: (filePath) => symbolIgnoreMatcher(filePath),
      });

      return buildNexusRuntime({
        projectRoot,
        sanitizer,
        semanticSearch,
        grepEngine,
        orchestrator,
        vectorStore,
        metadataStore,
        pipeline,
        eventQueue,
        pluginRegistry,
        watcher,
        loadFileContent,
        contentStore,
        symbolRetrievalService,
        metricsCollectorRegistry: metricsCollector.registry,
        metricsPort: config.metricsPort,
        storageDir: config.storage.rootDir,
        projectName: config.projectName,
        metricsHooks: metricsCollector,
        aggregatorPort: config.aggregatorPort,
        packageMode: config.packageMode,
        onClose: async () => {
          await onClose();
          if (drainListener) {
            logStream.off("drain", drainListener);
          }
          logStream.end();
          await finished(logStream);
          if (projectLock) {
            await projectLock.release().catch(() => {});
          }
        },
        runReindex: () =>
          DirectoryScanner.scan(
            projectRoot,
            projectRoot,
            ignorePaths,
            onLog,
          ),
      });
    } catch (error) {
      await onClose();
      if (drainListener) {
        logStream.off("drain", drainListener);
        drainListener = null;
      }
      logStream.end();
      await finished(logStream).catch(() => {});
      throw error;
    }
  } catch (error) {
    if (projectLock) {
      await projectLock.release().catch(() => {});
    }
    throw error;
  }
}

  private static setupPluginRegistry(config: Config): PluginRegistry {
    assertPackageModeConstraints(config);
    const registry = new PluginRegistry();
    registry.registerLanguage(new TypeScriptLanguagePlugin());
    registry.registerLanguage(new PythonLanguagePlugin());
    registry.registerLanguage(new GoLanguagePlugin());
    registry.registerLanguage(new CLanguagePlugin());
    registry.registerLanguage(new CppLanguagePlugin());
    registry.registerLanguage(new CSharpLanguagePlugin());
    registry.registerLanguage(new JavaLanguagePlugin());
    registry.registerLanguage(new RustLanguagePlugin());

    let provider;
    switch (config.embedding.provider) {
      case "ollama": {
        const ollamaConfig = {
          ...config.embedding,
          ollamaNumThread: config.embedding.ollamaNumThread ?? DEFAULT_OLLAMA_NUM_THREAD,
        };
        provider = new OllamaEmbeddingProvider(ollamaConfig);
        break;
      }
      case "openai-compat":
        provider = new OpenAICompatEmbeddingProvider(config.embedding);
        break;
      case "bedrock":
        provider = new BedrockEmbeddingProvider(config.embedding);
        break;
      case "test":
        throw new Error(
          "Test embedding provider is not supported in production.",
        );
      default:
        throw new Error(
          "Unsupported embedding provider: " +
            String(config.embedding.provider),
        );
    }

    registry.registerEmbeddingProvider(config.embedding.provider, provider);
    registry.setActiveEmbeddingProvider(config.embedding.provider);
    return registry;
  }

  private static createGrepEngine(projectRoot: string): RipgrepEngine {
    return new RipgrepEngine({
      projectRoot,
      spawn: async (params, signal) =>
        new Promise((res, rej) => {
          const args = [
            "--json",
            ...(params.caseSensitive ? [] : ["--ignore-case"]),
          ];
          if (params.glob?.length) {
            params.glob.forEach((g) => args.push("--glob", g));
          }
          args.push("--", params.query, params.cwd);

          const child = spawn("rg", args, { signal });
          let stdout = "";
          let stderr = "";
          child.stdout.on("data", (d: Buffer | string) => {
            stdout += d.toString();
          });
          child.stderr.on("data", (d: Buffer | string) => {
            stderr += d.toString();
          });
          child.on("close", (code) => {
            if (code !== 0 && code !== 1) {
              rej(new Error(`ripgrep failed: ${stderr}`));
              return;
            }
            res(this.parseGrepOutput(stdout));
          });
          child.on("error", (e) => {
            if (e.name === "AbortError") {
              res([]);
            } else {
              rej(e);
            }
          });
        }),
    });
  }

  private static parseGrepOutput(stdout: string): GrepMatch[] {
    return stdout
      .split("\n")
      .filter((l) => l.trim() !== "")
      .map((line) => {
        try {
          const parsed = JSON.parse(line) as RipgrepMatchData;
          if (parsed.type !== "match") {
            return null;
          }
          return {
            filePath: parsed.data.path.text,
            lineNumber: parsed.data.line_number,
            lineText: parsed.data.lines.text,
            submatches: parsed.data.submatches.map((m) => ({
              start: m.start,
              end: m.end,
              match: m.match.text,
            })),
          };
        } catch {
          return null;
        }
      })
      .filter((m): m is GrepMatch => m !== null);
  }
}
