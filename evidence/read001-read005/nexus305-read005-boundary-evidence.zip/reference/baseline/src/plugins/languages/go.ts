import type { FileToChunk, LanguagePlugin, ParsedDeclaration, ParsedSourceFile } from '../../types/index.js';
import type { StructuredLanguageParser } from '../../structured/contracts.js';
import { GoStructuredParser } from './go-structured.js';
import type { GoTreeSitterRuntime } from './go-structured.js';
import { projectLegacyResult } from './tree-sitter-language-plugin.js';

/**
 * Builds a Go declaration by scanning lines until the braces are balanced.
 * Handles block comments, raw strings, and regular strings.
 * For functions and methods, it continues scanning until an opening brace is found.
 * For type aliases, it terminates if no brace is found on the first line.
 */
const buildGoDeclaration = (
  lines: string[],
  startIndex: number,
  type: ParsedDeclaration['type'],
  name: string,
): ParsedDeclaration => {
  let endIndex = startIndex;
  let braceDepth = 0;
  let seenOpeningBrace = false;
  let inBlockComment = false;
  let inRawString = false;

  for (let i = startIndex; i < lines.length; i += 1) {
    const line = lines[i];
    if (line === undefined) continue;
    let stripped = '';

    // Process character by character to handle multi-line comments and strings correctly
    for (let j = 0; j < line.length; j += 1) {
      if (inBlockComment) {
        if (line.charAt(j) === '*' && line.charAt(j + 1) === '/') {
          inBlockComment = false;
          j += 1;
        }
        continue;
      }

      if (inRawString) {
        if (line.charAt(j) === '`') {
          inRawString = false;
        }
        continue;
      }

      const char = line.charAt(j);
      const nextChar = line.charAt(j + 1);

      if (char === '/' && nextChar === '*') {
        inBlockComment = true;
        j += 1;
        continue;
      }
      if (char === '/' && nextChar === '/') {
        break; // Line comment, skip rest of the line
      }

      // Simple string literals (single line in Go)
      if (char === '"' || char === '\'') {
        const quote = char;
        j += 1;
        while (j < line.length && line.charAt(j) !== quote) {
          if (line.charAt(j) === '\\') j += 1; // skip escaped
          j += 1;
        }
        continue;
      }

      // Backtick raw strings
      if (char === '`') {
        inRawString = true;
        continue;
      }

      stripped += char;
    }

    const opens = (stripped.match(/\{/g) ?? []).length;
    const closes = (stripped.match(/\}/g) ?? []).length;

    if (opens > 0) {
      seenOpeningBrace = true;
    }

    braceDepth += opens - closes;
    endIndex = i;

    // For non-function declarations (like type aliases),
    // if we don't see an opening brace on the first line, we assume it's a single-line declaration.
    if (i === startIndex && !seenOpeningBrace && type !== 'function' && type !== 'method') {
      break;
    }

    if (seenOpeningBrace && braceDepth <= 0) {
      break;
    }
  }

  return {
    type,
    name,
    startLine: startIndex + 1,
    endLine: endIndex + 1,
    content: lines.slice(startIndex, endIndex + 1).join('\n').trim(),
  };
};

class GoParser {
  async parse(file: FileToChunk): Promise<ParsedSourceFile> {
    const lines = file.content.split('\n');
    const declarations: ParsedDeclaration[] = [];

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      if (line === undefined) continue;
      const trimmedLine = line.trim();

      if (trimmedLine === '') continue;

      // Handle imports
      if (trimmedLine === 'import (' || /^import\s+/.test(trimmedLine)) {
        let endIndex = i;
        if (trimmedLine === 'import (') {
          while (endIndex < lines.length) {
            const currentLine = lines[endIndex];
            if (currentLine !== undefined && currentLine.trim() === ')') {
              break;
            }
            endIndex += 1;
          }
        }

        declarations.push({
          type: 'import',
          name: 'imports',
          startLine: i + 1,
          endLine: endIndex + 1,
          content: lines.slice(i, endIndex + 1).join('\n').trim(),
        });
        i = endIndex;
        continue;
      }

      // Handle grouped type declarations: type (...)
      if (trimmedLine === 'type (') {
        const startLine = i;
        let endIndex = i;
        while (endIndex < lines.length) {
          const currentLine = lines[endIndex];
          if (currentLine !== undefined && currentLine.trim() === ')') {
            break;
          }
          endIndex += 1;
        }

        // Extract individual types within the block
        for (let j = startLine + 1; j < endIndex; j += 1) {
          const currentLine = lines[j];
          if (currentLine === undefined) continue;
          const innerLine = currentLine.trim();

          // Pattern for identifiers in type blocks - broadened to support more types
          const innerTypeMatch = /^([A-Za-z_][A-Za-z0-9_]*)(?:\[[^\]]*\])?\s+([A-Za-z_\[*].*)/.exec(innerLine);
          const typeName = innerTypeMatch?.[1];
          if (typeName) {
            const decl = buildGoDeclaration(lines, j, 'class', typeName);
            declarations.push(decl);
            j = decl.endLine - 1;
          }
        }

        i = endIndex;
        continue;
      }

      // Handle single type declarations
      const typeMatch = /^type\s+([A-Za-z_][A-Za-z0-9_]*)(?:\[[^\]]*\])?\s+([A-Za-z_\[*].*)/.exec(trimmedLine);
      const typeName = typeMatch?.[1];
      if (typeName) {
        const decl = buildGoDeclaration(lines, i, 'class', typeName);
        declarations.push(decl);
        i = decl.endLine - 1;
        continue;
      }

      // Handle Methods
      const methodMatch = /^func\s*\([^)]*\)\s*([A-Za-z_][A-Za-z0-9_]*)(?:\[[^\]]*\])?\s*\(/.exec(trimmedLine);
      const methodName = methodMatch?.[1];
      if (methodName) {
        const decl = buildGoDeclaration(lines, i, 'method', methodName);
        declarations.push(decl);
        i = decl.endLine - 1;
        continue;
      }

      // Handle Functions
      const functionMatch = /^func\s+([A-Za-z_][A-Za-z0-9_]*)(?:\[[^\]]*\])?\s*\(/.exec(trimmedLine);
      const functionName = functionMatch?.[1];
      if (functionName) {
        const decl = buildGoDeclaration(lines, i, 'function', functionName);
        declarations.push(decl);
        i = decl.endLine - 1;
        continue;
      }
    }

    const sortedDeclarations = declarations.toSorted((left, right) => left.startLine - right.startLine);

    return {
      rootType: 'source_file',
      declarations: sortedDeclarations,
    };
  }
}

const textEncoder = new TextEncoder();

const sourceFor = (file: FileToChunk) => ({
  filePath: file.filePath,
  language: file.language,
  bytes: file.bytes ?? textEncoder.encode(file.content),
  text: file.content,
});

const loadTreeSitter = async (): Promise<GoTreeSitterRuntime> => {
  const [parser, go] = await Promise.all([import('tree-sitter'), import('tree-sitter-go')]);
  return { Parser: parser.default, Go: go.default };
};

export class GoLanguagePlugin implements LanguagePlugin {
  readonly languageId = 'go';

  readonly fileExtensions = ['.go'];

  supports(filePath: string): boolean {
    return this.fileExtensions.some((extension) => filePath.endsWith(extension));
  }

  async createStructuredParser(): Promise<StructuredLanguageParser> {
    const runtime = await loadTreeSitter();
    return new GoStructuredParser(runtime);
  }

  async createParser(): Promise<{ parse(file: FileToChunk): Promise<ParsedSourceFile> }> {
    const legacyParser = new GoParser();
    try {
      const structured = await this.createStructuredParser();
      return {
        parse: async (file) => {
          try {
            const source = sourceFor(file);
            const structuredResult = await structured.parseStructured(source);
            if (structuredResult.status === 'ok') {
              return projectLegacyResult(structuredResult, source, {
                rootType: 'source_file',
                typeFor: (kind) => kind === 'interface' ? 'class' : kind,
              });
            }
          } catch (error) {
            if (error instanceof Error) return legacyParser.parse(file);
            throw error;
          }
          return legacyParser.parse(file);
        },
      };
    } catch (error) {
      if (error instanceof Error) return legacyParser;
      throw error;
    }
  }
}
