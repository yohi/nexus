# Nexus #305 — Rev5 残留リスク / 独立 Review Gate 審査依頼

**申請種別:** Revision 5の**設計審査依頼**のみ。**Section 4.1 = BLOCKED**、Architecture提案は非承認、R3 Execution Gate未承認、製品実装/Implementation Plan作成未許可。Bedrock Automatic Mode個別保証も未承認。

## 1. 独立Reviewerへ提示する設計選択

推奨: **別OS PrincipalのNative Candidate Worker → private byte-copy Publisher → post-seal capability withdrawal → 完全別物理Immutable Legacy/Structured Pair → SQLite CAS Active Pointer → Pin-aware privileged GC**。Transportは **Single authoritative Publication Broker**が最終stdout FD / Node HTTP socketを専有し、Coordinatorと同期C0・非同期F1・最終Pを単一GateOwnerで直列化する。SSE Event StoreはPrivate/Released/Tombstonedの durable区別とreplay再認可を要する。対応不可経路はSemantic fail-closed。

採用しない: 同UIDで名前・パスのみ分けるStorage、LanceDB過去Version checkoutによるRetention、SDK `transport.send`入口のみの検証、`stdout.write(false)`をsend拒否とみなす論理、SDK内部許可をBridge外部送信許可へ流用する方式。

設計提出物相互参照:

- `SECTION4_1_REV5_PROPOSAL.md` — 不変条件・方式A/B・権限状態機械・C0/F1/P・6段階Journal・Cutover・Vector completeness・Failure Matrix。
- `R3_TARGETED_SPIKE_PLAN.md` — R3-S01〜S06、R3-T01〜T09の未実行Oracle。
- `FINDING_DISPOSITION.md` — EP-DES/EP41/EP42/SPIKE/R2 EVID/INV追跡。

## 2. 追加Finding / Review Questions（新規の未成立契約）

次のFindingは**R2 Evidenceを根拠とするRev5提案の残余検証課題**であり、実製品に既に存在するBugを断定しない。各FindingをFormal reviewerがSeverityや独立Gateの対象として審査する。

| Finding ID | Severity | 反例 / 失敗シナリオ | 最小修正・承認条件 | 関連INV / R3 |
|---|---|---|---|---|
| **RG-305-REV4-001** | **Major** | Candidate WriterのUIDを変えたが、旧Writerがpublished親dirfd、registry、Publisherの任意path RPC、Open FDを握っていてSeal後も更新。R2 `STORAGE-03`の同UID別connection成功が基礎反例。 | 「UID違い」のラベルではなく、**Parent/Shared metadata/FD/IPC全パスのnegative permission test**。post-sealでPublisher自体も公開物理ArtifactのMutation能力を失い、GC Actor以外は削除も不可。全readersがRO。 | 01/02/03/04、`S01/S02` |
| **RG-305-REV4-002** | **Major** | Candidateをbyte-copyしたがimport rootからPublishedへrename後、Publisherが同所有権でwriteできる。`chmod 0444`のみでは親directory rename/unlinkや高権限brokerを防げない。 | Seal Actorへ所有権/書換え能力を移管しPublisherのwrite/dirfd capabilityを破棄、RO mountまたは強制Immutable相当を検証。GCのDelete Intentに限り別限定Capabilityを発行。 | 02/03/04/05、`S01/S03/S04` |
| **RG-305-REV4-003** | **Critical (conditional)** | Coordinatorが「P許可」を出した後、別WorkerへIPC、`await`、Node queueが入り、C0が成立した後に旧Semanticが**初めて最終Writeに受理**。R2 HTTP/Bridgeが具体例。 | Brokerが**最終外部FD/Node ServerResponseを専有**し、同期C0と実Pの同一Gate（F1はC0後のdurable処理）を同じ直列化点へ収める。跨Process commit-ready Queueを禁止。実SDK最終送信観測で因果的に証明。成立しなければ該当transportのSemantic停止。 | 01/02/06、`T01/T03/T06/T07/T09` |
| **RG-305-REV4-004** | **Major** | `stdout.write(false)`を未公開扱いしてCancel/Close後の受理済みBufferがDrainで届く。未解決SendがF1を永久に待たせる。R2 `TRANSPORT-02-OS-STDOUT`で実受信。 | write acceptをPと記録、`P<C0`と`C0<=P`を分離。P前gate、bounded timeoutでisolate、P後は回収不可をAPI仕様に明示。 | 02/06、`T02` |
| **RG-305-REV4-005** | **Major** | `storeEvent()`保留中にC、保存後release/replayされる。最終R2 Replayは`AbortError`であり安全なreplay filterの成立を証明できない。 | SDK固定版の**真のcursor再接続**による旧Event非公開を実証。Store/release/replayの独立Gateと永続Tombstoneを要する。SDKで制御不能ならSSE Semantic/Replay無効。現行v1 EventStore未設定と区別。 | 02/05/06、`T05` |
| **RG-305-REV4-006** | **Major** | SQLite CASに成功したが物理pairの`fsync`/parent fsync不足でpowerloss後にManifest欠落。あるいはGC intentのみ残るがActorがActive File削除。 | Importの耐久化順序とGCの物理ID allowlist、Recoveryのfail-closedを固定。Crash/killの実R3とPowerlossは別証拠で判定し、未証明環境でActivation禁止。 | 03/04/05/07、`S04/S05` |
| **RG-305-REV4-007** | **Major** | `RequestKey`を受信ごとに新しいingressSequenceへ割り当てると、同じpending JSON-RPC IDの重複が**異なるKey**になり2回Terminal化する。R2 raw duplicate負例。 | Connection内のin-flight ID→**既存論理Requestの安定Sequence**マップとTerminal CASを定義。完了後の合法ID再利用と再試行の同一性は明示idempotency tokenがない場合に区別不能と認め、保証範囲を規範化する。Crash後unknown-deliveryの再送を禁止。 | 02/06、`T08/T09` |
| **RG-305-REV4-008** | **Major** | 同一Fingerprint旧Active Rebuild中に誤ってRuntime Epochを永久失効、検索継続が破壊。逆に非互換Fingerprintを「pendingだから」と放置し旧Semanticが発行。 | Verification failureによるPermit一時失効とIdentity ChangeによるGeneration永久失効を分離、Compatible旧Active継続・Incompatible即Closureをactual Searchとfinal Brokerで検証。 | 02/05/06/07、`S06/T08/T09` |
| **RG-305-REV4-009** | **Moderate** | 前回R1 ZIPは今回Hash一致でもR2実行時に原本がなく、R1→R2 Oracle差分が未監査。またSSE最終ReplayはAbortError。比較結果を「すべて解消」と報告。 | Review時点のR1原本/manifest確認を**限定**と明記、意味的diffは別記録。SSE Replay未成立は`INCONCLUSIVE`のまま、T05で再現。 | 横断、`T05` |
| **RG-305-REV4-010** | **Moderate** | Linuxに別UID/RO mount/namespaceが使えず、開発者が同UID通常ディレクトリへsilent fallback。R2 bwrapは権限不足でBLOCKED。 | OS capability matrixの**Fail-closed**を仕様に含め、代替B採用時はWORM/IAM credential separationとRO local cacheを別Gateで証明。未証明ホストではSemantic停止。 | 01/02/03/07、`S01` |
| **RG-305-REV4-011** | **Major** | Reader leaseのTTLが失効してもold processはopen FD保持。GCが古いManifest/data削除しold Readerが壊れる。R2 `STORAGE-04`の形を変えただけになる。 | `Reader Pin取得`と`GC DeleteIntent`の単一CAS、OS liveness/FD drainまで保持、不明時削除を保留。過剰保持ならAvailability調整し安全優先。 | 03/05/07、`S03/S04` |

**Severity優先:** REV4-003は、最終外部Publicationで閉鎖を無効化する経路が残るなら**Critical**として該当transportの採用を阻止。その他MajorはデザインレビューまたはR3安全Oracleの必須通過条件。Moderateも未処理のまま安全性を過大評価しない。

## 2.1 Rev4独立Reviewer 4件の修正Disposition（独立再審査を申請）

| Finding / Severity | 反例（Reviewer） | **Rev5最小修正条件に対する提出回答** | まだ証明していない事項 |
|---|---|---|---|
| `RG-305-R4-REVIEW-001` **Major** | Identity認識→F commit待機→旧Broker P | §3.1/3.4で**同Process GateOwnerの同期C0**を**F1開始前**に確立。F1 SUCCESS/FAILED/UNKNOWNでも旧P閉鎖維持。IPC受信とCoordinator認識を区別。`BOOT_UNCLEAN` + fail-closed restart。 | `T01/T09`の最終OS writeとの同期境界、F1 commit不明時のdurable replay、OS実FD ownership |
| `RG-305-R4-REVIEW-002` **Major** | `legacy-swapped`など旧Recoveryが新CASに競合 | §2.3.1で既存6phaseをOwner/Protocol別に写像。`merkle-activated`とPointer CASを同じSQLite COMMIT。新Modeで旧`reconcileOnStartup()`の起動をGuard、RollbackをCandidateに制限。 | 実旧Journal schema/APIの遮断可能性、migration中のincomplete legacy phase、`S05`全段階Crash |
| `RG-305-R4-REVIEW-003` **Major** | S42旧Pin→S43互換Activate→旧Result P | §3.5で旧Reader I/O継続とP拒否を分離。CAS後旧結果を捨て、未Terminal Claimのみbounded S43 retry。再試行不可ならError/独立Grep-only、永久失効は再認可禁止。 | `T08/T09`のCAS対P線形化、数度の連続Cutover、Claim後Unknown、Client Timeout |
| `RG-305-R4-REVIEW-004` **Moderate** | 単一Input Identityでは保存Vector全件を証明できない | §2.2.1でExpected Input ledgerとPersisted Vector receiptsの別々のroot、key-bijection、full+incrementalの全行、Publisher/Verifier再読込を要求。 | `S06`の実Vector readback/Independent expected ledger、Provider execution binding、canonical digest再現性 |

**判定:** 4件とも「**設計上修正を提出、独立Close前、動的未実証**」。独立Reviewerが原規範との整合とR3 Oracleの十分性を再判定する。今回の提出を`ACCEPT_FOR_R3_FEASIBILITY`、R3 Execution許可、Section 4.1承認と取り違えない。

## 2.2 Rev5で追加して監視する失敗・境界

| 新規追跡ID | Severity | 具体的反例 | 最小修正/否定条件 | R3 |
|---|---|---|---|---|
| `RG-305-REV5-012` | Major | GateOwner外のidentity detectorが「認識」と見なされ、IPC未配送中にP | Authoritative recognitionをGateOwnerに限定し、FD単一所有。外部detectorの遅延を保証窓から隠さず、成立不能構成はSemantic fail-closed | `T09-C` |
| `RG-305-REV5-013` | Major | C0直後F1 commit前にcrashしledgerに記録無し、旧Permitを再開 | `BOOT_UNCLEAN`をAdmission前durableに記録、Uncertain rebootはpre-crash epoch全閉鎖。Boot marker永続性が未証明ならSemantic停止 | `T09-D` |
| `RG-305-REV5-014` | Major | `catalog-activated`を旧Recoveryが実activeと解釈しLegacyのみ戻す | `authorityOwner/protocolVersion`で旧Recovery APIを起動前拒否、phase/Pointer同一CommitをS05で証明 | `S05-J1〜J6` |
| `RG-305-REV5-015` | Major | 同Fingerprintのcompatible cutoverはP permittedのままとしてS42結果がS43以降送信 | CASと最終Pを単一Authorityに直列化し、旧Snapshot結果Pを拒否、Claim前のみbounded retry | `T08-CUTOVER/T09-E` |
| `RG-305-REV5-016` | Moderate | Observed VectorからだけExpected rootを作り、欠落Chunkのcompletenessが誤PASS | source/Prepared Inputから独立Expected ledger、persisted-readbackとbijection、rootとexceptionの署名対象を分離 | `S06-P1〜P7` |

**危険な環境へのfallbackは禁止:** Publisher/Writer同UID、旧Version retention、SDK内部stdout/Socketの直接所有、旧Journal recoveryが迂回可能、同期C0とPを同じGateにできない、Expected ledgerを独立生成できない、のいずれかではその安全契約のSemantic Activation/Publicationを停止する。Exact/Grep独立性は維持する。


## 3. R2の未証明契約14項目との対応

以下は `R2:evidence/failure-matrix.json` の `residual[]` を基礎にしており、本書で「成功」に書き換えない。

| R2 residual ID | R2 status | Rev5の扱い・要求Gate |
|---|---|---|
| `PHASE0-ORIGINAL-ZIP` | BLOCKED | 今回添付R1 ZIPはHash/Manifestを読めたが、R2実行中未入手・差分未監査は保持。Evidence Review |
| `RG-305-SPIKE-003` | PASS | 固定パッケージ取得の範囲でのみ保持。R3環境固定 |
| `RG-305-SPIKE-001` | FAIL | 旧Version Pin不適合、物理Pair/S03で新規反証 |
| `RG-305-SPIKE-002` | INCONCLUSIVE | Native IO内Signal DeliveryをS02で再観測 |
| `PRODUCT-GATE1` | BLOCKED | Coordinator/Product Implementation Integration Gateに延期（R3のPASSで代替しない） |
| `PRODUCT-GATE4` | BLOCKED | Source Coverage/Indexer/Search統合Gateに延期 |
| `NATIVE-GC-RECOVERY` | BLOCKED | Pin/GC Native実証S04と製品Gate |
| `SAFE-OS-WRITER-ISOLATION` | BLOCKED | 別UID/RO mount強制S01、bwrap不可ならFail-closed |
| `FULL-NEXUS-RUNTIME-PUBLICATION` | BLOCKED | 実SDK Bridge limited test T07後も製品Gateを分離 |
| `JSON-BUFFER-TO-FENCE-SAFE-ADAPTER` | NOT_EXECUTED | 実WebResponse/NodeBroker T03/T06 |
| `SSE-EPOCH-AWARE-STORE-AND-REPLAY` | NOT_EXECUTED | Store completion/replay T05、現行v1とは別 |
| `CANCEL-AFTER-STDIO-WRITE-FALSE` | NOT_EXECUTED | OS stdout T02 |
| `HOST-POWERLOSS-RECOVERY` | NOT_EXECUTED | R3ではSIGKILL + fsync順序まで。真のpowerlossはSeparate Durability Gate必要 |
| `NATIVE-PIN-GC-AND-OLD-WRITER-GC-RACES` | BLOCKED | S03/S04 |

## 4. Gate通過のための判断依頼

### 4.1 独立Architectural Review（今回依頼）

Reviewerは、**今回のR4-REVIEW-001〜004の解消可否を最優先し**、次の事項について`ACCEPT_FOR_R3_FEASIBILITY / REVISION_REQUIRED / BLOCKED`のいずれかを判断し、**製品実装認可と区別**してください。

1. Rev5推奨Aの**強制可能なWriter/Publisher/Reader/GC権限分離**は旧同UID反例を除去する設計条件として十分か。Shared Metadata、親dir、opened FD、IPC proxy、root権限、Owner移転、post-seal immutableを漏らしていないか。
2. `QUIESCED -> IMPORTING -> SEALED -> VERIFIED -> PREPARED -> ACTIVE` と、既存Full Rebuild 6 phase（owner-version tagged）/Full・Incremental共通CAS、`publicationRevision`/`authorityRevision`/`slotRevision`/`parentSnapshotId`の比較点を承認できるか。Snapshot Hash/provenanceと物理耐久化の順序が充分か。
3. C0/F1/Pの共通Gateは、**最後の実stdout/writeHead/write/end**の直前で直列化できるか。`P<C0`後の配送遅延を仕様上許容するという限界を明確にできているか。未解決Promise・SDK内Buffer・v1/v2 Bridgeの迂回経路をどう禁止するか。
4. Raw SDKのEventStore/Replayは未認可であり、`TRANSPORT-03-SSE-STORE`の**最終Replay AbortError**と歴史的runを混同せずR3 Testとして成立しているか。現行v1 EventStore未設定と将来機構を区別しているか。
5. RequestKey重複認識/terminal claim/unknown deliveryの**at-most-once（not exactly-once）**契約は妥当か。
6. OSの不適合環境でSemanticをFail-closedとすること、同一互換性Rebuild時の旧検索継続/非互換Rebuild時のSemantic停止がINV-07に忠実か。
7. Provider Identity Contract、Approved Fingerprint Schema、Prepared Input、Exact Retrieval/Grep独立性とConflictしないか。
8. EP-DES/EP41 findingの**元原文・承認済みDesign blob**を別権威資料と突き合わせる必要があるか。このZIPは全文を含まないため、対応表の原文一致は未証明。

### 4.2 後続の独立R3 Execution Gate（今回は申請のみ）

Architectural Reviewが`ACCEPT_FOR_R3_FEASIBILITY`と判定して初めて、権限・専用環境・exact lockfile・fault injection・計測方法を含む別Execution Gate申請を作る。**本書はR3を実行する許可ではない**。R3はOS Native/SDK protected adapterの成立性だけを確認し、成果物にはSafety FailureとInconclusiveをそのまま残す。

R3 PASS後にも Product Integration Reviewが必要。実NexusのCoordinator、Native Indexer、Reader pair、Source Coverage、MCP全経路、GC、Rollback、Crash Recoveryとの統合は今回未実施。Section 4.1のFinal Approval、Implementation Plan承認、製品変更やrelease decision、Bedrock Automatic Mode個別保証に**自動的には連動しない**。

## 5. 最終リスク・承認境界

**現時点で証明されたのはR2の限定モデルPASSとNegative Controlによる旧方式の不適合、および添付アーカイブのHash/Manifest整合だけ。** Rev5提案自体のOS権限、native seal、immutable pair reader/GC、最終SDK write gate、Event replay、Cross-process durabilityは**すべて未実証**。

**Reviewerに求める結論:** `Revision 5 Architecture`をR3 Feasibilityの妥当な対象として審査すること。新規FindingにはID/Severity/具体的反例/最小修正条件で回答すること。**Section 4.1 Review Gate = BLOCKEDを維持**し、正式合格を宣言しないこと。

## 6. Rev5 提出時点のFormal Status

- **Revision 4 Review: `REVISION_REQUIRED`（維持）**。Rev5は4件への設計担当修正案であり独立判定を代行しない。
- **Revision 5 Review: `PENDING_INDEPENDENT_REVIEW`**。`ACCEPT_FOR_R3_FEASIBILITY`は未発行。
- **R3 Execution Gate: `NOT_AUTHORIZED`**、全R3 `NOT_EXECUTED`。
- **Section 4.1 Review Gate: `BLOCKED`**。Product implementation、GitHub変更、Implementation Plan、Design Spec全体承認、Bedrock Automatic Mode個別保証はいずれも未許可/未成立。
