# R3 execution runbook (prospective only)

Execution Gate: NOT_AUTHORIZED. This document is an experiment procedure, not
an implementation plan. All R3 tests and negative controls are NOT_EXECUTED.

## 1. Authorization hold point

The package author stops after handoff. An independent reviewer must review the
specific package ZIP SHA and amendment. The user must then explicitly approve
the named executor, venue, permissions, injection targets, resource limits and
command manifest. The environment administrator must bind actual principals,
paths, sockets, mounts and observers. A review verdict alone cannot authorize
signals, privilege use or installation. Keep Section 4.1 BLOCKED.

There is no supplied protected R3 executable harness. Do not invoke the R2
run-all script as if it were R3. Exact future command paths, adapter/harness
SHA and per-case selectors are TBD/approval required. Before execution, supply
an externally reviewed command manifest with argv arrays, working directory,
actor, environment allowlist, baseline/oracle SHA, side effects, timeout,
target PID policy and output paths for each run. Do not interpolate untrusted
review text into shell commands or invent runnable product commands here.

## 2. Environment preflight after approval

1. Read package SHA256SUMS and external ZIP sidecar; recheck original ZIPs,
   fixed commit, lockfile, command manifest and oracle hashes.
2. Administrator supplies $R3_ROOT on approved durable storage and creates
   run-<nonce>; bind realpath, device, inode and owner to the approval record.
   Reject existing roots, symlink ancestors, product paths and any .nexus data.
3. Provision separate principals and mount/ACL topology as approved. Record
   actual launcher, eUID/eGID/groups/caps/namespace and no inherited external
   stdout/socket or published writable FD for SDK/Writer/Publisher.
4. Install dependencies only in approved isolated root if PERM-DEPS is granted.
   Use the unchanged R2 lockfile and record integrity/actual native load. Do not
   substitute latest packages or alter product package files.
5. Record kernel/filesystem/mount options, SQLite version, journal_mode=WAL,
   synchronous=FULL, full schema/API hashes and observer capability. A genuine
   disk-backed fsync/rename profile is required for durability suboracles.
6. Freeze all selectors, reachable crash cells, barriers, safe/control variants,
   deadlines/limits and artifact destinations before the first run. Reject
   unknown or unmatched hashes. No experimental fallback is authorized.
7. Make BOOT_UNCLEAN durable before Semantic admission; no listener/private
   worker may bypass this. Capture boot incarnation and initial authority tuple.

Preflight version/read-only checks may be supplied by the executor; preflight
itself must not sneak in unapproved negative controls or native signal tests.

## 3. Run order and isolation

Use one run at a time, a fresh nonce/root and dedicated ports/pipes per variant.
Never overwrite previous evidence. Dependency order:

1. S01 isolation. If unsafe, stop Storage A expansion and classify blocked
   dependents; do not silently downgrade to same UID or Object Store B.
2. S02 native-in-flight signal and quiescence, classified separately.
3. S03 physical retention/pins; freeze verified pair fixture references.
4. S04 GC race/recovery and S05 journal/CAS/authority including Cases A/B/C/F.
5. S06 provenance and coverage, full/incremental and both tables.
6. T01 final stdout owner; T02 backpressure/close/cancel.
7. T03 JSON and T04 SSE; T05 future EventStore genuine replay.
8. T06 v2; T07 fixed-HEAD Bridge with synthetic handler and real output.
9. T08 duplicate keys/cutover retry; T09 same-owner C0/F1/CAS including A-F,
   on both actual stdout and HTTP v2. Reuse fixture receipts, not old permits.

The source plan's original evidence filenames are required in each row of the
matrix. Prefix them with evidence/results/ and add evidence/traces/<runId>.jsonl,
results/<test>/<runId>/result.json and immutable environment/oracle records.
Safe/control/model runs have separate IDs; R2 history is reference-only.

## 4. Injection target check

Before each approved signal or filesystem fault, compare operationId, nonce,
pidfd or PID+kernel starttime, TID/native FD inode and process tree with the
enrolled target. Validate the target still belongs to this run. Signal send
success is not proof of delivery during I/O; require observer delivery evidence.
Never use unbounded pkill, process-group kill, recursive delete or global mount
changes. Cross-UID observer/driver access is separately approved.

For database faults, name the actual transaction, WAL/DB inode, last commit
barrier and receipt nonce. For writes, name ServerResponse/FD/socket incarnation
and byte range. No time-only proof. For C0-before-CAS include an already begun
transaction held before final commit, not only a stale call made afterwards.

## 5. Stop, quarantine and rollback boundary

On a safe-variant forbidden transition, preserve the first counterexample and
stop expansion of that unsafe mechanism. An intentionally unsafe control may
produce its predeclared synthetic leak; record it separately and never promote
its result to a safe PASS. Any escape beyond the control's root/peer is a stop.

Immediately close experiment Semantic admission and isolate pending final
writes; preserve C0 and CUTOVER_HOLD distinctions. Capture current causal trace,
process/FD inventory, hashes, authority/WAL/receipts, exceptions and peer bytes.
No retry of an unknown-delivery terminal. Mark unobserved branches explicitly.

Before CAS: quarantine/abort candidate only; never modify old active pair.
After CAS: finalize using the new authority owner only; no journal rewind,
legacy swap, old pointer restore or revocation rollback. An uncertain tuple
stays closed. Permanent revocation cannot be cleared by cleanup or retry.

Resource/observer loss stops the run. Missing precondition is BLOCKED; an
attempted but unobservable window is INCONCLUSIVE. Do not extend runtime,
disk, privileges or fault range without an amended explicit approval.

## 6. Evidence closure and withdrawal

1. Emit a per-run result with actual/expected/counterexample, branch outcomes,
   limitation, causal graph and artifact hashes; preserve failed/unobservable
   attempts, not only successful reruns.
2. Reconcile all child/descendant/IPC writers, reader pins and open FDs. An
   uncertain live writer/reader means no deletion: retain QUARANTINED state.
3. Export stable database state with WAL relationship documented; no copying
   a live DB alone and claiming a coherent backup. Readback is done under the
   single authority and consistent transaction snapshot.
4. Hash all evidence excluding its own manifest, verify exact manifest coverage
   and ZIP CRC, then put ZIP and manifest checksums in an external sidecar.
5. With separately approved cleanup, administrator removes only enrolled
   disposable mounts/accounts/cgroup objects created for this run; restores no
   product state because product paths were never writable targets.
6. GC deletes only allowlisted retired roots after durable intent and proven
   zero pins/writers. Final root removal checks device/inode/nonce again. Preserve
   review/evidence ZIP outside deleted fixture roots, and record cleanup receipt.
7. Independent reviewer examines results. Even all PASS proves only this
   independent Spike scope, not product invariants or Section 4.1 approval.

No experiment procedure in this runbook was performed during package creation.
