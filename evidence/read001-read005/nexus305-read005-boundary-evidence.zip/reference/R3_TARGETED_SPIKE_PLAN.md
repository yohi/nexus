# Nexus #305 — R3 Targeted Feasibility Spike Plan（**計画のみ・未実行**）

> **目的:** Revision 5のStorage Publisher/OS権限とTransport Publication Brokerが**反証可能な形で成立するか**を確認する。これはImplementation Planでも製品統合の実行指示でもない。**独立実行担当と別途Execution Gateの承認が必要。Section 4.1はBLOCKED。**

**Revision 5改訂範囲（独立Review指摘への対応）:** `S05`に既存6段階Journalの全crash窓と旧Recovery禁止、`S06`に期待/保存Vector集合のbijection、`T08`にS42→S43のbounded retryと永久失効差、`T09`に**Identity認識=C0成立からF1完了まで**の旧P注入・F1失敗/UNKNOWN・同Process Gate・Crash/Bootとcompatible CASを追加。**以下はいずれも試験計画、未実行。** R3へのExecution Gateは発行しない。

## 1. 固定ベースラインと評価方法

**Pinned packages（全Test共通）**: `@lancedb/lancedb@0.18.2`、`@modelcontextprotocol/sdk@1.29.0`、`@modelcontextprotocol/server@2.0.0`（Local HTTP v2 / Bridgeで使用）、Node.js `>=24`（R2比較用はNode `26.10.0`、少なくともNode実バージョンを保存）。Apache Arrow peer dependencyを含むlockfile固定。Nexus固定HEAD `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d` に対し**read-only fixture**。独立Spike用ディレクトリ・コンテナ/OS principalでのみ検証。製品ソース/実データ変更禁止。ネットワーク・UID/cgroup/mount管理・fault injector・OS観測の利用には実行主体の別承認が必要。

事前条件: 結果・Oracleを**試験実行前に固定**。Node/package/native実ロード、OS/kernel/filesystem/mount flags、UID/GID/capabilities、lockfile SHA、ソースHEAD、ハーネス/Adapter SHAを保存。固定環境の準備ができなければ `BLOCKED`（依存不在や権限不足を機構のFAILと取り違えない）。各Test `PASS/FAIL/INCONCLUSIVE/BLOCKED`（必要ならNOT_EXECUTED）を区別する。

**Acceptance Oracle (AO):**

- `AO-S`: sealed Published Snapshot Pairの**全data/manifest/registry/parent metadata**、Catalog/Coverage/MerkleとProvenance hashがWriterから変化不能。`reader_pin`と`delete_intent`がCAS競合してもPin中削除なし。`PUBLISH`は正しいPair+Authority+Coverage+Slot/CASが成功した場合だけ。
- `AO-T`: `(C0 <= P) ∧ envelope.auth=old ∧ payload=semantic` が**0件**。`P<C0`でaccept済みのByteはC0後に到達してもFAILとしない。そのP時刻とaccept proofを要求。SDK buffering内はP未成立。各RequestKey Terminal Claimは高々1回。未解決Promiseはbounded isolation、delivery unknownをsuccessと偽らない。
- `AO-R`: C0 < F1 / F1_FAILED / F1_UNKNOWN時も旧P=0、起動前`BOOT_UNCLEAN`と再読込を要求。Crash/RestartでLedgerのrevocation・delete intent・Terminal Claimがrollback/replayで復活しない。不明状態はfail-closed。R3の成功を**製品本体のINV-01〜07全面PASSに換算しない**。
- `AO-C`: 全6段階Journal owner/version/Pointerのatomic整合、Expected/Observed全Vector集合同型検証、Baseline/Watcher gap/Journalとfingerprint/Prepared Input/provider provenanceが正しい時のみSemantic。Exact/Grepは別経路で動作し、HybridはGrep-onlyを別認可。R2モデルとの差分を実証する。

**因果時系列**: 一つのControlling Observerで`BARRIER_RELEASE`, `IDENTITY_RECOGNIZED`, `C0_SYNC_GATE_COMMIT`, `F1_BEGIN`, `F1_DURABLE_ACK/FAILED/UNKNOWN`, `BOOT_UNCLEAN`, `ACTIVE_CAS_AND_MERKLE_PHASE`, `P_ENQUEUE_ENTER/RETURN`, `WRITE_ACCEPT`, `READ_BYTES`, `SIG_DELIVERY`, `NATIVE_ENTER/EXIT`, `F1_FSYNC`, `RESTART`, `GC_INTENT`をイベントシーケンスで結ぶ。Process-local monotonic timeの大小をcross-process順序とみなさない。IPC barrier/OS probeの相関IDを使う。アプリ層の“送る予定”ログは最終writeの証拠ではない。全Testで最終Manifest/Hash/Result/exceptionを採取する。PASS時にtracesの矛盾・未観測境界があればINCONCLUSIVEへ下げる。

## 2. R3 Storageテスト

### R3-S01 — OS-enforced Writer Isolation / Shared Metadata

- **INV:** 01/02/03/04/05。**固定版:** 共通固定版、実 `lancedb@0.18.2`。
- **初期:** 旧Writer UID `u_candidate`、Publisher `u_publish`、Reader `u_reader`、GC Actorを別principalにし、Candidate RW / Published RO / publisher-owned parentとLanceDB registryを形成。old Writerは古いCandidate handleを保持。
- **注入:** 旧WriterがPublished `legacy.lance`/`structured.lance`/`_transactions`/`_versions`/`data`/index/registry/manifest/parent dirに別connectionで`open`, `append`, `rename`, `unlink`, `prune/optimize`, hardlink, symlink, dirfd/FD reuse, IPC broker requestを試みる。unprivileged Linuxと利用可能な別OS profileを明記。
- **期待トレース:** `OS_PRINCIPAL_PROVEN -> MUTATION_ATTEMPT -> EACCES/EPERM or unresolvable path -> COMPLETE_HASH_UNCHANGED -> READER_EQUAL`。Publisher/GCがold Writerに代行しない。**Seal後はPublisher自身からもPublishedへwrite/renameが拒否されること**、Seal Actorの所有権移管とGC限定Capabilityを確認。read-only bind mountのみの例外経路もテスト。
- **PASS:** 公開Parent/共有metadataまで全攻撃がOS権限で拒否、全byte Hash+Rows/Search不変、旧WriterからPublisher capability到達不能、Seal後Publisherも公開物理byte/parentを変更不能。**FAIL:** 1件でも変更、または同UIDで書ける bypass。**INCONCLUSIVE:** 権限境界が未成立/パス網羅不明。**BLOCKED:** UID/mount権限を使えない。
- **証拠:** `S01/principals.json`, `S01/mounts.json`, `S01/syscalls.jsonl`, `S01/paths-and-acls.json`, `S01/before-after-hashes.json`, `S01/lancedb-results.json`。
- **R2 Negative Controlとの差:** `STORAGE-03` は同UID別namespaceで100→101。R3は実際にOSがその操作を禁止するかを問う。R2 `STORAGE-03-BWRAP`は実験BLOCKEDでありPASS証拠ではない。

### R3-S02 — Native Writer In-flight Kill + Seal Quiescence

- **INV:** 02/03/04。**固定版:** 共通、実LanceDB Native。
- **初期:** fresh Candidate大容量vector/write/compaction中、parent ControllerはNative syscall/FFI開始および対象FDを識別、Published旧PairをPinして維持。
- **注入:** `SIGTERM`, `SIGKILL`を別走行で、**OSで確認した進行中Native I/Oの相関Operation ID/FDに対して**送達。別走行ではKill後の残存worker/FD/IPC、deadline timeout/再起動を挿入。
- **期待トレース:** `NATIVE_IO_ENTER -> SIGNAL_DELIVERED_WHILE_OP_ACTIVE -> EXIT/ISOLATION -> ALL_WRITERS_GONE -> QUIESCED -> IMPORT/SEAL` または `QUARANTINED`。旧Published Hash・Reader結果不変。
- **PASS:** Native-inflight注入の因果証拠、または明示した**Quiescence suboracle**についてwriter権限回収を全経路で証明しSealを安全に拒否/許可。両項目を別判定する。**FAIL:** 非隔離writerがSeal後に書く、I/O残存でもACTIVE化。**INCONCLUSIVE:** `API_ENTER`/artifact-changeしか見えずsignal時I/O state不明（R2と同様）。
- **証拠:** `S02/native-op-map.jsonl`, `S02/syscall-or-kernel-probe.jsonl`, `S02/process-tree.json`, `S02/fd-capabilities.json`, `S02/driver-timeline.jsonl`, `S02/after-restart-hashes.json`。
- **R2との差:** `STORAGE-02` の「data変化を観測してKill」のRaceを超えたNative IO内送達証拠。Process exitだけをNative内Killの証明としない。

### R3-S03 — Independent Immutable Pair Retention / Reader Pin

- **INV:** 03/04/06/07。**固定版:** 共通、実LanceDB。
- **初期:** G1 Legacy+StructuredをPublisherが物理byte-copy/Sealし、旧ReaderをDurable Pin。G2 Candidateを別物理rootに作成。
- **注入:** G2で`optimize/compact/prune`を連続実行、旧 G1 connection/read + fresh G1 open/read/vector search、Manifest/registry検証を並行実行。GCはPin保持中に試行。
- **期待トレース:** `G1_PIN -> G2_MUTATE/PRUNE -> G1_OLD_AND_FRESH_READ_OK -> GC_DENIED_WHILE_PINNED -> GC_AFTER_RELEASE_ONLY`。
- **PASS:** 旧Reader/fresh ReaderのRows・Vector検索・Payload/Manifest/Hashes・Catalog整合、G1全Fileが保持。**FAIL:** Pinの旧data/Manifest削除、世代混合、GCによる欠落。**INCONCLUSIVE:** 独立物理copyでなくバージョンCheckoutに依存、Fresh Checkout未観測。
- **証拠:** `S03/pairs-and-manifests.json`, `S03/reader-pin-ledger.json`, `S03/vector-results.json`, `S03/hash-tree.json`, `S03/gc-attempts.jsonl`。
- **R2との差:** `STORAGE-04` は単一Table内version pin後にpruneで消失。R3は旧物理PairにNative Pruneが到達不能であることまで検証。

### R3-S04 — Durable GC Intent, Pin/Writer Race, Partial Crash

- **INV:** 02/04/05/07。**固定版:** 共通、NativeLanceDB + SQLite durable Coordinator fixture。
- **初期:** G0 Retired / G1 Active、G0 Reader Pin残存、旧Writer Quiescence証拠、GC Actor制限。Delete Intentなし。
- **注入:** 同時 `acquirePin` vs `startDeleteIntent` を順序反転、unknown live Writer、途中delete直後`SIGKILL`、Controller/GC再起動。Ledgerのpermanent revocationは保持。
- **期待トレース:** `PIN_CAS_WIN -> DELETE_REJECT` または `DELETE_INTENT_CAS_WIN -> PIN_REJECT`、`DELETE_INTENT_DURABLE -> PARTIAL_DELETE -> CRASH -> RESTART -> IDEMPOTENT_COMPLETE`。
- **PASS:** Pin中の物理削除0、旧Writerが触り得るPathで削除0、Active削除0、復旧後Tombstone維持、再公開0。**FAIL:** 途中DeleteでActive/Pin崩壊またはLedger復活。**INCONCLUSIVE:** OS write FD/reader survival不明、Modelのみの再現。
- **証拠:** `S04/gc-transaction-log.jsonl`, `S04/reader-writer-liveness.json`, `S04/path-deletes.jsonl`, `S04/wal-recovery.json`, `S04/revocation-after-restart.json`。
- **R2との差:** `MODEL-GC-*` の合成file/lease-counter PASSでなく、Native artifactとOS principalを伴う削除競合。

### R3-S05 — Full/Incremental Snapshot CAS / Durable Authority Crash

- **INV:** 01/02/03/04/05/07。**固定版:** 共通、SQLite fixture（NativePairをS03から参照）。
- **初期:** publicationRevision 20 / authorityRevision 50 / slotRevision 10、同parentSnapshotIdのfull・incremental競合、永続revocation Ledger、Prepared/Import途中pair各1。
- **注入:** Slot所有時のauthorityRevision進行、二候補同時CAS、F1 commit直前/直後kill、snapshot rename後SQLite CAS前kill、SQLite CAS後restart/rollback。**R5-J1〜J6**として各Journal Phase `building`,`legacy-swapped`,`structured-swapped`,`catalog-activated`,`merkle-activated`,`idle`の直後に別々にCrash/Restart。`merkle-activated`のCAS直前/直後にkill。さらに未タグのlegacy journal（各中間phase）、mode不一致、旧`reconcileOnStartup()`呼び出し、旧Rollback API強制呼び出し、SQLite transaction commit unknown、incremental同一Journalを反例注入。host-powerlossは別環境許可時に限定。
- **期待トレース:** `SLOT_OWN -> SEALED/VERIFIED -> JOURNAL(catalog-activated) -> ATOMIC{ACTIVE_CAS, JOURNAL(merkle-activated), COMMIT_RECEIPT} -> JOURNAL(idle)`。前4段階中crashは旧Pointer継続＋新Candidate隔離、CAS後crashはfinalizeのみ、legacy mode/owner競合は`MIGRATION_BLOCKED`。loserは`STALE_PARENT/ABORT`、F1後旧revoked世代0件再開。
- **PASS:** 自己Slot非衝突・lost-updateなし・duplicate receipt一回・PhysicalPair同Generation・Rollback不可逆性に加え、**J1〜J6全件でphase/Pointerに二重Authorityなし**、`merkle-activated`とCASが同一Commit、旧Recoveryは新modeで**実行前に拒否**、CAS後の旧Rollbackによるswap=0。**FAIL:** stale publish、F1後復活、prepared暗黙activate、旧Recoveryが新PairやPointerを動かす、pointer=新でphase≠merkle-activated、phase=merkle-activatedでpointer=旧。**INCONCLUSIVE:** 独立Coordinator fixtureが既存6phase journal schema/旧Recovery APIを使用していない、SQLite耐久/fsync未測定。
- **証拠:** `S05/slot-transactions.jsonl`, `S05/authority-wal.json`, `S05/manifest-cas-receipts.json`, `S05/fsync-trace.json`, `S05/recovery-diff.json`, `S05/journal-six-phase-crash-matrix.json`, `S05/legacy-recovery-block-proof.json`, `S05/migration-mode-ledger.json`。
- **R2との差:** `MODEL-G1-*` は独立Schema、Host powerlossなし。ここでは物理pairのVerified receiptとjournalをCASへ結合。

### R3-S06 — Provenance/Coverage/Availability Boundary

- **INV:** 03/04/06/07。**固定版:** 共通、実Source fixtures+NativePair、SQLite Journal。
- **初期:** G1有効Pair、同一Fingerprint full rebuildと別Fingerprint rebuild各fixture、baseline scan、watcher watermark、Working Tree exact/grep authority。
- **注入:** watcher event喪失、scan後のファイル変更、同dimensionの異Provider embedding、Catalog/Merkle片側だけ遅延、reconciliation期限切れ、incompatible activation前の未処理変更。**R5-P1〜P7:** expectedにある1 Chunkの欠落、重複Chunk key、余剰row、同dimensionの異input vector入替、Provider receipt偽紐付け、Prepared Input Role/Task/Unicode不一致、Observedだけで期待Rootを自己生成する偽completeness。FullとIncremental両方、Legacy/Structured各tableで反復する。
- **期待トレース:** `SOURCE_INVENTORY -> EXPECTED_CHUNKS_FROZEN -> EMBED_RECEIPTS -> PERSISTED_VECTOR_READBACK -> INDEPENDENT_BIJECTION_VALIDATE -> ROOTS_BOUNDED_IN_MANIFEST -> VERIFIED`。P1〜P7は`PROVENANCE_INVALID/COVERAGE_INVALID -> ACTIVATION_DENY`。`BASELINE_COMPLETE -> OBLIGATION_COMMITTED -> PENDING (bounded safe only) -> COMPLETE` / `KNOWN_GAP -> COVERAGE_INVALID -> SEMANTIC_DENY`、incompatibleはC0後止まる。
- **PASS:** Full/Incremental双方で独立Expected集合と実persisted Row+Vector Receipt集合の全key bijection/roots一致、偽P1〜P7全件拒否、Provider Identity/role/task/Unicode確認後のみActivate、Grep-onlyは別認可。**FAIL:** 欠落/重複/余剰/すり替え/同dimension異SpaceをRowCountだけで許可、自己生成Manifestを真正Completeと扱う、Watcher gap無視、非互換中のSemantic送信。**INCONCLUSIVE:** 期待集合をobservedだけから作る、native vector readback不能、異Provider receiptの実行binding不明。
- **証拠:** `S06/source-baseline.json`, `S06/fingerprint-provider-receipts.json`, `S06/reconciliation-journal.jsonl`, `S06/query-modes.json`, `S06/merkle.json`, `S06/expected-chunks.jsonl`, `S06/persisted-vector-receipts.jsonl`, `S06/completeness-bijection.json`, `S06/provenance-negative-controls.json`, `S06/validator-independence.json`。
- **R2との差:** `MODEL-G4-SNAPSHOT/RECONCILIATION`限定モデルから、実物理Pairとquery publicationの境界を結合。

## 3. R3 Transportテスト

### R3-T01 — Real SDK stdio / Admission Closure vs Final Write

- **INV:** 01/02/06。**固定版:** MCP SDK 1.29.0、Node>=24、他共通固定。
- **初期:** SDK handlerはepoch1 semanticをprivate outputへ遅延生成。Publication Brokerだけが実child OS stdoutを保有。RequestKey 1件。
- **注入:** Handler return後、SDK frame生成後、private pipe受信後、それぞれBrokerのfinal `stdout.write`直前に `C0_SYNC` と `F1_PENDING` をGateOwner内部barrierで挿入。
- **期待トレース:** `HANDLER_RETURN -> PRIVATE_BUFFERED -> C0 -> F1_PENDING -> P_REJECTED_OLD -> (F1 SUCCESS + FRESH PERMIT時のみERROR/DEGRADEDの候補)`、old semantic external bytes=0。
- **PASS:** 最終FD受理前C0なら旧Semantic 0、error/Grep-onlyは新権限+terminal claim一回。**FAIL:** C0後P受理、SDKにstdout迂回権限。**INCONCLUSIVE:** stdoutの最終FDを誰が持つか観測できない。
- **証拠:** `T01/fd-ownership.json`, `T01/real-sdk-wire.jsonl`, `T01/sequence.jsonl`, `T01/terminal-receipts.json`。
- **R2との差:** raw `TRANSPORT-01-STDIO-RAW` FAIL、限定 `STDIO-GUARD` PASSと異なり最終OS FD所有を強制。

### R3-T02 — `write(false)` Backpressure + Close + Cancel-after-Enqueue

- **INV:** 02/06。**固定版:** SDK 1.29.0、実OS pipe / stdout。
- **初期:** external pipe reader paused、frameはhighWaterMarkを超える、send未解決、同RequestKeyにcancel可能状態を設定。
- **注入:** `P_WRITE_ACCEPT(false)`の直後 `C0 -> cancel -> close -> delayed drain/reader resume`。別走行で`C0`を`P`直前へ置く。close後の`send`未解決をbounded timeoutで隔離。
- **期待トレース:** `P<C0 -> bytes may arrive after C0, accepted-not-retractable` / `C0<P -> no old accept`、Promise timeoutは`TRANSPORT_FAILED`, duplicate sendなし。
- **PASS:** 2つの時系列を判別し、後者では旧受理ゼロ、前者では旧受信があってもP<C0記録、永久待ち/二重Terminalなし。**FAIL:** C0<P旧accept、未解決PromiseがC0/F1を無期限待機。**INCONCLUSIVE:** pipe enqueueとpeer bytes相関不明。
- **証拠:** `T02/write-return-and-drain.jsonl`, `T02/os-pipe-bytes.bin.sha256`, `T02/close-cancel-order.jsonl`, `T02/promise-isolation.json`。
- **R2との差:** R2 `TRANSPORT-02-OS-STDOUT/SDK-BACKPRESSURE`のunsafe raw behaviorを否定せず、Broker付き境界とCancel-after-enqueueを初検証。

### R3-T03 — Streamable HTTP JSON / SDK Buffered Response

- **INV:** 01/02/06。**固定版:** SDK 1.29.0、Node>=24。
- **初期:** SDKのactual web responseをprivate bufferで取得、BrokerのみNode ServerResponse所有。
- **注入:** SDK response construction後、Buffer完了後、`toNode`相当のwriteHead/write/end前に同期C0。異常として`res.writeHead`先行後にもC0。
- **期待トレース:** `SDK_BUFFER -> C0 -> FINAL_NODE_WRITE_DENIED -> SAFE_ERROR/DEGRADED`。Header firstの場合、P<C0なら受理済と分類しabort、後続旧Semantic禁止。
- **PASS:** C0後の旧body/headersの初回enqueueなし、外部status/content-length一致、未送信なら新権限エラーへ置換可。**FAIL:** SDK hidden bufferがClosure後Nodeへ旧bodyを書込。**INCONCLUSIVE:** underlying final Node writeを測れない。
- **証拠:** `T03/node-write-events.jsonl`, `T03/http-client-wire.json`, `T03/authority-terminal.json`。
- **R2との差:** `TRANSPORT-03-HTTP-JSON`はraw SDK負例。P位置を独立制御するSafe Adapterを評価。

### R3-T04 — SSE Chunked Publication / Partial Abort

- **INV:** 02/06。**固定版:** SDK 1.29.0、Node>=24。
- **初期:** private SSE event frame queue、G1 permit、異なるevent IDs、Broker owns Stream write。
- **注入:** Event1のfirst frameがP<C0、Event2のfinal write直前C0、さらにEvent1 headerだけ送信後abortする分岐。
- **期待トレース:** `P1<C0 -> old frame may complete`; `C0 -> EVENT2_DENY`、partialならconnection隔離、構造化Delivery unknown。
- **PASS:** 旧Semantic Event2 P=0、既受理Event1を撤回したと主張せず、追加eventなし、one-terminal。**FAIL:** Close後にEvent2新規受理、partial SSEに旧semanticを継ぎ足す。**INCONCLUSIVE:** event受理点を特定できない。
- **証拠:** `T04/sse-event-commits.jsonl`, `T04/partial-http-wire.bin`, `T04/isolation-reason.json`。
- **R2との差:** `TRANSPORT-03-HTTP-SSE` raw FAIL / `PARTIAL-ABORT`観測専用PASSから、個々のevent gateを検証。

### R3-T05 — `storeEvent()` In-flight + Durable Revocation + New-epoch Replay

- **INV:** 02/05/06。**固定版:** SDK 1.29.0（将来EventStore付きFixture、**現行Nexus v1設定ではない**）。
- **初期:** Durable Private EventStore、G1 epoch1 cursor、新session epoch2、同streamで複数event、genuine SDK replay API。
- **注入:** `storeEvent` pending中に同期C0を成立させ、その後F1をdurable commit、保存完了後old event release試行、新epochで**実Cursorから**SDK再接続を複数回、EventStore再起動して同様のReplayを試行。
- **期待トレース:** `STORE_START -> C0/F1 -> STORE_COMPLETE(PRIVATE_REVOKED) -> RELEASE_DENIED -> REPLAY_FILTERED -> NO_OLD_SEMANTIC`。Replayが本当に走った証拠は必須。
- **PASS:** 最終 `replay` HTTP成功（空/安全event）を観測し旧event frame=0、rebootでも旧event復活0。**FAIL:** 旧Semanticのrelease/replay成功。**INCONCLUSIVE:** replay `AbortError`、cursor不正、request自体が完了しない。**BLOCKED:** SDK ReplayをBrokerで遮断不能。
- **証拠:** `T05/private-event-store.json`, `T05/durable-event-ledger.jsonl`, `T05/replay-request-response.json`, `T05/replay-cursor.json`, `T05/restart-check.json`。
- **R2との差:** `TRANSPORT-03-SSE-STORE` final結果は旧Semantic初回送出でFAIL、**final replayはAbortError**。履歴と混同せず再接続成功のOracleを追加。

### R3-T06 — Local HTTP v2 Final Node Write

- **INV:** 01/02/06。**固定版:** server@2.0.0 + SDK@1.29.0、Node>=24。
- **初期:** `createMcpHandler`/`toNodeHandler`実Library、正当なMCP headers/_meta、private response adapterとBrokerを接続。
- **注入:** v2 WebResponse作成後、Node writeHead/write/end直前にC0。2回目はNode responseがpartial commitしてからC。
- **期待トレース:** `V2_RESPONSE -> C0 -> BROKER_DENY_NO_OLD_BYTES`、partial時はisolate/delivery unknown。
- **PASS:** v2外部HTTPでClosure後に旧semantic新規accept0、Broker専有Socket証拠あり。**FAIL:** v2 SDK/adapterから迂回write。**INCONCLUSIVE:** 非200/初期protocol handshake未成立だけで安全と判定。
- **証拠:** `T06/meta-and-handshake.json`, `T06/node-adapter-events.jsonl`, `T06/client-result.json`。
- **R2との差:** `TRANSPORT-05-V2`は未保護負例。R2の初回400 fixtureを再使用せず有効なv2 requestで検証。

### R3-T07 — Fixed-HEAD Nexus v1→v2 Bridge External Commit

- **INV:** 01/02/06。**固定版:** server@2.0.0 + SDK@1.29.0 + frozen Bridge source、Node>=24。
- **初期:** 固定HEAD由来のBridge sourceをread-only参照、v1 internal client/server + synthetic handler、実v2 External HTTP、Broker only owns final socket。
- **注入:** Bridge内部success後、v2 handler return後、最終Node write前にC0。Bridge内部queueでawait/barrierを意図的に挟む。
- **期待トレース:** `INTERNAL_SUCCESS -> C0 -> EXTERNAL_FINAL_WRITE_DENY -> SAFE_ERROR/ISOLATED`。
- **PASS:** 内部成功と外部Pを識別し、C0後old payload 0、Terminal一回。**FAIL:** 内部successをPublication扱いしてC0後送信。**INCONCLUSIVE:** 実Bridge source未使用、合成downstream writeのみ。
- **証拠:** `T07/fixed-head-bridge-source-hash.json`, `T07/bridge-queue-trace.jsonl`, `T07/v2-client-body.json`。
- **R2との差:** `TRANSPORT-05-BRIDGE`はモデルdownstream、`05-NEXUS-BRIDGE-V2`は実固定HEAD Bridge+合成handler+v2外部負例。本TestはBroker追加による解消可否だけを検証。全Nexus製品統合は未実施。

### R3-T08 — Duplicate RequestKey, Delayed Handler, Error/Hybrid Fallback

- **INV:** 01/02/06/07。**固定版:** SDK 1.29.0 + server2.0.0（使用経路のみ）、Node>=24。
- **初期:** 同connectionの**同じpending ID** request到着を二重化（既存ingressSequenceをreuse）、同connectionで完了後ID再使用、別incarnationで同IDの正当request、G1 pending handler、検索mode semantic/hybrid。
- **注入:** duplicate ingress、old handler return後C0、new epoch degrade、Terminal Claim後abnormal transport shutdown、old buffer replay。
- **期待トレース:** `REQUESTKEY_CLAIM_ONCE`; old payload drop; semantic⇒`COMPATIBILITY_REVOKED`、hybrid⇒`GREP_ONLY`（独立認可可のとき）、socket failure⇒internal `TRANSPORT_FAILED`、delivery unknownは再送なし。
- **PASS:** duplicate response/handler side effect0（認めた重複識別契約に限る）、各key一つ以下、別connection正当keyは排除しない、errorとgrepの新Authorityに一致。**FAIL:** 二重Terminal/旧Semantic混入/TransportFailedをDelivered扱い。**INCONCLUSIVE:** RequestKey同一性仕様や端末観測不足。
- **証拠:** `T08/request-key-map.json`, `T08/terminal-cas-receipts.json`, `T08/semantic-vs-grep-results.json`, `T08/late-handler-trace.jsonl`。
- **Review-003追加（R3-T08-CUTOVER）:** **初期**: G42/S42の旧ReaderをPin、同fingerprint新G43/S43を`PREPARED`、Semantic/Hybrid各RequestKeyのdeadline/`attemptBudget=2`、未Terminal Claim。**注入**: S42 vector query途中でS43をActive CASし、その後S42結果をBrokerへ到達させる。別runでS43 retry中にさらにS44 cutover、timeout、identity C0、Claim後cutoverを挿入。**観測**: `PIN_S42 → CUTOVER_HOLD → CAS_S43 → S42_P_DENY → RETRY_PIN_S43 → NEW_PAIR_COMPAT_CHECK → S43_P`、または期限/永久失効時にError/独立Grep-only。**PASS**: S42 post-HOLD/post-CAS P=0、retryは同RequestKeyで独立attemptId、total terminal<=1、永久失効ならsemantic retry=0、Pin中GC=0。**FAIL**: S42 post-CAS P受理、失効結果をS43として貼替、無制限retry/二重Claim、旧SemanticをGrepへ混入。**INCONCLUSIVE**: final PとCUTOVER_HOLD/CAS順序を連結できない。**証拠**: `T08/cutover-pin-cas-p-order.jsonl`, `T08/retry-budget-and-terminal.json`, `T08/permanent-vs-compatible.json`, `T08/hybrid-grep-only.json`。**Negative Control**: Rev4未定義の旧Permit「ActiveでないのにP」または「同Fingerprintだから無条件P」を比較runで記録、R2から直接証明された反例ではないと区別。


- **R2との差:** raw `TRANSPORT-04-DUPLICATE-REQUESTKEY` FAIL、cancel/closeのHandler遅延前抑止PASSはQueue公開後の一回性証明ではない。

### R3-T09 — C0/F1/P Single-owner Gate, Identity-to-Fence Gap, Compatible Cutover, Crash/Restart

- **INV:** 01/02/03/05/06/07。**固定版:** `@modelcontextprotocol/sdk@1.29.0`、`@modelcontextprotocol/server@2.0.0`（HTTP v2実行）、Node.js >=24、`@lancedb/lancedb@0.18.2`（Cutover Pair）とSQLite。lockfile/実ロードを全Runで記録。
- **初期:** 単一Authority `GateOwner` ProcessがCoordinator Identity Decisionと実stdout FD / Node HTTP `ServerResponse`最終writeを専有。SDK/Worker/Bridgeはprivate envelopeのみ送信。運転開始前 `BOOT_UNCLEAN` durable、G42/S42 Active、`publicationRevision=20`、初期closed=false、RequestKeyを各Run専用にする。F1 sinkは制御可能な遅延/失敗/unknown-returnを持ち、合法なG43/S43 Preparedも用意。
- **障害注入:** **T09-A**: GateOwnerがIdentity mismatchを**認識して同じ同期GateでC0をCommit**した直後、F1 SQLite txnをBarrierで長時間阻止。この間に**SDK handler完了後・Broker private queue内・別Worker IPC待機中**の旧Pを各々試行。**T09-B**: F1 SUCCESS/FAILED/UNKNOWNの3runと、Unknown後readback結果の両分岐。**T09-C**: Workerの非同期`MISMATCH_OBSERVED`送信と最終Pを競合させ、IPC受信をC0と取り違えないか確認（非同期Remote Coordinator構成は安全設計のnegative control）。**T09-D**: Claim durable後P前kill、P受理後ACK前kill、C0後F1前kill、`BOOT_UNCLEAN`破損/欠落/clean-restart、旧workerへのFD leak。**T09-E**: S42 pin→S43 CAS前後と最終Pを異順序で競わせる。Compatible CAS直後にS42 Resultを到着させ、新S43 retryと永久Revoke時をそれぞれ試す。
- **観測時系列:** `IDENTITY_RECOGNIZED == C0_GATE_SYNC -> F1_BEGIN -> [F1_PENDING | FAILED | UNKNOWN | DURABLE_ACK]`; その中で`OLD_FINAL_P_ATTEMPT -> DENIED(no write)`。Pが実際C0に先行したrunは`WRITE_ACCEPT(P) -> C0`で別分類。Crashでは`BOOT_UNCLEAN_DURABLE -> C0 -> CRASH_BEFORE_F1 -> BOOT_CLOSED -> FENCE_RECONCILE/QUARANTINE`。Cutoverは`S42_PIN -> CUTOVER_HOLD -> ACTIVE_CAS_S43 -> S42_P_DENIED -> fresh_S43_search_or_fallback`。GateOwnerへの`MISMATCH_OBSERVED`外部IPC時刻とCoordinator認識/C0を**別Event**で記録。
- **PASS:** **C0成立後F1未完了中の旧Semantic final write 0**、F1のSUCCESS/FAILED/UNKNOWNいずれも旧P再開0、UNKNOWN readback前の新Semantic P 0。外部FD/Node response所有はGateOwnerのみ、IPC grant-after-check writeがない。S42のPは`CUTOVER_HOLD`開始後0、S43再検索のみ新Authority+Claim<=1、永久失効からの旧semantic retry0。C0→Crash→Restartで旧Generation/epochの再開0（不明ならFail-closed）。Terminal duplicate 0。因果順序はOS write acceptとDB transaction/IPC barrierまで独立照合。
- **FAIL:** F1待機中に旧Pが新規accept、F1失敗/UNKNOWNでGate reopen、IPC grantだけで外部P、journal/Pointer競合で旧S42新規P、C0前後の線形化順を偽装、Crashで旧Permit復活、2 terminal。**INCONCLUSIVE:** `IDENTITY_RECOGNIZED`とC0、C0とPを同一Gateで計測できない、F1が実際遅延していない、Cutoverが同じAuthorityで行われていない、OS FD実所有不明、Restartがdurable boot markerを検証しない。**BLOCKED:** 実SDK経路のprivate envelope隔離が実現できない。
- **必要な証拠:** `T09/identity-c0-f1-gap.jsonl`, `T09/f1-success-failed-unknown.json`, `T09/authority-process-and-fds.json`, `T09/worker-ipc-order.jsonl`, `T09/db-wal-and-fsync.json`, `T09/os-write-trace.jsonl`, `T09/boot-unclean-and-restart.json`, `T09/terminal-recovery.json`, `T09/compatible-cutover-cas-vs-p.jsonl`, `T09/negative-control-remote-gate.json`。
- **Negative Controlとの差:** R2はSQLite modelと非保護Transportを別々に測定した。R3-T09は**同一最終write Gate**でのIdentity認識〜Durable Fence待ち窓、Crash、Snapshot切替を結合する。外部WorkerにC0権限を誤って与えた構成をわざと対照として記録し、PASSと混同しない。

## 4. 切り分け、停止規則、成果物

### 否定条件（即FAILまたはBLOCKED）

- S01で同UID/旧WriterがPublished本体、親、Registry、Shared metadataへwrite可能なら方式Aは**FAIL**（別Pathへの変更だけでは修正にならない）。
- S03で旧物理Reader/ManifestがPrune/GCにより欠落すれば方式Aは**FAIL**。
- T01/03/04/06/07のどれかがSDK内部でBroker迂回writeできればその経路は**Semantic許可不可**。ネットワークの受信時刻だけでPを推定しない。
- T05が`AbortError`で終わればReplay安全性は**INCONCLUSIVE**、安全を宣言しない。
- T09が順序の証拠を出せなければINV-02は未証明。
- 実行権限の不足やNative Observability不可は**BLOCKED / INCONCLUSIVE**、Fail closed環境ポリシーへ。

### 推奨実行順（計画上のみ）

`S01 → S02 → S03 → S04/S05 → S06`、`T01 → T02 → T03/T04 → T05 → T06 → T07 → T08/T09`。重大FAILで危険な方式の試験を拡張せず、結果を固定。代替B Object Storeは本最小セットでは**設計比較のみ**。A否定時は別途R3-B-specific ACL/Object Lock/RO-local-cacheテストを提案し、Bを勝手にPASSとしない。

**Evidence Package（独立実行担当が別承認後に生成する仕様）:** `R3-README.md`, `R3-RESULTS.json`, `R3-FAILURE-MATRIX.json`, `environment/lockfile-and-load.json`, `oracles/*.json`, `traces/*.jsonl`, `results/Sxx|Txx/*`, `files/SHA256SUMS`, 外部ZIP SHA/Manifest CRC、観測不能・再試験したrunを含む。各Testは`actual`, `expected`, `counterexample`, `classification`, `limitations`, `artifactHashes`を付ける。negative control、safe variant、モデルを別Run IDで隔離。

**R3判定の上限:** 全R3がPASSしても「方式A + Publication Brokerの独立Spike内成立性」まで。実Nexus Coordinator/Indexer/Search/MCP全経路・OSサポートmatrix・host-powerloss・Bedrock AutomaticのFormal Gateは**別**。R3未実行の現時点では安全性PASSは0件。
