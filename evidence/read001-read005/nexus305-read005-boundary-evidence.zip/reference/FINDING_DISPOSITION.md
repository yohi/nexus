# Nexus #305 — Section 4.1 Rev5 Finding Disposition / INV Traceability

> **結論:** 旧方式の実測FAILを維持。Rev5は**設計上の対処候補**であり、正式なFinding CloseやSection 4.1承認ではない。**Review Gate = BLOCKED。**

## 1. 結果の読み方と証拠参照規則

- `設計上対処`: 原因に対応するRev5 Contractを定義しただけ。R3と独立Reviewerの判定待ち。
- `実証待ち`: Dynamic/OS/SDK境界で保証がまだ成立していない。
- `不適合`: 旧方式がR2 Safety Oracleを満たさない（Negative ControlのFAIL）。
- `限定PASS`: 指定Fixture/モデルのPASSのみ。製品安全性PASSではない。
- 参照記法 `R2:<path>` は `R2-EVIDENCE.zip/nexus305-spike-r2/<path>` を意味する。R1は `R1-EVIDENCE.zip/<path>`。
- `EP-DES-001〜006` / `EP41-001〜005`の**元レビュー本文全文は今回添付ZIPにはない**。下記「論点」の対応は引き継ぎと過去審議の要約をもとにしたトレースであり、引用可能な原文/承認blob同一性は未照合。新しい承認済みNormative Textを捏造しない。`EP42-001〜003`は `R1:SPIKE-REPORT.md` §4と添付Contextに明示された契約を使用。`RG-305-R2-EVID-001/002` は別レビューの証拠補強論点として区別する。

## 2. EP-DES-001〜006

| Finding | 論点（要約・原文照合待ち） | INV | Rev5設計上の対処 | 実証待ち・最終処置 |
|---|---|---|---|---|
| **EP-DES-001** | Revocation Barrier・Mutation / Publication順序 | 01/02/05/06 | §3.1/3.4 同期C0→F1と最終Pの共通Gate、§2.3 CAS、不可逆Byteの境界 | `R3-T01/T02/T09`, `S02/S05`。**設計上対処・未Close** |
| **EP-DES-002** | Persistent/Immutable Snapshot・Retention | 02/03/07 | §2 物理Pair byte-copy、Writer隔離、Native version pin不使用 | `R3-S01/S03/S04`。`STORAGE-03/04`旧方式**不適合** |
| **EP-DES-003** | Incremental indexingのCrash-safe visibility | 03/04/07 | Full/Incremental共通Manifest検証＋Snapshot CAS、in-place mutate禁止 | `R3-S05/S06`。**設計上対処・未Close** |
| **EP-DES-004** | Authority / Journal / Recovery ordering | 01/04/05 | fsync/atomic rename→PREPARED→SQLite CAS、irreversible ledgerとGC intent | `R3-S04/S05/T09`、Host powerloss別ゲート。**未Close** |
| **EP-DES-005** | Search Publication / MCP最終境界 | 01/02/06 | SDK後の実OS FD/Node write直前Publication Broker、at-most-once Terminal | `R3-T01〜T09`。raw SDK負例**不適合** |
| **EP-DES-006** | Coverage completeness・Vector provenance | 03/04/06/07 | file-hash/Merkle/Prepared input/provider identity、source baseline/rescan obligation、Grep-only | `R3-S06/T08`。Dimension/Rowsのみ**不適合** |

## 3. RG-305-EP41-001〜005

| Finding | 論点（要約・原文照合待ち） | INV | Rev5設計・R2根拠 | 処置 |
|---|---|---|---|---|
| **RG-305-EP41-001** | Concurrent lost-update CAS | 01/02/04 | §2.3/§2.3.1 immutable `parentSnapshotId`＋base publication revision比較。R2 `MODEL-G1-CONCURRENT`, `STALE-FENCE`, `SELF-CONFLICT`独立モデルPASS | **設計上対処・製品実証待ち** `S05` |
| **RG-305-EP41-002** | Post-closure MCP request termination | 02/06 | §3.5 cutover bounded retry + §3 RequestKey durable Claim、error/degraded、`TRANSPORT_FAILED` / Promise isolation。R2 stdio/HTTP raw負例FAIL | **旧方式不適合・代替未証明** `T01/T02/T08/T09` |
| **RG-305-EP41-003** | Catalog/Merkle/Snapshot consistency | 03/04/06 | §2.2.1 Expected/Observed Chunk/Vector bijection + verified roots + Physical Pair。R2 `MODEL-G4-SNAPSHOT`モデルPASS | **設計上対処・実証待ち** `S03/S05/S06` |
| **RG-305-EP41-004** | Native Writer stop/fencing evidence | 02/03/04 | §2.2 OS Principal別分離、Quiescence証明とNative-inflight signal証明の分割。`STORAGE-02` INCONCLUSIVE、`STORAGE-03` FAIL | **未証明 / 旧同UID方式不適合** `S01/S02` |
| **RG-305-EP41-005** | Snapshot GC / Recovery / Revocation | 04/05/07 | §2.3.1 Journal Owner/6-phase統合、§2.4 Durable Pin、Delete Intent、OS Writer Quiescence、Rollback不可。R2 `MODEL-GC-*`限定PASS | **設計上対処・Native実証待ち** `S04/S05` |

## 4. RG-305-EP42-001〜003（R1 report §4で補強された契約）

| Finding | Normative論点 | INV | Rev5の取り込み | 判定 |
|---|---|---|---|---|
| **RG-305-EP42-001** | `basePublicationRevision`は`slotRevision`/`authorityRevision`と別。parent/fileGen/fence/coverage/ownershipを単一SQLite CASで確認。self-slot conflictを回避 | 01/02/04/05 | §2.3。R2 `MODEL-G1-SELF-CONFLICT/RECOVERY`モデルPASS | **設計方針継承、Native統合待ち** `S05` |
| **RG-305-EP42-002** | private/nonreplayable Event→PublicationとQueue/EventStore/Replay失効、at-most-once Terminal、isolation時`TRANSPORT_FAILED` | 01/02/05/06 | §3全体。R2 EventStore負例は将来fixtureであり現行v1 EventStore設定には帰属しない | **設計上対処・未実証** `T02/T04/T05/T08/T09` |
| **RG-305-EP42-003** | Baseline complete / pending reconciliation / invalidのAvailabilityと永久Obligation | 03/04/06/07 | §4.1 Coverage状態分類、final rescan、期限とsource mismatch | **設計方針継承、製品実証待ち** `S06` |

## 5. RG-305-SPIKE-001〜003 と R2 Evidence Review補強

| Finding | R2/今回確認できた事実 | INV | 位置づけ / R3 |
|---|---|---|---|
| **RG-305-SPIKE-001** | R2 `STORAGE-04` Optimize/Prune後、旧NativeReaderとManifestが不在。`R2:results/gate2/results.json` | 03/07 | **FAIL（旧Version保持方式不適合）**。物理Pair方式を `S03` で新規検証 |
| **RG-305-SPIKE-002** | R2 `STORAGE-02-SIGTERM/SIGKILL` はdata file変化とWriter exitを記録したがSignal delivery時にNative I/O中という証明なし。`R2:evidence/process-tree.json` | 02/04 | **INCONCLUSIVE**。`S02`はNative-inflightと停止/Sealを別Oracle化 |
| **RG-305-SPIKE-003** | R2 lockfile+loaded fixed packages+`npm ci`再読込。`R2:environment/runtime.json`, `R2:environment/dependency-tree.json` | 全INVの環境前提 | **限定PASS（環境固定）**。安全性とは別、R3でも再固定 |
| **RG-305-R2-EVID-001** | R2最終 `TRANSPORT-03-SSE-STORE` は旧Semanticのstoreと初回HTTP送出を実測したが、最終 `replay.error` = `AbortError: This operation was aborted`。履歴のreplay観測を最終runの成功と混同不可。`R2:results/gate3/results.json` | 02/05/06 | **証拠補強未完**。旧方式の初回送出FAILを維持、**Replay成功可否はINCONCLUSIVE**、`T05`でcursor/connection/restart再試験 |
| **RG-305-R2-EVID-002** | R2実行担当はR1 ZIP原本不在により監査できず。**本引き継ぎ時点**の添付R1 ZIPは指定SHA `6841d5...a032a`、内部Manifest `23/23`一致、内部Report一致 | 横断的証拠監査 | **原本存在/Hash照合は本書で成立（限定）**。R2実行時に差分監査済みになったわけではない。R1→R2コード/Oracle/結果の意味的差分は**未完**、独立確認要 |

## 5.1 Rev4独立ReviewerのFinding 001〜004（Rev5差分とINV対応）

**出典区分:** 下記FindingとSeverityは**今回ユーザーが提示した独立Rev4 Reviewer本文**を根拠とする。Rev5設計担当は修正案を提案するだけであり、独立Reviewerによる`CLOSED`判定はまだ無い。

| 独立Finding | Severity/反例 | 関連INV | Rev5の具体的規範と追跡 | 処置 |
|---|---|---|---|---|
| `RG-305-R4-REVIEW-001` | **Major** Identityを認識したがF durable待ちの間に旧Pが成立 | 01/02/05/06 | Proposal §3.1/3.4: Identity recognitionと同じGateで**同期C0**、後からF1。F1 Success/Failed/Unknown全分岐とBoot-unclean。`T01/T09` | **設計修正提示・未Close、R3未実証** |
| `RG-305-R4-REVIEW-002` | **Major** 旧`legacy-swapped`等と新CASに独立Recoveryが存在 | 01/03/04/05/07 | Proposal §2.3.1: 6 phaseのOwner/Version別解釈。`merkle-activated`+Pointer CAS同一SQLite Commit、旧`reconcileOnStartup`の新mode起動禁止。`S05` | **設計修正提示・未Close** |
| `RG-305-R4-REVIEW-003` | **Major** S42 Pin中にS43 Active、旧S42の検索結果が後送 | 02/03/06/07 | Proposal §3.5: 旧Pin計算継続とP権限を分離。旧P拒否→同RequestKeyでbounded fresh S43 retry、Claim前だけError/独立Grep-only、永久失効の再認可不可。`T08/T09` | **設計修正提示・未Close** |
| `RG-305-R4-REVIEW-004` | **Moderate** Manifest単一Input Identityやcountだけでは全Chunk→Vector正当性不明 | 03/04/06/07 | Proposal §2.2.1: independent expected/observed ledgers、key-bijection、vector receipt、deterministic roots、例外の明示。`S06` | **設計修正提示・未Close** |

既存のEP-DES/EP41/EP42/SPIKEとR2 Negative Controlの結果をRev5の設計修正でPASS/Closedへ昇格させない。`R3-S05/S06/T08/T09`の成否は独立実行担当の将来証拠のみで判定する。


## 6. R2 Fixed-version Evidence全件の処置（結果を上書きしない）

| R2 Test IDs | R2結果/範囲 | 関連INV | Rev5で残る検証 |
|---|---|---|---|
| `STORAGE-01` | **PASS限定**（separate pairの観測） | 03/07 | `S01/S03` OS不変性・Pin |
| `STORAGE-02-SIGTERM`, `STORAGE-02-SIGKILL` | **INCONCLUSIVE** Native I/O時点 | 02/04 | `S02` |
| `STORAGE-03`, `STORAGE-04` | **FAIL** isolation / retention | 02/03/07 | `S01/S03`（旧方式は不適合） |
| `STORAGE-05`, `STORAGE-03-BWRAP` | **BLOCKED** native integration / sandbox setup | 02/04 | `S01/S02`、Fail-closed |
| `TRANSPORT-01-STDIO-RAW` | **FAIL** raw SDK | 02/06 | `T01` |
| `TRANSPORT-01-STDIO-GUARD` | **PASS限定** throwaway adapter+real SDK | 01/02/06 | `T01/T09` |
| `TRANSPORT-02-SDK-BACKPRESSURE`, `TRANSPORT-02-OS-STDOUT` | **FAIL** accepted bytes/close promise | 02/06 | `T02` |
| `TRANSPORT-02-NODE-WRITABLE` | **PASS観測限定** Node Writableのみ | 02/06 | `T02` |
| `TRANSPORT-03-HTTP-JSON`, `TRANSPORT-03-HTTP-SSE` | **FAIL** raw SDK external write | 02/06 | `T03/T04` |
| `TRANSPORT-03-SSE-STORE` | **FAIL** event store/初回送出、final Replay**INCONCLUSIVE**（詳細上記）。未来fixtureのみ | 02/05/06 | `T05` |
| `TRANSPORT-03-PARTIAL-ABORT` | **PASS観測限定**、safe revocation証明でない | 02/06 | `T04` |
| `TRANSPORT-04-cancel`, `TRANSPORT-04-close` | **PASS限定** handler delay中の抑止 | 02/06 | `T02/T08`（enqueue後は未証明） |
| `TRANSPORT-04-DUPLICATE-REQUESTKEY` | **FAIL** raw SDK二重Terminal | 02/06 | `T08` |
| `TRANSPORT-05-V2` | **FAIL** Local HTTP v2単独外部 | 02/06 | `T06` |
| `TRANSPORT-05-BRIDGE` | **FAIL** v1内部実SDK + 下流MODEL | 02/06 | `T07` |
| `TRANSPORT-05-NEXUS-BRIDGE-V2` | **FAIL** 固定HEAD Bridge実ソース + 合成handler + v2実外部HTTP | 02/06 | `T07`。製品全体証明でない |
| `MODEL-G1-CONCURRENT`, `IDEMPOTENCY`, `STALE-FENCE`, `REVOCATION`, `SELF-CONFLICT`, `RECOVERY` | **PASS限定**独立SQLite model | 01/02/04/05 | `S05/T09` |
| `MODEL-REQUEST-LIFECYCLE` | **PASS限定**独立State model | 02/06 | `T08/T09` |
| `MODEL-G4-SNAPSHOT`, `MODEL-G4-RECONCILIATION` | **PASS限定** source file+SQLite coverage model | 03/04/06/07 | `S06` |
| `MODEL-GC-INTENT-CRASH`, `MODEL-GC-PIN-RACE`, `MODEL-GC-WRITER-RACE`, `MODEL-GC-PARTIAL-CRASH` | **PASS限定** SQLite ledger+合成physical files | 02/04/05/07 | `S04` |

**Source:** すべて `R2:evidence/failure-matrix.json` の `results[]` と対応する `results/gate*/...`, `evidence/oracles/<ID>.json`。`R2:SPIKE-REPORT.md` §5–§11。R2 `gates`: Gate1 BLOCKED, Gate2 FAIL, Gate3 FAIL (negative controls)/integration BLOCKED, Gate4 BLOCKED。R2記録の14件 `residual[]` をRev5で成功に変更しない。

## 7. INV-01〜07横断対応表

| INV | 不変条件の保持方法（設計案） | R2の実測・未証明 | 主要R3 |
|---|---|---|---|
| **INV-01** | Compatibility CoordinatorだけがP/M/Active/GCのGateを決定 | SQLite ModelのみPASS、製品Admission未実証 | `S01/S05/T01/T07/T09` |
| **INV-02** | 同期C0 / durable F1 / M / final Pの直列化、Writer quiescence、final write-owner | raw HTTP/stdIO/v2 FAIL、Native signal位置INCONCLUSIVE | `S01/S02/T01〜T09` |
| **INV-03** | 完全別物理Legacy+Structured同Pair、manifest pin | `STORAGE-01`限定PASS、Version retention FAIL | `S01/S03/S05/S06` |
| **INV-04** | Fingerprint+Profile+Coverage+Journal+Fence+Provenance+CAS | R2独立model限定PASS、Native統合未実証 | `S02/S05/S06` |
| **INV-05** | Durable RevocationとRollback非可逆、SSE replay tombstone、GC intent | model限定PASS、EventStore replay最終未証明 | `S04/S05/T05/T09` |
| **INV-06** | RetrievalPair permitを外部P直前に確認、error / Grep-onlyを別認可 | raw transport FAIL、guard局所PASS、実製品未実証 | `S03/S06/T01〜T09` |
| **INV-07** | 互換Rebuild旧RO Pin検索継続、非互換Rebuildは同期C0してSemantic停止 | `STORAGE-04` FAIL、availability model限定PASS | `S03/S04/S05/S06/T08` |

## 8. 未完了Findingの閉鎖条件

1. **独立Normative Reviewer**がEP-DES/EP41の原文と本対応表の論点一致を再確認すること（このZIPは全文保証しない）。
2. R3実行担当が各Oracleを実OS/固定SDK/実NativeでPASSにすること。**R3未実行**の今はFindingをClosedにしない。
3. R3の通過後も、実Nexus Coordinator/Indexer/Reader/GC/MCP全経路の製品統合Testは別Gateで必要。
4. `R2-EVID-001` のReplay `AbortError` と `EVID-002` の過去原本欠落を、安全性合格の根拠に変換しない。

**処置の総括:** 設計候補として論点を覆うが、R2 Failにより旧Path/Version Checkout/raw Transportを**不適合**として排除。Formal Section 4.1 Review Gateは**BLOCKED**。
