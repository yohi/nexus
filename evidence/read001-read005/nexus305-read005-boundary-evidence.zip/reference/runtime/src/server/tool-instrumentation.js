export function withToolMetrics(toolName, hooks, handler) {
    if (!hooks)
        return handler;
    return async (...args) => {
        const start = performance.now();
        try {
            const result = await handler(...args);
            const status = result.isError ? 'error' : 'success';
            hooks.onToolCall(toolName, status, (performance.now() - start) / 1000);
            return result;
        }
        catch (error) {
            hooks.onToolCall(toolName, 'error', (performance.now() - start) / 1000);
            throw error;
        }
    };
}
