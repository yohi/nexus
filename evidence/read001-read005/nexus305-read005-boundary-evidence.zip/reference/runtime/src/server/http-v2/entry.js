import { createServer } from 'node:http';
import { resolveLoopbackHost } from '../../config/index.js';
import { createRequestListener } from './routes.js';
import { createMcpNodeHandler } from './transport.js';
export const startHttpV2Server = async (deps) => {
    const resolvedHost = await resolveLoopbackHost(deps.host, 'HTTP v2 server host');
    const nodeHandler = createMcpNodeHandler(deps.handler);
    const server = createServer(createRequestListener({ mcpHandler: nodeHandler, isReady: deps.isReady }));
    await new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(deps.port, resolvedHost, resolve);
    });
    return {
        server,
        port: () => {
            const address = server.address();
            if (address === null || typeof address === 'string') {
                throw new Error('HTTP v2 server is not listening');
            }
            return address.port;
        },
        close: () => new Promise((resolve, reject) => {
            server.close((error) => (error === undefined ? resolve() : reject(error)));
        }),
    };
};
