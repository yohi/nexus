import { createMcpHandler, McpServer } from '@modelcontextprotocol/server';
import { registerV2Tools } from '../tools/registry/adapters/v2-adapter.js';
import { buildToolHandlers } from '../tools/tool-support.js';
const DEFAULT_SERVER_INFO = { name: 'nexus', version: '0.1.0' };
const resolveHandlers = (deps) => {
    if (deps.handlers !== undefined) {
        return deps.handlers;
    }
    if (deps.options !== undefined) {
        return buildToolHandlers(deps.options, deps.awaitInitialize);
    }
    throw new Error('v2 MCP handler requires tool handlers or server options');
};
export const createV2McpHandler = (deps) => createMcpHandler(() => {
    const server = new McpServer(deps.serverInfo ?? DEFAULT_SERVER_INFO, {
        capabilities: { tools: { listChanged: true } },
        instructions: 'Nexus MCP server for local code search and indexing.',
    });
    registerV2Tools(server, resolveHandlers(deps), deps.limits);
    return server;
}, { legacy: 'reject' });
