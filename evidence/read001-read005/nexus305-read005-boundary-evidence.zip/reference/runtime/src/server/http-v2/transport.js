import { toNodeHandler } from '@modelcontextprotocol/node';
export const createMcpNodeHandler = (handler) => toNodeHandler(handler);
