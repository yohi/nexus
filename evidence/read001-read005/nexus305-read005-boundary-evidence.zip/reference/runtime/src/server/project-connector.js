import { acquireGlobalLock, GlobalLockHeldError, projectStartupLockName, } from '../utils/global-lock.js';
import { readProjectEndpoint, removeProjectEndpointIfMatching, } from './project-endpoint.js';
import { isProcessAlive } from './process-lock.js';
import { mkdir, unlink } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
const DEFAULT_STARTUP_TIMEOUT_MS = 30_000;
const DEFAULT_POLL_INTERVAL_MS = 100;
const MAX_STARTUP_LOG_BYTES = 64 * 1024;
const STARTUP_STDOUT_LOG_NAME = 'startup-stdout.log';
const STARTUP_STDERR_LOG_NAME = 'startup-stderr.log';
function validateTimeout(value, name, fallback) {
    if (value === undefined) {
        return fallback;
    }
    if (!Number.isFinite(value) || value <= 0) {
        throw new RangeError(`${name} must be a finite, positive number`);
    }
    return value;
}
function tailBytes(text, maxBytes) {
    const encoder = new TextEncoder();
    let totalBytes = 0;
    let startIndex = text.length;
    for (let i = text.length - 1; i >= 0; i -= 1) {
        const charBytes = encoder.encode(text[i]).length;
        if (totalBytes + charBytes > maxBytes) {
            break;
        }
        totalBytes += charBytes;
        startIndex = i;
    }
    return text.slice(startIndex);
}
async function cleanupStartupLog(path) {
    if (path === undefined) {
        return;
    }
    try {
        await unlink(path);
    }
    catch (error) {
        const err = error;
        if (err.code !== 'ENOENT') {
            throw error;
        }
    }
}
function buildOutputPreview(stdoutLog, stderrLog) {
    const stdoutSection = stdoutLog
        ? `\n\nChild stdout:\n${stdoutLog.trimEnd()}`
        : '';
    const stderrSection = stderrLog
        ? `\n\nChild stderr:\n${stderrLog.trimEnd()}`
        : '';
    return `${stderrSection}${stdoutSection}`;
}
async function fetchHealth(endpoint, projectRoot, fetchImpl, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        let response;
        try {
            response = await fetchImpl(new URL('/health', endpoint.url).toString(), { signal: controller.signal });
        }
        catch {
            return undefined;
        }
        if (!response.ok) {
            return undefined;
        }
        let body;
        try {
            body = await response.json();
        }
        catch {
            return undefined;
        }
        if (typeof body !== 'object' ||
            body === null ||
            body.instanceId !== endpoint.instanceId ||
            body.projectRoot !== projectRoot) {
            return undefined;
        }
        return endpoint;
    }
    finally {
        clearTimeout(timer);
    }
}
async function validateEndpoint(endpoint, projectRoot, fetchImpl, timeoutMs) {
    if (endpoint === undefined) {
        return undefined;
    }
    if (endpoint.projectRoot !== projectRoot) {
        // Treat a projectRoot mismatch as an invalid descriptor so callers do not
        // have to silence unexpected errors with `.catch(() => undefined)`.
        return undefined;
    }
    let parsedUrl;
    try {
        parsedUrl = new URL(endpoint.url);
    }
    catch {
        return undefined;
    }
    if (parsedUrl.hostname !== '127.0.0.1') {
        return undefined;
    }
    if (!isProcessAlive(endpoint.pid)) {
        return undefined;
    }
    return fetchHealth(endpoint, projectRoot, fetchImpl, timeoutMs);
}
async function waitForHealthyEndpoint(storageDir, projectRoot, fetchImpl, timeoutMs, pollIntervalMs) {
    const deadline = Date.now() + timeoutMs;
    while (true) {
        const remainingMs = deadline - Date.now();
        if (remainingMs <= 0) {
            throw new Error('Timed out waiting for a healthy project endpoint');
        }
        const endpoint = await readProjectEndpoint(storageDir);
        const validated = await validateEndpoint(endpoint, projectRoot, fetchImpl, remainingMs);
        if (validated !== undefined) {
            return validated;
        }
        const remainingAfterCheck = deadline - Date.now();
        if (remainingAfterCheck <= 0) {
            throw new Error('Timed out waiting for a healthy project endpoint');
        }
        await new Promise((resolve) => {
            setTimeout(resolve, Math.min(pollIntervalMs, remainingAfterCheck));
        });
    }
}
export async function ensureProjectEndpoint(options) {
    const startupTimeoutMs = validateTimeout(options.startupTimeoutMs, 'startupTimeoutMs', DEFAULT_STARTUP_TIMEOUT_MS);
    const pollIntervalMs = validateTimeout(options.pollIntervalMs, 'pollIntervalMs', DEFAULT_POLL_INTERVAL_MS);
    await mkdir(options.storageDir, { recursive: true });
    const initialEndpoint = await readProjectEndpoint(options.storageDir);
    const validated = await validateEndpoint(initialEndpoint, options.projectRoot, options.fetch, startupTimeoutMs);
    if (validated !== undefined) {
        return new URL(validated.url);
    }
    // Descriptor was invalid; remove it so we do not reuse a stale record.
    if (initialEndpoint !== undefined) {
        await removeProjectEndpointIfMatching(options.storageDir, initialEndpoint).catch(() => { });
    }
    const lockName = await projectStartupLockName(options.storageDir);
    let lockHandle;
    let spawned = false;
    let succeeded = false;
    try {
        try {
            lockHandle = await acquireGlobalLock(lockName);
        }
        catch (error) {
            if (!(error instanceof GlobalLockHeldError)) {
                throw error;
            }
            // Another connector is starting the managed server for this project.
            // Wait for it to publish a healthy descriptor instead of spawning.
            const winnerEndpoint = await waitForHealthyEndpoint(options.storageDir, options.projectRoot, options.fetch, startupTimeoutMs, pollIntervalMs);
            succeeded = true;
            return new URL(winnerEndpoint.url);
        }
        // We hold the startup lock. Re-check the descriptor in case the winner
        // published while we were acquiring the lock.
        const winnerEndpoint = await validateEndpoint(await readProjectEndpoint(options.storageDir), options.projectRoot, options.fetch, startupTimeoutMs);
        if (winnerEndpoint !== undefined) {
            succeeded = true;
            return new URL(winnerEndpoint.url);
        }
        // Prepare startup log files so the detached child can write diagnostics
        // over a path that survives the bridge process exiting. Pipes would keep the
        // child coupled to the bridge's lifetime, so stdio is fully detached below
        // and the child receives log paths via environment variables instead.
        const startupStdoutLog = join(options.storageDir, `${randomUUID()}-${STARTUP_STDOUT_LOG_NAME}`);
        const startupStderrLog = join(options.storageDir, `${randomUUID()}-${STARTUP_STDERR_LOG_NAME}`);
        const child = options.spawn(options.childExecutable, [
            ...(options.childArgs ?? []),
            '--project-root',
            options.projectRoot,
            '--port',
            '0',
            '--managed',
        ], {
            detached: true,
            env: {
                ...options.env,
                NEXUS_STARTUP_STDOUT_LOG: startupStdoutLog,
                NEXUS_STARTUP_STDERR_LOG: startupStderrLog,
            },
            stdio: ['ignore', 'ignore', 'ignore'],
        });
        spawned = true;
        // Race the health-check poll against the child's own error/close events.
        // Without this, a spawn failure (e.g. ENOENT) or a child that crashes
        // immediately would otherwise be masked: waitForHealthyEndpoint() would
        // just keep polling until startupTimeoutMs elapses and report a generic
        // timeout instead of the real failure.
        //
        // Diagnostics are not captured from stdio pipes (stdio is detached so the
        // child can outlive the bridge). Instead, the child writes startup output
        // to per-stream log files and we read the trailing 64 KiB when reporting a
        // startup failure.
        let rejectChildFailure = () => { };
        const childFailure = new Promise((_, reject) => {
            rejectChildFailure = reject;
        });
        function buildFailureError(code, signal) {
            const readStartupLog = (path, label) => {
                try {
                    return readFileSync(path, 'utf8');
                }
                catch (error) {
                    const err = error;
                    if (err.code === 'ENOENT') {
                        return '';
                    }
                    return `[Unable to read ${label} startup log: ${err.message}]`;
                }
            };
            const stdoutLog = readStartupLog(startupStdoutLog, 'stdout');
            const stderrLog = readStartupLog(startupStderrLog, 'stderr');
            const outputPreview = buildOutputPreview(tailBytes(stdoutLog, MAX_STARTUP_LOG_BYTES), tailBytes(stderrLog, MAX_STARTUP_LOG_BYTES));
            return new Error(`Managed nexus child exited before publishing a healthy endpoint (code=${code ?? 'null'}, signal=${signal ?? 'null'})${outputPreview}`);
        }
        const onChildError = (error) => {
            rejectChildFailure(error);
        };
        const onChildClose = (code, signal) => {
            rejectChildFailure(buildFailureError(code, signal));
        };
        child.once('error', onChildError);
        child.once('close', onChildClose);
        child.unref();
        try {
            const managedEndpoint = await Promise.race([
                waitForHealthyEndpoint(options.storageDir, options.projectRoot, options.fetch, startupTimeoutMs, pollIntervalMs),
                childFailure,
            ]);
            succeeded = true;
            return new URL(managedEndpoint.url);
        }
        finally {
            child.removeListener('error', onChildError);
            child.removeListener('close', onChildClose);
            if (succeeded) {
                await Promise.all([
                    cleanupStartupLog(startupStdoutLog),
                    cleanupStartupLog(startupStderrLog),
                ]);
            }
        }
    }
    finally {
        await lockHandle?.release().catch(() => { });
        // If we spawned a child but never saw a healthy descriptor, clean up the
        // stale descriptor left by a crashed or slow-starting child.
        if (spawned && !succeeded) {
            const finalEndpoint = await readProjectEndpoint(options.storageDir);
            if (finalEndpoint !== undefined) {
                const stillHealthy = await validateEndpoint(finalEndpoint, options.projectRoot, options.fetch, pollIntervalMs);
                if (stillHealthy === undefined) {
                    await removeProjectEndpointIfMatching(options.storageDir, finalEndpoint).catch(() => { });
                }
            }
        }
    }
}
