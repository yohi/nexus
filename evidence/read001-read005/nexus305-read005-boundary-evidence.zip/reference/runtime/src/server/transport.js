import { randomUUID } from 'node:crypto';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { isInitializeRequest } from '@modelcontextprotocol/sdk/types.js';
export class HttpError extends Error {
    statusCode;
    constructor(statusCode, message) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'HttpError';
    }
}
export const createStreamableHttpHandler = ({ createServer, sessionIdleTimeoutMs = 30 * 60 * 1000, sessionCleanupIntervalMs = 5 * 60 * 1000, onSessionOpen, onSessionClose, }) => {
    const sessions = new Map();
    const safeClose = async (server, sessionId) => {
        try {
            await server.close();
        }
        catch (error) {
            console.error(`Error closing server for session ${sessionId ?? 'unknown'}:`, error);
        }
    };
    const closeEntry = async (sessionId, entry) => {
        if (entry.closed) {
            sessions.delete(sessionId);
            return;
        }
        entry.closed = true;
        sessions.delete(sessionId);
        await safeClose(entry.server, sessionId);
        onSessionClose?.(sessionId);
    };
    const createSessionEntry = (body) => {
        if (!isInitializeRequest(body)) {
            return undefined;
        }
        const server = createServer();
        const sessionEntryRef = {};
        const transport = new StreamableHTTPServerTransport({
            sessionIdGenerator: () => {
                const id = randomUUID();
                if (sessionEntryRef.current) {
                    sessions.set(id, sessionEntryRef.current);
                }
                return id;
            },
            onsessioninitialized: (createdSessionId) => {
                if (sessionEntryRef.current) {
                    sessions.set(createdSessionId, sessionEntryRef.current);
                }
                onSessionOpen?.(createdSessionId);
            },
        });
        const entry = {
            server,
            transport,
            lastActivity: Date.now(),
            inFlightRequests: 0,
            closed: false,
        };
        sessionEntryRef.current = entry;
        transport.onclose = () => {
            if (!entry.closed) {
                entry.closed = true;
                const activeId = transport.sessionId;
                if (activeId) {
                    sessions.delete(activeId);
                    onSessionClose?.(activeId);
                }
                void safeClose(entry.server, activeId);
            }
        };
        return { entry, isNewSession: true };
    };
    const cleanupFailedNewSession = async (entry, error) => {
        entry.closed = true;
        const activeId = entry.transport.sessionId;
        if (activeId) {
            sessions.delete(activeId);
            onSessionClose?.(activeId);
        }
        await safeClose(entry.server, activeId);
        throw error;
    };
    const interval = setInterval(() => {
        const now = Date.now();
        for (const [sessionId, entry] of sessions.entries()) {
            if (entry.inFlightRequests === 0 && now - entry.lastActivity > sessionIdleTimeoutMs) {
                void closeEntry(sessionId, entry);
            }
        }
    }, sessionCleanupIntervalMs);
    interval.unref();
    const handleRequest = async (req, res) => {
        const sessionIdHeader = req.headers['mcp-session-id'];
        const sessionId = Array.isArray(sessionIdHeader) ? sessionIdHeader[0] : sessionIdHeader;
        let body;
        try {
            body = await readBody(req);
        }
        catch (error) {
            const statusCode = error instanceof HttpError ? error.statusCode : 400;
            const message = error instanceof Error ? error.message : 'Invalid request body';
            res.statusCode = statusCode;
            res.setHeader('content-type', 'application/json');
            res.end(JSON.stringify({ jsonrpc: '2.0', error: { code: -32700, message }, id: null }));
            return;
        }
        try {
            let entry = sessionId ? sessions.get(sessionId) : undefined;
            let isNewSession = false;
            if (entry) {
                if (entry.closed) {
                    if (sessionId) {
                        sessions.delete(sessionId);
                    }
                    entry = undefined;
                }
                else {
                    entry.lastActivity = Date.now();
                }
            }
            else {
                const createdSession = createSessionEntry(body);
                if (!createdSession) {
                    res.statusCode = 400;
                    res.setHeader('content-type', 'application/json');
                    res.end(JSON.stringify({ jsonrpc: '2.0', error: { code: -32000, message: 'invalid session' }, id: null }));
                    return;
                }
                ({ entry, isNewSession } = createdSession);
            }
            if (!entry) {
                throw new HttpError(400, 'invalid session');
            }
            entry.inFlightRequests += 1;
            try {
                if (isNewSession) {
                    await entry.server.connect(entry.transport);
                }
                await entry.transport.handleRequest(req, res, body);
            }
            catch (error) {
                if (isNewSession && !entry.closed) {
                    await cleanupFailedNewSession(entry, error);
                }
                throw error;
            }
            finally {
                entry.inFlightRequests = Math.max(0, entry.inFlightRequests - 1);
                entry.lastActivity = Date.now();
            }
            // The sessions.set(activeSessionId, entry) after handleRequest is intentionally
            // idempotent (safe if onsessioninitialized already inserted the session). It
            // covers edge cases where the initialization callback may not run (e.g.,
            // early-return paths or missed events). Relevant symbols: handleRequest,
            // onsessioninitialized, activeSessionId, entry.closed, and sessions.set.
            const activeSessionId = entry.transport.sessionId;
            if (activeSessionId && !entry.closed) {
                sessions.set(activeSessionId, entry);
            }
        }
        catch (error) {
            const statusCode = error instanceof HttpError ? error.statusCode : 500;
            res.statusCode = statusCode;
            res.setHeader('content-type', 'application/json');
            res.end(JSON.stringify({
                jsonrpc: '2.0',
                error: { code: -32603, message: error instanceof Error ? error.message : String(error) },
                id: null,
            }));
        }
    };
    const handler = Object.assign(handleRequest, {
        dispose: async () => {
            clearInterval(interval);
            await Promise.all(Array.from(sessions.entries()).map(([sessionId, entry]) => closeEntry(sessionId, entry)));
        },
    });
    return handler;
};
const MAX_BODY_SIZE = 1 * 1024 * 1024; // 1 MB
const readBody = async (req) => {
    if (req.method === 'GET' || req.method === 'DELETE') {
        return undefined;
    }
    const chunks = [];
    let totalSize = 0;
    for await (const chunk of req) {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        totalSize += buffer.length;
        if (totalSize > MAX_BODY_SIZE) {
            throw new HttpError(413, 'Payload Too Large: Request body exceeds 1MB limit');
        }
        chunks.push(buffer);
    }
    if (chunks.length === 0) {
        return undefined;
    }
    const rawBody = Buffer.concat(chunks).toString('utf8');
    try {
        return JSON.parse(rawBody);
    }
    catch (error) {
        throw new HttpError(400, `Invalid JSON body: ${error instanceof Error ? error.message : String(error)}`);
    }
};
