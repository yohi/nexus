/** Classify a sanitized error message without exposing implementation details. */
export const classifyErrorMessage = (message) => {
    if (message.startsWith('Invalid line range:')) {
        return 'NEXUS_CONTENT_NOT_FOUND';
    }
    if (message === 'already_running' || message.includes('Reindex already running')) {
        return 'NEXUS_INDEXING_IN_PROGRESS';
    }
    const lower = message.toLowerCase();
    if (lower.includes('dimension')) {
        return 'NEXUS_VECTOR_DIMENSION_MISMATCH';
    }
    if (lower.includes('enoent') || lower.includes('no such file')) {
        return 'NEXUS_CONTENT_NOT_FOUND';
    }
    if (lower.includes('permission denied') ||
        lower.includes('access denied') ||
        lower.includes('forbidden')) {
        return 'NEXUS_ACCESS_DENIED';
    }
    if (lower.includes('database') ||
        lower.includes('sqlite') ||
        lower.includes('lancedb') ||
        lower.includes('storage') ||
        lower.includes('not initialized')) {
        return 'NEXUS_STORAGE_UNAVAILABLE';
    }
    return 'NEXUS_INTERNAL_ERROR';
};
