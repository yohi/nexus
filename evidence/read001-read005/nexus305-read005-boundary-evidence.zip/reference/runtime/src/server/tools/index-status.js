import { buildSharedIndexStatus } from './build-shared-index-status.js';
export const executeIndexStatus = async (metadataStore, vectorStore, pluginRegistry, pipeline) => {
    const shared = await buildSharedIndexStatus(metadataStore, vectorStore, pipeline);
    const pluginHealth = await pluginRegistry.healthCheck();
    return { ...shared, pluginHealth };
};
