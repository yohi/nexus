export const executeGetSymbolSource = async (service, args, signal, metricsHooks) => {
    const result = await service.getSymbolSource({ symbolId: args.symbolId, signal });
    if (result === null || typeof result !== 'object') {
        metricsHooks?.onStructuredRetrievalOutcome?.('get_symbol_source', 'error');
        return { result };
    }
    const status = result.status;
    metricsHooks?.onStructuredRetrievalOutcome?.('get_symbol_source', status ?? 'unknown');
    return result;
};
