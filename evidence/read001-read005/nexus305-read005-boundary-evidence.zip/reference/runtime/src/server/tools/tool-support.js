import { sanitizeErrorMessage } from '../../utils/error-utils.js';
import { withToolMetrics } from '../tool-instrumentation.js';
import { executeGetContext } from './get-context.js';
import { executeGrepSearch } from './grep-search.js';
import { executeHybridSearch } from './hybrid-search.js';
import { executeIndexStatus } from './index-status.js';
import { executeGetFileOutline } from './get-file-outline.js';
import { executeGetSymbolContext } from './get-symbol-context.js';
import { executeGetSymbolSource } from './get-symbol-source.js';
import { executeReindex } from './reindex.js';
import { executeSemanticSearch } from './semantic-search.js';
export const errorResult = (error) => {
    const errorMessage = sanitizeErrorMessage(error);
    console.error('[Nexus Server Error]', errorMessage);
    return {
        content: [{ type: 'text', text: `Error: ${errorMessage}` }],
        isError: true,
        structuredContent: { error: true, message: errorMessage },
    };
};
export const toolResult = (structuredContent) => {
    try {
        const normalized = JSON.parse(JSON.stringify(structuredContent, (_key, value) => typeof value === 'bigint' ? value.toString() : value));
        return {
            content: [{ type: 'text', text: JSON.stringify(normalized, null, 2) }],
            structuredContent: normalized,
        };
    }
    catch (error) {
        const errorMessage = sanitizeErrorMessage(error);
        console.error('[Nexus Serialization Error]', error);
        return {
            content: [{ type: 'text', text: `Failed to serialize structuredContent: ${errorMessage}` }],
            isError: true,
            structuredContent: {
                error: true,
                message: errorMessage,
                originalType: typeof structuredContent,
            },
        };
    }
};
export const createContentReader = (contentStore, fallback) => {
    if (contentStore === undefined) {
        return async (filePath, startLine = 1, endLine = Number.MAX_SAFE_INTEGER, signal) => {
            const content = await fallback(filePath, signal);
            const lines = content.split('\n');
            const clampedStart = Math.max(1, Math.min(startLine, lines.length));
            const clampedEnd = Math.max(1, Math.min(endLine, lines.length));
            if (clampedStart > clampedEnd) {
                throw new Error(`Invalid line range: startLine (${clampedStart}) is greater than endLine (${clampedEnd})`);
            }
            return lines.slice(clampedStart - 1, clampedEnd).join('\n');
        };
    }
    return async (filePath, startLine = 1, endLine = Number.MAX_SAFE_INTEGER, signal) => {
        try {
            return await contentStore.readRange(filePath, startLine, endLine, signal);
        }
        catch (error) {
            console.warn('[Nexus] ContentStore readRange failed; falling back to filesystem read:', error);
            const content = await fallback(filePath, signal);
            const lines = content.split('\n');
            const clampedStart = Math.max(1, Math.min(startLine, lines.length));
            const clampedEnd = Math.max(1, Math.min(endLine, lines.length));
            if (clampedStart > clampedEnd) {
                throw new Error(`Invalid line range: startLine (${clampedStart}) is greater than endLine (${clampedEnd})`);
            }
            return lines.slice(clampedStart - 1, clampedEnd).join('\n');
        }
    };
};
export const buildToolHandlers = (options, awaitInitialize) => {
    const readContent = createContentReader(options.contentStore, options.loadFileContent);
    return {
        semantic_search: withToolMetrics('semantic_search', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                const result = await executeSemanticSearch(options.semanticSearch, options.sanitizer, args, extra?.signal);
                options.metricsHooks?.onSearchResults('semantic', result.results.length);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        grep_search: withToolMetrics('grep_search', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                const result = await executeGrepSearch(options.grepEngine, options.projectRoot, options.sanitizer, args, extra?.signal);
                options.metricsHooks?.onSearchResults('grep', result.matches.length);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        hybrid_search: withToolMetrics('hybrid_search', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                const result = await executeHybridSearch(options.orchestrator, options.sanitizer, (filePath) => readContent(filePath, 1, Number.MAX_SAFE_INTEGER, extra?.signal), args, extra?.signal, options.metricsHooks);
                options.metricsHooks?.onSearchResults('hybrid', result.results.length);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        get_context: withToolMetrics('get_context', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                const result = await executeGetContext(readContent, options.sanitizer, args, extra?.signal);
                const lineCount = 'mode' in result
                    ? result.previewEndLine - result.previewStartLine + 1
                    : result.endLine - result.startLine + 1;
                options.metricsHooks?.onContextLinesFetched('get_context', lineCount);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        index_status: withToolMetrics('index_status', options.metricsHooks, async () => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                return toolResult(await executeIndexStatus(options.metadataStore, options.vectorStore, options.pluginRegistry, options.pipeline));
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        reindex: withToolMetrics('reindex', options.metricsHooks, async (args) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                return toolResult(await executeReindex(options.pipeline, options.runReindex, options.loadFileContent, args));
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        get_file_outline: withToolMetrics('get_file_outline', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                if (options.symbolRetrievalService === undefined) {
                    return errorResult(new Error('Structured retrieval service is not initialized'));
                }
                const parsed = args;
                const result = await executeGetFileOutline(options.symbolRetrievalService, parsed, extra?.signal, options.metricsHooks);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        get_symbol_source: withToolMetrics('get_symbol_source', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                if (options.symbolRetrievalService === undefined) {
                    return errorResult(new Error('Structured retrieval service is not initialized'));
                }
                const parsed = args;
                const result = await executeGetSymbolSource(options.symbolRetrievalService, parsed, extra?.signal, options.metricsHooks);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
        get_symbol_context: withToolMetrics('get_symbol_context', options.metricsHooks, async (args, extra) => {
            try {
                if (awaitInitialize)
                    await awaitInitialize();
                if (options.symbolRetrievalService === undefined) {
                    return errorResult(new Error('Structured retrieval service is not initialized'));
                }
                const parsed = args;
                const result = await executeGetSymbolContext(options.symbolRetrievalService, parsed, extra?.signal, options.metricsHooks);
                return toolResult(result);
            }
            catch (error) {
                return errorResult(error);
            }
        }),
    };
};
