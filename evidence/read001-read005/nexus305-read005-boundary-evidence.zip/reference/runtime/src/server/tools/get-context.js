import { resolveLineRange, sliceContent } from './context-helpers.js';
const PREVIEW_LINES = 20;
const DEFERRED_HINT = 'Call get_context with startLine/endLine to fetch specific ranges.';
const buildInvalidRangeError = (totalLines, startLine, endLine) => {
    const clampedStart = Math.max(1, Math.min(startLine ?? 1, totalLines));
    const clampedEnd = Math.max(1, Math.min(endLine ?? totalLines, totalLines));
    return new Error(`Invalid line range: startLine (${clampedStart}) is greater than endLine (${clampedEnd})`);
};
/**
 * Computes the preview window for deferred mode.
 *
 * - Both startLine and endLine given: the requested range, clamped to file boundaries.
 * - Only startLine given: startLine through startLine + PREVIEW_LINES - 1 (clamped).
 * - Only endLine given: endLine - PREVIEW_LINES + 1 through endLine (clamped).
 * - Neither given: the first PREVIEW_LINES lines of the file.
 */
const resolveDeferredPreviewRange = (totalLines, startLine, endLine) => {
    if (startLine !== undefined && endLine !== undefined) {
        const range = resolveLineRange(totalLines, startLine, endLine);
        if (range === null) {
            throw buildInvalidRangeError(totalLines, startLine, endLine);
        }
        return range;
    }
    if (startLine !== undefined) {
        const clampedStart = Math.max(1, Math.min(startLine, totalLines));
        return { startLine: clampedStart, endLine: Math.min(clampedStart + PREVIEW_LINES - 1, totalLines) };
    }
    if (endLine !== undefined) {
        const clampedEnd = Math.max(1, Math.min(endLine, totalLines));
        return { startLine: Math.max(1, clampedEnd - PREVIEW_LINES + 1), endLine: clampedEnd };
    }
    return { startLine: 1, endLine: Math.min(PREVIEW_LINES, totalLines) };
};
export const executeGetContext = async (loadFileContent, sanitizer, args, signal) => {
    const sanitizedPath = await sanitizer.sanitize(args.filePath);
    const hasExplicitEagerRange = args.mode !== 'deferred' && args.startLine !== undefined && args.endLine !== undefined;
    const requestedStartLine = args.startLine;
    const requestedEndLine = args.endLine;
    const canReadRequestedRange = hasExplicitEagerRange &&
        requestedStartLine !== undefined &&
        requestedEndLine !== undefined &&
        requestedStartLine <= requestedEndLine;
    const content = await loadFileContent(sanitizedPath, canReadRequestedRange ? requestedStartLine : 1, canReadRequestedRange ? requestedEndLine : Number.MAX_SAFE_INTEGER, signal);
    const lines = content.split('\n');
    const totalLines = lines.length;
    if (hasExplicitEagerRange && requestedStartLine !== undefined && requestedEndLine !== undefined) {
        const range = resolveLineRange(totalLines, requestedStartLine, requestedEndLine);
        if (range === null) {
            throw buildInvalidRangeError(totalLines, requestedStartLine, requestedEndLine);
        }
        return {
            filePath: args.filePath,
            content: canReadRequestedRange ? content : sliceContent(content, range),
            startLine: range.startLine,
            endLine: canReadRequestedRange ? requestedEndLine : range.endLine,
        };
    }
    if (args.mode === 'deferred') {
        const previewRange = resolveDeferredPreviewRange(totalLines, args.startLine, args.endLine);
        return {
            filePath: args.filePath,
            mode: 'deferred',
            totalLines,
            summary: sliceContent(content, previewRange),
            previewStartLine: previewRange.startLine,
            previewEndLine: previewRange.endLine,
            hint: DEFERRED_HINT,
        };
    }
    const range = resolveLineRange(totalLines, args.startLine, args.endLine);
    if (range === null) {
        throw buildInvalidRangeError(totalLines, args.startLine, args.endLine);
    }
    return {
        filePath: args.filePath,
        content: sliceContent(content, range),
        startLine: range.startLine,
        endLine: range.endLine,
    };
};
