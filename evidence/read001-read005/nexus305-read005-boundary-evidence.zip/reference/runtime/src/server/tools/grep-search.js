export const executeGrepSearch = async (grepEngine, projectRoot, sanitizer, args, abortSignal) => {
    let glob;
    if (args.filePattern) {
        glob = [sanitizer.validateGlob(args.filePattern)];
    }
    else if (args.filePatterns) {
        glob = args.filePatterns.map((p) => sanitizer.validateGlob(p));
    }
    return {
        matches: await grepEngine.search({
            query: args.pattern,
            cwd: projectRoot,
            glob,
            caseSensitive: args.caseSensitive,
            maxResults: args.maxResults,
            abortSignal,
        }),
    };
};
