import { buildSharedIndexStatus } from "./build-shared-index-status.js";
export const buildDashboardIndexStatusSnapshot = async (metadataStore, vectorStore, pluginRegistry, pipeline) => {
    const shared = await buildSharedIndexStatus(metadataStore, vectorStore, pipeline);
    const activeName = pluginRegistry.getActiveEmbeddingProviderName() ?? null;
    let providerStatus;
    if (activeName === null) {
        providerStatus = { providerName: null, health: "unknown", lastError: null };
    }
    else {
        const known = pluginRegistry.getEmbeddingProviderHealth(activeName);
        if (known === undefined) {
            providerStatus = { providerName: activeName, health: "unknown", lastError: null };
        }
        else {
            providerStatus = { providerName: activeName, health: known.health, lastError: known.lastError ?? null };
        }
    }
    return { ...shared, providerStatus };
};
