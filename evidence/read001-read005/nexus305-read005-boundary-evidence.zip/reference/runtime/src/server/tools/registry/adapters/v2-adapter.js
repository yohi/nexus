import { fromJsonSchema } from '@modelcontextprotocol/server';
import { z } from 'zod/v4';
import { classifyErrorMessage } from '../../../errors.js';
import { TOOL_DEFINITIONS } from '../definitions.js';
const DEFAULT_V2_TOOL_LIMITS = { topK: 100, maxResults: 1000 };
const limitFor = (fieldName, declaredMaximum, limits) => {
    if (fieldName === 'topK')
        return limits.topK;
    if (fieldName === 'maxResults')
        return limits.maxResults;
    return declaredMaximum;
};
const schemaDescription = (field) => field.description === undefined ? {} : { description: field.description };
const toV2JsonSchemaField = (name, field, limits) => {
    const description = schemaDescription(field);
    switch (field.kind) {
        case 'string':
            return {
                ...description,
                type: 'string',
                ...(field.pattern === undefined ? {} : { pattern: field.pattern }),
            };
        case 'integer':
            return {
                ...description,
                type: 'integer',
                minimum: field.minimum ?? 1,
                ...(field.maximum === undefined ? {} : { maximum: limitFor(name, field.maximum, limits) }),
            };
        case 'number':
            return { ...description, type: 'number' };
        case 'boolean':
            return {
                ...description,
                type: 'boolean',
                ...(field.default === undefined ? {} : { default: field.default }),
            };
        case 'stringArray':
            return { ...description, type: 'array', items: { type: 'string' } };
        case 'enum':
            return {
                ...description,
                type: 'string',
                enum: field.values,
                ...(field.default === undefined ? {} : { default: field.default }),
            };
    }
};
export const toV2JsonSchema = (schema, limits = DEFAULT_V2_TOOL_LIMITS) => {
    const properties = {};
    const required = [];
    for (const [name, field] of Object.entries(schema)) {
        properties[name] = toV2JsonSchemaField(name, field, limits);
        if (field.optional !== true) {
            required.push(name);
        }
    }
    return { type: 'object', properties, ...(required.length === 0 ? {} : { required }) };
};
const toZodV4Field = (name, field, limits) => {
    switch (field.kind) {
        case 'string': {
            let stringField = z.string();
            if (field.pattern !== undefined) {
                stringField = stringField.regex(new RegExp(field.pattern));
            }
            return stringField;
        }
        case 'integer': {
            let integer = z.number().int().positive();
            if (field.minimum !== undefined) {
                integer = integer.min(field.minimum);
            }
            if (field.maximum !== undefined) {
                integer = integer.max(limitFor(name, field.maximum, limits));
            }
            return integer;
        }
        case 'number':
            return z.number();
        case 'boolean':
            return z.boolean();
        case 'stringArray':
            return z.array(z.string());
        case 'enum':
            return z.enum(field.values);
    }
};
export const toZodV4Object = (schema, limits = DEFAULT_V2_TOOL_LIMITS) => {
    const shape = {};
    for (const [key, field] of Object.entries(schema)) {
        let zodField = toZodV4Field(key, field, limits);
        if (field.optional === true) {
            zodField = zodField.optional();
        }
        if ('default' in field && field.default !== undefined) {
            zodField = zodField.default(field.default);
        }
        if (field.description !== undefined) {
            zodField = zodField.describe(field.description);
        }
        shape[key] = zodField;
    }
    return z.object(shape);
};
export const withErrorCode = (result) => {
    if (result.isError !== true || result.structuredContent === undefined) {
        return result;
    }
    const message = result.structuredContent['message'];
    const code = typeof message === 'string' ? classifyErrorMessage(message) : 'NEXUS_INTERNAL_ERROR';
    return { ...result, structuredContent: { ...result.structuredContent, code } };
};
export const registerV2Tools = (server, handlers, limits = DEFAULT_V2_TOOL_LIMITS) => {
    for (const definition of TOOL_DEFINITIONS) {
        const handler = handlers[definition.name];
        if (handler === undefined) {
            throw new Error(`missing handler for tool: ${definition.name}`);
        }
        server.registerTool(definition.name, {
            description: definition.description,
            inputSchema: fromJsonSchema(toV2JsonSchema(definition.input, limits)),
        }, async (args, extra) => {
            const normalizedArgs = toZodV4Object(definition.input, limits).parse(args);
            return withErrorCode(await handler(normalizedArgs, { signal: extra.mcpReq.signal }));
        });
    }
};
