export const executeSemanticSearch = async (semanticSearch, sanitizer, args, abortSignal) => {
    const { filePattern, ...rest } = args;
    const validatedArgs = { ...rest };
    if (filePattern) {
        validatedArgs.filePatterns = [sanitizer.validateGlob(filePattern)];
    }
    else if (args.filePatterns) {
        validatedArgs.filePatterns = args.filePatterns.map((p) => sanitizer.validateGlob(p));
    }
    return {
        results: await semanticSearch.search({ ...validatedArgs, abortSignal }),
    };
};
