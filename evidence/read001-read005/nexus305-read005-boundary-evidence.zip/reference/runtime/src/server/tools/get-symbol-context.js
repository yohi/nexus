export const executeGetSymbolContext = async (service, args, signal, metricsHooks) => {
    const result = await service.getSymbolContext({ symbolId: args.symbolId, tokenBudget: args.tokenBudget, signal });
    if (result === null || typeof result !== 'object') {
        metricsHooks?.onStructuredRetrievalOutcome?.('get_symbol_context', 'error');
        return { result };
    }
    const status = result.status;
    metricsHooks?.onStructuredRetrievalOutcome?.('get_symbol_context', status ?? 'unknown');
    if (status === 'ok') {
        const budget = result.budget;
        if (budget) {
            metricsHooks?.onStructuredContextTokens?.('get_symbol_context', budget.requested ?? -1, budget.actual ?? -1);
            if ((budget.exceeded ?? false) && (budget.omittedForBudget ?? 0) > 0) {
                metricsHooks?.onStructuredBudgetOverflow?.('get_symbol_context', budget.omittedForBudget ?? 0);
            }
        }
    }
    return result;
};
