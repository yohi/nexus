export const executeGetFileOutline = async (service, args, signal, metricsHooks) => {
    const result = await service.getFileOutline({ filePath: args.filePath, signal });
    if (result === null || typeof result !== 'object') {
        metricsHooks?.onStructuredRetrievalOutcome?.('get_file_outline', 'error');
        return { result };
    }
    const status = result.status;
    metricsHooks?.onStructuredRetrievalOutcome?.('get_file_outline', status ?? 'unknown');
    return result;
};
