export const executeReindex = async (pipeline, runReindex, loadFileContent, args) => pipeline.reindex(runReindex, loadFileContent, args.fullRebuild, args.reason);
