const deriveStructuredStatus = (state) => {
    if (state.schemaVersion === null)
        return "reindex_required";
    if (state.schemaVersion !== 1)
        return "unsupported";
    if (state.rebuildState === "building")
        return "building";
    if (state.rebuildState === "failed")
        return "failed";
    return "idle";
};
export const buildSharedIndexStatus = async (metadataStore, vectorStore, pipeline) => {
    const structuredStatePromise = metadataStore.getStructuredIndexState === undefined
        ? Promise.resolve(undefined)
        : metadataStore.getStructuredIndexState();
    const [indexStats, vectorStats, deadLetterEntries, structuredState] = await Promise.all([
        metadataStore.getIndexStats(),
        vectorStore.getStats(),
        metadataStore.getDeadLetterEntries(),
        structuredStatePromise.catch(() => undefined),
    ]);
    const structuredIndex = structuredState === undefined
        ? undefined
        : {
            schemaVersion: structuredState.schemaVersion,
            targetSchemaVersion: 1,
            status: deriveStructuredStatus(structuredState),
            rebuildState: structuredState.rebuildState,
            lastErrorCode: structuredState.lastErrorCode,
            totalFiles: structuredState.counts.activeFiles,
            totalSymbols: structuredState.counts.activeSymbols,
            exactFiles: structuredState.counts.activeFiles,
            degradedFiles: 0,
            pendingFiles: structuredState.counts.pendingFiles,
            reindexRequired: structuredState.reindexRequired,
        };
    return {
        indexStats,
        vectorStats,
        skippedFiles: deadLetterEntries.length,
        pipelineProgress: pipeline.getProgress(),
        structuredIndex,
    };
};
