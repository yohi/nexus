import { createHash } from 'node:crypto';
import { realpath, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import lockfile from 'proper-lockfile';
export const GLOBAL_LOCK_STALE_MS = 60_000;
export const GLOBAL_LOCK_RETRIES = 10;
export const GLOBAL_LOCK_RETRY_MIN_TIMEOUT_MS = 100;
export const GLOBAL_LOCK_RETRY_MAX_TIMEOUT_MS = 1000;
/**
 * Derives a startup lock name based on the canonical path of the storage directory.
 * Note that the storage directory must already exist; otherwise, `realpath` will throw an ENOENT error.
 *
 * @param storageDir The path to the storage directory.
 */
export const projectStartupLockName = async (storageDir) => {
    const canonicalStorageDir = await realpath(storageDir);
    return `project-start-${createHash('sha256').update(canonicalStorageDir).digest('hex')}`;
};
const GLOBAL_LOCK_ERROR_MESSAGE = (name) => `Nexus global resource "${name}" is already in use by another process.`;
export class GlobalLockHeldError extends Error {
    lockName;
    name = 'GlobalLockHeldError';
    constructor(lockName) {
        super(GLOBAL_LOCK_ERROR_MESSAGE(lockName));
        this.lockName = lockName;
    }
}
export class GlobalLockTimeoutError extends Error {
    lockName;
    timeoutMs;
    name = 'GlobalLockTimeoutError';
    constructor(lockName, timeoutMs) {
        super(`Timed out waiting for Nexus global resource "${lockName}" after ${timeoutMs}ms.`);
        this.lockName = lockName;
        this.timeoutMs = timeoutMs;
    }
}
const abortError = (signal) => {
    if (signal.reason instanceof Error) {
        return signal.reason;
    }
    return new DOMException('The operation was aborted.', 'AbortError');
};
const waitForRetry = async (ms, signal) => {
    if (signal?.aborted) {
        throw abortError(signal);
    }
    await new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            signal?.removeEventListener('abort', onAbort);
            resolve();
        }, ms);
        const onAbort = () => {
            clearTimeout(timer);
            signal?.removeEventListener('abort', onAbort);
            reject(abortError(signal));
        };
        signal?.addEventListener('abort', onAbort, { once: true });
    });
};
export const acquireGlobalLock = async (name, options = {}) => {
    if (!/^[a-zA-Z0-9_-]+$/.test(name)) {
        throw new Error(`Invalid global lock name: "${name}". Only alphanumeric characters, underscores, and hyphens are allowed.`);
    }
    const retries = options.retries ?? GLOBAL_LOCK_RETRIES;
    const minTimeout = options.minTimeoutMs ?? GLOBAL_LOCK_RETRY_MIN_TIMEOUT_MS;
    const maxTimeout = options.maxTimeoutMs ?? GLOBAL_LOCK_RETRY_MAX_TIMEOUT_MS;
    const unlimited = options.retryMode === 'unlimited';
    if (!Number.isSafeInteger(retries) || retries < 0) {
        throw new RangeError('Global lock retries must be a finite, non-negative integer');
    }
    if (options.timeoutMs !== undefined && (!Number.isSafeInteger(options.timeoutMs) || options.timeoutMs <= 0)) {
        throw new RangeError('Global lock timeout must be a positive, safe integer');
    }
    const lockfilePath = join(tmpdir(), `nexus-global-${name}.lock`);
    // proper-lockfile requires the target file to exist
    await writeFile(lockfilePath, '', { flag: 'wx' }).catch((err) => {
        // Ignore only if file already exists
        if (err.code !== 'EEXIST')
            throw err;
    });
    let retryCount = 0;
    const startedAt = Date.now();
    while (true) {
        if (options.timeoutMs !== undefined && Date.now() - startedAt >= options.timeoutMs) {
            throw new GlobalLockTimeoutError(name, options.timeoutMs);
        }
        if (options.signal?.aborted) {
            throw abortError(options.signal);
        }
        try {
            const release = await lockfile.lock(lockfilePath, {
                retries: 0,
                stale: GLOBAL_LOCK_STALE_MS,
            });
            if (options.signal?.aborted) {
                await release().catch(() => { });
                throw abortError(options.signal);
            }
            return { release };
        }
        catch (error) {
            if (!isLockHeldError(error)) {
                throw error;
            }
            if (!unlimited && retryCount >= retries) {
                throw new GlobalLockHeldError(name);
            }
            retryCount += 1;
            const timeout = Math.min(maxTimeout, Math.max(minTimeout, minTimeout * 2 ** Math.min(retryCount - 1, 10)));
            let retryTimeout = timeout;
            if (options.timeoutMs !== undefined) {
                const remainingMs = options.timeoutMs - (Date.now() - startedAt);
                if (remainingMs <= 0) {
                    throw new GlobalLockTimeoutError(name, options.timeoutMs);
                }
                retryTimeout = Math.min(timeout, remainingMs);
            }
            options.onRetry?.(retryCount, retryTimeout);
            await waitForRetry(retryTimeout, options.signal);
        }
    }
};
const isLockHeldError = (error) => {
    if (typeof error !== 'object' || error === null) {
        return false;
    }
    return Reflect.get(error, 'code') === 'ELOCKED';
};
