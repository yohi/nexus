import path from 'node:path';
import lockfile from 'proper-lockfile';
export const PROJECT_LOCK_FILENAME = '.nexus-lock';
const PROJECT_LOCK_STALE_MS = 30_000;
const PROJECT_LOCK_RETRIES = 0;
const PROJECT_LOCK_ERROR_MESSAGE = (rootDir) => `Another Nexus process is already running for this project (${rootDir}). Only one instance per project is allowed.`;
export const acquireProjectLock = async (rootDir) => {
    const projectRoot = path.resolve(rootDir);
    const lockfilePath = path.join(projectRoot, PROJECT_LOCK_FILENAME);
    try {
        const release = await lockfile.lock(projectRoot, {
            lockfilePath,
            retries: PROJECT_LOCK_RETRIES,
            stale: PROJECT_LOCK_STALE_MS,
        });
        return { release };
    }
    catch (error) {
        if (isLockHeldError(error)) {
            throw new Error(PROJECT_LOCK_ERROR_MESSAGE(rootDir));
        }
        throw error;
    }
};
export const isProjectLocked = async (rootDir) => {
    const projectRoot = path.resolve(rootDir);
    return lockfile.check(projectRoot, {
        lockfilePath: path.join(projectRoot, PROJECT_LOCK_FILENAME),
        stale: PROJECT_LOCK_STALE_MS,
    });
};
const isLockHeldError = (error) => {
    if (typeof error !== 'object' || error === null) {
        return false;
    }
    return Reflect.get(error, 'code') === 'ELOCKED';
};
