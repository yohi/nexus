export class InstrumentedEmbeddingProvider {
    inner;
    hooks;
    providerName;
    constructor(inner, hooks, providerName) {
        this.inner = inner;
        this.hooks = hooks;
        this.providerName = providerName;
    }
    get dimensions() {
        return this.inner.dimensions;
    }
    async healthCheck() {
        return this.inner.healthCheck();
    }
    async embed(texts, signal) {
        const start = performance.now();
        try {
            const result = await (signal === undefined ? this.inner.embed(texts) : this.inner.embed(texts, signal));
            this.hooks.onEmbeddingRequest(this.providerName, 'success', (performance.now() - start) / 1000, texts.length);
            return result;
        }
        catch (error) {
            this.hooks.onEmbeddingRequest(this.providerName, 'error', (performance.now() - start) / 1000, texts.length);
            throw error;
        }
    }
}
