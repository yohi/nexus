export class BaseEmbeddingProvider {
    chunkTexts(texts, batchSize) {
        if (batchSize <= 0) {
            throw new RangeError('batchSize must be a positive integer');
        }
        const batches = [];
        for (let index = 0; index < texts.length; index += batchSize) {
            batches.push(texts.slice(index, index + batchSize));
        }
        return batches;
    }
}
