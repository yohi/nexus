import pLimit from 'p-limit';
import { DEFAULT_OLLAMA_LOCK_TIMEOUT_MS, resolveLoopbackHost } from '../../config/index.js';
import { RetryExhaustedError, DimensionMismatchError, NonRetryableEmbeddingError } from '../../types/index.js';
import { BaseEmbeddingProvider } from './base.js';
import { acquireGlobalLock } from '../../utils/global-lock.js';
const defaultDependencies = {
    fetch: globalThis.fetch,
    sleep: async (ms) => new Promise((resolve) => {
        setTimeout(resolve, ms);
    }),
};
const DEFAULT_TIMEOUT_MS = 60_000; // 60 seconds
export const resolveLocalOllamaBaseUrl = async (baseUrl) => {
    if (baseUrl === undefined) {
        return undefined;
    }
    const parsedBaseUrl = new URL(baseUrl);
    parsedBaseUrl.hostname = await resolveLoopbackHost(parsedBaseUrl.hostname, 'Ollama embedding host');
    return parsedBaseUrl.toString();
};
export class OllamaEmbeddingProvider extends BaseEmbeddingProvider {
    config;
    dependencies;
    dimensions;
    limit;
    constructor(config, dependencies = defaultDependencies) {
        super();
        this.config = config;
        this.dependencies = dependencies;
        this.dimensions = config.dimensions;
        this.limit = pLimit(config.maxConcurrency);
    }
    async embed(texts, signal) {
        const batches = this.chunkTexts(texts, this.config.batchSize);
        const lock = await acquireGlobalLock('ollama', {
            retryMode: 'unlimited',
            maxTimeoutMs: 5_000,
            timeoutMs: this.config.ollamaLockTimeoutMs ?? DEFAULT_OLLAMA_LOCK_TIMEOUT_MS,
            signal,
            onRetry: (retryCount, timeoutMs) => {
                if (retryCount === 1 || retryCount % 6 === 0) {
                    console.warn(`[Nexus] Waiting for Ollama global lock (retry ${retryCount}; next retry in ${timeoutMs}ms)`);
                }
            },
        });
        try {
            if (signal?.aborted) {
                throw signal.reason ?? new DOMException('The operation was aborted.', 'AbortError');
            }
            const promises = batches.map(async (batch) => this.limit(async () => this.embedBatchWithRetry(batch, signal)));
            const results = await Promise.all(promises);
            return results.flat();
        }
        finally {
            await lock.release().catch(() => { });
        }
    }
    async healthCheck() {
        try {
            const response = await this.dependencies.fetch(new URL('/api/tags', this.config.baseUrl).toString(), {
                method: 'GET',
            });
            return response.ok;
        }
        catch {
            return false;
        }
    }
    async embedBatchWithRetry(batch, signal) {
        let attempt = 0;
        let lastError;
        // attempt=0 is the first try, so we allow up to retryCount retries (total attempts: retryCount + 1)
        while (attempt <= this.config.retryCount) {
            try {
                return await this.requestEmbeddings(batch, signal);
            }
            catch (error) {
                lastError = error instanceof Error ? error : new Error(String(error));
                if (signal?.aborted) {
                    throw signal.reason ?? new DOMException('The operation was aborted.', 'AbortError');
                }
                if (error instanceof DimensionMismatchError) {
                    throw error;
                }
                // Non-retryable errors (e.g. HTTP 400 context length) must not be retried,
                // but the pipeline expects RetryExhaustedError to route to DLQ.
                if (error instanceof NonRetryableEmbeddingError) {
                    throw new RetryExhaustedError(error.message, 1, { cause: error });
                }
                if (attempt >= this.config.retryCount) {
                    break;
                }
                attempt += 1;
                await this.dependencies.sleep(this.config.retryBaseDelayMs * 2 ** (attempt - 1));
                if (signal?.aborted) {
                    throw signal.reason ?? new DOMException('The operation was aborted.', 'AbortError');
                }
            }
        }
        throw new RetryExhaustedError('Failed to fetch embeddings from Ollama', attempt + 1, {
            cause: lastError,
        });
    }
    async requestEmbeddings(batch, signal) {
        const timeoutMs = this.config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
        const controller = new AbortController();
        let timer;
        if (timeoutMs > 0) {
            timer = setTimeout(() => {
                controller.abort();
            }, timeoutMs);
        }
        try {
            const requestSignal = signal === undefined ? controller.signal : AbortSignal.any([signal, controller.signal]);
            const response = await this.dependencies.fetch(new URL('/api/embed', this.config.baseUrl).toString(), {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                },
                body: JSON.stringify({
                    model: this.config.model,
                    input: batch,
                    truncate: true,
                    options: {
                        num_thread: this.config.ollamaNumThread,
                    },
                }),
                signal: requestSignal,
            });
            if (!response.ok) {
                const body = await response.text();
                // 400 means the input is irrecoverably bad (e.g. context length exceeded).
                // Retrying the same content will never succeed, so surface immediately.
                if (response.status === 400) {
                    throw new NonRetryableEmbeddingError(`Ollama embed request failed (${response.status}): ${body}`);
                }
                throw new Error(`Ollama embed request failed (${response.status}): ${body}`);
            }
            const payload = (await response.json());
            if (payload.embeddings.length !== batch.length) {
                throw new Error(`Ollama returned ${payload.embeddings.length} embeddings for ${batch.length} inputs`);
            }
            for (const vector of payload.embeddings) {
                if (vector.length !== this.dimensions) {
                    throw new DimensionMismatchError(`Unexpected embedding dimension: expected ${this.dimensions}, received ${vector.length}`);
                }
            }
            return payload.embeddings;
        }
        finally {
            clearTimeout(timer);
        }
    }
}
