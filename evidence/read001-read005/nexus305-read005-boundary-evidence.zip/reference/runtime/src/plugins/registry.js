/**
 * Default timeout for plugin registry operations (e.g., health checks) in milliseconds.
 */
const REGISTRY_TIMEOUT_MS = 5000;
export class LanguageRegistry {
    plugins = [];
    register(plugin) {
        const existingIndex = this.plugins.findIndex((candidate) => candidate.languageId === plugin.languageId);
        if (existingIndex >= 0) {
            this.plugins.splice(existingIndex, 1, plugin);
            return;
        }
        this.plugins.push(plugin);
    }
    findForFile(filePath) {
        return this.plugins.find((plugin) => plugin.supports(filePath));
    }
    list() {
        return [...this.plugins];
    }
}
export class EmbeddingProviderRegistry {
    providers = new Map();
    activeProviderName = undefined;
    register(name, provider) {
        this.providers.set(name, provider);
        if (this.activeProviderName === undefined) {
            this.activeProviderName = name;
        }
    }
    setActive(name) {
        if (!this.providers.has(name)) {
            throw new Error(`Embedding provider not found: ${name}`);
        }
        this.activeProviderName = name;
    }
    getActive() {
        if (this.activeProviderName === undefined) {
            return undefined;
        }
        return this.providers.get(this.activeProviderName);
    }
    getActiveName() {
        return this.activeProviderName;
    }
    getRegisteredProviderNames() {
        return Array.from(this.providers.keys());
    }
}
export class PluginRegistry {
    languages = new LanguageRegistry();
    embeddings = new EmbeddingProviderRegistry();
    knownHealth = new Map();
    registerLanguage(plugin) {
        this.languages.register(plugin);
    }
    getLanguagePlugin(filePath) {
        return this.languages.findForFile(filePath);
    }
    registerEmbeddingProvider(name, provider) {
        this.embeddings.register(name, provider);
        this.knownHealth.delete(name);
    }
    getEmbeddingProvider() {
        return this.embeddings.getActive();
    }
    setActiveEmbeddingProvider(name) {
        this.embeddings.setActive(name);
        this.knownHealth.clear();
    }
    getActiveEmbeddingProviderName() {
        return this.embeddings.getActiveName();
    }
    getRegisteredEmbeddingProviderNames() {
        return this.embeddings.getRegisteredProviderNames();
    }
    getEmbeddingProviderHealth(name) {
        return this.knownHealth.get(name);
    }
    /**
     * Performs a health check on all registered plugins and providers.
     */
    async healthCheck() {
        const activeProvider = this.embeddings.getActive();
        const activeProviderName = this.embeddings.getActiveName();
        let embeddingHealthy = false;
        let probeError = null;
        if (activeProvider) {
            let timer;
            try {
                embeddingHealthy = await Promise.race([
                    activeProvider.healthCheck(),
                    new Promise((resolve) => {
                        timer = setTimeout(() => {
                            resolve(false);
                        }, REGISTRY_TIMEOUT_MS);
                    }),
                ]);
            }
            catch (err) {
                embeddingHealthy = false;
                probeError = err instanceof Error ? err.message : String(err);
            }
            finally {
                if (timer)
                    clearTimeout(timer);
            }
        }
        const stillCurrent = this.embeddings.getActiveName() === activeProviderName &&
            this.embeddings.getActive() === activeProvider;
        if (stillCurrent && activeProviderName !== undefined) {
            if (embeddingHealthy) {
                this.knownHealth.set(activeProviderName, { health: "healthy", lastError: null });
            }
            else {
                this.knownHealth.set(activeProviderName, { health: "unhealthy", lastError: probeError });
            }
        }
        const registeredLanguages = this.languages.list().map((plugin) => plugin.languageId);
        const languagesHealthy = registeredLanguages.length > 0;
        return {
            languages: {
                registered: registeredLanguages,
                healthy: languagesHealthy,
            },
            embeddings: {
                provider: activeProviderName,
                healthy: embeddingHealthy,
            },
            healthy: languagesHealthy && embeddingHealthy,
            isOperational: languagesHealthy,
        };
    }
}
