const isDocCommentLine = (line) => line.trim().startsWith('//');
const isGoDirectiveLine = (line) => line.trim().startsWith('//go:');
export const findDeclarationStartByte = (textLines, startLine, offsets) => {
    let lineIndex = startLine - 1;
    while (lineIndex > 0) {
        const previousLine = textLines[lineIndex - 1];
        if (previousLine === undefined)
            break;
        const trimmed = previousLine.trim();
        if (trimmed === '')
            break;
        if (isDocCommentLine(previousLine) || isGoDirectiveLine(previousLine)) {
            lineIndex -= 1;
            continue;
        }
        break;
    }
    const charOffset = textLines.slice(0, lineIndex).join('\n').length + (lineIndex > 0 ? 1 : 0);
    return offsets.byteOffsetAtUtf16(charOffset);
};
export const hasSyntaxProblem = (node) => node.isError || node.isMissing || node.children.some(hasSyntaxProblem);
export const diagnosticsFor = (node) => {
    const diagnostics = [];
    const visit = (current) => {
        if (current.isError || current.isMissing) {
            diagnostics.push(`${current.type} at ${current.startPosition.row + 1}:${current.startPosition.column}`);
        }
        for (const child of current.children)
            visit(child);
    };
    visit(node);
    return diagnostics;
};
export const positionFor = (node) => ({
    startLine: node.startPosition.row + 1,
    startColumn: node.startPosition.column,
    endLine: node.endPosition.row + 1,
    endColumn: node.endPosition.column,
});
export const signatureFor = (source, node) => {
    const body = node.children.find((child) => child.type === 'block');
    const endUtf16Index = body?.startIndex ?? node.endIndex;
    return source.text.slice(node.startIndex, endUtf16Index).replace(/\s+/gu, ' ').trim();
};
