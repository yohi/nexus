import { decodeUtf8 } from '../../structured/hash.js';
import { fixedLineFallback } from './python-legacy.js';
import { PythonStructuredParser } from './python-structured.js';
const textEncoder = new TextEncoder();
const warnFallback = (error) => console.warn('python-structured-parser.fallback', error);
const sourceFor = (file) => ({
    filePath: file.filePath,
    language: file.language,
    bytes: file.bytes ?? textEncoder.encode(file.content),
    text: file.content,
});
const loadTreeSitter = async () => {
    const [parser, python] = await Promise.all([import('tree-sitter'), import('tree-sitter-python')]);
    return { Parser: parser.default, Python: python.default };
};
const projectLegacyResult = (result, source) => {
    const declarations = result.declarations.map(({ kind, name, position, rawSource }) => ({
        type: kind, name, startLine: position.startLine, endLine: position.endLine, content: rawSource ?? '',
    }));
    const ranges = [...new Map(result.imports.map((item) => [`${item.startByte}:${item.endByte}`, item])).values()]
        .toSorted((left, right) => left.startByte - right.startByte);
    const first = ranges[0];
    const last = ranges.at(-1);
    if (first && last) {
        declarations.push({
            type: 'import', name: 'imports', startLine: first.position.startLine, endLine: last.position.endLine,
            content: decodeUtf8(source.bytes.subarray(first.startByte, last.endByte)),
        });
    }
    return {
        rootType: 'module',
        declarations: declarations.toSorted((left, right) => left.startLine - right.startLine),
    };
};
export class PythonLanguagePlugin {
    languageId = 'python';
    fileExtensions = ['.py', '.pyi'];
    supports(filePath) {
        return this.fileExtensions.some((extension) => filePath.endsWith(extension));
    }
    async createStructuredParser() {
        return new PythonStructuredParser(await loadTreeSitter());
    }
    async createParser() {
        try {
            const structured = await this.createStructuredParser();
            return {
                parse: async (file) => {
                    try {
                        const source = sourceFor(file);
                        return projectLegacyResult(await structured.parseStructured(source), source);
                    }
                    catch (error) {
                        if (error instanceof Error) {
                            warnFallback(error);
                            return fixedLineFallback(file);
                        }
                        throw error;
                    }
                },
            };
        }
        catch (error) {
            if (error instanceof Error) {
                warnFallback(error);
                return { parse: async (file) => fixedLineFallback(file) };
            }
            throw error;
        }
    }
}
