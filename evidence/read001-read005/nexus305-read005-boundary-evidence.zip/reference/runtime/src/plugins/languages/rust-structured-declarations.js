import { hasSyntaxProblem } from './tree-sitter-structured-support.js';
const declarationKeyFor = (node) => `${node.startIndex}:${node.endIndex}:${node.type}`;
const joinQualifiedName = (scope, name) => scope === '' ? name : `${scope}.${name}`;
const nameNodeText = (node) => {
    const name = node.childForFieldName('name');
    return name?.text;
};
const typePathFor = (node) => {
    if (node.type === 'generic_type' || node.type === 'type') {
        const pathNode = node.namedChildren.find((child) => child.type !== 'type_arguments');
        return pathNode === undefined ? undefined : typePathFor(pathNode);
    }
    if (!['identifier', 'scoped_identifier', 'type_identifier', 'scoped_type_identifier'].includes(node.type)) {
        return undefined;
    }
    return node.text.replace(/^::/u, '').replaceAll('::', '.');
};
const bodyNode = (node) => node.children.find((child) => child.type === 'declaration_list' || child.type === 'block');
const kindForType = (node) => {
    if (node.type === 'enum_item')
        return 'enum';
    if (node.type === 'trait_item')
        return 'trait';
    return 'struct';
};
const kindForFunction = (node, scope) => {
    if (node.type === 'function_item' && scope.scopeNode?.type === 'impl_item') {
        return 'method';
    }
    return 'function';
};
const declarationFor = (node, scope) => {
    const declarationKey = declarationKeyFor(node);
    const ownerKey = scope.ownerKey;
    const scopeNode = scope.scopeNode;
    switch (node.type) {
        case 'mod_item': {
            const name = nameNodeText(node);
            if (!name)
                return undefined;
            return {
                node, rangeNode: node, scopeNode, declarationKey, ownerKey,
                kind: 'namespace',
                name,
                qualifiedName: joinQualifiedName(scope.qualifiedName, name),
            };
        }
        case 'struct_item':
        case 'enum_item':
        case 'trait_item': {
            const name = nameNodeText(node);
            if (!name)
                return undefined;
            return {
                node, rangeNode: node, scopeNode, declarationKey, ownerKey,
                kind: kindForType(node),
                name,
                qualifiedName: joinQualifiedName(scope.qualifiedName, name),
            };
        }
        case 'impl_item': {
            const typeNode = node.childForFieldName('type') ?? node.children.find((c) => c.type === 'type');
            const traitNode = node.childForFieldName('trait') ?? undefined;
            const name = typeNode === undefined ? undefined : typePathFor(typeNode);
            if (!name)
                return undefined;
            const targetQualifiedName = joinQualifiedName(scope.qualifiedName, name);
            const traitName = traitNode === undefined ? undefined : typePathFor(traitNode);
            const qualifiedName = traitName !== undefined
                ? `${joinQualifiedName(scope.qualifiedName, traitName)}.${name}.impl`
                : `${targetQualifiedName}.impl`;
            return {
                node, rangeNode: node, scopeNode, declarationKey, ownerKey,
                kind: 'impl',
                name,
                qualifiedName,
                targetQualifiedName,
            };
        }
        case 'function_item':
        case 'function_signature_item': {
            const name = nameNodeText(node);
            if (!name)
                return undefined;
            return {
                node, rangeNode: node, scopeNode, declarationKey, ownerKey,
                kind: kindForFunction(node, scope),
                name,
                qualifiedName: joinQualifiedName(scope.qualifiedName, name),
            };
        }
        default:
            return undefined;
    }
};
const isContainer = (descriptor) => descriptor.kind === 'namespace' || descriptor.kind === 'impl' || descriptor.kind === 'trait';
const childrenScopeFor = (descriptor, typeDescriptors) => {
    if (descriptor.kind === 'impl') {
        const targetQualifiedName = descriptor.targetQualifiedName ?? descriptor.qualifiedName;
        const targetCandidates = typeDescriptors.filter((candidate) => candidate.qualifiedName === targetQualifiedName);
        const target = targetCandidates.length === 1 ? targetCandidates[0] : undefined;
        return {
            qualifiedName: targetQualifiedName,
            ownerKey: target?.declarationKey,
            scopeNode: descriptor.node,
        };
    }
    return {
        qualifiedName: descriptor.qualifiedName,
        ownerKey: descriptor.declarationKey,
        scopeNode: descriptor.node,
    };
};
export const declarationsFor = (root) => {
    const typeDescriptors = [];
    const collectTypeDescriptors = (node, scope) => {
        const descriptor = declarationFor(node, scope);
        if (descriptor === undefined)
            return;
        if (descriptor.kind === 'struct' || descriptor.kind === 'enum' || descriptor.kind === 'trait') {
            typeDescriptors.push(descriptor);
        }
        if (!isContainer(descriptor))
            return;
        if (hasSyntaxProblem(node))
            return;
        const body = bodyNode(node);
        if (body === undefined)
            return;
        const childScope = descriptor.kind === 'impl'
            ? { qualifiedName: descriptor.targetQualifiedName ?? descriptor.qualifiedName, scopeNode: descriptor.node }
            : { qualifiedName: descriptor.qualifiedName, ownerKey: descriptor.declarationKey, scopeNode: descriptor.node };
        for (const child of body.namedChildren)
            collectTypeDescriptors(child, childScope);
    };
    for (const child of root.namedChildren)
        collectTypeDescriptors(child, { qualifiedName: '' });
    const unresolved = [];
    const walk = (node, scope) => {
        const descriptor = declarationFor(node, scope);
        if (descriptor === undefined)
            return;
        unresolved.push(descriptor);
        if (!isContainer(descriptor))
            return;
        if (hasSyntaxProblem(node))
            return;
        const body = bodyNode(node);
        if (body === undefined)
            return;
        const childScope = childrenScopeFor(descriptor, typeDescriptors);
        for (const child of body.namedChildren)
            walk(child, childScope);
    };
    for (const child of root.namedChildren) {
        walk(child, { qualifiedName: '' });
    }
    return unresolved.map(({ targetQualifiedName: _target, ...descriptor }) => descriptor);
};
