import { declarationsFor } from './rust-structured-declarations.js';
import { importsFor } from './rust-structured-imports.js';
import { declarationStartByteFor } from './rust-structured-support.js';
import { createTreeSitterStructuredParserClass, } from './tree-sitter-structured-parser.js';
export const RustStructuredParser = createTreeSitterStructuredParserClass({
    languageId: 'rust',
    parserVersion: '0.24.0',
    declarationsFor,
    importsFor,
    startByteFor: declarationStartByteFor,
});
