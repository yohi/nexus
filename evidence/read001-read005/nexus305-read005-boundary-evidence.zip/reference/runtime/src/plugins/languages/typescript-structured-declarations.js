import ts from 'typescript';
const normalizedIdentifier = (identifier) => identifier.text.normalize('NFC');
const hasDefaultModifier = (node) => ts.canHaveModifiers(node) &&
    (ts.getModifiers(node) ?? []).some((modifier) => modifier.kind === ts.SyntaxKind.DefaultKeyword);
const declarationNameFor = (node) => {
    if (hasDefaultModifier(node))
        return 'default';
    return node.name ? normalizedIdentifier(node.name) : undefined;
};
const variableDescriptor = (node) => {
    if (!ts.isIdentifier(node.name) || !ts.isVariableDeclarationList(node.parent) || node.parent.declarations.length !== 1) {
        return undefined;
    }
    const rangeStartNode = ts.isVariableStatement(node.parent.parent) ? node.parent.parent : node.parent;
    let kind;
    if (node.initializer && (ts.isArrowFunction(node.initializer) || ts.isFunctionExpression(node.initializer))) {
        kind = 'function';
    }
    else if (node.parent.getChildren().some((child) => child.kind === ts.SyntaxKind.ConstKeyword || child.kind === ts.SyntaxKind.UsingKeyword)) {
        kind = 'constant';
    }
    else {
        kind = 'variable';
    }
    return {
        name: normalizedIdentifier(node.name),
        kind,
        createsScope: false,
        rangeStartNode,
        signatureNode: node,
    };
};
const constructorDescriptor = (node) => {
    if (!ts.isConstructorDeclaration(node))
        return undefined;
    return { name: 'constructor', kind: 'constructor', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const classDescriptor = (node) => {
    if (!ts.isClassDeclaration(node))
        return undefined;
    const name = declarationNameFor(node);
    if (!name)
        return undefined;
    return { name, kind: 'class', createsScope: true, rangeStartNode: node, signatureNode: node };
};
const functionDescriptor = (node) => {
    if (!ts.isFunctionDeclaration(node))
        return undefined;
    const name = declarationNameFor(node);
    if (!name)
        return undefined;
    return { name, kind: 'function', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const interfaceDescriptor = (node) => {
    if (!ts.isInterfaceDeclaration(node))
        return undefined;
    return { name: normalizedIdentifier(node.name), kind: 'interface', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const methodDescriptor = (node) => {
    if (!ts.isMethodDeclaration(node) && !ts.isGetAccessorDeclaration(node) && !ts.isSetAccessorDeclaration(node)) {
        return undefined;
    }
    if (!ts.isIdentifier(node.name))
        return undefined;
    return { name: normalizedIdentifier(node.name), kind: 'method', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const enumDescriptor = (node) => {
    if (!ts.isEnumDeclaration(node))
        return undefined;
    return { name: normalizedIdentifier(node.name), kind: 'enum', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const typeAliasDescriptor = (node) => {
    if (!ts.isTypeAliasDeclaration(node))
        return undefined;
    return { name: normalizedIdentifier(node.name), kind: 'typeAlias', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const propertyDescriptor = (node) => {
    if (!ts.isPropertyDeclaration(node) || !ts.isIdentifier(node.name))
        return undefined;
    return { name: normalizedIdentifier(node.name), kind: 'property', createsScope: false, rangeStartNode: node, signatureNode: node };
};
const moduleDescriptor = (node) => {
    if (!ts.isModuleDeclaration(node))
        return undefined;
    return { name: node.name.text.normalize('NFC'), kind: 'namespace', createsScope: true, rangeStartNode: node, signatureNode: node };
};
const variableDeclarationDescriptor = (node) => ts.isVariableDeclaration(node) ? variableDescriptor(node) : undefined;
const exportAssignmentKindFor = (node) => {
    const expression = node.expression;
    if (ts.isArrowFunction(expression) || ts.isFunctionExpression(expression))
        return 'function';
    if (ts.isClassExpression(expression))
        return 'class';
    return undefined;
};
const exportAssignmentDescriptor = (node) => {
    if (!ts.isExportAssignment(node) || node.isExportEquals)
        return undefined;
    const kind = exportAssignmentKindFor(node);
    if (!kind)
        return undefined;
    const createsScope = kind === 'class';
    return {
        name: 'default',
        kind,
        createsScope,
        rangeStartNode: node,
        signatureNode: node.expression,
        signaturePrefix: 'default',
    };
};
const declarationDescriptorFactories = [
    constructorDescriptor,
    classDescriptor,
    functionDescriptor,
    interfaceDescriptor,
    methodDescriptor,
    enumDescriptor,
    typeAliasDescriptor,
    propertyDescriptor,
    moduleDescriptor,
    variableDeclarationDescriptor,
    exportAssignmentDescriptor,
];
export const describeDeclaration = (node) => {
    for (const factory of declarationDescriptorFactories) {
        const descriptor = factory(node);
        if (descriptor)
            return descriptor;
    }
    return undefined;
};
