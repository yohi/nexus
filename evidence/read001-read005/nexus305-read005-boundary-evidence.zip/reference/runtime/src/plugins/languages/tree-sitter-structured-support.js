const defaultDiagnosticFor = (node) => `${node.type} at ${node.startPosition.row + 1}:${node.startPosition.column}`;
export const hasSyntaxProblem = (node) => node.isError || node.isMissing || node.children.some(hasSyntaxProblem);
export const diagnosticsFor = (root, formatDiagnostic = defaultDiagnosticFor) => {
    const diagnostics = [];
    const visit = (node) => {
        if (node.isError || node.isMissing)
            diagnostics.push(formatDiagnostic(node));
        for (const child of node.children)
            visit(child);
    };
    visit(root);
    return diagnostics;
};
export const positionFor = (node) => ({
    startLine: node.startPosition.row + 1,
    startColumn: node.startPosition.column,
    endLine: node.endPosition.row + 1,
    endColumn: node.endPosition.column,
});
export const signatureFor = (source, node) => {
    const body = node.childForFieldName('body')
        ?? node.childForFieldName('declaration_list')
        ?? node.namedChildren.find((child) => child.type === 'block');
    return source.text.slice(node.startIndex, body?.startIndex ?? node.endIndex).replace(/\s+/gu, ' ').trim();
};
export const startByteFor = (node, offsets) => offsets.byteOffsetAtUtf16(node.startIndex);
