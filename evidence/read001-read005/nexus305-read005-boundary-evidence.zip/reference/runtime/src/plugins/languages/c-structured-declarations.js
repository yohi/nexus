import { hasSyntaxProblem } from './tree-sitter-structured-support.js';
const keyFor = (node) => `${node.startIndex}:${node.endIndex}:${node.type}`;
const declaratorName = (node) => {
    const named = node.childForFieldName('declarator');
    if (named !== null)
        return declaratorName(named) ?? named.text;
    return node.childForFieldName('name')?.text ?? node.namedChildren.find((child) => ['identifier', 'type_identifier'].includes(child.type))?.text;
};
const descriptorFor = (node) => {
    if (node.type === 'function_definition') {
        const name = declaratorName(node);
        return name === undefined ? undefined : {
            node, rangeNode: node, declarationKey: keyFor(node), kind: 'function', name, qualifiedName: name,
        };
    }
    const taggedType = node.type === 'declaration' ? node.childForFieldName('type') : node;
    if (taggedType?.type === 'struct_specifier' || taggedType?.type === 'enum_specifier') {
        const name = taggedType.childForFieldName('name')?.text ?? taggedType.namedChildren.find((child) => child.type === 'type_identifier')?.text;
        return name === undefined ? undefined : {
            node,
            rangeNode: taggedType,
            declarationKey: keyFor(node),
            kind: taggedType.type === 'struct_specifier' ? 'struct' : 'enum',
            name,
            qualifiedName: name,
        };
    }
    return undefined;
};
export const declarationsFor = (root) => {
    const result = [];
    const walk = (node) => {
        const descriptor = descriptorFor(node);
        if (descriptor !== undefined) {
            if (!hasSyntaxProblem(descriptor.node) && !hasSyntaxProblem(descriptor.rangeNode))
                result.push(descriptor);
            return;
        }
        for (const child of node.namedChildren)
            walk(child);
    };
    for (const child of root.namedChildren)
        walk(child);
    return result;
};
