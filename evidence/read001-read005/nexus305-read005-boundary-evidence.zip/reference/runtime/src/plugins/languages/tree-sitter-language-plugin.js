import { decodeUtf8 } from '../../structured/hash.js';
const textEncoder = new TextEncoder();
export const loadTreeSitterLanguage = async (languageModule) => {
    const [parser, language] = await Promise.all([import('tree-sitter'), languageModule]);
    return { Parser: parser.default, language: language.default };
};
const sourceFor = (file) => {
    const bytes = file.bytes ?? textEncoder.encode(file.content);
    return {
        filePath: file.filePath,
        language: file.language,
        bytes,
        text: file.bytes === undefined ? file.content : decodeUtf8(bytes),
    };
};
export const projectLegacyResult = (result, source, options) => {
    const declarations = result.declarations.map(({ kind, name, position, rawSource }) => ({
        type: options.typeFor?.(kind) ?? kind,
        name,
        startLine: position.startLine,
        endLine: position.endLine,
        content: rawSource ?? '',
    }));
    const ranges = [...new Map(result.imports.map((item) => [`${item.startByte}:${item.endByte}`, item])).values()]
        .toSorted((left, right) => left.startByte - right.startByte);
    for (const item of ranges) {
        declarations.push({
            type: 'import',
            name: 'imports',
            startLine: item.position.startLine,
            endLine: item.position.endLine,
            content: decodeUtf8(source.bytes.subarray(item.startByte, item.endByte)),
        });
    }
    return {
        rootType: options.rootType,
        declarations: declarations.toSorted((left, right) => left.startLine - right.startLine),
    };
};
export class TreeSitterLanguagePlugin {
    config;
    languageId;
    fileExtensions;
    constructor(config) {
        this.config = config;
        this.languageId = config.languageId;
        this.fileExtensions = [...config.fileExtensions];
    }
    supports(filePath) {
        return this.fileExtensions.some((extension) => filePath.endsWith(extension));
    }
    createStructuredParser() {
        return this.config.createStructuredParser();
    }
    async createParser() {
        try {
            const structured = await this.createStructuredParser();
            const parse = async (file) => {
                try {
                    const source = sourceFor(file);
                    const result = await structured.parseStructured(source);
                    if (result.status !== 'ok' && result.status !== 'degraded') {
                        const fallback = this.config.parseFailureFallback;
                        if (fallback !== undefined)
                            return fallback(file);
                        throw new Error(result.failure.message);
                    }
                    return projectLegacyResult(result, source, { rootType: this.config.rootType });
                }
                catch (error) {
                    if (error instanceof Error)
                        this.config.onParseFailure?.(error);
                    throw error;
                }
            };
            return { parse };
        }
        catch (error) {
            const fallback = this.config.initializationFallback;
            if (fallback === undefined || !(error instanceof Error))
                throw error;
            this.config.onInitializationFailure?.(error);
            return { parse: async (file) => fallback(file) };
        }
    }
}
export const createTreeSitterLanguagePlugin = (config) => class extends TreeSitterLanguagePlugin {
    constructor() {
        super(config);
    }
};
