import ts from 'typescript';
export const flattenDiagnosticMessage = (messageText) => ts.flattenDiagnosticMessageText(messageText, '\n');
