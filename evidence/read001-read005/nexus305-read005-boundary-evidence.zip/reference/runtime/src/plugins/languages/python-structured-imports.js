import { sha256Hex } from '../../structured/hash.js';
import { createSymbolId } from '../../structured/identity.js';
const moduleControlFlowStatements = new Set(['for_statement', 'if_statement', 'try_statement', 'while_statement', 'with_statement']);
const isDeclaration = (node) => node.type === 'class_definition' || node.type === 'function_definition' || node.type === 'async_function_definition';
const definitionFor = (node) => {
    if (isDeclaration(node))
        return node;
    if (node.type !== 'decorated_definition')
        return undefined;
    const definition = node.childForFieldName('definition');
    return definition && isDeclaration(definition) ? definition : undefined;
};
const positionFor = (node) => ({
    startLine: node.startPosition.row + 1,
    startColumn: node.startPosition.column,
    endLine: node.endPosition.row + 1,
    endColumn: node.endPosition.column,
});
const byteRangeFor = (offsets, node) => ({
    startByte: offsets.byteOffsetAtUtf16(node.startIndex),
    endByte: offsets.byteOffsetAtUtf16(node.endIndex),
});
const bindingNamesFor = (node) => {
    if (node.type === 'identifier')
        return [node.text];
    if (node.type !== 'pattern_list' && node.type !== 'list_pattern' && node.type !== 'tuple_pattern')
        return [];
    return node.namedChildren.flatMap(bindingNamesFor);
};
const bindingTargetFor = (node) => {
    if (node.type === 'assignment' || node.type === 'for_statement')
        return node.childForFieldName('left') ?? undefined;
    if (node.type !== 'expression_statement')
        return undefined;
    return node.namedChildren.find((child) => child.type === 'assignment')?.childForFieldName('left') ?? undefined;
};
const bindingNamesInNestedBlocks = (node) => {
    if (definitionFor(node))
        return [];
    if (node.type === 'block')
        return node.namedChildren.flatMap(bindingNamesInStatement);
    return node.namedChildren.flatMap(bindingNamesInNestedBlocks);
};
const bindingNamesInStatement = (node) => {
    const definition = definitionFor(node);
    if (definition) {
        const name = definition.childForFieldName('name')?.text;
        return name ? [name] : [];
    }
    const target = bindingTargetFor(node);
    const bindings = target ? [...bindingNamesFor(target)] : [];
    if (!moduleControlFlowStatements.has(node.type))
        return bindings;
    return [...bindings, ...node.namedChildren.flatMap(bindingNamesInNestedBlocks)];
};
const bindingFor = (node, moduleSpecifier, fromImport) => {
    const imported = node.type === 'aliased_import' ? node.childForFieldName('name') : node;
    if (!imported)
        return undefined;
    const alias = node.type === 'aliased_import' ? node.childForFieldName('alias')?.text : undefined;
    const segments = imported.text.split('.');
    const fallback = fromImport ? segments.at(-1) : segments[0];
    return fallback ? { moduleSpecifier, bindingName: alias ?? fallback, partial: false } : undefined;
};
const importBindingsFor = (node) => {
    if (node.type === 'import_statement') {
        return node.childrenForFieldName('name').flatMap((item) => {
            const binding = bindingFor(item, item.type === 'aliased_import' ? item.childForFieldName('name')?.text ?? item.text : item.text, false);
            return binding ? [binding] : [];
        });
    }
    const moduleSpecifier = node.childForFieldName('module_name')?.text;
    if (!moduleSpecifier)
        return [];
    const bindings = node.childrenForFieldName('name').flatMap((item) => {
        const binding = bindingFor(item, moduleSpecifier, true);
        return binding ? [binding] : [];
    });
    return bindings.length > 0 ? bindings : [{ moduleSpecifier, partial: true }];
};
const completenessFor = (binding, bindingsBefore) => {
    if (binding.partial)
        return 'partial';
    if (binding.bindingName !== undefined && bindingsBefore.has(binding.bindingName))
        return 'partial';
    return 'complete';
};
const importsForNode = (node, context) => {
    if ((node.type !== 'import_statement' && node.type !== 'import_from_statement') || context.problemNodeIds.has(node.id)) {
        return [];
    }
    const { source, offsets, bindingsBefore, occurrences } = context;
    const { startByte, endByte } = byteRangeFor(offsets, node);
    return importBindingsFor(node).map((binding) => {
        const key = `${binding.moduleSpecifier}\u0000${binding.bindingName ?? '*'}`;
        const occurrence = occurrences.get(key) ?? 0;
        occurrences.set(key, occurrence + 1);
        const completeness = completenessFor(binding, bindingsBefore);
        const imported = {
            id: createSymbolId({
                filePath: source.filePath,
                qualifiedName: binding.bindingName ?? '*',
                kind: 'import',
                signatureDiscriminator: binding.moduleSpecifier,
                occurrence,
            }),
            moduleSpecifier: binding.moduleSpecifier,
            bindingName: binding.bindingName,
            startByte,
            endByte,
            sourceHash: sha256Hex(source.bytes.subarray(startByte, endByte)),
            completeness,
            position: positionFor(node),
        };
        if (binding.bindingName)
            bindingsBefore.add(binding.bindingName);
        return imported;
    });
};
export const importsFor = ({ source, root, offsets, problemNodeIds }) => {
    const bindingsBefore = new Set();
    const occurrences = new Map();
    const imports = [];
    const context = { source, offsets, problemNodeIds, bindingsBefore, occurrences };
    for (const node of root.namedChildren) {
        imports.push(...importsForNode(node, context));
        for (const binding of bindingNamesInStatement(node))
            bindingsBefore.add(binding);
    }
    return imports;
};
