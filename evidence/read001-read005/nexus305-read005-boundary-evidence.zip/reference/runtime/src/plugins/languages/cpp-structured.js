import { declarationsFor } from './cpp-structured-declarations.js';
import { importsFor } from './cpp-structured-imports.js';
import { createTreeSitterStructuredParserClass, } from './tree-sitter-structured-parser.js';
export const CppStructuredParser = createTreeSitterStructuredParserClass({
    languageId: 'cpp',
    parserVersion: '0.23.4',
    declarationsFor,
    importsFor,
    checkScopeNode: true,
});
