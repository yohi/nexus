import { declarationsFor } from './csharp-structured-declarations.js';
import { importsFor } from './csharp-structured-imports.js';
import { createTreeSitterStructuredParserClass, } from './tree-sitter-structured-parser.js';
import { signatureFor } from './tree-sitter-structured-support.js';
export const CSharpStructuredParser = createTreeSitterStructuredParserClass({
    languageId: 'csharp',
    parserVersion: '0.23.5',
    declarationsFor,
    importsFor,
    checkScopeNode: true,
    signatureFor: (source, node) => {
        if (node.type === 'property_declaration')
            return node.text.replace(/\s+/gu, ' ').trim();
        return signatureFor(source, node);
    },
});
