import { hasSyntaxProblem } from './tree-sitter-structured-support.js';
const keyFor = (node, index = 0) => `${node.startIndex}:${node.endIndex}:${node.type}:${index}`;
const join = (scope, name) => scope === '' ? name : `${scope}.${name}`;
const nameFor = (node) => node.childForFieldName('name')?.text ?? node.namedChildren.find((child) => ['identifier', 'type_identifier', 'scoped_identifier'].includes(child.type))?.text;
const bodyFor = (node) => node.childForFieldName('body') ?? node.namedChildren.find((child) => ['class_body', 'interface_body', 'enum_body', 'record_body', 'block'].includes(child.type));
const kindFor = (node) => {
    switch (node.type) {
        case 'class_declaration': return 'class';
        case 'interface_declaration': return 'interface';
        case 'enum_declaration': return 'enum';
        case 'record_declaration': return 'record';
        case 'method_declaration': return 'method';
        case 'constructor_declaration': return 'constructor';
        case 'field_declaration': return 'field';
        default: return undefined;
    }
};
const descriptorsForNode = (node, scope) => {
    if (node.type === 'package_declaration') {
        const name = nameFor(node);
        return name === undefined ? [] : [{
                node, rangeNode: node, scopeNode: scope.scopeNode,
                declarationKey: keyFor(node), ownerKey: scope.ownerKey, kind: 'namespace', name,
                qualifiedName: join(scope.qualifiedName, name),
            }];
    }
    const kind = kindFor(node);
    if (kind === undefined)
        return [];
    if (kind === 'field') {
        return node.namedChildren
            .filter((child) => child.type === 'variable_declarator')
            .flatMap((child, index) => {
            const name = child.childForFieldName('name')?.text;
            return name === undefined ? [] : [{
                    node, rangeNode: node, scopeNode: scope.scopeNode,
                    declarationKey: keyFor(child, index), ownerKey: scope.ownerKey, kind, name,
                    qualifiedName: join(scope.qualifiedName, name),
                }];
        });
    }
    const name = nameFor(node);
    return name === undefined ? [] : [{
            node, rangeNode: node, scopeNode: scope.scopeNode,
            declarationKey: keyFor(node), ownerKey: scope.ownerKey, kind, name,
            qualifiedName: join(scope.qualifiedName, name),
        }];
};
const isContainer = (descriptor) => ['namespace', 'class', 'interface', 'enum', 'record'].includes(descriptor.kind);
export const declarationsFor = (root) => {
    const packageNode = root.namedChildren.find((child) => child.type === 'package_declaration');
    const packageDescriptor = packageNode === undefined
        ? undefined
        : descriptorsForNode(packageNode, { qualifiedName: '' })[0];
    const unresolved = [];
    if (packageDescriptor !== undefined)
        unresolved.push(packageDescriptor);
    const walk = (node, scope) => {
        const descriptors = descriptorsForNode(node, scope);
        for (const descriptor of descriptors) {
            if (descriptor.node === packageNode)
                continue;
            unresolved.push(descriptor);
            if (isContainer(descriptor)) {
                const body = bodyFor(node);
                if (body === undefined || hasSyntaxProblem(node))
                    continue;
                const childScope = {
                    qualifiedName: descriptor.qualifiedName,
                    ownerKey: descriptor.declarationKey,
                    scopeNode: descriptor.node,
                };
                for (const child of body.namedChildren)
                    walk(child, childScope);
            }
        }
    };
    const baseScope = packageDescriptor === undefined
        ? { qualifiedName: '' }
        : {
            qualifiedName: packageDescriptor.qualifiedName,
            ownerKey: packageDescriptor.declarationKey,
            scopeNode: packageDescriptor.node,
        };
    for (const child of root.namedChildren) {
        if (child.type === 'package_declaration' || child.type === 'import_declaration')
            continue;
        walk(child, baseScope);
    }
    return unresolved;
};
