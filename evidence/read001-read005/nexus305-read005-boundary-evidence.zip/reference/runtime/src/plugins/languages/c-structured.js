import { declarationsFor } from './c-structured-declarations.js';
import { importsFor } from './c-structured-imports.js';
import { createTreeSitterStructuredParserClass, } from './tree-sitter-structured-parser.js';
export const CStructuredParser = createTreeSitterStructuredParserClass({
    languageId: 'c',
    parserVersion: '0.24.1',
    declarationsFor,
    importsFor,
    checkScopeNode: true,
    diagnosticFor: (node) => `${node.type}@${node.startIndex}`,
});
