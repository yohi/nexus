import { declarationsFor } from './java-structured-declarations.js';
import { importsFor } from './java-structured-imports.js';
import { createTreeSitterStructuredParserClass, } from './tree-sitter-structured-parser.js';
export const JavaStructuredParser = createTreeSitterStructuredParserClass({
    languageId: 'java',
    parserVersion: '0.23.5',
    declarationsFor,
    importsFor,
    checkScopeNode: true,
});
