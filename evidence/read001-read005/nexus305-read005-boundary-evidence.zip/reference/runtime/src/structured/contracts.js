export const structuredRetrievalStatus = {
    ok: 'ok',
    degraded: 'degraded',
    unsupported: 'unsupported',
    failed: 'failed',
};
export const structuredRetrievalReasonCode = {
    parseError: 'parse_error',
    unsupportedLanguage: 'unsupported_language',
    invalidUtf8: 'invalid_utf8',
    invariantViolation: 'invariant_violation',
};
