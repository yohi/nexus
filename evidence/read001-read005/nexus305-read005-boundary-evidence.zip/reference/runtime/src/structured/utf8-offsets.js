import { decodeUtf8 } from './hash.js';
export class Utf8SourceError extends Error {
    reasonCode;
    name = 'Utf8SourceError';
    constructor(reasonCode, message, options) {
        super(message, options);
        this.reasonCode = reasonCode;
    }
}
export const failedStructuredSource = (error) => ({
    status: 'failed',
    retrievability: 'none',
    declarations: [],
    imports: [],
    failure: { reasonCode: error.reasonCode, message: error.message },
});
const hasUtf8Bom = (bytes) => bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf;
const byteWidthFor = (byte) => {
    if (byte <= 0x7f)
        return 1;
    if (byte >= 0xc2 && byte <= 0xdf)
        return 2;
    if (byte >= 0xe0 && byte <= 0xef)
        return 3;
    if (byte >= 0xf0 && byte <= 0xf4)
        return 4;
    throw new Utf8SourceError('invalid_utf8', 'Structured source contains an invalid UTF-8 leading byte.');
};
export const createUtf8OffsetTable = (text, sourceBytes) => {
    let decoded;
    try {
        decoded = decodeUtf8(sourceBytes);
    }
    catch (error) {
        if (!(error instanceof TypeError))
            throw error;
        throw new Utf8SourceError('invalid_utf8', 'Structured source bytes are not valid UTF-8.', { cause: error });
    }
    if (decoded !== text) {
        throw new Utf8SourceError('invariant_violation', 'Structured source text does not match the original UTF-8 bytes.');
    }
    const offsets = new Uint32Array(text.length + 1);
    let textOffset = 0;
    let byteOffset = hasUtf8Bom(sourceBytes) ? 3 : 0;
    offsets[0] = byteOffset;
    while (textOffset < text.length) {
        const codePoint = text.codePointAt(textOffset);
        if (codePoint === undefined) {
            throw new Utf8SourceError('invariant_violation', 'Structured source text has an invalid UTF-16 boundary.');
        }
        const firstByte = sourceBytes[byteOffset];
        if (firstByte === undefined) {
            throw new Utf8SourceError('invariant_violation', 'Structured source bytes ended before the source text.');
        }
        byteOffset += byteWidthFor(firstByte);
        textOffset += codePoint > 0xffff ? 2 : 1;
        if (codePoint > 0xffff)
            offsets[textOffset - 1] = byteOffset;
        offsets[textOffset] = byteOffset;
    }
    if (byteOffset !== sourceBytes.length) {
        throw new Utf8SourceError('invariant_violation', 'Structured source byte and text lengths do not match.');
    }
    return { byteOffsetAtUtf16: (offset) => offsets[offset] ?? byteOffset };
};
