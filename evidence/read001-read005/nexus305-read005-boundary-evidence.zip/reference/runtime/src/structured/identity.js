import { createHash } from 'node:crypto';
export const createGenerationId = (input) => createHash('sha256').update(JSON.stringify([
    input.schemaVersion,
    input.parserId,
    input.parserVersion,
    input.contentHash,
]), 'utf8').digest('base64url');
export const createSymbolId = (input) => `symbol_v1_${createHash('sha256').update(JSON.stringify([
    1,
    input.filePath,
    input.qualifiedName,
    input.kind,
    input.signatureDiscriminator,
    input.occurrence,
]), 'utf8').digest('base64url')}`;
