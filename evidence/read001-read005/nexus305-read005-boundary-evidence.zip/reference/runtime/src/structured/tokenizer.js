import { Tiktoken } from 'js-tiktoken/lite';
import cl100kBase from 'js-tiktoken/ranks/cl100k_base';
const encoder = new Tiktoken(cl100kBase);
// js-tiktoken@1.0.21 does not export package.json; keep this synchronized with package.json and package-lock.json.
const jsTiktokenVersion = '1.0.21';
export const tokenCounter = {
    tokenizer: 'cl100k_base',
    tokenizerVersion: `js-tiktoken@${jsTiktokenVersion}`,
    count: (text) => encoder.encode(text).length,
};
export const buildCanonicalContext = (imports, symbolSource) => {
    const importText = imports.join('\n');
    return importText.length > 0 ? `${importText}\n\n${symbolSource}` : symbolSource;
};
export const packRelatedImports = (input) => {
    const selected = [];
    const seen = new Set();
    let omittedForBudget = 0;
    let selectedTokenCount = tokenCounter.count(input.symbolSource);
    for (const candidate of input.imports) {
        if (seen.has(candidate.id)) {
            continue;
        }
        seen.add(candidate.id);
        const proposedImports = [...selected.map((item) => item.rawSource), candidate.rawSource];
        const proposedTokenCount = tokenCounter.count(buildCanonicalContext(proposedImports, input.symbolSource));
        if (proposedTokenCount <= input.tokenBudget) {
            selected.push(candidate);
            selectedTokenCount = proposedTokenCount;
        }
        else {
            omittedForBudget += 1;
        }
    }
    const context = buildCanonicalContext(selected.map((candidate) => candidate.rawSource), input.symbolSource);
    return {
        context,
        imports: selected,
        tokenizer: tokenCounter.tokenizer,
        tokenizerVersion: tokenCounter.tokenizerVersion,
        budget: {
            exceeded: selectedTokenCount > input.tokenBudget,
            omittedForBudget,
        },
    };
};
