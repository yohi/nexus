import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { sha256Hex, decodeUtf8 } from './hash.js';
import { packRelatedImports, tokenCounter } from './tokenizer.js';
export class SymbolRetrievalService {
    options;
    constructor(options) {
        this.options = options;
    }
    async getFileOutline(input) {
        const relativePath = this.options.sanitizer.validateProjectRelative(input.filePath);
        const state = await this.options.catalog.getStructuredIndexState();
        const domain = this.checkGlobalState(state);
        if (domain !== undefined) {
            return { ...domain, request: { filePath: input.filePath } };
        }
        if (this.options.isExcluded) {
            const excluded = await this.options.isExcluded(relativePath);
            if (excluded) {
                return {
                    status: 'excluded',
                    freshness: 'unknown',
                    reindexRequired: false,
                    reasonCode: 'PATH_EXCLUDED',
                    request: { filePath: input.filePath },
                };
            }
        }
        const projectRoot = this.options.sanitizer.getProjectRoot();
        for (let attempt = 0; attempt < 2; attempt += 1) {
            const resolution = await this.options.catalog.resolveFile(relativePath);
            if (resolution.kind === 'pending') {
                return {
                    status: 'index_incomplete',
                    freshness: 'unknown',
                    reindexRequired: true,
                    reasonCode: 'INDEX_PENDING_GENERATION',
                    request: { filePath: input.filePath },
                };
            }
            const readResult = await this.readCurrentBytes(relativePath, projectRoot, input.signal);
            if (resolution.kind === 'missing') {
                if (readResult.status !== 'ok') {
                    return {
                        status: 'not_found',
                        freshness: 'unknown',
                        reindexRequired: false,
                        reasonCode: 'FILE_NOT_FOUND',
                        request: { filePath: input.filePath },
                    };
                }
                return {
                    status: 'not_indexed',
                    freshness: 'unknown',
                    reindexRequired: true,
                    reasonCode: 'STRUCTURED_INDEX_MISSING',
                    request: { filePath: input.filePath },
                };
            }
            // Active file: verify freshness before returning metadata.
            if (readResult.status !== 'ok') {
                return {
                    status: 'stale',
                    freshness: 'stale',
                    reindexRequired: true,
                    reasonCode: readResult.reasonCode,
                    request: { filePath: input.filePath },
                };
            }
            const generation = await this.options.catalog.getGeneration(relativePath, resolution.generationId);
            if (generation === null) {
                if (attempt === 0) {
                    continue;
                }
                return {
                    status: 'index_incomplete',
                    freshness: 'unknown',
                    reindexRequired: true,
                    reasonCode: 'INDEX_GENERATION_MISSING',
                    request: { filePath: input.filePath },
                };
            }
            const fileHash = sha256Hex(readResult.bytes);
            if (fileHash !== generation.fileHash) {
                const currentResolution = await this.options.catalog.resolveFile(relativePath);
                if (attempt === 0 && currentResolution.kind === 'active' && currentResolution.generationId !== resolution.generationId) {
                    continue;
                }
                return {
                    status: 'stale',
                    freshness: 'stale',
                    reindexRequired: true,
                    reasonCode: 'INDEX_FILE_HASH_MISMATCH',
                    request: { filePath: input.filePath },
                };
            }
            if (this.options.isSupportedLanguage && !this.options.isSupportedLanguage(generation.parserId)) {
                const currentResolution = await this.options.catalog.resolveFile(relativePath);
                if (attempt === 0 && currentResolution.kind === 'active' && currentResolution.generationId !== resolution.generationId) {
                    continue;
                }
                return {
                    status: 'unsupported',
                    freshness: 'unknown',
                    reindexRequired: false,
                    reasonCode: 'unsupported_language',
                    request: { filePath: input.filePath },
                };
            }
            const declarations = await this.options.catalog.getFileDeclarations(relativePath);
            const currentResolution = await this.options.catalog.resolveFile(relativePath);
            if (currentResolution.kind !== 'active' || currentResolution.generationId !== resolution.generationId) {
                if (attempt === 0) {
                    continue;
                }
                return {
                    status: 'stale',
                    freshness: 'stale',
                    reindexRequired: true,
                    reasonCode: 'INDEX_FILE_HASH_MISMATCH',
                    request: { filePath: input.filePath },
                };
            }
            const symbols = declarations.map((declaration) => ({
                name: declaration.name,
                qualifiedName: declaration.qualifiedName,
                symbolId: declaration.symbolId,
                kind: declaration.kind,
                signatureDiscriminator: declaration.signatureDiscriminator,
                position: declaration.position,
                isExact: declaration.isExact,
                languageId: declaration.languageId,
                parentSymbolId: declaration.parentSymbolId ?? null,
            }));
            return {
                ...(generation.fileCompleteness === 'partial'
                    ? { status: 'degraded', retrievability: 'partial', reasonCode: 'PARSER_COVERAGE_PARTIAL' }
                    : { status: 'ok' }),
                freshness: 'fresh',
                reindexRequired: false,
                file: {
                    filePath: relativePath,
                    language: generation.parserId,
                    parserId: generation.parserId,
                    parserVersion: generation.parserVersion,
                },
                symbols,
                request: { filePath: input.filePath },
            };
        }
        return {
            status: 'index_incomplete',
            freshness: 'unknown',
            reindexRequired: true,
            reasonCode: 'INDEX_GENERATION_MISSING',
            request: { filePath: input.filePath },
        };
    }
    async getSymbolSource(input) {
        const verified = await this.verifySymbol(input);
        if (!verified.ok) {
            return verified.status;
        }
        const symbolSlice = verified.bytes.subarray(verified.declaration.startByte, verified.declaration.endByte);
        const source = decodeUtf8(symbolSlice);
        return { status: 'ok', freshness: 'fresh', reindexRequired: false, source, request: { symbolId: input.symbolId } };
    }
    async getSymbolContext(input) {
        const verified = await this.verifySymbol(input);
        if (!verified.ok) {
            return { ...verified.status, request: { symbolId: input.symbolId, tokenBudget: input.tokenBudget } };
        }
        const symbolSlice = verified.bytes.subarray(verified.declaration.startByte, verified.declaration.endByte);
        const symbolSource = decodeUtf8(symbolSlice);
        const importRecords = await this.options.catalog.getImportsForSymbol(input.symbolId);
        const candidates = this.verifyImports(verified.bytes, importRecords);
        if (!candidates.ok) {
            return { ...candidates.status, request: { symbolId: input.symbolId, tokenBudget: input.tokenBudget } };
        }
        const packed = packRelatedImports({
            symbolSource,
            imports: candidates.imports,
            tokenBudget: input.tokenBudget,
        });
        const importsById = new Map(importRecords.map((record) => [record.id, record]));
        const filePath = verified.filePath;
        const importsCompleteness = this.mergeCompleteness(importRecords);
        return {
            status: 'ok',
            freshness: 'fresh',
            reindexRequired: false,
            context: packed.context,
            filePath,
            imports: packed.imports.map((item) => ({
                id: item.id,
                moduleSpecifier: importsById.get(item.id)?.moduleSpecifier,
                startByte: item.startByte,
                endByte: importsById.get(item.id)?.endByte,
            })),
            importsCompleteness,
            tokenizer: packed.tokenizer,
            tokenizerVersion: packed.tokenizerVersion,
            budget: {
                requested: input.tokenBudget,
                actual: tokenCounter.count(packed.context),
                exceeded: packed.budget.exceeded,
                omittedForBudget: packed.budget.omittedForBudget,
            },
            request: { symbolId: input.symbolId, tokenBudget: input.tokenBudget },
        };
    }
    async resolveSymbol(symbolId) {
        const pending = await this.options.catalog.getPendingSymbol(symbolId);
        if (pending.kind === 'pending') {
            return pending;
        }
        const active = await this.options.catalog.resolveSymbol(symbolId);
        return active;
    }
    async verifySymbol(input) {
        const state = await this.options.catalog.getStructuredIndexState();
        const domain = this.checkGlobalState(state);
        if (domain !== undefined) {
            return { ok: false, status: { ...domain, request: { symbolId: input.symbolId } } };
        }
        const resolution = await this.resolveSymbol(input.symbolId);
        if (resolution.kind === 'tombstone') {
            return {
                ok: false,
                status: {
                    status: 'stale_identity',
                    freshness: 'unknown',
                    reindexRequired: false,
                    reasonCode: 'SYMBOL_RETIRED',
                    request: { symbolId: input.symbolId },
                },
            };
        }
        if (resolution.kind === 'missing') {
            return {
                ok: false,
                status: {
                    status: 'not_found',
                    freshness: 'unknown',
                    reindexRequired: false,
                    reasonCode: 'SYMBOL_NOT_FOUND',
                    request: { symbolId: input.symbolId },
                },
            };
        }
        if (resolution.kind === 'pending') {
            return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_PENDING_GENERATION', request: { symbolId: input.symbolId } } };
        }
        const filePath = resolution.filePath;
        if (this.options.isExcluded) {
            const excluded = await this.options.isExcluded(filePath);
            if (excluded) {
                return {
                    ok: false,
                    status: {
                        status: 'excluded',
                        freshness: 'unknown',
                        reindexRequired: false,
                        reasonCode: 'PATH_EXCLUDED',
                        request: { symbolId: input.symbolId },
                    },
                };
            }
        }
        const fileResolution = await this.options.catalog.resolveFile(filePath);
        if (fileResolution.kind === 'pending') {
            return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_PENDING_GENERATION', request: { symbolId: input.symbolId } } };
        }
        const activeGeneration = fileResolution.kind === 'active' ? fileResolution.generationId : undefined;
        if (activeGeneration === undefined) {
            return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_PENDING_GENERATION', request: { symbolId: input.symbolId } } };
        }
        if (this.options.isSupportedLanguage && !this.options.isSupportedLanguage(resolution.declaration.languageId)) {
            return { ok: false, status: { status: 'unsupported', reasonCode: 'unsupported_language', request: { symbolId: input.symbolId } } };
        }
        const generation = await this.options.catalog.getGeneration(filePath, activeGeneration);
        if (generation === null) {
            return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_GENERATION_MISSING', request: { symbolId: input.symbolId } } };
        }
        const projectRoot = this.options.sanitizer.getProjectRoot();
        const readResult = await this.readCurrentBytes(filePath, projectRoot, input.signal);
        if (readResult.status !== 'ok') {
            return { ok: false, status: { status: 'stale', reasonCode: readResult.reasonCode, request: { symbolId: input.symbolId } } };
        }
        const fileHash = sha256Hex(readResult.bytes);
        if (fileHash !== generation.fileHash) {
            return { ok: false, status: { status: 'stale', reasonCode: 'INDEX_FILE_HASH_MISMATCH', request: { symbolId: input.symbolId } } };
        }
        const symbolSlice = readResult.bytes.subarray(resolution.declaration.startByte, resolution.declaration.endByte);
        const sliceHash = sha256Hex(symbolSlice);
        if (sliceHash !== resolution.declaration.sourceHash) {
            return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_SYMBOL_HASH_MISMATCH', request: { symbolId: input.symbolId } } };
        }
        return { ok: true, bytes: readResult.bytes, declaration: resolution.declaration, filePath };
    }
    verifyImports(bytes, importRecords) {
        const imports = [];
        for (const imported of importRecords) {
            const { startByte, endByte, sourceHash, id } = imported;
            if (startByte < 0 || endByte > bytes.length || startByte >= endByte) {
                return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_IMPORT_HASH_MISMATCH' } };
            }
            const slice = bytes.subarray(startByte, endByte);
            if (sha256Hex(slice) !== sourceHash) {
                return { ok: false, status: { status: 'index_incomplete', reasonCode: 'INDEX_IMPORT_HASH_MISMATCH' } };
            }
            imports.push({ id, rawSource: decodeUtf8(slice), startByte });
        }
        return { ok: true, imports };
    }
    mergeCompleteness(importRecords) {
        return importRecords.every((item) => item.completeness === 'complete') ? 'complete' : 'partial';
    }
    async readCurrentBytes(filePath, projectRoot, signal) {
        try {
            const absolutePath = join(projectRoot, filePath);
            const buffer = await readFile(absolutePath, { signal });
            return { status: 'ok', bytes: new Uint8Array(buffer) };
        }
        catch (error) {
            const code = error.code;
            if (code === 'ENOENT') {
                return { status: 'stale', reasonCode: 'INDEX_FILE_MISSING' };
            }
            throw error;
        }
    }
    checkGlobalState(state) {
        if (state.schemaVersion !== null && state.schemaVersion !== 1) {
            return {
                status: 'unsupported',
                freshness: 'unknown',
                reindexRequired: false,
                reasonCode: 'STRUCTURED_SCHEMA_UNSUPPORTED',
            };
        }
        if (state.rebuildState === 'building') {
            return {
                status: 'index_incomplete',
                freshness: 'unknown',
                reindexRequired: true,
                reasonCode: 'INDEX_PENDING_GENERATION',
            };
        }
        if (state.schemaVersion === null || state.rebuildState === 'failed') {
            return {
                status: 'not_indexed',
                freshness: 'unknown',
                reindexRequired: true,
                reasonCode: 'STRUCTURED_INDEX_MISSING',
            };
        }
        return undefined;
    }
}
