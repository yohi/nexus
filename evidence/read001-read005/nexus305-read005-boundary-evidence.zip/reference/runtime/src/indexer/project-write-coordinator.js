import { Mutex, withTimeout } from 'async-mutex';
export class ProjectWriteCoordinator {
    mutex;
    constructor(options = {}) {
        const mutex = new Mutex();
        this.mutex = options.lockTimeoutMs === undefined
            ? mutex
            : withTimeout(mutex, options.lockTimeoutMs);
    }
    async run(operation) {
        const release = await this.mutex.acquire();
        try {
            return await operation();
        }
        finally {
            release();
        }
    }
    isLocked() {
        return Promise.resolve(this.mutex.isLocked());
    }
}
