import path from 'node:path';
import { computeStringHash } from './hash.js';
/**
 * Memory-efficient MerkleTree implementation.
 * Instead of loading all nodes into memory, it persists directory hashes
 * and updates them incrementally from leaf to root.
 */
export class MerkleTree {
    metadataStore;
    // Simple FIFO cache for nodes to reduce DB hits
    cache = new Map();
    maxCacheSize;
    rootHash = null;
    // Cache metrics
    cacheHits = 0;
    cacheMisses = 0;
    cacheEvictions = 0;
    constructor(metadataStore, options) {
        this.metadataStore = metadataStore;
        this.maxCacheSize = options?.maxCacheSize ?? 10000;
    }
    addToCache(path, node) {
        if (this.cache.size >= this.maxCacheSize && !this.cache.has(path)) {
            const firstKey = this.cache.keys().next().value;
            if (firstKey !== undefined) {
                this.cache.delete(firstKey);
                this.cacheEvictions += 1;
            }
        }
        this.cache.set(path, node);
    }
    /**
     * Initializes the tree by loading the root hash if it exists.
     */
    async load() {
        this.cache.clear();
        // We don't have a single "root" entry, but we can compute the root hash
        // by looking at top-level nodes (parentPath is null).
        this.rootHash = await this.computeRootHashFromStore();
    }
    async restore(nodes) {
        await this.metadataStore.replaceAllMerkleNodes([...nodes]);
        await this.load();
    }
    async update(filePath, contentHash) {
        const parentPath = path.dirname(filePath) === '.' ? null : path.dirname(filePath);
        const fileNode = {
            path: filePath,
            hash: contentHash,
            parentPath,
            isDirectory: false,
        };
        // 1. Update the file node itself
        await this.metadataStore.bulkUpsertMerkleNodes([fileNode]);
        this.addToCache(filePath, fileNode);
        // 2. Recalculate hashes up to the root
        if (parentPath) {
            await this.bubbleUpHash(parentPath);
        }
        else {
            this.rootHash = await this.computeRootHashFromStore();
        }
    }
    async remove(filePath) {
        const node = await this.getNode(filePath);
        // 1. Remove the node or subtree
        if (node?.isDirectory) {
            const subtreePaths = await this.metadataStore.getSubtreePaths(filePath);
            await this.metadataStore.deleteSubtree(filePath);
            for (const p of subtreePaths) {
                this.cache.delete(p);
            }
        }
        else {
            await this.metadataStore.bulkDeleteMerkleNodes([filePath]);
            this.cache.delete(filePath);
        }
        // 2. Prune empty directories and update hashes
        const parentPath = path.dirname(filePath) === '.' ? null : path.dirname(filePath);
        if (parentPath) {
            await this.pruneAndBubble(parentPath);
        }
        else {
            this.rootHash = await this.computeRootHashFromStore();
        }
    }
    async move(oldPath, newPath, contentHash) {
        // Atomic rename in metadata store
        await this.metadataStore.renamePath(oldPath, newPath, contentHash);
        // Update local cache
        this.cache.delete(oldPath);
        const parentPath = path.dirname(newPath) === '.' ? null : path.dirname(newPath);
        this.addToCache(newPath, {
            path: newPath,
            hash: contentHash,
            parentPath,
            isDirectory: false,
        });
        // Bubble up hashes for both old and new paths
        const oldParentPath = path.dirname(oldPath) === '.' ? null : path.dirname(oldPath);
        if (oldParentPath) {
            await this.pruneAndBubble(oldParentPath);
        }
        if (parentPath) {
            await this.bubbleUpHash(parentPath);
        }
        else {
            this.rootHash = await this.computeRootHashFromStore();
        }
    }
    async pruneAndBubble(dirPath) {
        let current = dirPath;
        while (current !== null && current !== '.' && current !== path.sep) {
            const hasChildren = await this.metadataStore.hasChildren(current);
            if (!hasChildren) {
                const parentOfCurrent = path.dirname(current) === '.' ? null : path.dirname(current);
                await this.metadataStore.bulkDeleteMerkleNodes([current]);
                this.cache.delete(current);
                current = parentOfCurrent;
            }
            else {
                await this.bubbleUpHash(current);
                return;
            }
        }
        // Always refresh root hash if we pruned up to the top
        this.rootHash = await this.computeRootHashFromStore();
    }
    /**
     * Updates directory hashes from the given path up to the root.
     */
    async bubbleUpHash(startDirPath) {
        let current = startDirPath;
        const visited = new Set();
        const nodesToUpsert = [];
        while (current !== null && current !== '.' && current !== path.sep) {
            if (visited.has(current)) {
                break; // Prevent infinite loops
            }
            visited.add(current);
            const children = await this.metadataStore.getChildren(current);
            const hash = await this.calculateDirectoryHash(children);
            const parentPath = path.dirname(current) === '.' ? null : path.dirname(current);
            const dirNode = {
                path: current,
                hash,
                parentPath,
                isDirectory: true,
            };
            nodesToUpsert.push(dirNode);
            this.addToCache(current, dirNode);
            // Important: prevent getting stuck if dirname doesn't change anything
            if (parentPath === current)
                break;
            current = parentPath;
        }
        if (nodesToUpsert.length > 0) {
            await this.metadataStore.bulkUpsertMerkleNodes(nodesToUpsert);
        }
        this.rootHash = await this.computeRootHashFromStore();
    }
    async calculateDirectoryHash(children) {
        const childHashes = children.map((child) => {
            return `${child.path.length}:${child.path}:${child.hash}`;
        });
        return computeStringHash(childHashes.join(''));
    }
    async computeRootHashFromStore() {
        // Top-level nodes are those where parentPath is null
        const roots = await this.metadataStore.getChildren(null);
        if (roots.length === 0) {
            return null;
        }
        const rootHashes = roots.map((node) => {
            return `${node.path.length}:${node.path}:${node.hash}`;
        });
        return computeStringHash(rootHashes.join(''));
    }
    getRootHash() {
        return this.rootHash;
    }
    async getNode(nodePath) {
        if (this.cache.has(nodePath)) {
            this.cacheHits += 1;
            return this.cache.get(nodePath);
        }
        this.cacheMisses += 1;
        const node = await this.metadataStore.getMerkleNode(nodePath);
        if (node) {
            this.addToCache(nodePath, node);
        }
        return node ?? undefined;
    }
    /**
     * Detects rename candidates through matching deleted and added hashes.
     */
    static detectRenameCandidates(events) {
        const added = events.filter((event) => event.type === 'added' && event.contentHash !== undefined);
        const deleted = events.filter((event) => event.type === 'deleted' && event.contentHash !== undefined);
        const matches = [];
        const addedMap = new Map();
        for (const event of added) {
            if (event.contentHash !== undefined) {
                const list = addedMap.get(event.contentHash) ?? [];
                list.push(event);
                addedMap.set(event.contentHash, list);
            }
        }
        for (const removed of deleted) {
            if (removed.contentHash !== undefined) {
                const list = addedMap.get(removed.contentHash);
                if (list !== undefined && list.length > 0) {
                    const addedMatch = list.shift();
                    matches.push({
                        oldPath: removed.filePath,
                        newPath: addedMatch.filePath,
                        hash: addedMatch.contentHash,
                        oldEvent: removed,
                        newEvent: addedMatch,
                    });
                }
            }
        }
        return matches;
    }
    /**
     * Note: The static diff method is now deprecated for large trees.
     * Real diffing should be done using database-backed comparison.
     */
    static diff() {
        return Promise.reject(new Error('MerkleTree.diff() is deprecated. Use direct DB comparison.'));
    }
}
