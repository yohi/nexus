import * as path from 'node:path';
import { fuseResults } from './rrf.js';
export class SearchOrchestrator {
    options;
    rrfK;
    logger;
    constructor(options) {
        this.options = options;
        this.rrfK = options.rrfK ?? 60;
        this.logger = options.logger ?? console;
    }
    async search(params) {
        const startedAt = Date.now();
        const topK = params.topK ?? 20;
        const grepQuery = params.grepPattern ?? params.query;
        const [semanticResult, grepResult] = await Promise.allSettled([
            this.options.semanticSearch.search(params),
            this.options.grepEngine.search({
                query: grepQuery,
                cwd: this.options.projectRoot,
                glob: params.filePatterns,
                maxResults: topK,
                abortSignal: params.abortSignal,
            }),
        ]);
        const semanticResults = semanticResult.status === 'fulfilled' ? semanticResult.value : [];
        if (semanticResult.status === 'rejected') {
            this.logger.error('Semantic search failed:', semanticResult.reason);
        }
        const grepMatches = grepResult.status === 'fulfilled' ? grepResult.value : [];
        if (grepResult.status === 'rejected') {
            this.logger.error('Grep search failed:', grepResult.reason);
        }
        if (semanticResult.status === 'rejected' && grepResult.status === 'rejected') {
            throw new Error('Both semantic and grep searches failed');
        }
        const grepResults = grepMatches.map((match) => {
            const matchingSemantic = semanticResults.find((s) => s.chunk.filePath === match.filePath &&
                match.lineNumber >= s.chunk.startLine &&
                match.lineNumber <= s.chunk.endLine);
            return {
                chunk: matchingSemantic
                    ? matchingSemantic.chunk
                    : {
                        id: `${match.filePath}:${match.lineNumber}`,
                        filePath: match.filePath,
                        content: match.lineText,
                        language: inferLanguage(match.filePath),
                        symbolName: `line_${match.lineNumber}`,
                        symbolKind: 'unknown',
                        startLine: match.lineNumber,
                        endLine: match.lineNumber,
                        hash: `${match.filePath}:${match.lineNumber}:${match.lineText}`,
                    },
                score: 1,
                source: 'grep',
            };
        });
        return {
            query: params.query,
            results: fuseResults(semanticResults, grepResults, { k: this.rrfK, topK }),
            tookMs: Date.now() - startedAt,
        };
    }
}
const extensionToLang = {
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.py': 'python',
    '.go': 'go',
    '.rs': 'rust',
    '.rb': 'ruby',
    '.php': 'php',
    '.java': 'java',
    '.c': 'c',
    '.cpp': 'cpp',
    '.h': 'c',
    '.hpp': 'cpp',
    '.cs': 'csharp',
    '.sh': 'shell',
    '.md': 'markdown',
};
const inferLanguage = (filePath) => {
    const ext = path.extname(filePath).toLowerCase();
    return extensionToLang[ext] || 'unknown';
};
