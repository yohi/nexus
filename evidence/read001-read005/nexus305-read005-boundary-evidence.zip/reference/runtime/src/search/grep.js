import pLimit from 'p-limit';
const DEFAULT_MAX_CONCURRENCY = 4;
const DEFAULT_TIMEOUT_MS = 10_000;
const DEFAULT_MAX_RESULTS = 100;
const DEFAULT_KILL_GRACE_MS = 1000;
export class RipgrepEngine {
    options;
    limit;
    timeoutMs;
    killGraceMs;
    spawnImpl;
    /**
     * Factory function to create a new process controller for each search.
     */
    createProcessController;
    /**
     * Shared process controller instance.
     * @deprecated Use createProcessController for concurrent-safe execution.
     */
    processController;
    constructor(options) {
        this.options = options;
        const concurrency = options.grepMaxConcurrency ?? DEFAULT_MAX_CONCURRENCY;
        this.limit = pLimit(concurrency);
        this.timeoutMs = options.grepTimeoutMs ?? DEFAULT_TIMEOUT_MS;
        this.killGraceMs = options.killGraceMs ?? DEFAULT_KILL_GRACE_MS;
        this.createProcessController = options.createProcessController;
        this.processController = options.processController;
        if (options.processController && concurrency > 1) {
            throw new Error('Concurrent searches (grepMaxConcurrency > 1) cannot share a single processController. Provide createProcessController instead.');
        }
        if (!options.spawn) {
            throw new Error('RipgrepEngine requires a spawn function to be provided in options.');
        }
        this.spawnImpl = options.spawn;
    }
    async search(params) {
        return this.limit(async () => this.execute(params));
    }
    async execute(params) {
        const processController = this.createProcessController?.() ?? this.processController;
        const timeoutController = new AbortController();
        let timedOut = false;
        let settledViaAbort = false;
        let escalationId;
        const timeoutId = setTimeout(() => {
            timedOut = true;
            processController?.kill('SIGTERM');
            timeoutController.abort();
            if (processController) {
                escalationId = setTimeout(() => {
                    processController.kill('SIGKILL');
                }, this.killGraceMs);
            }
        }, this.timeoutMs);
        const combinedSignal = params.abortSignal
            ? AbortSignal.any([timeoutController.signal, params.abortSignal])
            : timeoutController.signal;
        if (combinedSignal.aborted) {
            clearTimeout(timeoutId);
            return [];
        }
        try {
            return await this.spawnImpl(this.normalizeParams(params), combinedSignal);
        }
        catch (error) {
            if (combinedSignal.aborted) {
                settledViaAbort = true;
                return [];
            }
            throw error;
        }
        finally {
            clearTimeout(timeoutId);
            if (escalationId && !(timedOut && !settledViaAbort)) {
                clearTimeout(escalationId);
            }
        }
    }
    normalizeParams(params) {
        return {
            ...params,
            cwd: this.options.projectRoot,
            query: params.query,
            maxResults: params.maxResults ?? DEFAULT_MAX_RESULTS,
        };
    }
}
