export { supportsStructuredCatalog } from '../storage/interfaces/metadata-store.js';
export class DimensionMismatchError extends Error {
    constructor(message, options) {
        super(message, options);
        this.name = 'DimensionMismatchError';
    }
}
export class RetryExhaustedError extends Error {
    attempts;
    constructor(message, attempts, options) {
        super(message, options);
        this.name = 'RetryExhaustedError';
        this.attempts = attempts;
    }
}
/** Thrown for embedding errors that must not be retried (e.g. HTTP 400 context-length exceeded). */
export class NonRetryableEmbeddingError extends Error {
    constructor(message, options) {
        super(message, options);
        this.name = 'NonRetryableEmbeddingError';
    }
}
export class PathTraversalError extends Error {
    attemptedPath;
    constructor(attemptedPath, options) {
        super(`Path traversal detected: ${attemptedPath}`, options);
        this.name = 'PathTraversalError';
        this.attemptedPath = attemptedPath;
    }
}
