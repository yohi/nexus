export const executeBatchedWithYield = async ({ items, batchSize, yieldAfterBatch, executeBatch, }) => {
    if (typeof batchSize !== 'number' || !Number.isInteger(batchSize) || !Number.isFinite(batchSize) || batchSize <= 0) {
        throw new RangeError('batchSize must be a positive integer');
    }
    for (let start = 0; start < items.length; start += batchSize) {
        const batch = items.slice(start, start + batchSize);
        await executeBatch(batch, start / batchSize);
        if (yieldAfterBatch !== undefined && start + batchSize < items.length) {
            await yieldAfterBatch();
        }
    }
};
