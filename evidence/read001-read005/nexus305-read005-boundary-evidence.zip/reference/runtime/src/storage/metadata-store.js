import { dirname } from 'node:path';
import Database from 'better-sqlite3';
import { DEFAULT_BATCH_SIZE } from '../config/index.js';
import { executeBatchedWithYield } from './batched-transaction.js';
import { sha256Hex } from '../structured/hash.js';
const PRIMARY_STATS_ID = 'primary';
const UPSERT_INDEX_STATS_SQL = `
  INSERT INTO index_stats (
    id, total_files, total_chunks, last_indexed_at, last_full_scan_at, overflow_count, last_error
  ) VALUES (
    @id, @totalFiles, @totalChunks, @lastIndexedAt, @lastFullScanAt, @overflowCount, @lastError
  )
  ON CONFLICT(id) DO UPDATE SET
    total_files = excluded.total_files,
    total_chunks = excluded.total_chunks,
    last_indexed_at = excluded.last_indexed_at,
    last_full_scan_at = excluded.last_full_scan_at,
    overflow_count = excluded.overflow_count,
    last_error = excluded.last_error`;
export class SqliteMetadataStore {
    db;
    batchSize;
    deferFullRebuildRecovery;
    asyncBoundary = async () => new Promise((resolve) => {
        setImmediate(resolve);
    });
    immediateTransaction(operation) {
        this.db.exec('BEGIN IMMEDIATE');
        try {
            const result = operation();
            this.db.exec('COMMIT');
            return result;
        }
        catch (error) {
            this.db.exec('ROLLBACK');
            throw error;
        }
    }
    pruneUnreferencedStructuredData(filePath) {
        const referencedGenerations = `
      SELECT active_generation AS generation
      FROM structured_files
      WHERE file_path = ? AND active_generation IS NOT NULL
      UNION
      SELECT pending_generation AS generation
      FROM structured_files
      WHERE file_path = ? AND pending_generation IS NOT NULL`;
        let deleted = 0;
        deleted += this.db.prepare(`DELETE FROM symbol_imports WHERE file_path = ? AND generation NOT IN (${referencedGenerations})`).run(filePath, filePath, filePath).changes;
        deleted += this.db.prepare(`DELETE FROM imports WHERE file_path = ? AND generation NOT IN (${referencedGenerations})`).run(filePath, filePath, filePath).changes;
        deleted += this.db.prepare(`DELETE FROM symbols WHERE file_path = ? AND generation NOT IN (${referencedGenerations})`).run(filePath, filePath, filePath).changes;
        deleted += this.db.prepare(`DELETE FROM symbol_generations WHERE file_path = ? AND generation NOT IN (${referencedGenerations})`).run(filePath, filePath, filePath).changes;
        return deleted;
    }
    pruneOrphanedStructuredData() {
        let deleted = 0;
        deleted += this.db.prepare('DELETE FROM symbol_imports WHERE NOT EXISTS (SELECT 1 FROM structured_files AS f WHERE f.file_path = symbol_imports.file_path AND (f.active_generation = symbol_imports.generation OR f.pending_generation = symbol_imports.generation))').run().changes;
        deleted += this.db.prepare('DELETE FROM imports WHERE NOT EXISTS (SELECT 1 FROM structured_files AS f WHERE f.file_path = imports.file_path AND (f.active_generation = imports.generation OR f.pending_generation = imports.generation))').run().changes;
        deleted += this.db.prepare('DELETE FROM symbols WHERE NOT EXISTS (SELECT 1 FROM structured_files AS f WHERE f.file_path = symbols.file_path AND (f.active_generation = symbols.generation OR f.pending_generation = symbols.generation))').run().changes;
        deleted += this.db.prepare('DELETE FROM symbol_generations WHERE NOT EXISTS (SELECT 1 FROM structured_files AS f WHERE f.file_path = symbol_generations.file_path AND (f.active_generation = symbol_generations.generation OR f.pending_generation = symbol_generations.generation))').run().changes;
        return deleted;
    }
    constructor(options) {
        this.db = new Database(options.databasePath);
        if (options.batchSize !== undefined) {
            if (!Number.isInteger(options.batchSize) || options.batchSize <= 0) {
                throw new TypeError('SqliteMetadataStore batchSize must be a positive integer');
            }
            this.batchSize = options.batchSize;
        }
        else {
            this.batchSize = DEFAULT_BATCH_SIZE;
        }
        this.deferFullRebuildRecovery = options.deferFullRebuildRecovery ?? false;
    }
    addMissingColumns(tableName, columns) {
        const existingColumns = new Set(this.db.pragma(`table_info(${tableName})`).map((column) => column.name));
        for (const [name, definition] of columns) {
            if (!existingColumns.has(name)) {
                this.db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${name} ${definition}`);
            }
        }
    }
    migrateSchema() {
        this.addMissingColumns('dead_letter_queue', [['recovery_attempts', 'INTEGER NOT NULL DEFAULT 0']]);
        this.addMissingColumns('index_stats', [
            ['last_error', 'TEXT'],
            ['structured_schema_version', 'INTEGER'],
            ['structured_rebuild_state', 'TEXT'],
            ['structured_rebuild_epoch', 'INTEGER NOT NULL DEFAULT 0'],
            ['structured_last_error_code', 'TEXT'],
        ]);
        this.addMissingColumns('structured_rebuild_backup_runs', [
            ['phase', "TEXT NOT NULL DEFAULT 'building'"],
            ['merkle_snapshot', 'TEXT'],
        ]);
        this.db.prepare('INSERT OR IGNORE INTO index_stats (id,total_files,total_chunks,last_indexed_at,last_full_scan_at,overflow_count,last_error,structured_rebuild_epoch) VALUES (?,?,?,?,?,?,?,?)').run(PRIMARY_STATS_ID, 0, 0, null, null, 0, null, 0);
        this.db.prepare('UPDATE index_stats SET structured_rebuild_epoch = COALESCE(structured_rebuild_epoch, 0) WHERE structured_rebuild_epoch IS NULL').run();
        this.addMissingColumns('imports', [
            ['id', "TEXT NOT NULL DEFAULT ''"],
            ['start_byte', 'INTEGER NOT NULL DEFAULT 0'],
            ['end_byte', 'INTEGER NOT NULL DEFAULT 0'],
            ['source_hash', "TEXT NOT NULL DEFAULT ''"],
            ['is_complete', 'INTEGER NOT NULL DEFAULT 1'],
            ['diagnostics_json', 'TEXT'],
        ]);
        this.migrateImportsPrimaryKey();
        this.addMissingColumns('symbol_imports', [
            ['import_binding_id', "TEXT NOT NULL DEFAULT ''"],
        ]);
        this.migrateSymbolImportsPrimaryKey();
        this.addMissingColumns('symbols', [
            ['start_byte', 'INTEGER NOT NULL DEFAULT 0'],
            ['end_byte', 'INTEGER NOT NULL DEFAULT 0'],
            ['parent_symbol_id', 'TEXT'],
            ['language_id', "TEXT NOT NULL DEFAULT ''"],
            ['is_exact', 'INTEGER NOT NULL DEFAULT 1'],
        ]);
        this.addMissingColumns('symbol_generations', [[
                'file_completeness', "TEXT NOT NULL DEFAULT 'complete' CHECK (file_completeness IN ('complete', 'partial'))",
            ]]);
        this.addMissingColumns('symbol_tombstones', [['retired_at', 'INTEGER NOT NULL DEFAULT 0']]);
        if (this.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='structured_generations'").get()) {
            this.db.exec('INSERT OR IGNORE INTO symbol_generations (file_path,generation,schema_version,parser_id,parser_version,content_hash,rebuild_epoch) SELECT file_path,generation,schema_version,parser_id,parser_version,content_hash,rebuild_epoch FROM structured_generations');
        }
    }
    migrateImportsPrimaryKey() {
        const info = this.db.pragma('table_info(imports)');
        const pkColumns = info.filter((column) => column.pk > 0).map((column) => column.name);
        if (pkColumns.includes('id'))
            return;
        this.db.exec(`
      CREATE TABLE imports_new (
        file_path TEXT NOT NULL, generation TEXT NOT NULL, id TEXT NOT NULL,
        source TEXT NOT NULL, imported_names TEXT NOT NULL, start_line INTEGER NOT NULL, start_column INTEGER NOT NULL,
        end_line INTEGER NOT NULL, end_column INTEGER NOT NULL,
        start_byte INTEGER NOT NULL DEFAULT 0, end_byte INTEGER NOT NULL DEFAULT 0,
        source_hash TEXT NOT NULL,
        is_complete INTEGER NOT NULL DEFAULT 1, diagnostics_json TEXT,
        PRIMARY KEY (file_path, generation, id)
      );
      INSERT OR IGNORE INTO imports_new
        SELECT file_path, generation, source || char(0) || imported_names, source, imported_names,
               start_line, start_column, end_line, end_column, start_byte, end_byte, source_hash, is_complete, diagnostics_json
        FROM imports;
      DROP TABLE imports;
      ALTER TABLE imports_new RENAME TO imports;
      CREATE INDEX imports_file_generation_idx ON imports (file_path, generation);
    `);
    }
    migrateSymbolImportsPrimaryKey() {
        const info = this.db.pragma('table_info(symbol_imports)');
        const pkColumns = info.filter((column) => column.pk > 0).map((column) => column.name);
        if (pkColumns.includes('import_binding_id'))
            return;
        this.db.exec(`
      CREATE TABLE symbol_imports_new (
        file_path TEXT NOT NULL, generation TEXT NOT NULL, symbol_id TEXT NOT NULL,
        import_binding_id TEXT NOT NULL, source TEXT NOT NULL, source_hash TEXT NOT NULL,
        PRIMARY KEY (file_path, generation, symbol_id, import_binding_id)
      );
      INSERT OR IGNORE INTO symbol_imports_new
        SELECT si.file_path, si.generation, si.symbol_id, i.id, si.source, si.source_hash
        FROM symbol_imports AS si
        JOIN imports AS i
          ON i.file_path = si.file_path
         AND i.generation = si.generation
         AND i.source = si.source;
      DROP TABLE symbol_imports;
      ALTER TABLE symbol_imports_new RENAME TO symbol_imports;
    `);
    }
    async initialize() {
        await this.asyncBoundary();
        this.db.pragma('journal_mode = WAL');
        this.db.pragma('wal_autocheckpoint = 1000');
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS merkle_nodes (
        path TEXT PRIMARY KEY,
        hash TEXT NOT NULL,
        parent_path TEXT,
        is_directory INTEGER NOT NULL CHECK (is_directory IN (0, 1))
      );

      CREATE INDEX IF NOT EXISTS merkle_nodes_parent_path_idx ON merkle_nodes (parent_path);

      CREATE TABLE IF NOT EXISTS index_stats (
        id TEXT PRIMARY KEY,
        total_files INTEGER NOT NULL,
        total_chunks INTEGER NOT NULL,
        last_indexed_at TEXT,
        last_full_scan_at TEXT,
        overflow_count INTEGER NOT NULL,
        last_error TEXT
      );

      CREATE TABLE IF NOT EXISTS dead_letter_queue (
        id TEXT PRIMARY KEY,
        file_path TEXT NOT NULL,
        content_hash TEXT NOT NULL,
        error_message TEXT NOT NULL,
        attempts INTEGER NOT NULL,
        recovery_attempts INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_retry_at TEXT
      );

      CREATE INDEX IF NOT EXISTS idx_dlq_created ON dead_letter_queue (created_at);

      CREATE TABLE IF NOT EXISTS embedding_cache (
        hash TEXT PRIMARY KEY,
        vector TEXT NOT NULL,
        dimensions INTEGER NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS structured_files (
        file_path TEXT PRIMARY KEY,
        active_generation TEXT,
        pending_generation TEXT
      );
      CREATE TABLE IF NOT EXISTS symbol_generations (
        file_path TEXT NOT NULL,
        generation TEXT NOT NULL,
        schema_version INTEGER NOT NULL,
        parser_id TEXT NOT NULL,
        parser_version TEXT NOT NULL,
        content_hash TEXT NOT NULL,
        rebuild_epoch INTEGER NOT NULL,
        file_completeness TEXT NOT NULL DEFAULT 'complete' CHECK (file_completeness IN ('complete', 'partial')),
        PRIMARY KEY (file_path, generation)
      );
      CREATE TABLE IF NOT EXISTS symbols (
        file_path TEXT NOT NULL, generation TEXT NOT NULL, symbol_id TEXT NOT NULL,
        name TEXT NOT NULL, qualified_name TEXT NOT NULL, kind TEXT NOT NULL,
        signature_discriminator TEXT NOT NULL, start_line INTEGER NOT NULL,
        start_column INTEGER NOT NULL, end_line INTEGER NOT NULL, end_column INTEGER NOT NULL,
        start_byte INTEGER NOT NULL DEFAULT 0, end_byte INTEGER NOT NULL DEFAULT 0,
        parent_symbol_id TEXT, language_id TEXT NOT NULL DEFAULT '', is_exact INTEGER NOT NULL DEFAULT 1, source_hash TEXT NOT NULL,
        PRIMARY KEY (file_path, generation, symbol_id)
      );
      CREATE INDEX IF NOT EXISTS symbols_symbol_id_idx ON symbols (symbol_id);
      CREATE TABLE IF NOT EXISTS imports (
        file_path TEXT NOT NULL, generation TEXT NOT NULL, id TEXT NOT NULL,
        source TEXT NOT NULL, imported_names TEXT NOT NULL, start_line INTEGER NOT NULL, start_column INTEGER NOT NULL,
        end_line INTEGER NOT NULL, end_column INTEGER NOT NULL,
        start_byte INTEGER NOT NULL DEFAULT 0, end_byte INTEGER NOT NULL DEFAULT 0,
        source_hash TEXT NOT NULL,
        is_complete INTEGER NOT NULL DEFAULT 1, diagnostics_json TEXT,
        PRIMARY KEY (file_path, generation, id)
      );
      CREATE INDEX IF NOT EXISTS imports_file_generation_idx ON imports (file_path, generation);
      CREATE TABLE IF NOT EXISTS symbol_imports (
        file_path TEXT NOT NULL, generation TEXT NOT NULL, symbol_id TEXT NOT NULL,
        import_binding_id TEXT NOT NULL, source TEXT NOT NULL, source_hash TEXT NOT NULL,
        PRIMARY KEY (file_path, generation, symbol_id, import_binding_id)
      );
      CREATE TABLE IF NOT EXISTS symbol_tombstones (
        symbol_id TEXT PRIMARY KEY, file_path TEXT NOT NULL, generation TEXT NOT NULL,
        retired_at_rebuild_epoch INTEGER NOT NULL, retired_at INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS structured_rebuild_backup_files (
        rebuild_epoch INTEGER NOT NULL,
        file_path TEXT NOT NULL,
        active_generation TEXT,
        pending_generation TEXT,
        PRIMARY KEY (rebuild_epoch, file_path)
      );

      CREATE TABLE IF NOT EXISTS structured_rebuild_backup_tombstones (
        rebuild_epoch INTEGER NOT NULL,
        symbol_id TEXT NOT NULL,
        file_path TEXT NOT NULL,
        generation TEXT NOT NULL,
        retired_at_rebuild_epoch INTEGER NOT NULL,
        retired_at INTEGER NOT NULL,
        PRIMARY KEY (rebuild_epoch, symbol_id)
      );

      CREATE TABLE IF NOT EXISTS structured_rebuild_backup_runs (
        rebuild_epoch INTEGER PRIMARY KEY,
        phase TEXT NOT NULL DEFAULT 'building',
        merkle_snapshot TEXT
      );

      CREATE TABLE IF NOT EXISTS structured_rebuild_backup_vectors (
        rebuild_epoch INTEGER NOT NULL,
        table_kind TEXT NOT NULL CHECK (table_kind IN ('legacy', 'structured')),
        shadow_name TEXT NOT NULL,
        replacement_name TEXT NOT NULL,
        backup_name TEXT,
        had_live_table INTEGER NOT NULL CHECK (had_live_table IN (0, 1)),
        backup_complete INTEGER NOT NULL DEFAULT 0 CHECK (backup_complete IN (0, 1)),
        PRIMARY KEY (rebuild_epoch, table_kind)
      );
    `);
        this.migrateSchema();
        if (!this.deferFullRebuildRecovery) {
            this.recoverInterruptedFullRebuildOnInitialize();
        }
    }
    async bootstrapStructuredSchema() {
        await this.initialize();
    }
    async getStructuredIndexState() {
        await this.asyncBoundary();
        const rows = this.db.prepare('SELECT file_path, active_generation FROM structured_files WHERE active_generation IS NOT NULL').all();
        const state = this.db.prepare('SELECT structured_schema_version AS schemaVersion, structured_rebuild_state AS rebuildState, structured_rebuild_epoch AS rebuildEpoch, structured_last_error_code AS lastErrorCode FROM index_stats WHERE id = ?').get(PRIMARY_STATS_ID);
        return { schemaVersion: state?.schemaVersion ?? null, rebuildState: state?.rebuildState ?? null, rebuildEpoch: state?.rebuildEpoch ?? 0, lastErrorCode: state?.lastErrorCode ?? null, counts: await this.getStructuredCounts(), activeGenerations: new Map(rows.map((row) => [row.file_path, row.active_generation])), reindexRequired: state?.schemaVersion === null || state?.schemaVersion === undefined };
    }
    async stageGeneration(input) {
        await this.asyncBoundary();
        const transaction = () => {
            this.db.prepare('INSERT INTO symbol_generations (file_path,generation,schema_version,parser_id,parser_version,content_hash,rebuild_epoch,file_completeness) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(file_path,generation) DO UPDATE SET schema_version=excluded.schema_version, parser_id=excluded.parser_id, parser_version=excluded.parser_version, content_hash=excluded.content_hash, rebuild_epoch=excluded.rebuild_epoch, file_completeness=excluded.file_completeness').run(input.filePath, input.generation.generationId, input.generation.schemaVersion, input.generation.parserId, input.generation.parserVersion, input.generation.fileHash, input.rebuildEpoch, input.fileCompleteness);
            this.db.prepare('DELETE FROM symbols WHERE file_path = ? AND generation = ?').run(input.filePath, input.generation.generationId);
            this.db.prepare('DELETE FROM symbol_imports WHERE file_path = ? AND generation = ?').run(input.filePath, input.generation.generationId);
            this.db.prepare('DELETE FROM imports WHERE file_path = ? AND generation = ?').run(input.filePath, input.generation.generationId);
            const symbol = this.db.prepare('INSERT INTO symbols (file_path,generation,symbol_id,name,qualified_name,kind,signature_discriminator,start_line,start_column,end_line,end_column,start_byte,end_byte,parent_symbol_id,language_id,is_exact,source_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            for (const declaration of input.declarations)
                symbol.run(input.filePath, input.generation.generationId, declaration.symbolId, declaration.name, declaration.qualifiedName, declaration.kind, declaration.signatureDiscriminator, declaration.position.startLine, declaration.position.startColumn, declaration.position.endLine, declaration.position.endColumn, declaration.startByte, declaration.endByte, declaration.parentSymbolId ?? null, declaration.languageId, declaration.isExact ? 1 : 0, sha256Hex(input.bytes.subarray(declaration.startByte, declaration.endByte)));
            const importRow = this.db.prepare('INSERT INTO imports (file_path,generation,id,source,imported_names,start_line,start_column,end_line,end_column,start_byte,end_byte,source_hash,is_complete,diagnostics_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            const bindingRow = this.db.prepare('INSERT INTO symbol_imports (file_path,generation,symbol_id,import_binding_id,source,source_hash) VALUES (?,?,?,?,?,?)');
            const importsById = new Map(input.imports.map((imported) => [imported.id, imported]));
            for (const imported of input.imports)
                importRow.run(input.filePath, input.generation.generationId, imported.id, imported.moduleSpecifier ?? '', imported.bindingName ?? '', imported.position.startLine, imported.position.startColumn, imported.position.endLine, imported.position.endColumn, imported.startByte, imported.endByte, sha256Hex(input.bytes.subarray(imported.startByte, imported.endByte)), imported.completeness === 'complete' ? 1 : 0, JSON.stringify(imported.diagnostics ?? []));
            for (const declaration of input.declarations) {
                const linkedBindingIds = new Set();
                for (const bindingId of declaration.importBindingIds ?? []) {
                    const imported = importsById.get(bindingId);
                    if (imported === undefined)
                        continue;
                    if (linkedBindingIds.has(imported.id))
                        continue;
                    linkedBindingIds.add(imported.id);
                    bindingRow.run(input.filePath, input.generation.generationId, declaration.symbolId, imported.id, imported.moduleSpecifier ?? '', sha256Hex(input.bytes.subarray(imported.startByte, imported.endByte)));
                }
            }
            this.db.prepare('INSERT INTO structured_files (file_path,pending_generation) VALUES (?,?) ON CONFLICT(file_path) DO UPDATE SET pending_generation=excluded.pending_generation').run(input.filePath, input.generation.generationId);
            this.db.prepare('UPDATE index_stats SET structured_rebuild_epoch=? WHERE id=?').run(input.rebuildEpoch, PRIMARY_STATS_ID);
            this.pruneUnreferencedStructuredData(input.filePath);
        };
        this.immediateTransaction(transaction);
    }
    async activateGeneration(input) {
        await this.asyncBoundary();
        const transaction = () => {
            const epoch = this.db.prepare('SELECT structured_rebuild_epoch AS value FROM index_stats WHERE id = ?').get(PRIMARY_STATS_ID);
            if ((epoch?.value ?? 0) !== input.expectedRebuildEpoch)
                return { activated: false, reason: 'stale_rebuild_epoch' };
            const file = this.db.prepare('SELECT active_generation,pending_generation FROM structured_files WHERE file_path = ?').get(input.filePath);
            if ((file?.active_generation ?? null) !== input.expectedActiveGeneration)
                return { activated: false, reason: 'stale_active_generation' };
            if (file?.pending_generation !== input.generationId)
                return { activated: false, reason: 'missing_generation' };
            if (file.active_generation)
                this.db.prepare('INSERT OR REPLACE INTO symbol_tombstones SELECT symbol_id,file_path,generation,?,? FROM symbols WHERE file_path=? AND generation=? AND symbol_id NOT IN (SELECT symbol_id FROM symbols WHERE file_path=? AND generation=?)').run(input.expectedRebuildEpoch, Date.now(), input.filePath, file.active_generation, input.filePath, input.generationId);
            this.db.prepare('DELETE FROM symbol_tombstones WHERE symbol_id IN (SELECT symbol_id FROM symbols WHERE file_path=? AND generation=?)').run(input.filePath, input.generationId);
            this.db.prepare('UPDATE structured_files SET active_generation = ?, pending_generation = NULL WHERE file_path = ?').run(input.generationId, input.filePath);
            this.pruneUnreferencedStructuredData(input.filePath);
            return { activated: true };
        };
        return this.immediateTransaction(transaction);
    }
    async clearPendingGeneration(input) {
        await this.asyncBoundary();
        const transaction = () => {
            const row = this.db.prepare('SELECT active_generation,pending_generation FROM structured_files WHERE file_path=?').get(input.filePath);
            const epoch = this.db.prepare('SELECT structured_rebuild_epoch AS value FROM index_stats WHERE id=?').get(PRIMARY_STATS_ID);
            if (!row || row.active_generation !== input.expectedActiveGeneration || row.pending_generation !== input.expectedPendingGeneration || (epoch?.value ?? 0) !== input.expectedRebuildEpoch)
                return { cleared: false };
            this.db.prepare('UPDATE structured_files SET pending_generation=NULL WHERE file_path=?').run(input.filePath);
            this.pruneUnreferencedStructuredData(input.filePath);
            return { cleared: true };
        };
        return this.immediateTransaction(transaction);
    }
    async retireFile(input) {
        await this.asyncBoundary();
        const transaction = () => {
            const row = this.db.prepare('SELECT active_generation FROM structured_files WHERE file_path=?').get(input.filePath);
            if (!row || row.active_generation !== input.expectedActiveGeneration)
                return;
            const epoch = this.db.prepare('SELECT structured_rebuild_epoch AS value FROM index_stats WHERE id=?').get(PRIMARY_STATS_ID);
            if ((epoch?.value ?? 0) !== input.rebuildEpoch)
                return;
            this.db.prepare('INSERT OR REPLACE INTO symbol_tombstones SELECT symbol_id,file_path,generation,?,? FROM symbols WHERE file_path=? AND generation=?').run(input.rebuildEpoch, input.tombstoneTimestamp ?? Date.now(), input.filePath, row.active_generation);
            this.db.prepare('UPDATE structured_files SET active_generation=NULL,pending_generation=NULL WHERE file_path=?').run(input.filePath);
            this.pruneUnreferencedStructuredData(input.filePath);
        };
        this.immediateTransaction(transaction);
    }
    async resolveFile(filePath) {
        await this.asyncBoundary();
        const row = this.db.prepare('SELECT active_generation,pending_generation FROM structured_files WHERE file_path=?').get(filePath);
        if (row?.active_generation)
            return { kind: 'active', generationId: row.active_generation };
        if (row?.pending_generation)
            return { kind: 'pending', generationId: row.pending_generation };
        return { kind: 'missing' };
    }
    async getActiveGenerationMap(filePaths) {
        await this.asyncBoundary();
        const result = new Map();
        const statement = this.db.prepare('SELECT active_generation FROM structured_files WHERE file_path=?');
        for (const filePath of filePaths) {
            const row = statement.get(filePath);
            if (row?.active_generation)
                result.set(filePath, row.active_generation);
        }
        return result;
    }
    declaration(row) { return { name: String(row.name), symbolId: String(row.symbol_id), qualifiedName: String(row.qualified_name), kind: row.kind, signatureDiscriminator: String(row.signature_discriminator), position: { startLine: Number(row.start_line), startColumn: Number(row.start_column), endLine: Number(row.end_line), endColumn: Number(row.end_column) }, startByte: Number(row.start_byte ?? 0), endByte: Number(row.end_byte ?? 0), sourceHash: String(row.source_hash), languageId: typeof row.language_id === 'string' ? row.language_id : '', isExact: Boolean(row.is_exact ?? 1), parentSymbolId: typeof row.parent_symbol_id === 'string' ? row.parent_symbol_id : undefined }; }
    async resolveSymbol(symbolId) {
        await this.asyncBoundary();
        const row = this.db.prepare('SELECT s.*, f.file_path AS file_path FROM symbols s JOIN structured_files f ON f.file_path=s.file_path AND f.active_generation=s.generation WHERE s.symbol_id=?').get(symbolId);
        if (row)
            return { kind: 'active', declaration: this.declaration(row), filePath: String(row.file_path) };
        const tombstone = await this.getTombstone(symbolId);
        return tombstone ? { kind: 'tombstone', tombstone } : { kind: 'missing' };
    }
    async getPendingSymbol(symbolId) {
        await this.asyncBoundary();
        const row = this.db.prepare('SELECT s.* FROM symbols s JOIN structured_files f ON f.file_path=s.file_path AND f.pending_generation=s.generation WHERE s.symbol_id=?').get(symbolId);
        return row ? { kind: 'pending', declaration: this.declaration(row) } : { kind: 'missing' };
    }
    async getTombstone(symbolId) {
        await this.asyncBoundary();
        const row = this.db.prepare('SELECT symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at FROM symbol_tombstones WHERE symbol_id=?').get(symbolId);
        return row ? { symbolId: row.symbol_id, filePath: row.file_path, generationId: row.generation, retiredAtRebuildEpoch: row.retired_at_rebuild_epoch, retiredAt: row.retired_at } : null;
    }
    async getStructuredCounts() {
        await this.asyncBoundary();
        const activeFiles = this.db.prepare('SELECT count(*) AS n FROM structured_files WHERE active_generation IS NOT NULL').get();
        const pendingFiles = this.db.prepare('SELECT count(*) AS n FROM structured_files WHERE pending_generation IS NOT NULL').get();
        const activeSymbols = this.db.prepare('SELECT count(*) AS n FROM symbols s JOIN structured_files f ON f.file_path=s.file_path AND f.active_generation=s.generation').get();
        const pendingSymbols = this.db.prepare('SELECT count(*) AS n FROM symbols s JOIN structured_files f ON f.file_path=s.file_path AND f.pending_generation=s.generation').get();
        const tombstones = this.db.prepare('SELECT count(*) AS n FROM symbol_tombstones').get();
        return { activeFiles: activeFiles.n, activeSymbols: activeSymbols.n, pendingFiles: pendingFiles.n, pendingSymbols: pendingSymbols.n, tombstones: tombstones.n };
    }
    async getImportsForSymbol(symbolId) {
        await this.asyncBoundary();
        const rows = this.db.prepare(`
      SELECT i.id AS bindingId, i.source AS moduleSpecifier, i.imported_names AS bindingName,
             i.start_byte AS startByte, i.end_byte AS endByte,
             i.source_hash AS sourceHash, i.is_complete AS isComplete
      FROM symbol_imports si
      JOIN imports i ON i.file_path = si.file_path AND i.generation = si.generation AND i.id = si.import_binding_id
      JOIN structured_files f ON f.file_path = si.file_path AND f.active_generation = si.generation
      WHERE si.symbol_id = ?
    `).all(symbolId);
        return rows.map((row) => ({
            id: row.bindingId,
            moduleSpecifier: row.moduleSpecifier || undefined,
            bindingName: row.bindingName || undefined,
            startByte: row.startByte,
            endByte: row.endByte,
            sourceHash: row.sourceHash,
            completeness: row.isComplete === 1 ? 'complete' : 'partial',
        }));
    }
    async getFileDeclarations(filePath) {
        await this.asyncBoundary();
        const rows = this.db.prepare(`
      SELECT s.*, f.file_path AS file_path
      FROM symbols s
      JOIN structured_files f ON f.file_path = s.file_path AND f.active_generation = s.generation
      WHERE s.file_path = ?
      ORDER BY s.start_byte, s.qualified_name
    `).all(filePath);
        return rows.map((row) => this.declaration(row));
    }
    async getGeneration(filePath, generationId) {
        await this.asyncBoundary();
        const row = this.db.prepare(`
      SELECT file_path, generation, schema_version, parser_id, parser_version, content_hash, file_completeness
      FROM symbol_generations
      WHERE file_path = ? AND generation = ?
    `).get(filePath, generationId);
        if (row === undefined)
            return null;
        return {
            generationId: row.generation,
            schemaVersion: row.schema_version,
            parserId: row.parser_id,
            parserVersion: row.parser_version,
            fileHash: row.content_hash,
            fileCompleteness: row.file_completeness === 'partial' ? 'partial' : 'complete',
        };
    }
    validateFullRebuildEpoch(input, mode) {
        const epoch = this.db.prepare('SELECT structured_rebuild_epoch AS value FROM index_stats WHERE id = ?').get(PRIMARY_STATS_ID);
        if ((epoch?.value ?? 0) !== input.rebuildEpoch) {
            throw new Error(`SqliteMetadataStore.${mode}FullRebuild: stale rebuild epoch ${input.rebuildEpoch}`);
        }
    }
    validateFullRebuildTarget(paths, filePath, expectedActiveGeneration, generationId, retired, mode) {
        const operation = `SqliteMetadataStore.${mode}FullRebuild`;
        if (paths.has(filePath)) {
            throw new Error(`${operation}: duplicate ${retired ? 'retired ' : ''}file ${filePath}`);
        }
        paths.add(filePath);
        const requiresPendingGeneration = mode === 'activate' && generationId !== undefined;
        const query = requiresPendingGeneration
            ? 'SELECT active_generation,pending_generation FROM structured_files WHERE file_path = ?'
            : 'SELECT active_generation FROM structured_files WHERE file_path = ?';
        const row = this.db.prepare(query).get(filePath);
        const activeMatches = retired
            ? row?.active_generation === expectedActiveGeneration
            : (row?.active_generation ?? null) === expectedActiveGeneration;
        const pendingMatches = !requiresPendingGeneration || row?.pending_generation === generationId;
        if (!activeMatches || !pendingMatches) {
            throw new Error(`${operation}: ${retired ? 'retired ' : ''}generation validation failed for ${filePath}`);
        }
    }
    validateFullRebuildTargets(input, mode) {
        this.validateFullRebuildEpoch(input, mode);
        const paths = new Set();
        for (const file of input.files) {
            this.validateFullRebuildTarget(paths, file.filePath, file.expectedActiveGeneration, file.generationId, false, mode);
        }
        for (const file of input.retiredFiles) {
            this.validateFullRebuildTarget(paths, file.filePath, file.expectedActiveGeneration, undefined, true, mode);
        }
    }
    async prepareFullRebuild(input, merkleSnapshot) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            this.validateFullRebuildTargets(input, 'prepare');
            this.db.prepare('DELETE FROM structured_rebuild_backup_runs').run();
            this.db.prepare('DELETE FROM structured_rebuild_backup_files').run();
            this.db.prepare('DELETE FROM structured_rebuild_backup_tombstones').run();
            this.db.prepare('DELETE FROM structured_rebuild_backup_vectors').run();
            this.db.prepare(`
        INSERT INTO structured_rebuild_backup_files (rebuild_epoch,file_path,active_generation,pending_generation)
        SELECT ?,file_path,active_generation,pending_generation
        FROM structured_files
      `).run(input.rebuildEpoch);
            this.db.prepare('INSERT INTO structured_rebuild_backup_tombstones (rebuild_epoch,symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at) SELECT ?,symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at FROM symbol_tombstones').run(input.rebuildEpoch);
            this.db.prepare('INSERT INTO structured_rebuild_backup_runs (rebuild_epoch,phase,merkle_snapshot) VALUES (?,?,?)').run(input.rebuildEpoch, 'building', JSON.stringify(merkleSnapshot));
        });
    }
    async recordFullRebuildVectorArtifact(input) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            this.validateFullRebuildEpoch({
                rebuildEpoch: input.rebuildEpoch,
                files: [],
                retiredFiles: [],
            }, 'prepare');
            this.db.prepare(`
        INSERT INTO structured_rebuild_backup_vectors
          (rebuild_epoch,table_kind,shadow_name,replacement_name,backup_name,had_live_table,backup_complete)
        VALUES (?,?,?,?,?,?,?)
        ON CONFLICT(rebuild_epoch,table_kind) DO UPDATE SET
          shadow_name=excluded.shadow_name,
          replacement_name=excluded.replacement_name,
          backup_name=excluded.backup_name,
          had_live_table=excluded.had_live_table,
          backup_complete=excluded.backup_complete
      `).run(input.rebuildEpoch, input.table, input.shadowName, input.replacementName, input.backupName, input.hadLiveTable ? 1 : 0, input.backupComplete ? 1 : 0);
        });
    }
    async markFullRebuildVectorBackupComplete(input) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            const result = this.db.prepare(`
        UPDATE structured_rebuild_backup_vectors
        SET backup_complete=1
        WHERE rebuild_epoch=? AND table_kind=?
      `).run(input.rebuildEpoch, input.table);
            if (result.changes !== 1) {
                throw new Error(`SqliteMetadataStore.markFullRebuildVectorBackupComplete: missing ${input.table} artifact for epoch ${input.rebuildEpoch}`);
            }
        });
    }
    async activateFullRebuild(input) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            this.validateFullRebuildTargets(input, 'activate');
            const symbolsByFileAndGeneration = this.db.prepare('SELECT symbol_id FROM symbols WHERE file_path = ? AND generation = ?');
            const addTombstone = this.db.prepare('INSERT OR REPLACE INTO symbol_tombstones (symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at) VALUES (?,?,?,?,?)');
            const deleteNewTombstone = this.db.prepare('DELETE FROM symbol_tombstones WHERE symbol_id IN (SELECT symbol_id FROM symbols WHERE file_path = ? AND generation = ?)');
            const activate = this.db.prepare('UPDATE structured_files SET active_generation = ?, pending_generation = NULL WHERE file_path = ?');
            for (const file of input.files) {
                if (file.expectedActiveGeneration !== null) {
                    const newSymbols = new Set(symbolsByFileAndGeneration.all(file.filePath, file.generationId).map((row) => row.symbol_id));
                    for (const row of symbolsByFileAndGeneration.all(file.filePath, file.expectedActiveGeneration)) {
                        if (!newSymbols.has(row.symbol_id))
                            addTombstone.run(row.symbol_id, file.filePath, file.expectedActiveGeneration, input.rebuildEpoch, Date.now());
                    }
                }
                deleteNewTombstone.run(file.filePath, file.generationId);
                activate.run(file.generationId, file.filePath);
            }
            for (const file of input.retiredFiles) {
                for (const row of symbolsByFileAndGeneration.all(file.filePath, file.expectedActiveGeneration)) {
                    addTombstone.run(row.symbol_id, file.filePath, file.expectedActiveGeneration, input.rebuildEpoch, Date.now());
                }
                activate.run(null, file.filePath);
            }
        });
    }
    async rollbackFullRebuild(input) {
        await this.asyncBoundary();
        this.restoreFullRebuild(input.rebuildEpoch, null);
    }
    async finalizeFullRebuild(input) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            this.pruneOrphanedStructuredData();
            this.db.prepare('DELETE FROM structured_files WHERE active_generation IS NULL AND pending_generation IS NULL').run();
            this.db.prepare('DELETE FROM structured_rebuild_backup_runs WHERE rebuild_epoch = ?').run(input.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_files WHERE rebuild_epoch = ?').run(input.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_tombstones WHERE rebuild_epoch = ?').run(input.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_vectors WHERE rebuild_epoch = ?').run(input.rebuildEpoch);
        });
        await this.reconcileStructuredState();
    }
    readFullRebuildRecovery() {
        const row = this.db.prepare(`
      SELECT r.rebuild_epoch AS rebuildEpoch, r.phase, r.merkle_snapshot AS merkleSnapshot
      FROM structured_rebuild_backup_runs AS r
      JOIN index_stats AS s ON s.structured_rebuild_epoch = r.rebuild_epoch
      WHERE s.id = ? AND r.phase = s.structured_rebuild_state
      ORDER BY r.rebuild_epoch DESC
      LIMIT 1
    `).get(PRIMARY_STATS_ID);
        if (row === undefined || !this.isRecoverablePhase(row.phase))
            return null;
        const vectorArtifacts = this.db.prepare(`
      SELECT
        rebuild_epoch AS rebuildEpoch,
        table_kind AS tableKind,
        shadow_name AS shadowName,
        replacement_name AS replacementName,
        backup_name AS backupName,
        had_live_table AS hadLiveTable,
        backup_complete AS backupComplete
      FROM structured_rebuild_backup_vectors
      WHERE rebuild_epoch=?
      ORDER BY table_kind
    `).all(row.rebuildEpoch);
        return {
            rebuildEpoch: row.rebuildEpoch,
            phase: row.phase,
            merkleSnapshot: this.parseMerkleSnapshot(row.merkleSnapshot),
            vectorArtifacts: vectorArtifacts.map((artifact) => ({
                rebuildEpoch: artifact.rebuildEpoch,
                table: artifact.tableKind,
                shadowName: artifact.shadowName,
                replacementName: artifact.replacementName,
                backupName: artifact.backupName,
                hadLiveTable: artifact.hadLiveTable === 1,
                backupComplete: artifact.backupComplete === 1,
            })),
        };
    }
    isRecoverablePhase(phase) {
        return phase === 'building'
            || phase === 'legacy-swapped'
            || phase === 'structured-swapped'
            || phase === 'catalog-activated'
            || phase === 'merkle-activated';
    }
    parseMerkleSnapshot(value) {
        if (value === null)
            return null;
        try {
            const parsed = JSON.parse(value);
            if (!Array.isArray(parsed))
                throw new Error('Invalid full rebuild Merkle snapshot');
            return parsed.map((node) => {
                if (typeof node !== 'object' || node === null)
                    throw new Error('Invalid full rebuild Merkle snapshot node');
                const candidate = node;
                if (typeof candidate.path !== 'string'
                    || typeof candidate.hash !== 'string'
                    || (candidate.parentPath !== null && typeof candidate.parentPath !== 'string')
                    || typeof candidate.isDirectory !== 'boolean') {
                    throw new Error('Invalid full rebuild Merkle snapshot node');
                }
                return {
                    path: candidate.path,
                    hash: candidate.hash,
                    parentPath: candidate.parentPath,
                    isDirectory: candidate.isDirectory,
                };
            });
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            console.error('[Nexus MetadataStore] Failed to parse full rebuild Merkle snapshot:', message);
            throw new Error('Invalid full rebuild Merkle snapshot', { cause: error });
        }
    }
    recoverInterruptedFullRebuildOnInitialize() {
        try {
            const recovery = this.readFullRebuildRecovery();
            if (recovery === null || recovery.phase === 'merkle-activated')
                return;
            this.restoreFullRebuild(recovery.rebuildEpoch, recovery.merkleSnapshot, true);
        }
        catch (error) {
            console.error('[Nexus MetadataStore] Failed to recover interrupted full rebuild:', error);
        }
    }
    async getFullRebuildRecovery() {
        await this.asyncBoundary();
        return this.readFullRebuildRecovery();
    }
    async recoverInterruptedFullRebuild() {
        await this.asyncBoundary();
        const recovery = this.readFullRebuildRecovery();
        if (recovery === null || recovery.phase === 'merkle-activated')
            return;
        this.restoreFullRebuild(recovery.rebuildEpoch, recovery.merkleSnapshot, true);
    }
    async finalizeInterruptedFullRebuild() {
        await this.asyncBoundary();
        const recovery = this.readFullRebuildRecovery();
        if (recovery === null || recovery.phase !== 'merkle-activated')
            return;
        this.immediateTransaction(() => {
            this.db.prepare('DELETE FROM structured_rebuild_backup_runs WHERE rebuild_epoch = ?').run(recovery.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_files WHERE rebuild_epoch = ?').run(recovery.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_tombstones WHERE rebuild_epoch = ?').run(recovery.rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_vectors WHERE rebuild_epoch = ?').run(recovery.rebuildEpoch);
            this.db.prepare('UPDATE index_stats SET structured_rebuild_state=?, structured_last_error_code=? WHERE id=?').run('idle', null, PRIMARY_STATS_ID);
        });
    }
    restoreFullRebuild(rebuildEpoch, merkleSnapshot, markFailed = false) {
        this.immediateTransaction(() => {
            const backupFiles = this.db.prepare(`
        SELECT file_path AS filePath, active_generation AS activeGeneration, pending_generation AS pendingGeneration
        FROM structured_rebuild_backup_files
        WHERE rebuild_epoch = ?
      `).all(rebuildEpoch);
            const deleteFile = this.db.prepare('DELETE FROM structured_files WHERE file_path = ?');
            const restoreFile = this.db.prepare('INSERT INTO structured_files (file_path,active_generation,pending_generation) VALUES (?,?,?)');
            this.db.prepare('DELETE FROM structured_files WHERE file_path NOT IN (SELECT file_path FROM structured_rebuild_backup_files WHERE rebuild_epoch = ?)').run(rebuildEpoch);
            for (const file of backupFiles) {
                deleteFile.run(file.filePath);
                if (file.activeGeneration !== null || file.pendingGeneration !== null) {
                    restoreFile.run(file.filePath, file.activeGeneration, file.pendingGeneration);
                }
            }
            this.db.prepare('DELETE FROM symbol_tombstones').run();
            this.db.prepare(`
        INSERT INTO symbol_tombstones (symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at)
        SELECT symbol_id,file_path,generation,retired_at_rebuild_epoch,retired_at
        FROM structured_rebuild_backup_tombstones
        WHERE rebuild_epoch = ?
      `).run(rebuildEpoch);
            if (merkleSnapshot !== null) {
                this.db.prepare('DELETE FROM merkle_nodes').run();
                const insertMerkle = this.db.prepare('INSERT INTO merkle_nodes (path,hash,parent_path,is_directory) VALUES (?,?,?,?)');
                for (const node of merkleSnapshot)
                    insertMerkle.run(node.path, node.hash, node.parentPath, node.isDirectory ? 1 : 0);
            }
            this.pruneOrphanedStructuredData();
            this.db.prepare('DELETE FROM structured_files WHERE active_generation IS NULL AND pending_generation IS NULL').run();
            this.db.prepare('DELETE FROM structured_rebuild_backup_runs WHERE rebuild_epoch = ?').run(rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_files WHERE rebuild_epoch = ?').run(rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_tombstones WHERE rebuild_epoch = ?').run(rebuildEpoch);
            this.db.prepare('DELETE FROM structured_rebuild_backup_vectors WHERE rebuild_epoch = ?').run(rebuildEpoch);
            if (markFailed) {
                this.db.prepare('UPDATE index_stats SET structured_rebuild_state=?, structured_last_error_code=? WHERE id=?').run('failed', 'interrupted full rebuild rolled back during startup recovery', PRIMARY_STATS_ID);
            }
        });
    }
    async reconcileStructuredState() {
        await this.asyncBoundary();
        return this.immediateTransaction(() => {
            const orphanedRows = this.pruneOrphanedStructuredData();
            const prunedTombstones = this.db.prepare('DELETE FROM symbol_tombstones WHERE symbol_id IN (SELECT s.symbol_id FROM symbols AS s JOIN structured_files AS f ON f.file_path=s.file_path AND f.active_generation=s.generation)').run().changes;
            const current = this.db.prepare('SELECT structured_schema_version AS schemaVersion, structured_rebuild_state AS rebuildState, structured_last_error_code AS lastErrorCode FROM index_stats WHERE id=?').get(PRIMARY_STATS_ID);
            const schema = this.db.prepare('SELECT MIN(sg.schema_version) AS minimum, MAX(sg.schema_version) AS maximum, COUNT(*) AS count FROM symbol_generations AS sg JOIN structured_files AS f ON f.file_path=sg.file_path AND f.active_generation=sg.generation').get();
            const pending = this.db.prepare('SELECT 1 FROM structured_files WHERE pending_generation IS NOT NULL LIMIT 1').get() !== undefined;
            const schemaVersion = schema.count > 0 && schema.minimum === schema.maximum ? schema.minimum : null;
            let rebuildState;
            if (pending) {
                rebuildState = 'building';
            }
            else if (current?.rebuildState === 'building') {
                rebuildState = 'failed';
            }
            else {
                rebuildState = current?.rebuildState ?? 'idle';
            }
            const stateChanged = current?.schemaVersion !== schemaVersion || current?.rebuildState !== rebuildState;
            this.db.prepare('UPDATE index_stats SET structured_schema_version=?, structured_rebuild_state=?, structured_last_error_code=? WHERE id=?').run(schemaVersion, rebuildState, current?.lastErrorCode ?? null, PRIMARY_STATS_ID);
            return { repaired: orphanedRows > 0 || prunedTombstones > 0 || stateChanged, prunedTombstones };
        });
    }
    async setStructuredRebuildState(input) {
        await this.asyncBoundary();
        this.immediateTransaction(() => {
            this.db.prepare('UPDATE index_stats SET structured_rebuild_state=?, structured_last_error_code=? WHERE id=?').run(input.rebuildState, input.lastErrorCode ?? null, PRIMARY_STATS_ID);
            this.db.prepare('UPDATE structured_rebuild_backup_runs SET phase=? WHERE rebuild_epoch=(SELECT structured_rebuild_epoch FROM index_stats WHERE id=?)').run(input.rebuildState, PRIMARY_STATS_ID);
        });
    }
    async incrementRebuildEpoch() {
        await this.asyncBoundary();
        this.db.prepare('UPDATE index_stats SET structured_rebuild_epoch = COALESCE(structured_rebuild_epoch, 0) + 1 WHERE id=?').run(PRIMARY_STATS_ID);
        const row = this.db.prepare('SELECT structured_rebuild_epoch AS epoch FROM index_stats WHERE id=?').get(PRIMARY_STATS_ID);
        return row?.epoch ?? 0;
    }
    async bulkUpsertMerkleNodes(nodes) {
        const statement = this.db.prepare(`
      INSERT INTO merkle_nodes (path, hash, parent_path, is_directory)
      VALUES (@path, @hash, @parentPath, @isDirectory)
      ON CONFLICT(path) DO UPDATE SET
        hash = excluded.hash,
        parent_path = excluded.parent_path,
        is_directory = excluded.is_directory
    `);
        await executeBatchedWithYield({
            items: nodes,
            batchSize: this.batchSize,
            executeBatch: async (batch) => {
                await this.asyncBoundary();
                const transaction = this.db.transaction((rows) => {
                    for (const node of rows) {
                        statement.run({
                            path: node.path,
                            hash: node.hash,
                            parentPath: node.parentPath,
                            isDirectory: node.isDirectory ? 1 : 0,
                        });
                    }
                });
                transaction(batch);
            },
            yieldAfterBatch: this.asyncBoundary,
        });
    }
    async bulkDeleteMerkleNodes(paths) {
        const statement = this.db.prepare('DELETE FROM merkle_nodes WHERE path = ?');
        await executeBatchedWithYield({
            items: paths,
            batchSize: this.batchSize,
            executeBatch: async (batch) => {
                await this.asyncBoundary();
                const transaction = this.db.transaction((rows) => {
                    for (const targetPath of rows) {
                        statement.run(targetPath);
                    }
                });
                transaction(batch);
            },
            yieldAfterBatch: this.asyncBoundary,
        });
    }
    async bulkDeleteSubtrees(paths) {
        const statement = this.db.prepare("DELETE FROM merkle_nodes WHERE path = ? OR path LIKE ? ESCAPE '\\'");
        await this.asyncBoundary();
        const transaction = this.db.transaction((allPaths) => {
            let totalChanges = 0;
            for (const targetPath of allPaths) {
                const escapedPrefix = targetPath.replace(/%/g, '\\%').replace(/_/g, '\\_');
                const prefix = `${escapedPrefix}/%`;
                const result = statement.run(targetPath, prefix);
                totalChanges += result.changes;
            }
            return totalChanges;
        });
        return transaction(paths);
    }
    async replaceAllMerkleNodes(nodes) {
        await this.asyncBoundary();
        const transaction = this.db.transaction((rows) => {
            this.db.prepare('DELETE FROM merkle_nodes').run();
            const statement = this.db.prepare(`
        INSERT INTO merkle_nodes (path, hash, parent_path, is_directory)
        VALUES (@path, @hash, @parentPath, @isDirectory)
      `);
            for (const node of rows) {
                statement.run({
                    path: node.path,
                    hash: node.hash,
                    parentPath: node.parentPath,
                    isDirectory: node.isDirectory ? 1 : 0,
                });
            }
        });
        transaction(nodes);
    }
    async deleteSubtree(pathPrefix) {
        await this.asyncBoundary();
        const escapedPrefix = pathPrefix.replace(/%/g, '\\%').replace(/_/g, '\\_');
        const prefix = `${escapedPrefix}/%`;
        const result = this.db
            .prepare("DELETE FROM merkle_nodes WHERE path = ? OR path LIKE ? ESCAPE '\\'")
            .run(pathPrefix, prefix);
        return result.changes;
    }
    /**
     * Returns all paths within a subtree, including the root of the subtree.
     */
    async getSubtreePaths(pathPrefix) {
        await this.asyncBoundary();
        const escapedPrefix = pathPrefix.replace(/%/g, '\\%').replace(/_/g, '\\_');
        const prefix = `${escapedPrefix}/%`;
        const rows = this.db
            .prepare("SELECT path FROM merkle_nodes WHERE path = ? OR path LIKE ? ESCAPE '\\'")
            .all(pathPrefix, prefix);
        return rows.map((r) => r.path);
    }
    async renamePath(oldPath, newPath, hash) {
        await this.asyncBoundary();
        const parentPath = dirname(newPath);
        const normalizedParentPath = parentPath === '.' || parentPath === '/' || parentPath === '' ? null : parentPath;
        this.db.transaction(() => {
            // Get the existing node to preserve its is_directory type
            const oldNode = this.db
                .prepare('SELECT is_directory FROM merkle_nodes WHERE path = ?')
                .get(oldPath);
            const isDirectory = oldNode?.is_directory ?? 0;
            this.db.prepare('DELETE FROM merkle_nodes WHERE path = ?').run(oldPath);
            this.db
                .prepare(`
        INSERT INTO merkle_nodes (path, hash, parent_path, is_directory)
        VALUES (@path, @hash, @parentPath, @isDirectory)
        ON CONFLICT(path) DO UPDATE SET
          hash = excluded.hash,
          parent_path = excluded.parent_path,
          is_directory = excluded.is_directory
      `)
                .run({
                path: newPath,
                hash,
                parentPath: normalizedParentPath,
                isDirectory,
            });
        })();
    }
    async pruneEmptyParents(path, pathExists) {
        let currentPath = dirname(path);
        const stmt = this.db.prepare('DELETE FROM merkle_nodes WHERE path = ?');
        while (currentPath !== '.' && currentPath !== '/' && currentPath !== '') {
            await this.asyncBoundary();
            const hasChildren = await this.hasChildren(currentPath);
            if (!hasChildren) {
                // If the directory still exists on disk, don't prune it from metadata
                if (await pathExists(currentPath)) {
                    break;
                }
                stmt.run(currentPath);
                currentPath = dirname(currentPath);
            }
            else {
                break;
            }
        }
    }
    async getMerkleNode(path) {
        await this.asyncBoundary();
        const row = this.db
            .prepare('SELECT path, hash, parent_path AS parentPath, is_directory AS isDirectory FROM merkle_nodes WHERE path = ?')
            .get(path);
        if (row === undefined) {
            return null;
        }
        return {
            path: row.path,
            hash: row.hash,
            parentPath: row.parentPath,
            isDirectory: row.isDirectory === 1,
        };
    }
    async getChildren(path) {
        await this.asyncBoundary();
        const rows = this.db
            .prepare(`SELECT path, hash, parent_path AS parentPath, is_directory AS isDirectory
         FROM merkle_nodes
         WHERE parent_path ${path === null ? 'IS NULL' : '= ?'}
         ORDER BY path ASC`)
            .all(path === null ? [] : [path]);
        return rows.map((row) => ({
            path: row.path,
            hash: row.hash,
            parentPath: row.parentPath,
            isDirectory: row.isDirectory === 1,
        }));
    }
    async hasChildren(path) {
        await this.asyncBoundary();
        const row = this.db
            .prepare(`SELECT 1 FROM merkle_nodes WHERE parent_path ${path === null ? 'IS NULL' : '= ?'} LIMIT 1`)
            .get(path === null ? [] : [path]);
        return row !== undefined;
    }
    async getAllNodes() {
        await this.asyncBoundary();
        const rows = this.db
            .prepare(`SELECT path, hash, parent_path AS parentPath, is_directory AS isDirectory
         FROM merkle_nodes
         ORDER BY path ASC`)
            .all();
        return rows.map((row) => ({
            path: row.path,
            hash: row.hash,
            parentPath: row.parentPath,
            isDirectory: row.isDirectory === 1,
        }));
    }
    async getAllFileNodes() {
        await this.asyncBoundary();
        const rows = this.db
            .prepare(`SELECT path, hash, parent_path AS parentPath, is_directory AS isDirectory
         FROM merkle_nodes
         WHERE is_directory = 0
         ORDER BY path ASC`)
            .all();
        return rows.map((row) => ({
            path: row.path,
            hash: row.hash,
            parentPath: row.parentPath,
            isDirectory: row.isDirectory === 1,
        }));
    }
    async getAllPaths() {
        await this.asyncBoundary();
        const rows = this.db.prepare('SELECT path FROM merkle_nodes ORDER BY path ASC').all();
        return rows.map((row) => row.path);
    }
    async getIndexStats() {
        await this.asyncBoundary();
        const row = this.db
            .prepare(`SELECT id, total_files AS totalFiles, total_chunks AS totalChunks,
                last_indexed_at AS lastIndexedAt, last_full_scan_at AS lastFullScanAt,
                overflow_count AS overflowCount, last_error AS lastError
         FROM index_stats
         WHERE id = ?`)
            .get(PRIMARY_STATS_ID);
        return row ?? null;
    }
    async setIndexStats(stats) {
        await this.asyncBoundary();
        this.db.prepare(UPSERT_INDEX_STATS_SQL).run(stats);
    }
    async atomicCompletionCheck(stats) {
        await this.asyncBoundary();
        const runTransaction = this.db.transaction(() => {
            const dlqEntries = this.db
                .prepare(`SELECT id,
                  file_path AS filePath,
                  content_hash AS contentHash,
                  error_message AS errorMessage,
                  attempts,
                  recovery_attempts AS recoveryAttempts,
                  created_at AS createdAt,
                  updated_at AS updatedAt,
                  last_retry_at AS lastRetryAt
           FROM dead_letter_queue
           ORDER BY created_at ASC`)
                .all();
            if (dlqEntries.length === 0) {
                this.db.prepare(UPSERT_INDEX_STATS_SQL).run(stats);
            }
            return { dlqEmpty: dlqEntries.length === 0, dlqEntries };
        });
        return runTransaction.immediate();
    }
    async upsertDeadLetterEntries(entries) {
        const statement = this.db.prepare(`
      INSERT INTO dead_letter_queue (
        id, file_path, content_hash, error_message, attempts, recovery_attempts, created_at, updated_at, last_retry_at
      ) VALUES (
        @id, @filePath, @contentHash, @errorMessage, @attempts, @recoveryAttempts, @createdAt, @updatedAt, @lastRetryAt
      )
      ON CONFLICT(id) DO UPDATE SET
        file_path = excluded.file_path,
        content_hash = excluded.content_hash,
        error_message = excluded.error_message,
        attempts = excluded.attempts,
        recovery_attempts = excluded.recovery_attempts,
        updated_at = excluded.updated_at,
        last_retry_at = excluded.last_retry_at
    `);
        await executeBatchedWithYield({
            items: entries,
            batchSize: this.batchSize,
            executeBatch: async (batch) => {
                await this.asyncBoundary();
                const transaction = this.db.transaction((rows) => {
                    for (const entry of rows) {
                        statement.run(entry);
                    }
                });
                transaction(batch);
            },
            yieldAfterBatch: this.asyncBoundary,
        });
    }
    async removeDeadLetterEntries(ids) {
        await this.asyncBoundary();
        const statement = this.db.prepare('DELETE FROM dead_letter_queue WHERE id = ?');
        const transaction = this.db.transaction((rows) => {
            for (const id of rows) {
                statement.run(id);
            }
        });
        transaction(ids);
    }
    async getDeadLetterEntries() {
        await this.asyncBoundary();
        return this.db
            .prepare(`SELECT id,
                file_path AS filePath,
                content_hash AS contentHash,
                error_message AS errorMessage,
                attempts,
                recovery_attempts AS recoveryAttempts,
                created_at AS createdAt,
                updated_at AS updatedAt,
                last_retry_at AS lastRetryAt
         FROM dead_letter_queue
         ORDER BY created_at ASC`)
            .all();
    }
    async getEmbeddings(hashes) {
        await this.asyncBoundary();
        const result = new Map();
        if (hashes.length === 0) {
            return result;
        }
        const MAX_VARIABLES = 999; // SQLite default limit for older versions
        for (let offset = 0; offset < hashes.length; offset += MAX_VARIABLES) {
            const batch = hashes.slice(offset, offset + MAX_VARIABLES);
            const placeholders = batch.map(() => '?').join(', ');
            const rows = this.db
                .prepare(`SELECT hash, vector FROM embedding_cache WHERE hash IN (${placeholders})`)
                .all(...batch);
            for (const row of rows) {
                try {
                    result.set(row.hash, JSON.parse(row.vector));
                }
                catch {
                    console.warn(`[Nexus MetadataStore] Skipping corrupted embedding cache entry for hash ${row.hash}`);
                }
            }
        }
        return result;
    }
    async pruneEmbeddings(maxAgeDays) {
        await this.asyncBoundary();
        // Calculate cutoff date in JavaScript to enable parameterization.
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - maxAgeDays);
        const cutoffIso = cutoffDate.toISOString();
        const result = this.db
            .prepare(`DELETE FROM embedding_cache WHERE created_at < ?`)
            .run(cutoffIso);
        return Number(result.changes ?? 0);
    }
    async setEmbeddings(entries) {
        if (entries.length === 0) {
            return;
        }
        await this.asyncBoundary();
        const statement = this.db.prepare(`
      INSERT INTO embedding_cache (hash, vector, dimensions, created_at)
      VALUES (@hash, @vector, @dimensions, @createdAt)
      ON CONFLICT(hash) DO UPDATE SET
        vector = excluded.vector,
        dimensions = excluded.dimensions
    `);
        const now = new Date().toISOString();
        const transaction = this.db.transaction((rows) => {
            for (const entry of rows) {
                statement.run({
                    hash: entry.hash,
                    vector: JSON.stringify(entry.vector),
                    dimensions: entry.vector.length,
                    createdAt: now,
                });
            }
        });
        transaction(entries);
    }
    async deleteEmbeddings(hashes) {
        if (hashes.length === 0) {
            return;
        }
        await this.asyncBoundary();
        const statement = this.db.prepare('DELETE FROM embedding_cache WHERE hash = ?');
        const transaction = this.db.transaction((rows) => {
            for (const hash of rows) {
                statement.run(hash);
            }
        });
        transaction(hashes);
    }
    async clearEmbeddings() {
        await this.asyncBoundary();
        this.db.exec('DELETE FROM embedding_cache');
    }
    getPragmaValue(name) {
        return this.db.pragma(`${name}`, { simple: true });
    }
    async close() {
        await this.asyncBoundary();
        this.db.close();
    }
}
