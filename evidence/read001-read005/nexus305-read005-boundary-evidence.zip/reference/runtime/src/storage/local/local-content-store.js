import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const clampLine = (line, totalLines) => Math.max(1, Math.min(line, totalLines));
export class LocalContentStore {
    deps;
    constructor(deps) {
        this.deps = deps;
    }
    async put(_contentHash, _content) {
        throw new Error('LocalContentStore.put is not implemented (Phase 4 scope)');
    }
    async get(_contentHash) {
        return null;
    }
    async delete(_contentHash) {
        throw new Error('LocalContentStore.delete is not implemented (Phase 4 scope)');
    }
    async exists(_contentHash) {
        return false;
    }
    async readRange(filePath, startLine, endLine, signal) {
        const sanitizedPath = await this.deps.sanitize(filePath);
        const content = await readFile(resolve(this.deps.projectRoot, sanitizedPath), { encoding: 'utf8', signal });
        const lines = content.split('\n');
        const totalLines = lines.length;
        const clampedStart = clampLine(startLine, totalLines);
        const clampedEnd = clampLine(endLine, totalLines);
        if (clampedStart > clampedEnd) {
            throw new Error(`Invalid line range: startLine (${clampedStart}) is greater than endLine (${clampedEnd})`);
        }
        return lines.slice(clampedStart - 1, clampedEnd).join('\n');
    }
}
export class LocalContentStoreFactory {
    store;
    constructor(deps) {
        this.store = new LocalContentStore(deps);
    }
    getStore(workspaceId, revisionId) {
        if (workspaceId.trim() === '') {
            throw new Error('workspaceId must be a non-empty string');
        }
        if (revisionId.trim() === '') {
            throw new Error('revisionId must be a non-empty string');
        }
        return this.store;
    }
}
