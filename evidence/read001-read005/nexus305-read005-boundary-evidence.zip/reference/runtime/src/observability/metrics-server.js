import { createServer } from 'node:http';
export class MetricsHttpServer {
    registry;
    dashboardStatusEndpoint;
    server;
    listening = false;
    constructor(registry, dashboardStatusEndpoint) {
        this.registry = registry;
        this.dashboardStatusEndpoint = dashboardStatusEndpoint;
    }
    async start(port, host = '127.0.0.1') {
        if (this.listening || this.server) {
            return;
        }
        const reg = this.registry;
        const statusEndpoint = this.dashboardStatusEndpoint;
        const server = createServer((req, res) => {
            void (async () => {
                try {
                    if (req.url === '/status' && statusEndpoint) {
                        await statusEndpoint.handler(req, res);
                        return;
                    }
                    if (req.url === '/metrics') {
                        const metrics = await reg.metrics();
                        res.writeHead(200, { 'Content-Type': 'text/plain' });
                        res.end(metrics);
                    }
                    else if (req.url === '/metrics/json') {
                        const json = await reg.getMetricsAsJSON();
                        res.writeHead(200, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify(json));
                    }
                    else if (req.url === '/health') {
                        res.writeHead(200, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ status: 'ok' }));
                    }
                    else {
                        res.writeHead(404, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ status: 'error', error: 'Not found' }));
                    }
                }
                catch (err) {
                    console.error('[Nexus Metrics] Request failed:', err);
                    if (!res.headersSent) {
                        res.writeHead(500, { 'Content-Type': 'application/json' });
                    }
                    res.end(JSON.stringify({ status: 'error', error: 'Internal server error' }));
                }
            })().catch((err) => {
                console.error('[Nexus Metrics] Unhandled request error:', err);
            });
        });
        return new Promise((resolve, reject) => {
            const portNum = port;
            server.on('error', (err) => {
                if (err.code === 'EADDRINUSE') {
                    console.warn(`[Nexus] Metrics port ${portNum} already in use. Metrics HTTP server disabled.`);
                    this.listening = false;
                    resolve();
                }
                else {
                    reject(err);
                }
            });
            server.listen(portNum, host, () => {
                this.server = server;
                this.listening = true;
                resolve();
            });
        });
    }
    async stop() {
        const currentServer = this.server;
        if (!currentServer || !this.listening) {
            this.server = undefined;
            return;
        }
        return new Promise((resolve, reject) => {
            currentServer.close((err) => {
                this.server = undefined;
                this.listening = false;
                if (err)
                    reject(err);
                else
                    resolve();
            });
        });
    }
    isListening() {
        return this.listening;
    }
    getPort() {
        if (!this.server || !this.listening) {
            return undefined;
        }
        const address = this.server.address();
        if (!address || typeof address === "string") {
            return undefined;
        }
        return address.port;
    }
}
