export class RegistrationClient {
    payload;
    config;
    fetchFn;
    logger;
    timer;
    constructor(payload, config, fetchFn = globalThis.fetch, logger) {
        this.payload = payload;
        this.config = config;
        this.fetchFn = fetchFn;
        this.logger = logger;
    }
    start() {
        if (this.timer) {
            clearInterval(this.timer);
        }
        void this.register();
        this.timer = setInterval(() => void this.register(), this.config.heartbeatIntervalMs);
        this.timer.unref();
    }
    stop() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = undefined;
        }
    }
    async register() {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), this.config.requestTimeoutMs);
        try {
            const response = await this.fetchFn(`http://127.0.0.1:${this.config.aggregatorPort}/api/discovery/register`, {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify(this.payload),
                signal: controller.signal,
            });
            if (!response.ok) {
                throw new Error(`Aggregator registration failed with status ${response.status} ${response.statusText}`.trim());
            }
        }
        catch (error) {
            this.logger?.debug?.('Aggregator registration failed (non-fatal):', error);
        }
        finally {
            clearTimeout(timeout);
        }
    }
}
