import { WebStandardStreamableHTTPServerTransport, localhostAllowedHostnames, localhostAllowedOrigins, validateHostHeader, validateOriginHeader } from "@modelcontextprotocol/server";
import { getRequestListener } from "@hono/node-server";

//#region src/middleware/hostHeaderValidation.ts
/**
* Node.js request guard for DNS rebinding protection.
* Validates the `Host` header hostname (port-agnostic) against an allowed list.
*
* Unlike the framework adapters, plain `node:http` has no middleware chain, so
* the guard returns whether the request may proceed: when it returns `false`
* it has already answered the request with a `403` JSON-RPC error and the
* caller must not handle it further.
*
* @param allowedHostnames - List of allowed hostnames (without ports).
*   For IPv6, provide the address with brackets (e.g., `[::1]`).
*
* @example
* ```ts
* const validateHost = hostHeaderValidation(['localhost', '127.0.0.1', '[::1]']);
* http.createServer((req, res) => {
*     if (!validateHost(req, res)) return;
*     void transport.handleRequest(req, res);
* });
* ```
*/
function hostHeaderValidation(allowedHostnames) {
	return (req, res) => {
		const result = validateHostHeader(req.headers.host, allowedHostnames);
		if (result.ok) return true;
		res.writeHead(403, { "Content-Type": "application/json" });
		res.end(JSON.stringify({
			jsonrpc: "2.0",
			error: {
				code: -32e3,
				message: result.message
			},
			id: null
		}));
		return false;
	};
}
/**
* Convenience guard for localhost DNS rebinding protection.
* Allows only `localhost`, `127.0.0.1`, and `[::1]` (IPv6 localhost) hostnames.
*/
function localhostHostValidation() {
	return hostHeaderValidation(localhostAllowedHostnames());
}

//#endregion
//#region src/middleware/originValidation.ts
/**
* Node.js request guard for Origin header validation.
* Validates the `Origin` header hostname (port-agnostic) against an allowed list.
*
* Requests without an `Origin` header pass (non-browser MCP clients do not send
* one); a present value that is not allowed, or that cannot be parsed, is
* rejected with `403`. The guard returns whether the request may proceed: when
* it returns `false` it has already answered the request and the caller must
* not handle it further.
*
* @param allowedOriginHostnames - List of allowed origin hostnames (without scheme or port).
*   For IPv6, provide the address with brackets (e.g., `[::1]`).
*
* @example
* ```ts
* const validateOrigin = originValidation(['localhost', '127.0.0.1', '[::1]']);
* http.createServer((req, res) => {
*     if (!validateOrigin(req, res)) return;
*     void transport.handleRequest(req, res);
* });
* ```
*/
function originValidation(allowedOriginHostnames) {
	return (req, res) => {
		const result = validateOriginHeader(req.headers.origin, allowedOriginHostnames);
		if (result.ok) return true;
		res.writeHead(403, { "Content-Type": "application/json" });
		res.end(JSON.stringify({
			jsonrpc: "2.0",
			error: {
				code: -32e3,
				message: result.message
			},
			id: null
		}));
		return false;
	};
}
/**
* Convenience guard for localhost Origin validation.
* Allows only origins whose hostname is `localhost`, `127.0.0.1`, or `[::1]` (IPv6 localhost).
*/
function localhostOriginValidation() {
	return originValidation(localhostAllowedOrigins());
}

//#endregion
//#region src/streamableHttp.ts
/**
* Server transport for Streamable HTTP: this implements the MCP Streamable HTTP transport specification.
* It supports both SSE streaming and direct HTTP responses.
*
* This is a wrapper around {@linkcode WebStandardStreamableHTTPServerTransport} that provides Node.js HTTP compatibility.
* It uses the `@hono/node-server` library to convert between Node.js HTTP and Web Standard APIs.
*
* In stateful mode:
* - Session ID is generated and included in response headers
* - Session ID is always included in initialization responses
* - Requests with invalid session IDs are rejected with `404 Not Found`
* - Non-initialization requests without a session ID are rejected with `400 Bad Request`
* - State is maintained in-memory (connections, message history)
*
* In stateless mode:
* - No Session ID is included in any responses
* - No session validation is performed
*
* @example Stateful setup
* ```ts source="./streamableHttp.examples.ts#NodeStreamableHTTPServerTransport_stateful"
* const server = new McpServer({ name: 'my-server', version: '1.0.0' });
*
* const transport = new NodeStreamableHTTPServerTransport({
*     sessionIdGenerator: () => randomUUID()
* });
*
* await server.connect(transport);
* ```
*
* @example Stateless setup
* ```ts source="./streamableHttp.examples.ts#NodeStreamableHTTPServerTransport_stateless"
* const transport = new NodeStreamableHTTPServerTransport({
*     sessionIdGenerator: undefined
* });
* ```
*
* @example Using with a pre-parsed request body (e.g. Express)
* ```ts source="./streamableHttp.examples.ts#NodeStreamableHTTPServerTransport_express"
* app.post('/mcp', (req, res) => {
*     transport.handleRequest(req, res, req.body);
* });
* ```
*/
var NodeStreamableHTTPServerTransport = class {
	_webStandardTransport;
	_requestListener;
	_requestContext = /* @__PURE__ */ new WeakMap();
	constructor(options = {}) {
		this._webStandardTransport = new WebStandardStreamableHTTPServerTransport(options);
		this._requestListener = getRequestListener(async (webRequest) => {
			const context = this._requestContext.get(webRequest);
			return this._webStandardTransport.handleRequest(webRequest, {
				authInfo: context?.authInfo,
				parsedBody: context?.parsedBody
			});
		}, { overrideGlobalObjects: false });
	}
	/**
	* Gets the session ID for this transport instance.
	*/
	get sessionId() {
		return this._webStandardTransport.sessionId;
	}
	/**
	* Sets callback for when the transport is closed.
	*/
	set onclose(handler) {
		this._webStandardTransport.onclose = handler;
	}
	get onclose() {
		return this._webStandardTransport.onclose;
	}
	/**
	* Sets callback for transport errors.
	*/
	set onerror(handler) {
		this._webStandardTransport.onerror = handler;
	}
	get onerror() {
		return this._webStandardTransport.onerror;
	}
	/**
	* Sets callback for incoming messages.
	*/
	set onmessage(handler) {
		this._webStandardTransport.onmessage = handler;
	}
	get onmessage() {
		return this._webStandardTransport.onmessage;
	}
	/**
	* Starts the transport. This is required by the {@linkcode Transport} interface but is a no-op
	* for the Streamable HTTP transport as connections are managed per-request.
	*/
	async start() {
		return this._webStandardTransport.start();
	}
	/**
	* Closes the transport and all active connections.
	*/
	async close() {
		return this._webStandardTransport.close();
	}
	/**
	* Sends a JSON-RPC message through the transport.
	*/
	async send(message, options) {
		return this._webStandardTransport.send(message, options);
	}
	/**
	* Forwards the supported protocol versions to the wrapped Web Standard
	* transport for `MCP-Protocol-Version` header validation. Called by the
	* protocol layer during connect; without this delegation a server's
	* `supportedProtocolVersions` option never reached the Node adapter's
	* header validation.
	*/
	setSupportedProtocolVersions(versions) {
		this._webStandardTransport.setSupportedProtocolVersions(versions);
	}
	/**
	* Handles an incoming HTTP request, whether `GET` or `POST`.
	*
	* This method converts Node.js HTTP objects to Web Standard Request/Response
	* and delegates to the underlying {@linkcode WebStandardStreamableHTTPServerTransport}.
	*
	* @param req - Node.js `IncomingMessage`, optionally with `auth` property from middleware
	* @param res - Node.js `ServerResponse`
	* @param parsedBody - Optional pre-parsed body from body-parser middleware
	*/
	async handleRequest(req, res, parsedBody) {
		const authInfo = req.auth;
		await getRequestListener(async (webRequest) => {
			return this._webStandardTransport.handleRequest(webRequest, {
				authInfo,
				parsedBody
			});
		}, { overrideGlobalObjects: false })(req, res);
	}
	/**
	* Close an SSE stream for a specific request, triggering client reconnection.
	* Use this to implement polling behavior during long-running operations -
	* client will reconnect after the retry interval specified in the priming event.
	*/
	closeSSEStream(requestId) {
		this._webStandardTransport.closeSSEStream(requestId);
	}
	/**
	* Close the standalone GET SSE stream, triggering client reconnection.
	* Use this to implement polling behavior for server-initiated notifications.
	*/
	closeStandaloneSSEStream() {
		this._webStandardTransport.closeStandaloneSSEStream();
	}
};

//#endregion
//#region src/toNodeHandler.ts
/**
* Adapts a web-standard MCP handler (`handler.fetch`) to a Node.js
* `(req, res, parsedBody?)` request handler. The returned function converts the
* Node request to a web-standard `Request`, calls `handler.fetch`, then writes
* the `Response` back to `res` (honoring write backpressure for streamed SSE
* responses).
*
* `req.auth` is forwarded as the handler's pass-through `authInfo`. A function
* third argument (Express's `next`) is ignored, never treated as a body.
*
* Pass `{ onerror }` to observe the adapter-level error fallback (request
* conversion / `handler.fetch` throw) before the `500` response is written.
*/
function toNodeHandler(handler, opts) {
	return async (req, res, parsedBody) => {
		if (typeof parsedBody === "function") parsedBody = void 0;
		let finished = false;
		const abort = new AbortController();
		res.on("close", () => {
			if (!finished) abort.abort();
		});
		if (res.destroyed === true) abort.abort();
		let response;
		try {
			const request = await toWebRequest(req, parsedBody, { signal: abort.signal });
			response = await handler.fetch(request, {
				...req.auth !== void 0 && { authInfo: req.auth },
				...parsedBody !== void 0 && { parsedBody }
			});
		} catch (error) {
			try {
				opts?.onerror?.(error instanceof Error ? error : new Error(String(error)));
			} catch {}
			response = internalServerErrorResponse(echoableRequestId(parsedBody));
		}
		const headers = {};
		for (const [name, value] of response.headers) headers[name] = value;
		res.writeHead(response.status, headers);
		if (response.body === null) {
			finished = true;
			res.end();
			return;
		}
		let drainResolve;
		const releaseDrainWait = () => {
			drainResolve?.();
			drainResolve = void 0;
		};
		res.on("drain", releaseDrainWait);
		const closed = new Promise((resolve) => {
			abort.signal.addEventListener("abort", () => resolve(), { once: true });
		});
		try {
			for await (const chunk of response.body) {
				if (abort.signal.aborted) break;
				if (res.write(chunk) === false) await Promise.race([new Promise((resolve) => {
					drainResolve = resolve;
				}), closed]);
			}
		} catch {}
		finished = true;
		res.end();
	};
}
function singleHeaderValue(value) {
	return Array.isArray(value) ? value[0] : value;
}
/**
* Convert a Node.js `IncomingMessage` (duck-typed — an Express `req` works) to
* the web-standard `Request` that `handler.fetch()` and `isLegacyRequest()`
* take. This is the conversion {@linkcode toNodeHandler} performs internally,
* exported for hand-wired compositions:
*
* ```ts
* const probe = await toWebRequest(req, req.body);
* await ((await isLegacyRequest(probe)) ? legacy(req, res) : modern(req, res, req.body));
* ```
*
* With no `parsedBody` the Node stream is read to completion — read the body
* from the returned `Request` afterwards, not from `req`. When a body parser
* already consumed the stream (`express.json()`), pass the parsed value as
* `parsedBody` and nothing is read from `req`.
*/
async function toWebRequest(req, parsedBody, options) {
	const method = (req.method ?? "GET").toUpperCase();
	const url = `http://${singleHeaderValue(req.headers["host"]) ?? singleHeaderValue(req.headers[":authority"]) ?? "localhost"}${req.url ?? "/"}`;
	const headers = new Headers();
	for (const [name, value] of Object.entries(req.headers)) {
		if (value === void 0 || name.startsWith(":")) continue;
		if (Array.isArray(value)) for (const item of value) headers.append(name, item);
		else headers.set(name, value);
	}
	let body;
	if (method !== "GET" && method !== "HEAD") if (parsedBody === void 0) {
		const decoder = new TextDecoder();
		let collected = "";
		for await (const chunk of req) collected += typeof chunk === "string" ? chunk : decoder.decode(chunk, { stream: true });
		collected += decoder.decode();
		if (collected.length > 0) body = collected;
	} else {
		const serialized = JSON.stringify(parsedBody);
		headers.delete("content-encoding");
		headers.delete("transfer-encoding");
		if (serialized === void 0) headers.delete("content-length");
		else {
			body = serialized;
			headers.set("content-length", String(new TextEncoder().encode(serialized).byteLength));
		}
	}
	return new Request(url, {
		method,
		headers,
		...options?.signal !== void 0 && { signal: options.signal },
		...body !== void 0 && { body }
	});
}
/**
* The JSON-RPC id to echo on an adapter-built error response: the body's `id`
* when the body is a single JSON-RPC request whose id is a string or number,
* `null` otherwise.
*/
function echoableRequestId(body) {
	if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
	const { method, id } = body;
	if (typeof method !== "string") return null;
	return typeof id === "string" || typeof id === "number" ? id : null;
}
function internalServerErrorResponse(id) {
	return Response.json({
		jsonrpc: "2.0",
		error: {
			code: -32603,
			message: "Internal server error"
		},
		id
	}, { status: 500 });
}

//#endregion
export { NodeStreamableHTTPServerTransport, hostHeaderValidation, localhostHostValidation, localhostOriginValidation, originValidation, toNodeHandler, toWebRequest };
//# sourceMappingURL=index.mjs.map