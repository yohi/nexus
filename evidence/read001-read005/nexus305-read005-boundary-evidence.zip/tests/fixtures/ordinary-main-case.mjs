// SOURCE ONLY; explicit ordinary-case import boundary, not an executable venue.
export async function exerciseMainCase(facade, { initializeRequest, followupRequest }) {
  const main = await facade.initialize(initializeRequest);
  const result = await facade.route(main, followupRequest);
  const snapshot = await facade.snapshot(main);
  return { result, snapshot };
}
