// SOURCE ONLY: do not execute without separately authorized genuine venue.
import assert from 'node:assert/strict';

const rawKeys = ['transport', 'server', 'attempt', 'session', 'handleRequest', 'send', 'onmessage', 'close'];

export async function opaqueHandleEscapeDenied(venue) {
  const handle = await venue.initializeGenuineMain();
  const driver = await venue.drivers.sdkWeb(handle);
  assert.deepEqual(Reflect.ownKeys(handle), []);
  assert.equal(Object.getPrototypeOf(handle), null);
  assert.equal(Object.isFrozen(handle), true);
  for (const key of rawKeys) assert.equal(key in handle, false);
  assert.deepEqual(Reflect.ownKeys(driver).sort(), ['close', 'plan', 'replay', 'route']);
  assert.equal(Object.getPrototypeOf(driver), null);
  assert.equal(Object.isFrozen(driver), true);
  assert.equal(venue.mainOwners.reference, undefined);
  assert.throws(() => { venue.mainOwners.receipts = venue.untrustedReceipts; }, TypeError);
  const { transport, server, handleRequest, close } = handle;
  assert.deepEqual([transport, server, handleRequest, close], [undefined, undefined, undefined, undefined]);
  assert.throws(() => driver.transport.handleRequest(venue.followupRequest), TypeError);
  assert.throws(() => handle.close(), TypeError);
  await assert.rejects(driver.close(), /MAIN_OWNER_CLOSE_AUTHORITY_UNSPECIFIED/);
  const view = await venue.mainOwners.admit(handle, venue.followupRequest, venue.followupTarget);
  assert.equal(view, undefined);
  assert.equal(await venue.observeSDKDispatchDelta(), 0);
  assert.equal(await venue.observeFinalWriteDelta(), 0);
  assert.equal(await venue.observeMainCloseDelta(), 0);
}

export async function fabricatedHandlesDenied(venue) {
  const handle = await venue.initializeGenuineMain();
  const fabrications = [{ ...handle }, JSON.parse(JSON.stringify(handle)), Object.create(handle),
    Object.freeze(Object.create(null)), JSON.stringify(handle), venue.knownSessionId];
  assert.throws(() => String(handle), TypeError);
  for (const forged of fabrications) {
    assert.throws(() => venue.mainOwners.assertHandle(forged), /MAIN_OWNER_HANDLE_REQUIRED/);
    await assert.rejects(venue.drivers.sdkWeb(forged), /MAIN_OWNER_HANDLE_REQUIRED/);
    await assert.rejects(venue.mainOwners.dispatch(forged, venue.followupRequest, venue.followupTarget), /MAIN_OWNER_HANDLE_REQUIRED/);
    assert.equal(await venue.observeSDKDispatchDelta(), 0);
  }
  const cloned = structuredClone(handle);
  assert.throws(() => venue.mainOwners.assertHandle(cloned), /MAIN_OWNER_HANDLE_REQUIRED/);
}

// Baseline exploit (historical): ctx.drivers.registry.sync('initialize',
// 'observeActiveSync', { row }).transport.handleRequest(request).
// The current ordinary context must not expose that graph at all.
export async function caseContextCannotReadProviderRawIdentity(venue) {
  const { facade, initializeRequest } = await venue.issueOrdinaryMainCase();
  const handle = await facade.initialize(initializeRequest);
  assert.deepEqual(Reflect.ownKeys(facade).sort(), ['initialize', 'reconnect', 'route', 'snapshot']);
  for (const key of ['drivers', 'registry', 'receipts', 'observer', 'transport', 'server'])
    assert.equal(key in facade, false);
  await venue.verifyOrdinaryReachability(facade, handle);
  assert.equal(await venue.observeSDKDispatchDelta(), 0);
}

export async function staleOrForeignAuthorityDenied(venue) {
  const handle = await venue.initializeGenuineMain();
  const driver = await venue.drivers.sdkWeb(handle);
  for (const control of ['foreign-principal', 'foreign-session', 'boot-change', 'expired-active',
    'credential-revoke', 'revoked-authority', 'lifecycle-close', 'lifecycle-crash', 'individual-request-abort',
    'revoke-during-authentication', 'revoke-at-final-sync-verification', 'forged-dispatch-receipt']) {
    const input = await venue.prepareMainControl(control);
    await assert.rejects(driver.route(input.request, input.target, input.signal));
    assert.equal(await venue.observeSDKDispatchDelta(), 0);
    assert.equal(await venue.observeFinalWriteDelta(), 0);
  }
}

export async function replayUsesOnlyIndependentBroker(venue) {
  const handle = await venue.initializeGenuineMain();
  const driver = await venue.drivers.sdkWeb(handle);
  await driver.route(venue.authenticatedReplayRequest, venue.replayTarget, venue.replaySignal);
  const artifact = await venue.observeReplayRoutingArtifact();
  await venue.verifyIndependentReplayArtifact(artifact);
  assert.equal(artifact.authenticatedBrokerDelta, 1);
  assert.equal(artifact.mainSDKDispatchDelta, 0);
  assert.equal(artifact.mainCloseDelta, 0);
  assert.equal(artifact.rendererWasFreshPrivateStateless, true);
  assert.equal(artifact.revokedPayloadP, 0);
  assert.equal(artifact.terminalClaimRevival, 0);
}

export async function publicationAndLifecycleRemainDistinct(venue) {
  for (const control of ['C0', 'F1', 'P', 'stored-auth-no-promotion', 'terminal-claim',
    'INV-01', 'INV-02', 'INV-03', 'INV-04', 'INV-05', 'INV-06', 'INV-07',
    'same-session-close', 'same-session-crash', 'same-session-request-abort']) {
    const artifact = await venue.prepareAndObserveExistingInvariant(control);
    await venue.verifyIndependentInvariantArtifact(control, artifact);
    assert.equal(artifact.invariantPreserved, true);
  }
}
