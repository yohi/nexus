// SOURCE ONLY. Requires genuine enrolled venue; never run during static closure.
import assert from 'node:assert/strict';
import { caseA, caseD, caseE } from '../src/cases.mjs';
import { actualPrivateStdio } from '../src/adapters/sdk-drivers.mjs';
import { PrivateTransport } from '../src/adapters/mcp.mjs';

export async function sameMainObjectAfterInitialize(venue) {
  // Given a genuine completed initialization and independently enrolled request.
  const { facade, initializeRequest, followupRequest } = await venue.issueOrdinaryMainCase();
  const initialized = await facade.initialize(initializeRequest);
  assert.deepEqual(Reflect.ownKeys(initialized), []);
  assert.equal(Object.getPrototypeOf(initialized), null);
  assert.equal('transport' in facade, false);
  // When a subsequent request is dispatched through the shared owner.
  const routed = await facade.route(initialized, followupRequest);
  assert.equal(routed.ok, true);
  // Then independent dispatch evidence must identify the exact object.
  const evidence = await venue.observeMainDispatch();
  // Venue verifies a hashed raw artifact against its private identity enrollment;
  // no raw SDK object or self-reported owner token is accepted as evidence.
  await venue.verifyIndependentMainIdentityArtifact(evidence);
  assert.match(evidence.rawArtifactSha256, /^[a-f0-9]{64}$/);
  assert.equal(typeof evidence.independentObserverRef, 'string');
  assert.equal(evidence.sameInitializeTransport, true);
  assert.equal(evidence.sameInitializeServer, true);
  assert.equal(evidence.sameActiveCommitToken, true);
  assert.equal('transport' in evidence, false);
  assert.equal('server' in evidence, false);
}

export async function clonedOwnerDeniedBeforeSDK(venue) {
  const initialized = await venue.initializeGenuineMain();
  await assert.rejects(venue.drivers.sdkWeb({ ...initialized }), /MAIN_OWNER_HANDLE_REQUIRED/);
  assert.equal(await venue.observeSDKDispatchDelta(), 0);
}

export async function rejectedMainRequests(venue) {
  const initialized = await venue.initializeGenuineMain();
  const driver = await venue.drivers.sdkWeb(initialized);
  for (const control of ['foreign-session', 'foreign-principal', 'credential-revoke', 'foreign-transport', 'missing-target', 'cloned-target', 'boot-change', 'owner-close']) {
    const request = await venue.prepareMainControl(control);
    await assert.rejects(driver.route(request.request, request.target, request.signal));
    assert.equal(await venue.observeSDKDispatchDelta(), 0);
  }
}

export async function v2AndBridgeCannotInventActive(venue) {
  for (const driver of [venue.v2, venue.bridge]) {
    await assert.rejects(driver.routeNode(venue.initNodeRequest, venue.initBody, venue.initTarget, venue.initSignal), /SDK_API_CONTRACT_BLOCKED/);
    assert.equal(await venue.observeActiveCommitDelta(), 0);
  }
}

export async function obsoleteStdoutCallbackCannotWrite(venue) {
  await assert.rejects(venue.callObsoleteStdoutSignature(), /PUBLICATION_PERMIT_REQUIRED/);
  assert.equal(await venue.observeFinalWriteDelta(), 0);
}

export async function disposableSinkPermit(venue) {
  const { gate, permit } = await venue.enrollGenuineStdoutPermit();
  assert.equal(gate.publishPermit(permit).accepted, true);
  assert.equal(gate.publishPermit(permit).accepted, false);
  assert.equal(await venue.observeFinalWriteDelta(), 1);
}

export async function missingBarrierOrAntecedentCannotPass(venue) {
  for (const control of ['missing-barrier-origin', 'wrong-run-hash', 'self-observer', 'missing-forbidden-action', 'missing-antecedent']) {
    await assert.rejects(venue.collectRealControl(control));
  }
}

export async function caseDriversUseEnrolledFinalPublication(venue) {
  for (const scenario of [{ name: 'A', runner: caseA }, { name: 'D', runner: caseD }, { name: 'E', runner: caseE }]) {
    const ctx = await venue.prepareGenuineCaseContext(scenario.name);
    // Legacy write callbacks must not be needed for owner-side sink selection.
    ctx.attemptOldPublication = () => { throw new Error('LEGACY_CALLBACK_MUST_NOT_RUN'); };
    ctx.holdF1AndAttemptOldPublication = ctx.attemptOldPublication;
    await scenario.runner(ctx);
    const observation = await venue.observeCaseFinalPermits();
    assert.equal(observation.unenrolledWriteDelta, 0);
    assert.equal(observation.oldPAfterC0, 0);
  }
}

export function selfAssertedPipeCannotReachSDK() {
  // Given only a caller-provided enrollment string, no registry proof exists.
  assert.throws(() => actualPrivateStdio({}, { input: {}, output: {}, enrollmentRef: 'self-asserted' }), /VENUE_BINDING_REQUIRED/);
}

export async function privateTransportRejectsCallbackOutput() {
  // Given an arbitrary writer callback, constructor refuses the legacy shape.
  assert.throws(() => new PrivateTransport(() => { throw new Error('FINAL_WRITE_MUST_NOT_RUN'); }), /PRIVATE_FRAME_BOUND_REQUIRED/);
}
