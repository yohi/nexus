// SOURCE ONLY. Never import/execute under the source-closure handoff.
import assert from 'node:assert/strict';
import { projectData, projectCaseError, projectCaseResult } from '../src/case-context/projection.mjs';

// Break caught: allowing live/nested values or invoking a projection getter.
export function projectionRejectsLiveValues() {
  let getters = 0;
  const accessor = Object.defineProperty({}, 'server', { get() { getters++; return {}; } });
  const cycle = {}; cycle.self = cycle;
  const sparse = new Array(3); sparse[0] = 'first'; sparse[2] = 'last';
  for (const value of [{ nested: { transport: { handleRequest() {} } } }, accessor,
    { fn: (() => {}).bind(null) }, { key: Symbol('authority') }, new Map(), cycle, sparse,
    { value: Infinity }, { value: NaN }, { [Symbol('hidden')]: 'x' }]) {
    assert.throws(() => projectData(value), /CASE_RESULT_UNSAFE/);
  }
  assert.equal(getters, 0);
  const original = { list: [null, true, 3, 'safe'] };
  const copy = projectData(original);
  assert.equal(Object.getPrototypeOf(copy), null);
  assert.equal(Object.isFrozen(copy.list), true);
  original.list[3] = 'changed';
  assert.equal(copy.list[3], 'safe');
}

// Break caught: forwarding arbitrary error text/cause/custom capability data.
export function errorProjectionDoesNotLeak() {
  const raw = new Error('secret arbitrary provider text');
  raw.cause = { transport: { handleRequest() {} } }; raw.server = {};
  assert.deepEqual(Object.keys(projectCaseError(raw)).sort(), ['code', 'ok']);
  assert.equal(projectCaseError(raw).code, 'CASE_OPERATION_FAILED');
  assert.equal(projectCaseError(new Error('MAIN_OWNER_HANDLE_REQUIRED')).code, 'MAIN_OWNER_HANDLE_REQUIRED');
  let getters = 0;
  const error = Object.defineProperty({}, 'message', { get() { getters++; return 'hidden'; } });
  assert.equal(projectCaseError(error).code, 'CASE_OPERATION_FAILED');
  assert.equal(getters, 0);
  const result = projectCaseResult('route', { requestKey: 'r1', evidenceRef: 'artifact:r1', transport: raw.cause.transport });
  assert.deepEqual(Object.keys(result).sort(), ['evidenceRef', 'ok', 'operation', 'requestKey']);
}

// The following oracles require independent genuine venue enrollment. Trusted
// observers/control helpers belong to the oracle runner, NEVER to Case Context.
// No provider, counter, artifact or SDK is simulated here. Proxy traps, debugger,
// arbitrary module loading and mutable trusted prototypes require separate venue
// isolation and are not solved by descriptor inspection.
export async function caseCannotSupplyServerOrFactory(venue) {
  const { facade, initializeRequest } = await venue.issueOrdinaryMainCase();
  for (const forged of [{ server: venue.trustedServer }, { factory: () => venue.trustedServer },
    { callback() {} }, { ...initializeRequest }, JSON.parse(JSON.stringify(initializeRequest))]) {
    await assert.rejects(facade.initialize(forged), /CASE_REQUEST_HANDLE_REQUIRED/);
  }
  assert.equal(await venue.observeSDKDispatchDelta(), 0);
}

export async function initializeConnectsAfterObservation(venue) {
  const { facade, initializeRequest, followupRequest } = await venue.issueOrdinaryMainCase();
  const main = await facade.initialize(initializeRequest);
  await facade.route(main, followupRequest);
  const artifact = await venue.observeMainDispatch();
  await venue.verifyIndependentMainIdentityArtifact(artifact);
  assert.equal(artifact.sameInitializeTransport, true);
  assert.equal(artifact.sameInitializeServer, true);
  assert.equal(artifact.connectCount, 1);
  assert.deepEqual(artifact.initializeOrdering, ['construct', 'configure', 'observe', 'connect', 'initialize']);
}

export async function caseFacadeHasOnlyApprovedOperations(venue) {
  const { facade, initializeRequest } = await venue.issueOrdinaryMainCase();
  assert.deepEqual(Reflect.ownKeys(facade).sort(), ['initialize', 'reconnect', 'route', 'snapshot']);
  assert.equal(Object.getPrototypeOf(facade), null);
  assert.equal(Object.isFrozen(facade), true);
  const main = await facade.initialize(initializeRequest);
  assert.deepEqual(Reflect.ownKeys(main), []);
  await venue.verifyOrdinaryReachability(facade, main);
}

export async function requestAndSessionCopiesDoNotAuthorize(venue) {
  const first = await venue.issueOrdinaryMainCase();
  const second = await venue.issueOrdinaryMainCase();
  const main = await first.facade.initialize(first.initializeRequest);
  for (const forged of [{ ...main }, Object.create(main), structuredClone(main), JSON.stringify(main), venue.knownSessionId]) {
    assert.equal((await first.facade.route(forged, first.followupRequest)).ok, false);
  }
  assert.equal((await second.facade.route(main, second.followupRequest)).ok, false);
  assert.equal((await first.facade.route(main, { ...first.followupRequest })).ok, false);
  assert.equal(await venue.observeSDKDispatchDelta(), 0);
}

export async function currentAuthorizationCannotBeCached(venue) {
  for (const control of ['foreign-principal', 'expired-active', 'active-token-change', 'boot-change',
    'revoked-authority', 'execution-revoked-during-authentication', 'execution-revoked-at-final-sync']) {
    const { facade, main, followupRequest } = await venue.prepareCaseControl(control);
    assert.equal((await facade.route(main, followupRequest)).ok, false);
    assert.equal(await venue.observeSDKDispatchDelta(), 0);
    assert.equal(await venue.observeFinalWriteDelta(), 0);
  }
}

export async function publicReceiptCannotAuthorizeDispatch(venue) {
  for (const control of ['forged-digest', 'self-observer', 'wrong-run', 'wrong-boot', 'wrong-session',
    'wrong-attempt', 'wrong-active-token', 'wrong-request', 'wrong-principal', 'copied-public-receipt']) {
    const { facade, main, request } = await venue.prepareEvidenceControl(control);
    const result = await facade.snapshot(main);
    assert.equal(result.ok, false);
    assert.equal((await facade.route(result, request)).ok, false);
    assert.equal(await venue.observeSDKDispatchDelta(), 0);
  }
}

export async function scenarioRunCannotEscape(venue) {
  const { scenario, prepared } = await venue.prepareHostileProviderResult();
  assert.deepEqual(Reflect.ownKeys(prepared), ['executeWithRegisteredBarriers']);
  const result = await prepared.executeWithRegisteredBarriers();
  await venue.verifyOrdinaryReachability(prepared, result);
  assert.equal(await venue.observeInjectedGetterDelta(), 0);
  await scenario.collectIndependentRaw(prepared);
}
