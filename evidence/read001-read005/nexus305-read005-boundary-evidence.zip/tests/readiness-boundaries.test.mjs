// SOURCE ONLY; not run in this handoff. No fake trusted provider or ACTIVE row.
import assert from 'node:assert/strict';
import { assembleDrivers } from '../src/drivers/integration.mjs';
import { buildScenarioFixture } from '../src/readiness/fixtures.mjs';
import { ScenarioVenue } from '../src/readiness/scenario-runner.mjs';

export async function testMissingRegistryStopsBeforeDatabase() {
  await assert.rejects(assembleDrivers({ modules: {}, venueBinding: null }), /VENUE_CAPABILITY_UNENROLLED:REGISTRY/);
}
export async function testEnrolledOwnerBoundaries(realVenue) {
  const venue = new ScenarioVenue(realVenue.registry);
  await venue.requireSeparateExecutionAuthorization();
  await venue.verifyPinnedSDKAndIndependentObservers();
  const run = await venue.prepareRealScenario('RP-19', 'two-sequential-nonempty');
  const descriptor = buildScenarioFixture('RP-19', 'two-sequential-nonempty');
  assert.equal(descriptor.actual, null);
  assert.equal(descriptor.evidenceClass, 'DESCRIPTOR_ONLY_NOT_RUNTIME_EVIDENCE');
  assert.deepEqual(Reflect.ownKeys(run), ['executeWithRegisteredBarriers']);
  const outcome = await run.executeWithRegisteredBarriers();
  assert.equal(outcome.runId.length > 0, true);
  const evidence = await venue.collectIndependentRaw(run);
  // These are trusted independent oracle controls, not methods on an ordinary
  // Case Context. Genuine implementation/enrollment remains a venue blocker.
  const artifact = await realVenue.observeTwoReconnectArtifact(outcome.runId);
  await realVenue.verifyIndependentTwoReconnectArtifact(artifact);
  assert.equal(artifact.firstStatus, 200); assert.equal(artifact.secondStatus, 200);
  assert.notEqual(artifact.firstRendererInstanceId, artifact.secondRendererInstanceId);
  assert.equal(evidence.terminalClaimDelta, 0);
}

export async function scenarioRevocationBlocksSecondReplay(realVenue) {
  const control = await realVenue.prepareSecondReplayRevocation();
  const result = await control.prepared.executeWithRegisteredBarriers();
  assert.equal(result.ok, false);
  const artifact = await realVenue.observeSecondReplayRevocationArtifact();
  await realVenue.verifyIndependentRevocationArtifact(artifact);
  assert.equal(artifact.unauthorizedSDKDispatchDelta, 0);
  assert.equal(artifact.unauthorizedFinalWriteDelta, 0);
}
