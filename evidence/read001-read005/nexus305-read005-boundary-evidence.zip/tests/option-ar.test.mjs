// SOURCE ONLY. No test was executed during implementation. A separate executor
// must supply independently enrolled real SDK/SQLite/auth/HTTP observers.
import assert from 'node:assert/strict';
import { classifyReplayEvidence } from '../src/replay/oracle.mjs';

export const scenarios = Object.freeze({
  'RP-01': ['genuine-progress'], 'RP-02': ['foreign-principal', 'foreign-tenant'],
  'RP-03': ['foreign-session', 'foreign-stream', 'foreign-transport'],
  'RP-04': ['unknown-cursor', 'payload-swap', 'sequence-gap', 'duplicate'],
  'RP-05': ['expiry', 'credential-revoke', 'grant-revoke'],
  'RP-06': ['c0', 'f1-pending', 'f1-failed', 'f1-unknown'],
  'RP-07': ['anchor-empty'],
  'RP-07A': ['anchor-version', 'anchor-scope', 'anchor-range', 'anchor-digest', 'anchor-compromise', 'anchor-late-revoke', 'anchor-restart'],
  'RP-07B': ['anchor-new-event', 'anchor-new-foreign-stream'],
  'RP-08': ['compatible-cutover', 'permanent-revoke'], 'RP-09': ['restart-fresh-successor'],
  'RP-10': ['same-stream-concurrent', 'distinct-stream-concurrent', 'late-callback'],
  'RP-11': ['terminal-in-plan'], 'RP-12': ['header-c0', 'write-false', 'disconnect'],
  'RP-13': ['sdk-abort'], 'RP-14': ['priming-empty'], 'RP-15': ['stored-true-current-false'],
  'RP-16': ['direct-callback', 'direct-sdk', 'worker-final-fd'],
  'RP-17': ['callback-before-result-error', 'partial-result', 'init-abort'],
  'RP-18': ['initialize-success', 'p-active-crash-gap', 'init-header-c0'],
  'RP-19': ['two-sequential-nonempty'],
  'RP-19A': ['cancel-only-control', 'cancel-public-close', 'close-failure', 'close-timeout', 'late-send'],
  'RP-19B': ['two-principal-parallel', 'same-stream-lease', 'foreign-session', 'restart-anchor', 'lookup-c0-replay'],
  'R1-001-04': ['different-request-key']
});

// Fault control lives in the independently enrolled executor, not production.
// All inputs (including IDs) must come from real initialize/store/release paths.
export async function testOptionAR(venue, caseId, scenario) {
  assert(scenarios[caseId]?.includes(scenario));
  await venue.requireSeparateExecutionAuthorization();
  await venue.verifyPinnedSDKAndIndependentObservers();
  const run = await venue.prepareRealScenario(caseId, scenario);
  assert.equal(run.evidenceClass, 'REAL_SDK_SQLITE_AUTH_HTTP');
  let outcome;
  if (caseId === 'RP-19') {
    const first = await run.broker.reconnect(run.firstRequest, run.firstTarget);
    // Reusing renderer, releasing lease before end, skipping close/EOF, or
    // returning second SDK409 must falsify this test.
    const second = await run.broker.reconnect(run.secondRequest, run.secondTarget);
    for (const result of [first, second]) {
      assert.equal(result.status, 200);
      assert.equal(result.accepted, true);
      assert(result.frameCount > 0);
      assert.equal(result.closeOK, true);
      assert.equal(result.bodyEOF, true);
    }
    assert.notEqual(first.rendererInstanceId, second.rendererInstanceId);
    assert.equal(first.sessionId, second.sessionId);
    assert.equal(first.streamId, second.streamId);
    assert.equal(first.grantVersion, second.grantVersion);
    assert.notEqual(first.requestKey, second.requestKey);
    assert.equal(first.mainTransportId, second.mainTransportId);
    outcome = { first, second };
  } else {
    // Uses registered barrier hooks to drive real scenario cells, including
    // real SDK cancel-only negative control; never fabricates observer counts.
    outcome = await run.executeWithRegisteredBarriers();
  }
  const evidence = await venue.collectIndependentRaw(run, outcome);
  assert.equal(evidence.terminalClaimDelta, 0);
  const verdict = classifyReplayEvidence(caseId, scenario, evidence);
  const expected = scenario === 'sdk-abort' ? 'INCONCLUSIVE'
    : scenario === 'cancel-only-control' ? 'NEGATIVE_CONTROL_OBSERVATION' : 'PASS';
  assert.equal(verdict, expected);
  return { caseId, scenario, verdict, rawEvidencePath: evidence.rawEvidencePath };
}
