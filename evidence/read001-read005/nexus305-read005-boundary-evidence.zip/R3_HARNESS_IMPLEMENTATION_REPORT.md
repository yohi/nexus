# R3 harness implementation report

## Delivered code and limits

The source manifest lists real `.mjs` files and SHA-256 values. Modules are
disposable independent Spike logic, not Nexus product changes. No experimental
module has been executed, imported for testing or credited with dynamic PASS.

Implemented logic: Authority C0/CAS/hold, bounded request identity/retry,
terminal claim and final-write gate, barriers and signal-adapter validation,
Native observation correlation, separated Writer/Publisher/Seal/Reader/GC actors,
private MCP transport/server/client adapters, final Node write wrappers,
private EventStore wrapper, SQLite fixture, legacy API owner guard,
provenance key-bijection and persisted float32 digest, readback/causal Oracle,
A/B/B2/C/D/E/F executable scenario functions and evidence collector.

`CASFaultDriver.commitAtBarrier` supplies a concrete CAS-begin/pre-commit pause,
final synchronous commit attempt, precommit-loss and postcommit ACK-loss injection.
`f1WithBarrier` supplies delayed commit, failed and both UNKNOWN durable branches.
These functions are source only in this handoff; they were never invoked.

`UnboundOSAdapter` deliberately throws for unresolved device/permission work.
`group-drivers.mjs` explicitly requires an enrolled real experiment context.
No fabricated endpoint or simulated OS success fills it. `launcher.mjs` can
describe an existing binding; execution always rejects. `stop.mjs` also rejects
without an enrolled stop unit. Removing those holds is not authorized here.

## Component traceability

| Component | Source / function |
| --- | --- |
| Coordinator / Authority | src/authority.mjs / Authority |
| Writer Worker | src/actors/writer.mjs / buildCandidate, mutateCandidate |
| Private Publisher | src/actors/publisher.mjs / privateImport |
| Seal Actor | src/actors/seal.mjs / sealPair |
| Reader | src/actors/reader.mjs / readPinnedPair |
| GC Actor | src/actors/gc.mjs / collectRetired |
| Transport GateOwner | src/gate-owner.mjs / GateOwner |
| MCP Server / Client | src/adapters/mcp.mjs / privateMcpServer, privateMcpClient |
| Fault Controller | src/fault-controller.mjs / FaultController |
| Native I/O Observer | src/native-observer.mjs / NativeIOObserver |
| Evidence Collector | src/evidence-collector.mjs / EvidenceCollector |
| Launcher / stop | src/launcher.mjs, src/stop.mjs |

## Fifteen groups: concrete source and remaining binding work

`R3_TRACEABILITY.json` preserves every original branch and Oracle. Every group
has a concrete dispatch function and real source; integration completion is
not implied by dispatch coverage.

| Group | Existing logic | Remaining concrete adapter/action |
| --- | --- | --- |
| S01 | Publisher/Seal requirements and OS adapter boundary | A01/A03; safe path copy and exhaustive mutation matrix including FD/IPC/backing mounts |
| S02 | Worker, signal allowlist, Native enter/delivery correlation | A04/A06; real pidfd and native TID/FD observer integration |
| S03 | Independent candidate and pinned old/fresh read interfaces | Real RO pairs, native prune variant, handle-close proof |
| S04 | SQLite pin/intent serialization and GC actor | Enrolled deletion allowlist, actual races/partial-crash context |
| S05 | Fenced commit, SQLite fixture, six-phase owner guard, A/B/B2/C/F | Actual fixed-HEAD schema/API integration, native pair and WAL/ACK/crash context |
| S06 | Source/observed bijection, vector digest and independent provider receipt join | Source enumerator, P1-P7 mutators, full/incremental native readback and provider binding |
| T01 | Private SDK transport and stdout final gate | Real SDK stdio private pipe and OS final FD enrollment |
| T02 | write(false) accepted semantics and bounded barrier | Paused OS pipe/drain/cancel/close driver |
| T03 | Private response buffering and Node header/body entry wrappers | Real SDK Web Response route and linked multiwrite admission |
| T04 | Private frame and event boundary contracts | Per-frame continuation/partial-abort SSE driver |
| T05 | Private event storage/replay filtering | Durable ledger, genuine successful cursor replay and restart driver |
| T06 | v2 handler adapter boundary and final Node wrapper | Verify actual createMcpHandler options, _meta handshake and node@2.0.0 adapter |
| T07 | Read-only fixed-HEAD Bridge source and private v2 boundary | Actual Bridge executable adapter and external v2 integration |
| T08 | Stable pending RequestKey, two attempts, claim-once | Real pinned queries/fresh retry and independently authorized Grep-only |
| T09 | Same-owner C0/CAS/final write and A-F functions | Durable same-owner context plus real stdout AND HTTP v2 driver |

The SQLite fixture is explicitly independent; matching phase strings is not
proof of using the actual six-phase journal schema. Fixed-HEAD sources are
preserved for the real adapter. Original group evaluation enumerates concrete
mandatory witness requirements for each of the 15 groups and stays INCONCLUSIVE
until the corresponding raw semantic validators and branch coverage are bound.
This limitation cannot award PASS
merely because files exist. Negative controls require distinct unsafe contexts;
they are not silently dispatched through safe logic or counted as implemented.

## RG-305-R5-R3-001 A-F

| Case | Fault function | Implemented injection sequence / Oracle |
| --- | --- | --- |
| A | caseA | Actual commit/readback before C0, then old queued P during F1 hold; legitimate receipt preserved |
| B | caseB | C0 before attempted CAS; activation projection unchanged |
| B2 | caseB2 | Begin CAS, wait pre-commit decision barrier, C0, release commit barrier, deny stale activation |
| C | caseC | ACK loss after commit and precommit loss as distinct durable outcomes; Semantic held until five-way readback |
| D | caseD | Pending/Failed/Unknown committed/Unknown not committed/ACK, SDK/private queue/IPC old P, stale CAS |
| E | caseE | S42 pin/query, HOLD, S43 CAS/readback, old reader completion and P deny, S44/deadline/C0/post-claim branches |
| F | caseF | Seven phase states (six normal plus failed) crossed with 13 legal-prefix selectors; require reachability proof for skipped cells |

These are actual callable scenario functions, but their OS/DB/SDK context remains
unbound and they were not called. Case F enumerates 91 proposed cells; no cell is
asserted reachable, skipped or PASS in this preparation. The reachability driver
must prove each cell and retain per-cell evidence. `evaluateCase` checks required
witness coverage, raw artifact/causal provenance and explicit counterexamples;
`forbiddenTransitions` checks causal post-C0 commits and duplicate terminal claims.
Independent semantic witness validation is still required before any PASS.

## Binding advancement

All original 190 + 44 IDs are preserved. Each now has real source paths/hashes,
dispatch function, launcher argv, describe argv, stop source, limits, evidence
templates, exact original Oracle and individually enumerated blockers. All 234
source references are fixed; all 234 experiment entries are still BLOCKED.
There are zero runnable protected experiment commands. Source-only binding is
not represented as approved UID/FD/socket enrollment. Unexpanded historical case
IDs are preserved as identifiers while actual case functions name subbranches.

## Verification boundary

Static checks only: Node syntax, TypeScript AST import/export consistency, schema
validation through existing Ajv, Test ID/Oracle/source/argv coverage, pinned
lock metadata, baseline fixture hashes, forbidden-operation scan, original ZIP
retention and package member readback. TDD runtime execution was not performed
because the user permits static validation only. No Native/Transport dynamic
result, crash evidence, signal proof or Section 4.1 approval is generated.
