# R3 Journal and recovery driver report

## Actual baseline rather than phase-name imitation

The original independent `SQLiteAuthorityStore` is retained and explicitly
identified as a fixture. `FixedJournalStore` instead shares the actual
`SqliteMetadataStore` better-sqlite3 connection. The baseline's TypeScript
`private db` is a normal emitted property, not an ECMAScript private field.
Using it is deliberate fixed-HEAD test instrumentation, not a supported public API.

`createFixedJournalDriver` constructs the real metadata store with
`deferFullRebuildRecovery: true` before `initialize`. Preparation uses real
`prepareFullRebuild` and `setStructuredRebuildState`; observation uses real
`getFullRebuildRecovery`. Actual tables are `index_stats`,
`structured_rebuild_backup_runs`, `structured_rebuild_backup_files`,
`structured_rebuild_backup_tombstones` and `structured_rebuild_backup_vectors`.
Additive authority/receipt/revocation/pin/terminal tables are harness extensions,
not mislabeled existing Nexus capabilities.

The seven observed states include the six normal phases and `failed`. The real
recovery getter intentionally omits `idle`/`failed`; raw consistent SQL readback
retains them rather than misclassifying a null getter result as proof of idle.

## CAS, B2 and readback

Active pointer/revision, unique success receipt, retired parent and both actual
journal phase fields move in one synchronous SQLite transaction. Shadow phase
updates do not invoke native legacy swaps. Duplicate receipts remain idempotent.

For B2, `CASFaultDriver` begins an actual `BEGIN IMMEDIATE` transaction before
waiting at `ACTIVE_CAS_BEGIN_BEFORE_COMMIT_DECISION`. No activation writes are
performed before that wait. Identity recognition establishes C0 synchronously
while the transaction is held. The final owner-local predicate is checked before
activation/COMMIT; a C0 winner rejects and rolls back the pending transaction.
F1 waits outside the synchronous gate until the pending transaction resolves.
No observer callback is invoked between activation writes and SQLite COMMIT.

Precommit loss and postcommit ACK loss are distinct source branches. Unknown
outcomes hold semantic publication until a consistent pointer/revision/journal/
receipt/revocation readback. Actual journal consistency is an additional driver
check; the original A-F/B2 Oracles are unchanged.

## Recovery guard and limitations

`guardedLegacyCall` reads owner/version and rejects new-owner calls before invoking
actual `reconcileOnStartup`, rollback, recover, finalize or legacy activation.
Owner-absent and mismatched mode are blocked. New-owner recovery selects quarantine
before CAS and finalize-only after CAS. No old swap/rollback is used to implement
the new-owner projection.

Startup is closed by default. `bindBoot` requires an independently verified durable
boot receipt and matching stored incarnation. A pre-crash epoch is quarantined;
successful readback never clears local closure or reopens a permanently revoked
generation. F1 UNKNOWN is reconciled by nonce, not blind replay.

The raw product metadata/pipeline APIs still exist in frozen source. Full launcher
capability isolation and startup dispatcher coverage are not proven by a wrapper;
they remain explicit review/runtime requirements. Crash-cell reachability, native
swap interception, WAL/fsync observations and all A/B/B2/C/F contexts are not run.
There is no observed impossibility of synchronization; there is also no dynamic
proof of it. Execution remains **NOT_AUTHORIZED / NOT_EXECUTED**.
