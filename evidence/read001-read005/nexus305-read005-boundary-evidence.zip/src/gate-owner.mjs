import { digest } from './evidence-collector.mjs';
import { canonical } from './provenance.mjs';
import { PreclaimAdmissionDenied, projectStoredFrameAuth } from './publication-admission.mjs';
import { StoredEventDenied } from './stored-event-binding.mjs';

// Owner-local opaque capabilities. These objects are never sent over worker IPC.
// No await, event callback or durable IO is placed between final check and write.
export class GateOwner {
  #claims = new WeakMap(); #sinks = new WeakMap(); #channels = new WeakMap(); #permits = new WeakMap();
  #events; #replay = null;
  constructor(authority, store, emit, events = null) { this.authority = authority; this.store = store; this.emit = emit; this.#events = events; }
  prepareTerminal(envelope) {
    // A reconnect/stale envelope must not turn an existing claim into a retry.
    if (this.store.hasTerminalClaim(envelope.requestKey)) return null;
    // Same synchronous owner turn as claim. No stale result consumes the key.
    if (!this.authority.allows(envelope)) throw new PreclaimAdmissionDenied();
    const durable = this.store.claimTerminal(envelope.requestKey, envelope.bytesDigest, envelope);
    if (!durable) return null;
    const claim = Object.freeze({ requestKey: envelope.requestKey, bytesDigest: envelope.bytesDigest });
    this.#claims.set(claim, { envelope: Object.freeze({ ...envelope }), state: 'CLAIMED' });
    this.emit('TERMINAL_CLAIM', { requestKey: envelope.requestKey, bytesDigest: envelope.bytesDigest,
      epoch: envelope.epoch, generation: envelope.generation, physicalPairId: envelope.pairId,
      publicationRevision: envelope.publicationRevision, attemptId: envelope.attemptId,
      retrievalPairVerified: envelope.retrievalPairVerified });
    return claim;
  }
  publish(envelope, claim, writeSync) {
    // Arbitrary legacy callbacks carry no independently enrolled FD capability.
    throw new Error('VENUE_CAPABILITY_UNENROLLED:LEGACY_DIRECT_WRITER');
  }
  enrollFinalSink(writeSync, ownershipToken) {
    if (!this.finalBoundary?.owns(ownershipToken)) throw new Error('VENUE_CAPABILITY_UNENROLLED:FINAL_SINK');
    if (typeof writeSync !== 'function' || writeSync.constructor.name === 'AsyncFunction') throw new Error('SYNCHRONOUS_OWNER_SINK_REQUIRED');
    const sink = Object.freeze({}); this.#sinks.set(sink, writeSync); return sink;
  }
  bindReplayAuthority(authorizer) {
    if (this.#replay || !authorizer) throw new StoredEventDenied('REPLAY_OWNER_ALREADY_BOUND');
    this.#replay = authorizer;
  }
  openReplayPublication(sink, ticket, frames) {
    if (!this.#sinks.has(sink) || !this.#replay) throw new StoredEventDenied('REPLAY_OWNER_UNBOUND');
    const context = this.#replay.context(ticket);
    const lifecycle = this.#replay.ledger.read('lifecycle', context.renderer_instance_id);
    if (lifecycle.state !== 'RENDERER_DISCARDED' || !lifecycle.RENDERER_CLOSE_OK || !lifecycle.PRIVATE_BODY_DONE ||
      !lifecycle.SDK_REPLAY_CALLBACK_SETTLED || !lifecycle.PRIVATE_FRAME_SET_COMPLETE) throw new StoredEventDenied('RENDERER_COMPLETION_UNPROVEN');
    this.#replay.verify(context, 'PUBLICATION_ADMISSION');
    this.#replay.assertFrames(context, frames);
    const plan = [{ kind: 'header', status: 200, bytes: Buffer.alloc(0), headers: Object.freeze({
      'content-type': 'text/event-stream', 'cache-control': 'no-cache, no-transform', 'mcp-session-id': context.sessionId
    }) }, ...frames.map(frame => ({ ...frame, bytes: Buffer.from(frame.bytes) })), { kind: 'end', bytes: Buffer.alloc(0) }];
    const channel = Object.freeze({});
    // Replay never calls prepareTerminal or releasePublicationPlan.
    this.#channels.set(channel, { sink, envelope: context.envelope, replay: context, plan,
      next: 0, pending: null, state: 'CLAIMED', accepted: 0, storedEvents: false });
    return channel;
  }
  openPublication(sink, envelope, steps) {
    if (!this.#sinks.has(sink) || !steps.length) throw new Error('OWNER_SINK_REQUIRED');
    const kinds = steps.map(step => step.kind);
    const stdout = kinds.length === 1 && kinds[0] === 'stdout';
    const http = kinds[0] === 'header' && kinds.at(-1) === 'end' && kinds.slice(1, -1).every(kind => ['body', 'sse-frame', 'continuation'].includes(kind));
    if (!stdout && !http) throw new Error('INVALID_PUBLICATION_SEQUENCE');
    // Snapshot and copy bytes privately. Caller mutation cannot change a permit.
    const plan = steps.map(step => ({ kind: step.kind, bytes: Buffer.from(step.bytes ?? []),
      status: step.status ?? null, headers: Object.freeze({ ...(step.headers ?? {}) }), eventId: step.eventId ?? null,
      auth: step.auth ? projectStoredFrameAuth(step.auth) : null, eventTicket: step.eventTicket ?? null }));
    if (envelope.publicationMode === 'REPLAY') throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
    // Preserve R1's proven-no-claim cutover outcome before event eligibility.
    if (this.store.hasTerminalClaim(envelope.requestKey)) return null;
    if (!this.authority.allows(envelope)) throw new PreclaimAdmissionDenied();
    const storedEvents = plan.some(step => step.kind === 'sse-frame' || step.auth || step.eventId || step.eventTicket);
    const sseResponse = Object.entries(plan[0].headers).some(([name, value]) => name.toLowerCase() === 'content-type' && String(value).trim().toLowerCase().startsWith('text/event-stream'));
    if (sseResponse && plan.slice(1, -1).some(step => step.kind !== 'sse-frame')) throw new StoredEventDenied('SSE_FRAME_BINDING_REQUIRED');
    if (storedEvents) {
      if (!this.#events) throw new StoredEventDenied('STORED_EVENT_LEDGER_UNBOUND');
      if (plan.some(step => step.kind !== 'sse-frame' && (step.auth || step.eventId || step.eventTicket))) throw new StoredEventDenied('SSE_FRAME_BINDING_REQUIRED');
      this.#events.assertPublicationPlan(plan, envelope, this.authority);
    }
    for (const step of plan) if (step.auth) {
      for (const field of ['epoch', 'generation', 'pairId', 'publicationRevision']) {
        if (step.auth[field] !== envelope[field]) throw new Error('STORED_FRAME_AUTH_MISMATCH_NO_RELABEL');
      }
    }
    const projection = plan.map(step => ({ ...step, bytes: undefined, bytesDigest: digest(step.bytes) }));
    // undefined is not canonical JSON; omit the private byte buffer explicitly.
    const planDigest = digest(Buffer.from(canonical(projection.map(({ bytes, ...row }) => row))));
    const bound = Object.freeze({ ...envelope, bytesDigest: planDigest });
    if (storedEvents) this.#events.releasePublicationPlan(plan, envelope, this.authority);
    const claim = this.prepareTerminal(bound);
    if (!claim) return null;
    const channel = Object.freeze({});
    this.#claims.get(claim).state = 'CHANNEL';
    this.#channels.set(channel, { sink, claim, envelope: bound, plan, storedEvents, next: 0, pending: null, state: 'CLAIMED', accepted: 0 });
    return channel;
  }
  openInitializePublication(sink, envelope, steps, sessionId, attemptNonce, authTicket) {
    if (!this.#sinks.has(sink) || !this.#replay) throw new StoredEventDenied('INIT_OWNER_UNBOUND');
    const initialization = Object.freeze({ envelope, sessionId, attemptNonce, authTicket });
    const session = this.#replay.verifyInitialization(initialization);
    const result = steps.filter(step => step.kind === 'sse-frame' && step.bytes.toString().startsWith('event: message\n'));
    if (steps[0]?.kind !== 'header' || steps.at(-1)?.kind !== 'end' || result.length !== 1 ||
      digest(result[0].bytes) !== session.init_result_digest) throw new StoredEventDenied('INIT_FRAME_BINDING_REQUIRED');
    const plan = steps.map(step => ({ ...step, bytes: Buffer.from(step.bytes ?? []), headers: Object.freeze({ ...(step.headers ?? {}) }) }));
    const bound = Object.freeze({ ...envelope, bytesDigest: digest(Buffer.concat(plan.map(step => step.bytes))) });
    const claim = this.prepareTerminal(bound);
    if (!claim) throw new StoredEventDenied('INIT_ALREADY_CLAIMED_NO_RETRY');
    const channel = Object.freeze({});
    this.#claims.get(claim).state = 'CHANNEL';
    this.#channels.set(channel, { sink, envelope: bound, initialization, plan, next: 0,
      pending: null, state: 'CLAIMED', accepted: 0, storedEvents: false });
    return channel;
  }
  nextPermit(channel) {
    const state = this.#channels.get(channel);
    if (!state || !['CLAIMED', 'PARTIAL'].includes(state.state) || state.pending || state.next >= state.plan.length) return null;
    const permit = Object.freeze({});
    this.#permits.set(permit, { channel, index: state.next, used: false }); state.pending = permit;
    return permit;
  }
  publishPermit(permit) {
    const item = this.#permits.get(permit);
    if (!item || item.used) return { accepted: false, reason: 'PERMIT_CONSUMED', state: item ? this.#channels.get(item.channel).state : 'CLAIMED_NO_PUBLICATION' };
    item.used = true;
    const state = this.#channels.get(item.channel);
    if (state.pending !== permit || item.index !== state.next || !['CLAIMED', 'PARTIAL'].includes(state.state)) return { accepted: false, reason: 'PUBLICATION_CLOSED', state: state.state };
    state.pending = null;
    const step = state.plan[item.index];
    if (state.initialization) {
      try { this.#replay.verifyInitialization(state.initialization); }
      catch (error) {
        state.state = state.accepted ? 'UNKNOWN_DELIVERY' : 'CLAIMED_NO_PUBLICATION';
        return { accepted: false, reason: error.message, state: state.state };
      }
    }
    if (state.replay) {
      try { this.#replay.verify(state.replay, 'FINAL_P'); }
      catch (error) {
        state.state = state.accepted ? 'UNKNOWN_DELIVERY' : 'CLAIMED_NO_PUBLICATION';
        return { accepted: false, reason: error.message, state: state.state };
      }
    }
    // Recheck provenance/current authorization even after RELEASED or header P.
    // These reads precede #admit; the final Authority check/write stays IO-free.
    if (state.storedEvents) {
      try { this.#events.assertPublicationPlan(state.plan, state.envelope, this.authority); }
      catch (error) {
        if (!(error instanceof StoredEventDenied)) throw error;
        state.state = state.accepted ? 'UNKNOWN_DELIVERY' : 'CLAIMED_NO_PUBLICATION';
        this.emit('P_WRITE_DENY', { requestKey: state.envelope.requestKey, reason: error.code });
        return { accepted: false, reason: error.code, state: state.state };
      }
    }
    // Matching stored identity is checked before claim, never merged into the
    // request-owned retrieval verdict. Keep projected provenance for evidence.
    const envelope = { ...state.envelope, storedFrameAuth: step.auth, bytesDigest: digest(step.bytes), publicationKind: step.kind, permitSequence: item.index, eventId: step.eventId };
    const sink = this.#sinks.get(state.sink);
    const result = this.#admit(envelope, () => sink(step));
    if (state.replay) {
      const event = step.kind === 'sse-frame' ? state.replay.events[item.index - 1] : null;
      try { this.#replay.ledger.decision(state.replay, item.index, event,
        result.accepted === true ? 'P_ACCEPTED_NOT_ACKED' : result.accepted === null ? 'UNKNOWN_DELIVERY' : 'NO_P'); }
      catch (error) {
        state.state = 'UNKNOWN_DELIVERY';
        return { accepted: null, reason: 'P_RECEIPT_DURABILITY_UNKNOWN_NO_RETRY', state: state.state };
      }
    }
    if (result.accepted === true) {
      state.accepted++; state.next++;
      state.state = state.next === state.plan.length ? 'ENDED' : 'PARTIAL';
    } else state.state = state.accepted ? 'UNKNOWN_DELIVERY' : 'CLAIMED_NO_PUBLICATION';
    return { ...result, state: state.state };
  }
  abortPublication(channel, reason) {
    const state = this.#channels.get(channel);
    if (!state || state.state === 'ENDED') return;
    state.state = state.accepted ? 'UNKNOWN_DELIVERY' : 'CLAIMED_NO_PUBLICATION';
    this.emit('PUBLICATION_ABORT_NO_RETRY', { requestKey: state.envelope.requestKey, reason, acceptedSteps: state.accepted, state: state.state });
  }
  #admit(envelope, writeSync) {
    if (!this.authority.allows(envelope)) {
      this.emit('P_WRITE_DENY', { ...envelope, physicalPairId: envelope.pairId, bytes: undefined });
      return { accepted: false, reason: 'AUTHORITY_DENIED_NO_RETRY' };
    }
    try {
      const returned = writeSync();
      if (returned && typeof returned.then === 'function') throw new Error('ASYNC_FINAL_WRITE_FORBIDDEN');
      this.emit('P_WRITE_ACCEPT', { ...envelope, physicalPairId: envelope.pairId, bytes: undefined, returned: returned === false ? false : true });
      return { accepted: true, backpressure: returned === false };
    } catch (error) {
      this.emit('P_WRITE_UNKNOWN', { requestKey: envelope.requestKey, code: error instanceof Error ? error.message : 'WRITE_FAILED' });
      return { accepted: null, reason: 'UNKNOWN_DELIVERY_NO_RETRY' };
    }
  }
}
