export function coherentReadback(view) {
  if (!view || view.protocolVersion !== 'snapshot-cas-v2' || view.authorityOwner !== 'compatibility-coordinator' || !view.bootUnclean) return false;
  const committed = ['merkle-activated', 'idle'].includes(view.phase);
  if (!committed) return view.phase !== 'failed' && view.pairId === view.parentSnapshotId && !view.receipt;
  return Boolean(view.receipt && view.receipt.pairId === view.pairId && view.receipt.publicationRevision === view.publicationRevision &&
    view.receipt.transactionId === view.activationTransactionId && view.journalTransactionId === view.activationTransactionId &&
    view.retiredParent === view.parentSnapshotId && view.sealVerified && view.coverageVerified && view.provenanceVerified);
}
export function unchangedActivation(before, after) {
  const fields = ['pairId', 'publicationRevision', 'phase', 'receipt'];
  return fields.every(field => JSON.stringify(before[field]) === JSON.stringify(after[field]));
}
export function causalPrecedes(events, earlier, later) {
  const byId = new Map(events.map(event => [event.eventId, event]));
  if (byId.size !== events.length || !byId.has(earlier) || !byId.has(later)) return false;
  const pending = [...byId.get(later).causalParents]; const seen = new Set();
  while (pending.length) {
    const id = pending.pop();
    if (id === earlier) return true;
    if (seen.has(id)) continue;
    seen.add(id);
    const event = byId.get(id);
    if (!event) return false;
    pending.push(...event.causalParents);
  }
  return false;
}
export function forbiddenTransitions(events) {
  const counterexamples = [];
  for (const close of events.filter(event => event.event === 'C0_GATE_SYNC')) {
    for (const event of events) {
      if (event.epoch !== close.epoch || !causalPrecedes(events, close.eventId, event.eventId)) continue;
      if (['ACTIVE_CAS_COMMIT', 'P_WRITE_ACCEPT'].includes(event.event)) counterexamples.push({ reason: 'OLD_COMMIT_AFTER_C0', close: close.eventId, forbidden: event.eventId });
    }
  }
  const claims = new Map();
  for (const event of events.filter(event => event.event === 'TERMINAL_CLAIM')) {
    const count = (claims.get(event.requestKey) ?? 0) + 1; claims.set(event.requestKey, count);
    if (count > 1) counterexamples.push({ reason: 'DUPLICATE_TERMINAL', eventId: event.eventId });
  }
  return counterexamples;
}
