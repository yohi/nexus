import { digest } from './evidence-collector.mjs';
export function canonical(value) {
  if (typeof value === 'string') {
    for (const character of value) {
      const code = character.codePointAt(0);
      if (code >= 0xD800 && code <= 0xDFFF) throw new Error('UNPAIRED_SURROGATE');
    }
    return JSON.stringify(value);
  }
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'number' && Number.isFinite(value)) return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) return `{${Object.keys(value).sort().map(key => `${canonical(key)}:${canonical(value[key])}`).join(',')}}`;
  throw new Error('NON_CANONICAL_INPUT');
}
const key = row => canonical([row.tableKind, row.sourceKey, row.sourceVersion, row.chunkOrdinal, row.chunkId]);
export const vectorDigest = values => {
  const bytes = Buffer.alloc(values.length * 4);
  values.forEach((value, index) => { if (!Number.isFinite(value)) throw new Error('NON_FINITE_VECTOR'); bytes.writeFloatLE(value, index * 4); });
  return digest(bytes);
};
export function root(domain, rows) {
  return digest(Buffer.from(`${domain}\0${canonical([...rows].sort((a, b) => key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0))}`));
}
export function validateBijection(expected, observed, sourceReceipt, providerReceipts = []) {
  if (!sourceReceipt.independentlyEnumerated || !sourceReceipt.frozenBeforeEmbedding || !sourceReceipt.noWatchGap) return { valid: false, reason: 'COVERAGE_INVALID' };
  const byKey = new Map();
  for (const row of observed) {
    if (byKey.has(key(row))) return { valid: false, reason: 'DUPLICATE_OBSERVED' };
    byKey.set(key(row), row);
  }
  const seen = new Set();
  for (const row of expected) {
    const id = key(row);
    if (seen.has(id)) return { valid: false, reason: 'DUPLICATE_EXPECTED' };
    seen.add(id);
    const stored = byKey.get(id);
    if (row.expectedStatus === 'SKIP') {
      if (!row.skipRule || !row.skipEvidence || stored) return { valid: false, reason: 'INVALID_SKIP' };
      continue;
    }
    if (!stored || !stored.nativeReadback || !stored.providerBindingVerified || !stored.providerReceiptId || stored.vectorDigest !== vectorDigest(stored.vector)) return { valid: false, reason: 'PROVENANCE_INVALID' };
    for (const field of ['preparedInputDigest', 'role', 'taskType', 'canonicalizationVersion', 'effectiveInputIdentity', 'spaceFingerprint', 'dimension']) {
      if (stored[field] !== row[field]) return { valid: false, reason: `MISMATCH:${field}` };
    }
    const receipt = providerReceipts.find(receipt => receipt.id === stored.providerReceiptId && receipt.chunkKey === id);
    if (!receipt || !receipt.independentlyVerified || receipt.preparedInputDigest !== row.preparedInputDigest || receipt.spaceFingerprint !== row.spaceFingerprint || receipt.vectorDigest !== stored.vectorDigest) return { valid: false, reason: 'PROVIDER_RECEIPT_MISBOUND' };
    byKey.delete(id);
  }
  if (byKey.size) return { valid: false, reason: 'EXTRA_OBSERVED' };
  return { valid: true, expectedRoot: root('r3-expected-v1', expected), observedRoot: root('r3-observed-v1', observed), completenessRoot: digest(Buffer.from(canonical({ keys: [...seen].sort(), missing: [], extra: [] }))) };
}
