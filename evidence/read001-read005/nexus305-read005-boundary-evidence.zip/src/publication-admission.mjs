// A denial of this type proves that terminal INSERT/COMMIT was not attempted.
// Unknown database outcomes must never be converted to this retryable denial.
export class PreclaimAdmissionDenied extends Error {
  constructor() {
    super('TERMINAL_PRECLAIM_AUTHORITY_DENIED');
    this.name = 'PreclaimAdmissionDenied';
  }
}

// Stored provenance cannot supply request verification or write capabilities.
export function projectStoredFrameAuth(auth) {
  return Object.freeze({ epoch: auth.epoch, generation: auth.generation,
    pairId: auth.pairId, publicationRevision: auth.publicationRevision });
}
