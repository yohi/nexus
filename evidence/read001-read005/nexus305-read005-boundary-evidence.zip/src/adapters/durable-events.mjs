import { randomUUID } from 'node:crypto';
import { canonical } from '../provenance.mjs';
import { digest } from '../evidence-collector.mjs';
import { PreclaimAdmissionDenied, projectStoredFrameAuth } from '../publication-admission.mjs';
import { StoredEventDenied, requireEventEnvelope, eventIdentityDigest, assertDurableEvent, assertStoredFrame, assertNewEventAuthorization } from '../stored-event-binding.mjs';

// Fresh, additive experiment schema. R1 r3_events rows lack Session/provenance
// evidence and are quarantined; they are never silently migrated into this table.
export class DurableEventLedger {
  #tickets = new WeakMap();
  #ownerAdmission = null;
  constructor(store, envelopeFor, emit) {
    if (typeof envelopeFor !== 'function' || typeof emit !== 'function') throw new StoredEventDenied('EVENT_CONTEXT_UNBOUND');
    this.store = store; this.envelopeFor = envelopeFor; this.emit = emit;
    store.db.exec(`CREATE TABLE IF NOT EXISTS r3_bound_events_v2 (
      sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL,
      stream TEXT NOT NULL, session TEXT NOT NULL, original_request TEXT NOT NULL,
      transport_instance TEXT NOT NULL, connection_incarnation TEXT NOT NULL,
      message TEXT NOT NULL, message_wire TEXT NOT NULL, auth TEXT NOT NULL,
      payload_digest TEXT NOT NULL, identity_digest TEXT NOT NULL,
      state TEXT NOT NULL CHECK(state IN ('PRIVATE','RELEASED','REVOKED')),
      terminal INTEGER NOT NULL CHECK(terminal IN (0,1)));`);
  }
  reserve(streamId, message, auth) {
    requireEventEnvelope(auth);
    this.#ownerAdmission?.store(auth, message, streamId);
    if (message === null || typeof message !== 'object' || Array.isArray(message)) throw new StoredEventDenied('EVENT_MESSAGE_INVALID');
    // Snapshot the owner context and SDK wire message before any store await.
    const messageWire = JSON.stringify(message);
    const authText = canonical(auth); const savedAuth = JSON.parse(authText);
    requireEventEnvelope(savedAuth);
    if (streamId !== savedAuth.streamId) throw new StoredEventDenied('EVENT_STREAM_MISMATCH');
    const savedMessage = JSON.parse(messageWire); const messageText = canonical(savedMessage);
    const id = randomUUID(); const terminal = ('result' in savedMessage || 'error' in savedMessage) ? 1 : 0;
    this.store.transaction(() => {
      const inserted = this.store.db.prepare(`INSERT INTO r3_bound_events_v2
        (id,stream,session,original_request,transport_instance,connection_incarnation,message,message_wire,auth,payload_digest,identity_digest,state,terminal)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,'PRIVATE',?) RETURNING sequence`)
        .get(id, streamId, savedAuth.sessionId, savedAuth.requestKey, savedAuth.transportInstance, savedAuth.connectionIncarnation,
          messageText, messageWire, authText, digest(Buffer.from(messageWire)), '', terminal);
      const row = { id, sequence: inserted.sequence, stream: streamId, session: savedAuth.sessionId, original_request: savedAuth.requestKey,
        transport_instance: savedAuth.transportInstance, connection_incarnation: savedAuth.connectionIncarnation,
        auth: savedAuth, terminal, payload_digest: digest(Buffer.from(messageWire)) };
      this.store.db.prepare('UPDATE r3_bound_events_v2 SET identity_digest=? WHERE id=?').run(eventIdentityDigest(row), id);
    });
    return id;
  }
  lookup(id) {
    const stored = this.store.db.prepare('SELECT * FROM r3_bound_events_v2 WHERE id=?').get(id);
    if (!stored) throw new StoredEventDenied('EVENT_UNKNOWN');
    try {
      const row = { ...stored, auth: JSON.parse(stored.auth), message: JSON.parse(stored.message) };
      assertDurableEvent(row); return row;
    } catch (error) {
      if (error instanceof SyntaxError) throw new StoredEventDenied('EVENT_PROVENANCE_MISMATCH');
      throw error;
    }
  }
  storeEventState(id, authority) {
    return this.store.transaction(() => {
      const row = this.lookup(id);
      if (row.state === 'REVOKED') return;
      if (!authority.allows(row.auth)) this.store.db.prepare("UPDATE r3_bound_events_v2 SET state='REVOKED' WHERE id=?").run(id);
    });
  }
  bindFrame(step, authority, publication) {
    const row = this.lookup(step.eventId);
    assertStoredFrame(row, step);
    assertNewEventAuthorization(row, authority, publication);
    const eventTicket = Object.freeze({});
    this.#tickets.set(eventTicket, { id: row.id, sequence: row.sequence, identityDigest: row.identity_digest,
      bytesDigest: digest(step.bytes), bytes: Buffer.from(step.bytes), envelope: Object.freeze({ ...publication.envelope }) });
    return { eventTicket, auth: projectStoredFrameAuth(row.auth) };
  }
  assertPublicationPlan(plan, envelope, authority) {
    let previousSequence = 0;
    for (const step of plan) {
      if (step.kind !== 'sse-frame') continue;
      const bound = this.#tickets.get(step.eventTicket);
      if (!bound || bound.id !== step.eventId || bound.bytesDigest !== digest(step.bytes)) throw new StoredEventDenied('EVENT_PUBLICATION_TICKET_REQUIRED');
      for (const field of ['requestKey', 'sessionId', 'streamId', 'transportInstance', 'connectionIncarnation', 'epoch', 'generation', 'pairId', 'publicationRevision']) {
        if (bound.envelope[field] !== envelope[field]) throw new StoredEventDenied('EVENT_CURRENT_ENVELOPE_MISMATCH');
      }
      const row = this.lookup(bound.id);
      if (bound.identityDigest !== row.identity_digest || bound.sequence !== row.sequence || row.sequence <= previousSequence) throw new StoredEventDenied('EVENT_SEQUENCE_PROVENANCE_MISMATCH');
      assertStoredFrame(row, step);
      assertNewEventAuthorization(row, authority, { mode: 'NEW', envelope });
      previousSequence = row.sequence;
    }
  }
  releasePublicationPlan(plan, envelope, authority) {
    this.#ownerAdmission?.release(plan, envelope);
    this.store.transaction(() => {
      if (this.store.hasTerminalClaim(envelope.requestKey)) throw new StoredEventDenied('TERMINAL_ALREADY_CLAIMED');
      // Validate ALL frames first: a later foreign frame causes zero release.
      this.assertPublicationPlan(plan, envelope, authority);
      const view = this.store.readView();
      if (['epoch', 'generation', 'pairId', 'publicationRevision'].some(field => view[field] !== envelope[field]) ||
          this.store.db.prepare('SELECT epoch FROM revocations WHERE epoch=? OR generation=?').get(envelope.epoch, envelope.generation)) throw new PreclaimAdmissionDenied();
      for (const step of plan) if (step.kind === 'sse-frame') {
        this.store.db.prepare("UPDATE r3_bound_events_v2 SET state='RELEASED' WHERE id=? AND state!='REVOKED'").run(step.eventId);
      }
    });
    // Observation is after COMMIT and before GateOwner's next Authority check.
    // It is not a substitute for independently validated SQLite readback.
    for (const step of plan) if (step.kind === 'sse-frame') this.emit('EVENT_RELEASE_COMMIT', {
      eventId: step.eventId, requestKey: envelope.requestKey, attemptId: envelope.attemptId,
      sessionId: envelope.sessionId, streamId: envelope.streamId,
      epoch: envelope.epoch, generation: envelope.generation, physicalPairId: envelope.pairId,
      publicationRevision: envelope.publicationRevision });
  }
  release(id, authority, publication) {
    if (publication?.mode === 'REPLAY') throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
    if (publication?.mode !== 'NEW') throw new StoredEventDenied('EVENT_PUBLICATION_MODE_UNBOUND');
    const bound = this.#tickets.get(publication?.eventTicket);
    if (!bound || bound.id !== id) throw new StoredEventDenied('EVENT_PUBLICATION_TICKET_REQUIRED');
    if (this.store.hasTerminalClaim(publication.envelope.requestKey)) throw new StoredEventDenied('TERMINAL_ALREADY_CLAIMED');
    this.releasePublicationPlan([{ kind: 'sse-frame', eventId: id, eventTicket: publication.eventTicket, bytes: bound.bytes }], publication.envelope, authority);
    return true;
  }
  afterGenuineCursor(id, publication) {
    const envelope = publication?.envelope; requireEventEnvelope(envelope);
    if (publication.mode !== 'REPLAY') throw new StoredEventDenied('EVENT_PUBLICATION_MODE_UNBOUND');
    const cursor = this.lookup(id);
    if (cursor.stream !== envelope.streamId || cursor.session !== envelope.sessionId) throw new StoredEventDenied('REPLAY_CURSOR_SCOPE_MISMATCH');
    const rows = this.store.db.prepare('SELECT id FROM r3_bound_events_v2 WHERE stream=? AND sequence>? ORDER BY sequence').all(cursor.stream, cursor.sequence);
    for (const reference of rows) {
      const row = this.lookup(reference.id);
      if (row.sequence <= cursor.sequence || row.stream !== cursor.stream || row.session !== cursor.session) throw new StoredEventDenied('REPLAY_EVENT_SEQUENCE_MISMATCH');
    }
    // Genuine cursor/sequence establishes identity, NOT entitlement. No grant
    // issuer/verifier is defined: no event or stream is returned to this caller.
    throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
  }
  revokeClosed(authority) {
    return this.store.transaction(() => {
      for (const reference of this.store.db.prepare("SELECT id FROM r3_bound_events_v2 WHERE state!='REVOKED'").all()) {
        if (!authority.allows(this.lookup(reference.id).auth)) this.store.db.prepare("UPDATE r3_bound_events_v2 SET state='REVOKED' WHERE id=?").run(reference.id);
      }
    });
  }
  bindOwnerAdmission(admission) {
    if (this.#ownerAdmission || typeof admission?.store !== 'function' || typeof admission?.release !== 'function') throw new StoredEventDenied('EVENT_OWNER_BINDING_REQUIRED');
    this.#ownerAdmission = admission;
  }
}
export class DurableSDKEventStore {
  #ledger; #authority; #faults;
  constructor(ledger, authority, faults) { this.#ledger = ledger; this.#authority = authority; this.#faults = faults; }
  async storeEvent(streamId, message) {
    // This must resolve an enrolled owner context, never message self-claims.
    const auth = this.#ledger.envelopeFor(message, streamId);
    const id = this.#ledger.reserve(streamId, message, auth);
    await this.#faults.pause('STORE_EVENT_BEFORE_COMMIT', id);
    this.#ledger.storeEventState(id, this.#authority); return id;
  }
  async getStreamIdForEventId() {
    // SDK provides only an ID here, not an authenticated reconnect context.
    throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
  }
  async replayEventsAfter() {
    // No send callback can run without an approved entitlement contract.
    throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
  }
}
