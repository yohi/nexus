import { EventEmitter } from 'node:events';
import { bufferPrivateResponse } from './final-write.mjs';
import { PreclaimAdmissionDenied } from '../publication-admission.mjs';
import { StoredEventDenied } from '../stored-event-binding.mjs';

// SDK/node@2.0.0 sees this private structural response, never ServerResponse.
export class PrivateNodeResponse extends EventEmitter {
  #steps = []; #size = 0; #limit; #ended = false;
  destroyed = false;
  constructor(limit = 16777216) { super(); this.#limit = limit; }
  writeHead(status, headers = {}) {
    if (this.destroyed || this.#steps.length) throw new Error('PRIVATE_HEADERS_ALREADY_SET');
    this.#steps.push({ kind: 'header', status, headers: { ...headers } }); return this;
  }
  write(chunk) {
    if (this.destroyed || this.#ended || !this.#steps.length) throw new Error('PRIVATE_RESPONSE_CLOSED');
    const bytes = Buffer.from(chunk); this.#size += bytes.length;
    if (this.#size > this.#limit) throw new Error('PRIVATE_BUFFER_LIMIT');
    this.#steps.push({ kind: 'body', bytes }); return true;
  }
  end(chunk) {
    if (chunk !== undefined) this.write(chunk);
    if (this.destroyed || this.#ended) throw new Error('PRIVATE_RESPONSE_CLOSED');
    this.#steps.push({ kind: 'end' }); this.#ended = true; this.emit('finish'); return this;
  }
  cancel() { this.destroyed = true; this.emit('close'); }
  takePlan() {
    if (!this.#ended || this.destroyed) throw new Error('PRIVATE_RESPONSE_INCOMPLETE');
    return this.#steps.map(step => ({ ...step, ...(step.bytes ? { bytes: Buffer.from(step.bytes) } : {}) }));
  }
}

export function frameSSE(bytes, maximumFrameBytes = 16777216) {
  // Work on bytes, not per-chunk TextDecoder output; retain UTF-8 split bytes.
  const frames = []; let offset = 0;
  for (let index = 0; index < bytes.length - 1; index++) {
    let end = 0;
    if (bytes[index] === 10 && bytes[index + 1] === 10) end = index + 2;
    if (index + 3 < bytes.length && bytes[index] === 13 && bytes[index + 1] === 10 && bytes[index + 2] === 13 && bytes[index + 3] === 10) end = index + 4;
    if (!end) continue;
    const frame = Buffer.from(bytes.subarray(offset, end));
    if (frame.length > maximumFrameBytes) throw new Error('SSE_FRAME_LIMIT');
    const eventId = frame.toString('utf8').split(/\r?\n/).find(line => line.startsWith('id:'))?.slice(3).trim() ?? null;
    frames.push({ kind: 'sse-frame', bytes: frame, eventId }); offset = end; index = end - 1;
  }
  if (offset !== bytes.length) throw new Error('PARTIAL_PRIVATE_SSE_FRAME');
  return frames;
}

export async function privateWebPlan(response, signal) {
  signal.throwIfAborted();
  const bytes = await bufferPrivateResponse(response, 16777216, { signal });
  signal.throwIfAborted();
  const headers = Object.fromEntries(response.headers);
  const sse = (headers['content-type'] ?? '').startsWith('text/event-stream');
  // Whole JSON is complete before claim; do not forward SDK compression/length
  // metadata for a changed buffer. SSE is finite here; live streams stay blocked.
  delete headers['transfer-encoding'];
  if (!sse) headers['content-length'] = String(bytes.length);
  return [{ kind: 'header', status: response.status, headers }, ...(sse ? frameSSE(bytes) : [{ kind: 'body', bytes }]), { kind: 'end' }];
}

export function normalizeCapturedPlan(plan) {
  const header = plan[0];
  const bytes = Buffer.concat(plan.filter(step => step.kind === 'body').map(step => step.bytes));
  if ((header.headers['content-type'] ?? '').startsWith('text/event-stream')) return [header, ...frameSSE(bytes), { kind: 'end' }];
  return [{ ...header, headers: { ...header.headers, 'content-length': String(bytes.length) } }, { kind: 'body', bytes }, { kind: 'end' }];
}

export function bindStoredFrames(plan, ledger, authority, publication) {
  if (publication?.mode === 'REPLAY') throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
  if (publication?.mode !== 'NEW') throw new StoredEventDenied('EVENT_PUBLICATION_MODE_UNBOUND');
  if (!ledger) throw new StoredEventDenied('STORED_EVENT_LEDGER_UNBOUND');
  return plan.map(step => {
    if (step.kind !== 'sse-frame') return step;
    if (!step.eventId) throw new StoredEventDenied('SSE_FRAME_BINDING_REQUIRED');
    // Binding performs no release or claim. GateOwner validates the entire
    // private plan before the first state transition or external header write.
    return { ...step, ...ledger.bindFrame(step, authority, publication) };
  });
}

// The response and stdout are captured only by owner-local closures. Returning
// an opaque sink does not transfer the external write capability to the SDK.
export function enrollHTTPFinal(gate, response) {
  if (!gate.finalBoundary) throw new Error('VENUE_CAPABILITY_UNENROLLED:FINAL_WRITER');
  return gate.finalBoundary.enroll(response, gate, step => {
    switch (step.kind) {
      case 'header': response.writeHead(step.status, step.headers); return true;
      case 'body': case 'sse-frame': case 'continuation': return response.write(step.bytes);
      case 'end': response.end(step.bytes.length ? step.bytes : undefined); return true;
      default: throw new Error('HTTP_WRITE_KIND_REQUIRED');
    }
  });
}
export function enrollStdoutFinal(gate, writable) {
  if (!gate.finalBoundary) throw new Error('VENUE_CAPABILITY_UNENROLLED:FINAL_WRITER');
  return gate.finalBoundary.enroll(writable, gate, step => {
    if (step.kind !== 'stdout') throw new Error('STDOUT_WRITE_KIND_REQUIRED');
    return writable.write(step.bytes);
  });
}
export async function publishPlan({ gate, sink, envelope, plan, finalStream, barrier, signal, timeoutMs = 10000 }) {
  let channel;
  try {
    channel = gate.openPublication(sink, envelope, plan);
  } catch (error) {
    if (error instanceof PreclaimAdmissionDenied) return { accepted: false, reason: error.message, claimCommitted: false };
    throw error;
  }
  if (!channel) return { accepted: false, reason: 'TERMINAL_ALREADY_CLAIMED', claimCommitted: true };
  try {
    for (let index = 0; index < plan.length; index++) {
      signal.throwIfAborted();
      // Barrier is outside admission. C0 may win after header and before body.
      if (barrier) await barrier(plan[index].kind, index);
      signal.throwIfAborted();
      const result = gate.publishPermit(gate.nextPermit(channel));
      if (result.accepted !== true) {
        gate.abortPublication(channel, result.reason); finalStream.destroy(); return { ...result, claimCommitted: true };
      }
      if (result.backpressure) await drainOrClose(finalStream, signal, timeoutMs);
    }
    return { accepted: true, delivery: 'ENQUEUED_NOT_PEER_ACKED', claimCommitted: true };
  } catch (error) {
    gate.abortPublication(channel, error instanceof Error ? error.message : 'PUBLICATION_ABORT');
    finalStream.destroy(); throw error;
  }
}
export function drainOrClose(stream, signal, timeoutMs) {
  // Waiting never holds the authority gate. false already means accepted P.
  return new Promise((resolve, reject) => {
    const cleanup = () => { clearTimeout(timer); stream.off('drain', drained); stream.off('close', closed); stream.off('error', failed); signal.removeEventListener('abort', aborted); };
    const drained = () => { cleanup(); resolve(); };
    const failed = error => { cleanup(); reject(error); };
    const closed = () => failed(new Error('TRANSPORT_CLOSED_UNKNOWN_DELIVERY'));
    const aborted = () => failed(new Error('PUBLICATION_ABORTED_UNKNOWN_DELIVERY'));
    const timer = setTimeout(() => failed(new Error('DRAIN_TIMEOUT_UNKNOWN_DELIVERY')), timeoutMs);
    stream.once('drain', drained); stream.once('close', closed); stream.once('error', failed); signal.addEventListener('abort', aborted, { once: true });
    if (signal.aborted) aborted(); else if (stream.destroyed) closed(); else if (!stream.writableNeedDrain) drained();
  });
}
