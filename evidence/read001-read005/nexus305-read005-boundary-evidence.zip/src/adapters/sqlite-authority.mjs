import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { PreclaimAdmissionDenied } from '../publication-admission.mjs';
// Independent fixture only. The fixed-HEAD journal-schema/API adapter remains
// required for S05/F; this schema must never substitute for that evidence.
export class SQLiteAuthorityStore {
  constructor(path, database = null) {
    this.db = database ?? new DatabaseSync(path);
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
      CREATE TABLE IF NOT EXISTS authority(id INTEGER PRIMARY KEY CHECK(id=1), view TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS receipts(operation TEXT PRIMARY KEY, receipt TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS terminals(request_key TEXT PRIMARY KEY, digest TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS revocations(epoch INTEGER PRIMARY KEY, nonce TEXT UNIQUE NOT NULL, generation TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS pins(pair TEXT, token TEXT PRIMARY KEY);
      CREATE TABLE IF NOT EXISTS delete_intents(pair TEXT PRIMARY KEY, state TEXT NOT NULL);`);
  }
  transaction(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn();
      if (result && typeof result.then === 'function') throw new Error('ASYNC_SQL_TRANSACTION_FORBIDDEN');
      this.db.exec('COMMIT'); return result;
    }
    catch (error) { if (this.db.isTransaction || this.db.inTransaction) this.db.exec('ROLLBACK'); throw error; }
  }
  initialize(view) {
    return this.transaction(() => this.db.prepare('INSERT INTO authority VALUES(1,?)').run(JSON.stringify({ ...view, bootUnclean: true })));
  }
  readView() { return JSON.parse(this.db.prepare('SELECT view FROM authority WHERE id=1').get().view); }
  writeView(view) { this.db.prepare('UPDATE authority SET view=? WHERE id=1').run(JSON.stringify(view)); }
  consistentReadback() {
    return this.transaction(() => ({ ...this.readView(),
      revocations: this.db.prepare('SELECT * FROM revocations ORDER BY epoch').all(),
      terminals: this.db.prepare('SELECT * FROM terminals ORDER BY request_key').all(),
      pins: this.db.prepare('SELECT * FROM pins ORDER BY token').all(),
      deleteIntents: this.db.prepare('SELECT * FROM delete_intents ORDER BY pair').all(), ...this.readJournalProjection() }));
  }
  readJournalProjection() { return {}; }
  commitJournalProjection() {}
  activate(candidate) {
    return this.transaction(() => this.activateInTransaction(candidate));
  }
  activateInTransaction(candidate) {
      const view = this.readView();
      const duplicate = this.db.prepare('SELECT receipt FROM receipts WHERE operation=?').get(candidate.operationId);
      if (duplicate) return JSON.parse(duplicate.receipt);
      if (this.db.prepare('SELECT epoch FROM revocations WHERE epoch=? OR generation=?').get(candidate.epoch, candidate.generation)) throw new Error('REVOKED');
      if (view.pairId !== candidate.parentSnapshotId || view.publicationRevision !== candidate.basePublicationRevision || view.authorityRevision !== candidate.authorityRevision || view.slotRevision !== candidate.slotRevision) throw new Error('STALE_AUTHORITY');
      if (!candidate.sealed || !candidate.verified || !candidate.durable || !candidate.coverageVerified || !candidate.provenanceVerified || view.phase !== 'catalog-activated' || view.protocolVersion !== 'snapshot-cas-v2' || view.authorityOwner !== 'compatibility-coordinator') throw new Error('ACTIVATION_DENIED');
      const receipt = { operationId: candidate.operationId, pairId: candidate.pairId, publicationRevision: view.publicationRevision + 1, transactionId: candidate.transactionId };
      this.writeView({ ...view, epoch: candidate.epoch, pairId: candidate.pairId, generation: candidate.generation, publicationRevision: receipt.publicationRevision, phase: 'merkle-activated', receipt, retiredParent: view.pairId, activationTransactionId: candidate.transactionId, journalTransactionId: candidate.transactionId, sealVerified: candidate.sealed, coverageVerified: candidate.coverageVerified, provenanceVerified: candidate.provenanceVerified });
      this.db.prepare('INSERT INTO receipts VALUES(?,?)').run(candidate.operationId, JSON.stringify(receipt));
      this.commitJournalProjection(candidate, receipt);
      return receipt;
  }
  hasTerminalClaim(requestKey) {
    return Boolean(this.db.prepare('SELECT request_key FROM terminals WHERE request_key=?').get(requestKey));
  }
  claimTerminal(requestKey, bytesDigest, envelope) {
    return this.transaction(() => {
      // Uniqueness wins over preclaim denial even with another DB connection.
      if (this.hasTerminalClaim(requestKey)) return null;
      // BEGIN IMMEDIATE serializes this decision with compatible CAS and F1.
      // This read and terminal INSERT share a transaction, not cached authority.
      const view = this.readView();
      if (view.epoch !== envelope.epoch || view.pairId !== envelope.pairId ||
          view.generation !== envelope.generation || view.publicationRevision !== envelope.publicationRevision ||
          envelope.retrievalPairVerified !== true ||
          this.db.prepare('SELECT epoch FROM revocations WHERE epoch=? OR generation=?').get(envelope.epoch, envelope.generation)) {
        throw new PreclaimAdmissionDenied();
      }
      const inserted = this.db.prepare('INSERT OR IGNORE INTO terminals VALUES(?,?)').run(requestKey, bytesDigest);
      return inserted.changes === 1 ? { requestKey, bytesDigest, used: false } : null;
    });
  }
  fence(epoch, nonce, generation) {
    if (typeof generation !== 'string') throw new Error('REVOCATION_GENERATION_REQUIRED');
    return this.transaction(() => {
      const prior = this.db.prepare('SELECT * FROM revocations WHERE epoch=? OR nonce=?').get(epoch, nonce);
      if (prior && (prior.epoch !== epoch || prior.nonce !== nonce || prior.generation !== generation)) throw new Error('REVOCATION_NONCE_CONFLICT');
      return this.db.prepare('INSERT OR IGNORE INTO revocations VALUES(?,?,?)').run(epoch, nonce, generation);
    });
  }
  acquirePin(pairId, token = randomUUID()) {
    return this.transaction(() => {
      const view = this.readView();
      if (view.pairId !== pairId || !view.bootUnclean || this.db.prepare('SELECT epoch FROM revocations WHERE epoch=?').get(view.epoch) || this.db.prepare('SELECT pair FROM delete_intents WHERE pair=?').get(pairId)) return null;
      this.db.prepare('INSERT INTO pins VALUES(?,?)').run(pairId, token);
      return { pairId, token };
    });
  }
  releasePin(pin, proof) {
    if (!proof.rawArtifactRef || proof.noOpenReaderFDs !== true || proof.noMappings !== true) throw new Error('READER_CLOSE_PROOF_REQUIRED');
    return this.transaction(() => this.db.prepare('DELETE FROM pins WHERE pair=? AND token=?').run(pin.pairId, pin.token));
  }
  startDeleteIntent(pairId) {
    return this.transaction(() => {
      const view = this.readView();
      if (view.retiredParent !== pairId || view.pairId === pairId || view.preparedPairId === pairId || this.db.prepare('SELECT token FROM pins WHERE pair=?').get(pairId)) return null;
      this.db.prepare("INSERT OR IGNORE INTO delete_intents VALUES(?,'PENDING')").run(pairId);
      return { pairId, status: 'PENDING' };
    });
  }
  completeDeleteIntent(intent) { this.db.prepare("UPDATE delete_intents SET state='DELETED' WHERE pair=?").run(intent.pairId); }
}
