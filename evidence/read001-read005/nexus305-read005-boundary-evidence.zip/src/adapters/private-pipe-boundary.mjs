import { requireValue } from '../replay/common.mjs';

// Neither enrollmentRef nor a supplied stream proves OS-private topology.
export function inspectPrivatePipes(registry, pipes) {
  requireValue(registry && pipes?.input && pipes?.output, 'VENUE_BINDING_REQUIRED:PRIVATE_OS_PIPE');
  const proof = registry.sync('privatePipes', 'inspectPrivatePipesSync', { pipes });
  requireValue(proof?.rawArtifactRef && proof.independentObserverRef && proof.bootId === registry.boot &&
    proof.input === pipes.input && proof.output === pipes.output && proof.topologyArtifactRef && proof.fdArtifactRef &&
    proof.privateOnly === true && proof.externalFinalFDReachable === false && proof.exclusive === true &&
    Number.isSafeInteger(proof.inputFd) && proof.inputFd > 2 &&
    Number.isSafeInteger(proof.outputFd) && proof.outputFd > 2 && proof.expiresAt > registry.now(),
  'PRIVATE_PIPE_TOPOLOGY_UNPROVEN');
  return Object.freeze({ input: pipes.input, output: pipes.output });
}
