export class UnboundOSAdapter {
  blocked(operation) { throw new Error(`BLOCKED_OS_BINDING:${operation}`); }
  enumerateNoFollow() { return this.blocked('openat2_inventory'); }
  hashTree() { return this.blocked('complete_metadata_hash_tree'); }
  copyBytesExclusiveNoFollow() { return this.blocked('safe_physical_copy'); }
  fsyncFilesAndDirectories() { return this.blocked('disk_fsync'); }
  withdrawPublisherFDs() { return this.blocked('publisher_fd_withdrawal'); }
  transferToSealOwnerAndPublish() { return this.blocked('seal_uid_mount_transfer'); }
  fsyncPublishedParent() { return this.blocked('published_parent_fsync'); }
  inspectAllMutationRoutes() { return this.blocked('fd_ipc_backing_mount_inspection'); }
  deleteEnrolledPairNoFollow() { return this.blocked('gc_device_inode_nonce'); }
  deliverPidfdSignal() { return this.blocked('pidfd_signal'); }
}
