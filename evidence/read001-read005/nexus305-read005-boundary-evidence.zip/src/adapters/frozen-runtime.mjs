import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { pinnedRequire } from './dependency-loader.mjs';

export async function loadFrozenRuntime(enrollment) {
  if (!enrollment?.runtimeRoot || !enrollment.dependencyPackageURL || !enrollment.lockURL) throw new Error('VENUE_BINDING_REQUIRED:FROZEN_RUNTIME');
  // No loading during preparation. Verify each static fixture before future
  // imports. Runtime package resolution must be enrolled, never ambient latest.
  const evidence = JSON.parse(readFileSync(new URL('R3_API_SIGNATURE_EVIDENCE.json', enrollment.packageRoot), 'utf8'));
  for (const source of evidence.fixed.filter(row => row.runtimePath)) {
    const bytes = readFileSync(new URL(source.runtimePath, enrollment.packageRoot));
    if (createHash('sha256').update(bytes).digest('hex') !== source.runtimeSha256) throw new Error('FROZEN_RUNTIME_HASH_MISMATCH');
  }
  const require = pinnedRequire(enrollment.dependencyPackageURL, enrollment.lockURL);
  const runtimeRequire = createRequire(new URL('package.json', enrollment.runtimeRoot));
  for (const name of ['better-sqlite3', 'zod', '@modelcontextprotocol/sdk/client/index.js']) {
    if (runtimeRequire.resolve(name) !== require.resolve(name)) throw new Error('RUNTIME_DEPENDENCY_TREE_NOT_ENROLLED');
  }
  const metadata = await import(new URL('src/storage/metadata-store.js', enrollment.runtimeRoot));
  const bridge = await import(new URL('src/server/http-v2/v1-runtime-bridge.js', enrollment.runtimeRoot));
  return { SqliteMetadataStore: metadata.SqliteMetadataStore, createV1RuntimeToolBridge: bridge.createV1RuntimeToolBridge };
}
