import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
export function pinnedRequire(packageJSONURL, lockURL) {
  const hash = createHash('sha256').update(readFileSync(lockURL)).digest('hex');
  if (hash !== '19be4560ec6e0dcb9404d24cce40a03bf0a9f6efebcb18b336bdc77fa78b30f7') throw new Error('LOCKFILE_NOT_R2');
  const require = createRequire(packageJSONURL);
  const expected = { '@lancedb/lancedb': '0.18.2', '@modelcontextprotocol/sdk': '1.29.0', '@modelcontextprotocol/server': '2.0.0', '@modelcontextprotocol/node': '2.0.0' };
  const lock = JSON.parse(readFileSync(lockURL, 'utf8'));
  for (const [name, version] of Object.entries(expected)) {
    if (lock.packages[`node_modules/${name}`]?.version !== version) throw new Error(`PIN_MISMATCH:${name}`);
  }
  // Native/module load is intentionally absent here. Approved executor must
  // record resolved file/native binary hashes and actual exports before using
  // this resolver; lockfile presence is not a native-load proof.
  return require;
}
