export class VenueBindingRequired extends Error {
  constructor(operation) { super(`VENUE_CAPABILITY_UNENROLLED:${operation}`); this.code = 'VENUE_CAPABILITY_UNENROLLED'; }
}
// An interface, not a launcher or an administrator grant. No synthetic OS IDs.
export class VenueBoundary {
  #binding;
  constructor(binding = null) { this.#binding = binding; }
  async call(operation, input) {
    if (!this.#binding?.registry) throw new VenueBindingRequired(operation);
    const capability = ['verifyActor', 'proveFinalWriteOwnership'].includes(operation) ? 'finalWriter' : 'native';
    if (operation === 'proveFinalWriteOwnership') return this.#binding.finalBoundary.prove(input);
    const result = await this.#binding.registry.call(capability, operation, input);
    if (!result?.rawArtifactRef) throw new VenueBindingRequired(`${operation}:RAW_RECEIPT`);
    return result;
  }
  verifyActor(input) { return this.call('verifyActor', input); }
  inspectPairTopology(input) { return this.call('inspectPairTopology', input); }
  observeHandleClosure(input) { return this.call('observeHandleClosure', input); }
  correlateNativeOperation(input) { return this.call('correlateNativeOperation', input); }
  proveFinalWriteOwnership(input) { return this.call('proveFinalWriteOwnership', input); }
}
