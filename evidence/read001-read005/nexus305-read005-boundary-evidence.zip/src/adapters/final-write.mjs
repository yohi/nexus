import { digest } from '../evidence-collector.mjs';
export function prepareBytes(envelope, bytes) {
  return { ...envelope, bytes: Buffer.from(bytes), bytesDigest: digest(bytes) };
}
export function stdoutFinal(gate, permit, ...obsoleteArguments) {
  if (obsoleteArguments.length) throw new Error('PUBLICATION_PERMIT_REQUIRED');
  return gate.publishPermit(permit);
}
export function httpBodyFinal(gate, permit) {
  return gate.publishPermit(permit);
}
export function httpHeadersFinal(gate, permit) {
  return gate.publishPermit(permit);
}
export function httpEndFinal(gate, permit) { return gate.publishPermit(permit); }
// Buffering is private, bounded and cancellable; it is never P.
export async function bufferPrivateResponse(response, maximumBytes = 16777216, { signal, timeoutMs = 30000 } = {}) {
  const chunks = []; let size = 0;
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  let timer; let aborted;
  const stopped = new Promise((resolve, reject) => {
    aborted = () => reject(new Error('PRIVATE_RESPONSE_ABORTED'));
    timer = setTimeout(() => reject(new Error('PRIVATE_RESPONSE_TIMEOUT')), timeoutMs);
    signal?.addEventListener('abort', aborted, { once: true });
    if (signal?.aborted) aborted();
  });
  try {
    while (true) {
      const { value, done } = await Promise.race([reader.read(), stopped]);
      if (done) break;
      size += value.byteLength;
      if (size > maximumBytes) throw new Error('PRIVATE_BUFFER_LIMIT');
      chunks.push(Buffer.from(value));
    }
    return Buffer.concat(chunks);
  } catch (error) {
    // Cancellation does not delay C0 or authorize any final write.
    void reader.cancel().catch(() => undefined);
    throw error;
  } finally {
    clearTimeout(timer); signal?.removeEventListener('abort', aborted); reader.releaseLock();
  }
}
