import { SQLiteAuthorityStore } from './sqlite-authority.mjs';
import { coordinatorRecovery } from './legacy-recovery.mjs';
export const actualPhases = Object.freeze(['building', 'legacy-swapped', 'structured-swapped', 'catalog-activated', 'merkle-activated', 'idle', 'failed']);

// Uses the actual fixed-HEAD metadata db and actual journal tables. r3 fixture
// authority/receipts are additive experiment tables, not preexisting Nexus APIs.
export class FixedJournalStore extends SQLiteAuthorityStore {
  constructor(metadata, emit) {
    // TS `private db` is an ordinary runtime property at this exact baseline.
    // This deliberate test instrumentation is not a public product contract.
    if (!metadata.db?.prepare || !metadata.db?.transaction) throw new Error('FIXED_HEAD_DB_ACCESS_REQUIRED');
    super(null, metadata.db);
    this.metadata = metadata; this.emit = emit;
    this.pendingCAS = null; this.pendingWaiters = [];
  }
  beginPendingCAS(candidate) {
    if (this.pendingCAS || this.db.inTransaction) throw new Error('AUTHORITY_QUEUE_BUSY');
    this.db.exec('BEGIN IMMEDIATE');
    this.pendingCAS = candidate.operationId;
    // Actual transaction is open before the B2 barrier, with no activation
    // writes yet. C0 remains a synchronous owner-local operation, not DB I/O.
  }
  abortPendingCAS() {
    if (!this.pendingCAS) return;
    if (this.db.inTransaction) this.db.exec('ROLLBACK');
    this.pendingCAS = null;
    for (const resolve of this.pendingWaiters.splice(0)) resolve();
  }
  waitForPendingCAS() {
    return this.pendingCAS ? new Promise(resolve => this.pendingWaiters.push(resolve)) : Promise.resolve();
  }
  activate(candidate) {
    if (!this.pendingCAS) return super.activate(candidate);
    if (this.pendingCAS !== candidate.operationId) throw new Error('AUTHORITY_QUEUE_BUSY');
    try {
      const receipt = this.activateInTransaction(candidate);
      this.db.exec('COMMIT');
      this.pendingCAS = null;
      for (const resolve of this.pendingWaiters.splice(0)) resolve();
      return receipt;
    } catch (error) { this.abortPendingCAS(); throw error; }
  }
  readJournalProjection() {
    const stats = this.db.prepare('SELECT structured_rebuild_epoch AS rebuildEpoch, structured_rebuild_state AS phase FROM index_stats WHERE id=?').get('primary');
    const journal = this.db.prepare('SELECT rebuild_epoch AS rebuildEpoch, phase, merkle_snapshot AS merkleSnapshot FROM structured_rebuild_backup_runs WHERE rebuild_epoch=?').get(stats.rebuildEpoch);
    return { actualJournal: { stats, journal: journal ?? null } };
  }
  commitJournalProjection(candidate, receipt) {
    const { actualJournal } = this.readJournalProjection();
    if (actualJournal.stats.rebuildEpoch !== candidate.rebuildEpoch || actualJournal.stats.phase !== 'catalog-activated' || actualJournal.journal?.phase !== 'catalog-activated') throw new Error('ACTUAL_JOURNAL_PHASE_MISMATCH');
    this.db.prepare('UPDATE structured_rebuild_backup_runs SET phase=? WHERE rebuild_epoch=?').run('merkle-activated', candidate.rebuildEpoch);
    this.db.prepare('UPDATE index_stats SET structured_rebuild_state=?, structured_last_error_code=NULL WHERE id=?').run('merkle-activated', 'primary');
    // Same synchronous connection and transaction as Active CAS and receipt.
    // No asynchronous setStructuredRebuildState() is called inside the commit.
    // No observer callback is invoked before COMMIT: it could reenter C0.
  }
  async prepareActualJournal(input, merkleSnapshot) {
    await this.metadata.prepareFullRebuild(input, merkleSnapshot);
    await this.metadata.setStructuredRebuildState({ rebuildState: 'building' });
    this.transaction(() => this.writeView({ ...this.readView(), phase: 'building', rebuildEpoch: input.rebuildEpoch }));
  }
  advanceShadowPhase(phase) {
    if (!['legacy-swapped', 'structured-swapped', 'catalog-activated', 'failed'].includes(phase)) throw new Error('PHASE_REQUIRES_CAS_OR_RECOVERY');
    return this.transaction(() => {
      const view = this.readView();
      const order = actualPhases.slice(0, 4);
      if (phase !== 'failed' && order.indexOf(phase) !== order.indexOf(view.phase) + 1) throw new Error('ILLEGAL_SHADOW_PHASE');
      this.db.prepare('UPDATE structured_rebuild_backup_runs SET phase=? WHERE rebuild_epoch=?').run(phase, view.rebuildEpoch);
      this.db.prepare('UPDATE index_stats SET structured_rebuild_state=? WHERE id=?').run(phase, 'primary');
      this.writeView({ ...view, phase });
    });
  }
  guardedLegacyCall(target, name, args = []) {
    const view = this.consistentReadback();
    this.emit('LEGACY_RECOVERY_ATTEMPT', { name, protocolVersion: view.protocolVersion, authorityOwner: view.authorityOwner });
    if (view.protocolVersion !== 'legacy-journal-v1' || view.authorityOwner !== 'legacy') {
      this.emit('LEGACY_RECOVERY_DENIED_BEFORE_CALL', { name });
      throw new Error('MIGRATION_BLOCKED');
    }
    if (!['reconcileOnStartup', 'rollbackFullRebuild', 'recoverInterruptedFullRebuild', 'finalizeInterruptedFullRebuild', 'activateFullRebuild'].includes(name)) throw new Error('LEGACY_API_NOT_ALLOWED');
    return target[name](...args);
  }
  recoveryReadback() {
    const view = this.consistentReadback();
    const stats = view.actualJournal.stats;
    const journal = view.actualJournal.journal;
    const actualCoherent = stats.phase === view.phase && stats.rebuildEpoch === view.rebuildEpoch && (journal?.phase === view.phase || (view.phase === 'idle' && journal === null));
    return { ...view, coherent: actualCoherent, recoveryAction: actualCoherent ? coordinatorRecovery({ ...view, coherent: true }) : 'CLOSED' };
  }
  verifyReadback(view) {
    const { stats, journal } = view.actualJournal;
    return stats.phase === view.phase && stats.rebuildEpoch === view.rebuildEpoch && (journal?.phase === view.phase || (view.phase === 'idle' && journal === null));
  }
  finalizeProjection() {
    return this.transaction(() => {
      const view = this.readView();
      if (view.phase !== 'merkle-activated' || !view.receipt) throw new Error('FINALIZE_ONLY_AFTER_CAS');
      this.db.prepare('UPDATE structured_rebuild_backup_runs SET phase=? WHERE rebuild_epoch=?').run('idle', view.rebuildEpoch);
      this.db.prepare('UPDATE index_stats SET structured_rebuild_state=? WHERE id=?').run('idle', 'primary');
      this.writeView({ ...view, phase: 'idle' });
    });
  }
}

export async function createFixedJournalDriver({ SqliteMetadataStore, databasePath, emit }) {
  // Suppress the product's eager legacy recovery before opening a new-owner DB.
  const metadata = new SqliteMetadataStore({ databasePath, deferFullRebuildRecovery: true });
  await metadata.initialize();
  const store = new FixedJournalStore(metadata, emit);
  return { store, metadata, actualRecovery: () => metadata.getFullRebuildRecovery(),
    recoverLegacy: (target, name, args) => store.guardedLegacyCall(target, name, args),
    fenceSink: async (epoch, nonce, generation) => { await store.waitForPendingCAS(); store.fence(epoch, nonce, generation); return 'ACK'; } };
}
