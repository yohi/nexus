export const phases = ['building', 'legacy-swapped', 'structured-swapped', 'catalog-activated', 'merkle-activated', 'idle'];
export function guardedLegacyCall(journal, apiName, actualLegacyAPI, args) {
  if (journal.protocolVersion !== 'legacy-journal-v1' || journal.authorityOwner !== 'legacy') throw new Error('MIGRATION_BLOCKED');
  if (!['reconcileOnStartup', 'rollbackFullRebuild', 'recoverInterruptedFullRebuild', 'finalizeInterruptedFullRebuild'].includes(apiName)) throw new Error('RECOVERY_API_NOT_ALLOWED');
  return actualLegacyAPI[apiName](...args);
}
export function coordinatorRecovery(view) {
  if (view.protocolVersion !== 'snapshot-cas-v2' || view.authorityOwner !== 'compatibility-coordinator' || !view.bootUnclean) return 'CLOSED';
  if (['merkle-activated', 'idle'].includes(view.phase)) return view.coherent && view.receipt ? 'FINALIZE_ONLY' : 'CLOSED';
  return 'QUARANTINE_NO_ACTIVATION';
}
