// Real callable commit barrier over the synchronous authority/store interface.
// OS/WAL observer and fixed-HEAD schema binding still required for R3 evidence.
export class CASFaultDriver {
  constructor(authority, faults, emit) { this.authority = authority; this.faults = faults; this.emit = emit; }
  async commitAtBarrier(candidate, { loseAck = false, abortBeforeCommit = false } = {}) {
    this.authority.beginCAS(candidate);
    this.authority.store.beginPendingCAS?.(candidate);
    try { await this.faults.pause('ACTIVE_CAS_BEGIN_BEFORE_COMMIT_DECISION', candidate.operationId); }
    catch (error) { this.authority.store.abortPendingCAS?.(); throw error; }
    this.emit('ACTIVE_CAS_COMMIT_ATTEMPT', { operationId: candidate.operationId, epoch: candidate.epoch });
    if (abortBeforeCommit) {
      this.authority.store.abortPendingCAS?.();
      this.authority.unknown = true;
      this.authority.hold = true;
      this.emit('ACTIVE_CAS_UNKNOWN', { operationId: candidate.operationId, injected: 'PRECOMMIT_LOSS' });
      return { committed: null };
    }
    const result = this.authority.commitCAS(candidate);
    if (result.committed !== true) this.authority.store.abortPendingCAS?.();
    if (loseAck && result.committed === true) {
      this.authority.unknown = true;
      this.authority.hold = true;
      this.emit('ACTIVE_CAS_UNKNOWN', { operationId: candidate.operationId, injected: 'POSTCOMMIT_ACK_LOSS' });
      return { committed: null };
    }
    return result;
  }
  releaseCommitBarrier(operationId) {
    this.faults.release('ACTIVE_CAS_BEGIN_BEFORE_COMMIT_DECISION', operationId);
  }
  async f1WithBarrier(epoch, nonce, durableSink, requestedOutcome) {
    return this.authority.fence(epoch, nonce, async () => {
      await this.faults.pause('F1_BEFORE_DURABLE_COMMIT', nonce);
      if (requestedOutcome === 'FAILED') throw new Error('INJECTED_F1_FAILURE');
      if (requestedOutcome === 'UNKNOWN_NOT_COMMITTED') return 'UNKNOWN';
      await durableSink(epoch, nonce);
      return requestedOutcome === 'UNKNOWN_COMMITTED' ? 'UNKNOWN' : 'ACK';
    });
  }
}
