import { DurableSDKEventStore } from './durable-events.mjs';

// One implementation for store completion and replay denial. The older adapter
// must not retain a separate cursor-only send loop or terminal replay bypass.
export class PrivateEventStore extends DurableSDKEventStore {}
