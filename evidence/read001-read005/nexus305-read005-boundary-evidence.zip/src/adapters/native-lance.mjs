import { randomUUID } from 'node:crypto';
import { vectorDigest, validateBijection } from '../provenance.mjs';
import { VenueBindingRequired } from './venue-boundary.mjs';

// The injected module must be the enrolled @lancedb/lancedb@0.18.2 module.
// Module loading and all methods below are future authorized work only.
export class NativeLanceDriver {
  #lance; #venue; #store; #emit; #handles = new Map();
  constructor({ lance, venue, store, emit }) {
    this.#lance = lance; this.#venue = venue; this.#store = store; this.#emit = emit;
  }
  async #open(pair, role, rows) {
    const topology = await this.#venue.inspectPairTopology({ pair, role });
    if (!topology?.rawArtifactRef || topology.sharedWriteInodes !== false || topology.role !== role) throw new VenueBindingRequired('independent_pair_topology');
    const actor = await this.#venue.verifyActor({ role, pairId: pair.pairId });
    if (!actor?.rawArtifactRef || !actor.processIdentity || !actor.mountIdentity) throw new VenueBindingRequired('principal_fd_mount');
    const connections = []; const tables = {};
    const token = randomUUID();
    // Register partial opens too: failed opens cannot silently release a pin.
    const handle = { token, pairId: pair.pairId, role, connections, tables, actor, state: 'OPENING', pending: 0 };
    this.#handles.set(token, handle);
    try {
      for (const kind of ['legacy', 'structured']) {
        const connection = await this.#lance.connect(pair.roots[kind], { readConsistencyInterval: 0 });
        connections.push(connection);
        tables[kind] = rows
          ? await connection.createTable(kind, rows[kind], { mode: 'create' })
          : await connection.openTable(kind);
      }
      handle.state = 'OPEN';
      this.#emit('NATIVE_HANDLES_OPEN', { token, physicalPairId: pair.pairId, role, artifactRefs: [topology.rawArtifactRef, actor.rawArtifactRef] });
      return handle;
    } catch (error) {
      handle.state = 'OPEN_FAILED_PIN_RETAINED';
      this.#emit('NATIVE_OPEN_FAILED', { token, physicalPairId: pair.pairId });
      throw error;
    }
  }
  createCandidate(pair, rows) { return this.#open(pair, 'writer', rows); }
  async openPublished(pair) {
    const pin = this.#store.acquirePin(pair.pairId);
    if (!pin) throw new Error('PIN_DENIED');
    // Failed open leaves the durable pin in place; no lease-only deletion.
    const handle = await this.#open(pair, 'reader');
    handle.pin = pin;
    return handle;
  }
  async #operation(handle, name, perform) {
    if (this.#handles.get(handle.token) !== handle || handle.state !== 'OPEN') throw new Error('HANDLE_NOT_OPEN');
    const operationId = randomUUID();
    handle.pending++;
    this.#emit('API_ENTER', { operationId, token: handle.token, physicalPairId: handle.pairId, name });
    try { return await perform(); }
    finally {
      handle.pending--;
      this.#emit('API_RETURN', { operationId, token: handle.token, physicalPairId: handle.pairId, name });
    }
  }
  append(handle, kind, rows) {
    if (handle.role !== 'writer' || !['legacy', 'structured'].includes(kind)) throw new Error('CANDIDATE_ONLY');
    return this.#operation(handle, 'add', () => handle.tables[kind].add(rows));
  }
  optimizeCandidate(handle, cleanupOlderThan) {
    if (handle.role !== 'writer' || !(cleanupOlderThan instanceof Date)) throw new Error('CANDIDATE_ONLY');
    // Pruning in 0.18.2 is optimize(options), not a nonexistent table.prune().
    return this.#operation(handle, 'optimize-prune', async () => {
      const result = {};
      for (const kind of ['legacy', 'structured']) result[kind] = await handle.tables[kind].optimize({ cleanupOlderThan, deleteUnverified: false });
      return result;
    });
  }
  readback(handle, query) {
    return this.#operation(handle, 'readback', async () => {
      const result = {};
      for (const kind of ['legacy', 'structured']) {
        const table = handle.tables[kind];
        result[kind] = { version: await table.version(), count: await table.countRows(), rows: await table.query().toArray(), search: await table.vectorSearch(query).limit(10).toArray() };
      }
      return result;
    });
  }
  async persistedRows(handle, receipts) {
    return this.#operation(handle, 'persisted-vector-readback', async () => {
      const observed = [];
      for (const tableKind of ['legacy', 'structured']) {
        for (const persisted of await handle.tables[tableKind].query().toArray()) {
          const vector = Array.from(persisted.vector);
          const receipt = receipts.find(row => row.tableKind === tableKind && row.physicalRowKey === persisted.physicalRowKey);
          // No provider truth is inferred from the vector or fabricated receipt.
          observed.push({ ...persisted, tableKind, vector, vectorDigest: vectorDigest(vector), nativeReadback: true,
            providerBindingVerified: receipt?.independentlyVerified === true,
            providerReceiptId: receipt?.id ?? null, dimension: vector.length });
        }
      }
      return observed;
    });
  }
  async verifyCompleteness(handle, fixture) {
    return validateBijection(fixture.expected, await this.persistedRows(handle, fixture.providerReceipts), fixture.sourceReceipt, fixture.providerReceipts);
  }
  async close(handle) {
    if (this.#handles.get(handle.token) !== handle || handle.pending !== 0) throw new Error('HANDLE_CLOSE_NOT_QUIESCENT');
    handle.state = 'CLOSING';
    for (const table of Object.values(handle.tables)) table.close();
    for (const connection of handle.connections) connection.close();
    handle.state = 'API_CLOSED_OS_PROOF_PENDING';
    const proof = await this.#venue.observeHandleClosure({ token: handle.token, pairId: handle.pairId, processIdentity: handle.actor.processIdentity });
    if (!proof?.rawArtifactRef || proof.noOpenReaderFDs !== true || proof.noMappings !== true) throw new VenueBindingRequired('reader_fd_close_proof');
    if (handle.pin) this.#store.releasePin(handle.pin, proof);
    handle.state = 'CLOSED'; this.#handles.delete(handle.token);
    this.#emit('READER_HANDLE_CLOSED', { token: handle.token, physicalPairId: handle.pairId, artifactRefs: [proof.rawArtifactRef] });
  }
  correlateObservation(record) {
    // API_ENTER alone never becomes NATIVE_ENTER. Actual TID/FD/syscall evidence
    // comes from the independent enrolled observer and its loss accounting.
    return this.#venue.correlateNativeOperation(record);
  }
}
