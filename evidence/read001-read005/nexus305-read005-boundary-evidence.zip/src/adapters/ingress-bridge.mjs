import { frozen, requireValue, hash } from '../replay/common.mjs';

const singleton = new Set(['mcp-session-id', 'last-event-id', 'mcp-protocol-version', 'content-length', 'authorization', 'host']);
export class IngressBridge {
  #requests = new WeakMap(); #targets = new WeakMap();
  constructor(registry, policy) {
    this.registry = registry; this.policy = frozen(policy);
    const origin = new URL(policy.origin);
    requireValue(origin.protocol === 'https:' && origin.origin === policy.origin &&
      policy.path?.startsWith('/') && Array.isArray(policy.protocolVersions), 'INGRESS_POLICY_REQUIRED');
  }
  async bindWeb(request, externalContext) {
    requireValue(!this.#requests.has(request), 'INGRESS_REQUEST_ALREADY_BOUND');
    const url = new URL(request.url);
    requireValue(url.origin === this.policy.origin && url.pathname === this.policy.path && !url.search && !url.hash &&
      ['GET', 'POST', 'DELETE'].includes(request.method) && !request.signal.aborted, 'WEB_INGRESS_TARGET_DENIED');
    const protocol = request.headers.get('mcp-protocol-version');
    requireValue(!protocol || this.policy.protocolVersions.includes(protocol), 'PROTOCOL_VERSION_DENIED');
    requireValue(!request.headers.has('x-principal') && !request.headers.has('x-grant-id'), 'CLIENT_AUTHORITY_HEADER_DENIED');
    if (request.headers.has('last-event-id')) requireValue(request.method === 'GET' &&
      request.headers.get('last-event-id') && request.headers.get('mcp-session-id') && protocol, 'REPLAY_HEADERS_REQUIRED');
    const context = await this.registry.call('ingress', 'capture', { request, externalContext });
    requireValue(context?.requestIdentity && context.rawArtifactRef && context.bootId === this.registry.boot &&
      context.method === request.method && context.url === request.url && context.trustRootRef &&
      context.clockReceipt && context.rotationReceipt, 'EXTERNAL_INGRESS_PROVENANCE_REQUIRED');
    this.#requests.set(request, frozen(context)); return request;
  }
  context(request) {
    const context = this.#requests.get(request);
    requireValue(context && context.bootId === this.registry.boot, 'OWNER_ENROLLED_INGRESS_REQUIRED');
    this.registry.entry('ingress'); return context;
  }
  async fromNode(node, parsedBody, signal, externalContext) {
    requireValue(signal && !signal.aborted && ['GET', 'POST', 'DELETE'].includes(node.method), 'HTTP_METHOD_OR_DISCONNECT_DENIED');
    requireValue(Array.isArray(node.rawHeaders) && node.rawHeaders.length % 2 === 0, 'RAW_HEADERS_REQUIRED');
    const headers = new Headers(); const seen = new Set();
    for (let i = 0; i < node.rawHeaders.length; i += 2) {
      const name = node.rawHeaders[i].toLowerCase(); const value = node.rawHeaders[i + 1];
      requireValue(typeof value === 'string' && !/[\r\n]/.test(value) && (!singleton.has(name) || !seen.has(name)), 'AMBIGUOUS_HEADER_DENIED');
      requireValue(!['x-principal', 'x-grant-id', 'grantid', 'connection', 'transfer-encoding', 'upgrade'].includes(name), 'UNTRUSTED_OR_HOP_HEADER_DENIED');
      seen.add(name); headers.append(name, value);
    }
    requireValue(typeof node.url === 'string' && node.url.startsWith('/') && !node.url.startsWith('//'), 'REQUEST_URL_DENIED');
    const url = new URL(node.url, this.policy.origin);
    requireValue(url.origin === this.policy.origin && url.pathname === this.policy.path && !url.search && !url.hash, 'REQUEST_TARGET_DENIED');
    if (headers.has('host')) requireValue(headers.get('host') === url.host, 'HOST_MISMATCH');
    if (headers.has('mcp-protocol-version')) requireValue(this.policy.protocolVersions.includes(headers.get('mcp-protocol-version')), 'PROTOCOL_VERSION_DENIED');
    const replay = headers.has('last-event-id');
    requireValue(!replay || (node.method === 'GET' && headers.get('last-event-id') && headers.get('mcp-session-id') && headers.get('mcp-protocol-version')), 'REPLAY_HEADERS_REQUIRED');
    requireValue(node.method === 'POST' || (parsedBody == null && !headers.has('content-length')), 'GET_DELETE_BODY_DENIED');
    let body;
    if (node.method === 'POST') {
      requireValue(headers.get('content-type')?.startsWith('application/json') && parsedBody !== undefined, 'POST_BODY_REQUIRED');
      body = JSON.stringify(parsedBody);
      requireValue(Buffer.byteLength(body) <= 1048576, 'PRIVATE_REQUEST_BODY_LIMIT');
      headers.delete('content-length'); // Re-serialized private body, not original wire length.
    }
    const request = new Request(url, { method: node.method, headers, signal, ...(body === undefined ? {} : { body }) });
    await this.bindWeb(request, { ...externalContext, node, disconnectSignal: signal });
    return request;
  }
  async verify(request) {
    const context = this.context(request);
    const principal = await this.registry.call('ingress', 'verify', { request, context });
    requireValue(principal?.requestIdentity === context.requestIdentity && principal.trustRootRef === context.trustRootRef &&
      principal.clockReceipt && principal.rotationReceipt && principal.rawArtifactRef &&
      Number.isSafeInteger(principal.expires_at) && principal.expires_at > this.registry.now(), 'AUTHN_CONTEXT_MISMATCH');
    return principal;
  }
  revalidateSync(principal) { return this.registry.sync('ingress', 'revalidateSync', principal); }
  get bindingReceipt() { return this.registry.receipt('ingress'); }
  targetFor(request, suppliedTarget) {
    const context = this.context(request);
    const target = this.registry.sync('ownerContext', 'targetForSync', { request, context });
    requireValue(target && (!suppliedTarget || target === suppliedTarget) && target.response && target.envelope &&
      target.envelope.requestKey && target.rawArtifactRef && target.requestIdentity === context.requestIdentity,
    'OWNER_TARGET_MISMATCH');
    const snapshot = Object.freeze({ ...target, envelope: frozen(target.envelope) });
    this.#targets.set(snapshot, { request, context }); return snapshot;
  }
  async resolveOwnerGrant(target, input) {
    const binding = this.#targets.get(target);
    requireValue(binding && input.principal.requestIdentity === binding.context.requestIdentity, 'OWNER_GRANT_CONTEXT_REQUIRED');
    const selected = await this.registry.call('ownerContext', 'resolveOwnerGrant', { ...input, context: binding.context, envelope: target.envelope });
    requireValue(selected?.rawArtifactRef && selected.requestIdentity === binding.context.requestIdentity &&
      selected.principalKey === input.principal.principal_key && selected.sessionId === input.sessionId &&
      selected.cursorDigest === hash(input.cursor), 'OWNER_GRANT_SELECTION_MISMATCH');
    return selected;
  }
}
