// All libraries are injected from a separately verified R2 dependency tree.
export function createPrivateMcpServer({ McpServer, z }, waitHandler) {
  if (typeof waitHandler !== 'function') throw new Error('VENUE_CAPABILITY_UNENROLLED:MAIN_SERVER_SETUP');
  const server = new McpServer({ name: 'r3-private-fixture', version: '1.0.0' });
  server.registerTool('synthetic', { inputSchema: { value: z.string() } }, async ({ value }) => {
    await waitHandler();
    return { content: [{ type: 'text', text: value }] };
  });
  return server;
}
export async function privateMcpServer(modules, transport, waitHandler) {
  const server = createPrivateMcpServer(modules, waitHandler);
  await server.connect(transport);
  return server;
}
export async function privateMcpClient({ Client }, transport) {
  const client = new Client({ name: 'r3-private-client', version: '1.0.0' });
  await client.connect(transport);
  return client;
}
export function v2PrivateHandler(createMcpHandler, factory, options) {
  return createMcpHandler(factory, options);
}
export class PrivateTransport {
  #frames = []; #size = 0; #closed = false;
  constructor(maximumBytes = 16777216) {
    if (!Number.isSafeInteger(maximumBytes) || maximumBytes <= 0) throw new Error('PRIVATE_FRAME_BOUND_REQUIRED');
    this.maximumBytes = maximumBytes;
  }
  async start() {}
  async send(message) {
    const frame = Buffer.from(`${JSON.stringify(message)}\n`);
    if (this.#closed || this.#size + frame.length > this.maximumBytes) throw new Error('PRIVATE_FRAME_BUFFER_CLOSED_OR_FULL');
    this.#frames.push(frame); this.#size += frame.length;
  }
  takePrivateFrame() {
    const frame = this.#frames.shift() ?? null;
    if (frame) this.#size -= frame.length;
    return frame;
  }
  async close() { this.#closed = true; this.onclose?.(); }
  receive(message) { this.onmessage?.(message); }
}
