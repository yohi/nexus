import { privateWebPlan } from './http-publication.mjs';
import { StoredEventDenied, assertNoUnprovenReplay } from '../stored-event-binding.mjs';
import { inspectPrivatePipes } from './private-pipe-boundary.mjs';

// No package defaults silently fall back to process.stdin/process.stdout.
export function actualPrivateStdio({ StdioServerTransport }, pipes, registry) {
  const enrolled = inspectPrivatePipes(registry, pipes);
  return new StdioServerTransport(enrolled.input, enrolled.output);
}

// A real SDK Client over enrolled private pipes, using the SDK's own JSONL
// serializer/read buffer. This never launches a process or writes external FD.
export class SDKPipeClientTransport {
  constructor({ ReadBuffer, serializeMessage }, pipes, registry) {
    this.buffer = new ReadBuffer(); this.serialize = serializeMessage; this.pipes = inspectPrivatePipes(registry, pipes);
    this.registry = registry;
    this.data = chunk => {
      this.buffer.append(chunk);
      try { let message; while ((message = this.buffer.readMessage()) !== null) this.onmessage?.(message); }
      catch (error) { this.onerror?.(error instanceof Error ? error : new Error('SDK_FRAME_INVALID')); }
    };
  }
  async start() { this.pipes.input.on('data', this.data); }
  send(message) {
    inspectPrivatePipes(this.registry, this.pipes);
    return new Promise((resolve, reject) => this.pipes.output.write(this.serialize(message), error => error ? reject(error) : resolve()));
  }
  async close() { this.pipes.input.off('data', this.data); this.onclose?.(); }
}

export async function actualSDKWeb(_SDK, mainSession, _options, replayBroker = null, requestBoundary = null, mainOwners = null) {
  if (!mainOwners || !requestBoundary) throw new Error('VENUE_CAPABILITY_UNENROLLED:MAIN_SESSION');
  mainOwners.assertHandle(mainSession);
  return Object.freeze(Object.assign(Object.create(null), {
    route: async (request, target, signal) => {
      requestBoundary?.context(request);
      if (!requestBoundary) throw new Error('VENUE_CAPABILITY_UNENROLLED:INGRESS');
      if (request.headers.has('last-event-id') && request.method !== 'GET') throw new StoredEventDenied('REPLAY_GET_REQUIRED');
      if (request.method === 'GET' && request.headers.has('last-event-id')) {
        if (!replayBroker) throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
        await mainOwners.admit(mainSession, request, target);
        return replayBroker.reconnect(request, target);
      }
      assertNoUnprovenReplay(request);
      return { privatePlan: await privateWebPlan(await mainOwners.dispatch(mainSession, request, target), signal) };
    },
    plan: async (request, signal, target) => {
      assertNoUnprovenReplay(request);
      return privateWebPlan(await mainOwners.dispatch(mainSession, request, target), signal);
    },
    replay: () => { throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN'); },
    // No public lifecycle-close authorization contract is enrolled. SDK close
    // callbacks still fence/revoke through InitializeReceipts.endSession.
    close: async () => { throw new Error('MAIN_OWNER_CLOSE_AUTHORITY_UNSPECIFIED'); } }));
}

export function actualV2Driver() {
  // Fixed server@2 exposes only per-request modern / stateless legacy serving.
  // Never borrow a v1 ACTIVE receipt to authorize a fresh v2 transport.
  const blocked = () => { throw new Error('SDK_API_CONTRACT_BLOCKED:V2_MAIN_STATEFUL_OWNER'); };
  return {
    routeNode: async () => blocked(),
    capture: async () => blocked(),
    close: async () => blocked()
  };
}

export async function actualBridgeDriver() {
  // Do not even connect the private v1 client when no v2 owner can be proved.
  // Original bridge handlers/close remain frozen in reference/fixed-head.
  throw new Error('SDK_API_CONTRACT_BLOCKED:BRIDGE_MAIN_STATEFUL_OWNER');
}

export function modernRequestMaterial(sdk, { id, method, params, name }) {
  const meta = { [sdk.PROTOCOL_VERSION_META_KEY]: '2026-07-28',
    [sdk.CLIENT_INFO_META_KEY]: { name: 'r3-private-client', version: '1.0.0' },
    [sdk.CLIENT_CAPABILITIES_META_KEY]: {} };
  return { body: { jsonrpc: '2.0', id, method, params: { ...params, _meta: meta } },
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream',
      'mcp-protocol-version': '2026-07-28', 'mcp-method': method, ...(name ? { 'mcp-name': name } : {}) } };
}
export function legacyHandshakeMaterial(id) {
  return { body: { jsonrpc: '2.0', id, method: 'initialize', params: { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'r3-private-client', version: '1.0.0' } } },
    headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream' } };
}
