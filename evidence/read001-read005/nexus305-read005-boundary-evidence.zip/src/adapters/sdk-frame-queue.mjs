export class SDKFrameQueue {
  #pending = Buffer.alloc(0); #frames = []; #parse; #envelopeFor;
  constructor({ parseMessage, envelopeFor, maximumBytes = 16777216 }) {
    this.#parse = parseMessage; this.#envelopeFor = envelopeFor; this.maximumBytes = maximumBytes;
  }
  acceptPrivateBytes(chunk) {
    this.#pending = Buffer.concat([this.#pending, Buffer.from(chunk)]);
    if (this.#pending.length > this.maximumBytes) throw new Error('PRIVATE_STDIO_BUFFER_LIMIT');
    let newline;
    while ((newline = this.#pending.indexOf(10)) !== -1) {
      const bytes = Buffer.from(this.#pending.subarray(0, newline + 1));
      this.#pending = Buffer.from(this.#pending.subarray(newline + 1));
      const message = this.#parse(JSON.parse(bytes.toString('utf8')));
      const envelope = Object.freeze({ ...this.#envelopeFor(message) });
      this.#frames.push({ bytes, envelope });
      if (this.#frames.reduce((sum, frame) => sum + frame.bytes.length, 0) > this.maximumBytes) throw new Error('PRIVATE_STDIO_QUEUE_LIMIT');
    }
  }
  take() { return this.#frames.shift() ?? null; }
  closePrivate() {
    // A partial SDK JSONL line is never forwarded or completed after closure.
    const pendingBytes = this.#pending.length; this.#pending = Buffer.alloc(0);
    return { pendingBytes, completePrivateFrames: this.#frames.length };
  }
}
