import { requireValue, hash } from '../replay/common.mjs';

export class FinalOwnerBoundary {
  #responses = new WeakMap(); #sinks = new WeakSet();
  constructor(registry) { this.registry = registry; }
  async prove(input) {
    requireValue(input.response && input.envelope && input.identity, 'FINAL_TARGET_REQUIRED');
    const receipt = await this.registry.call('finalWriter', 'proveFinalWriteOwnership', input);
    this.validate(receipt, input);
    this.#responses.set(input.response, Object.freeze({ ...input, receipt })); return receipt;
  }
  validate(receipt, input) {
    requireValue(receipt?.rawArtifactRef && receipt.bootId === this.registry.boot && receipt.kind === input.kind &&
      receipt.identity === input.identity && receipt.owner === 'gateowner' && receipt.fdArtifactRef &&
      receipt.topologyArtifactRef && receipt.exclusive === true && receipt.expiresAt > this.registry.now() &&
      receipt.response === input.response && receipt.independentObserverRef && receipt.role === 'gateowner' &&
      Number.isSafeInteger(receipt.pid) && receipt.pid > 0 && Number.isSafeInteger(receipt.tid) && receipt.tid > 0 &&
      receipt.envelopeDigest === hash(JSON.stringify(input.envelope)), 'FINAL_FD_OWNERSHIP_UNPROVEN');
  }
  enroll(response, gate, writeSync) {
    const input = this.#responses.get(response);
    requireValue(input, 'FINAL_FD_NOT_ENROLLED');
    const token = Object.freeze({}); this.#sinks.add(token);
    return gate.enrollFinalSink(step => {
      // Called inside synchronous GateOwner admission: no await or callback gap.
      const current = this.registry.sync('finalWriter', 'inspectFinalSync', input);
      this.validate(current, input);
      requireValue(current.fenceState === 'CONFIRMED' && current.authorityMatches === true &&
        current.c0Receipt && current.f1Receipt && current.gateOrderReceipt && !response.destroyed, 'C0_F1_FINAL_OWNER_DENIED');
      let returned;
      try { returned = writeSync(step); }
      catch (error) {
        this.registry.sync('finalWriter', 'observeWriteSync', { input, step, outcome: 'UNKNOWN_DELIVERY', error });
        throw error;
      }
      requireValue(!returned?.then, 'ASYNC_FINAL_WRITE_FORBIDDEN');
      const observation = this.registry.sync('finalWriter', 'observeWriteSync', {
        input, step, returned, outcome: 'NODE_ENQUEUED_NOT_PEER_ACKED', gateOrderReceipt: current.gateOrderReceipt
      });
      requireValue(observation?.rawArtifactRef && observation.independentObserverRef &&
        observation.kind === step.kind && observation.accepted === true && observation.peerAckClaimed === false,
      'FINAL_P_OBSERVATION_UNKNOWN_NO_RETRY');
      return returned;
    }, token);
  }
  owns(token) { return this.#sinks.has(token); }
}
