import { requireValue, frozen } from '../replay/common.mjs';

// Composition-root input only; never constructed from HTTP/IPC request data.
// Receipts are checked by the venue's independent enrollment authority, not by
// trusting an `authorized: true` property on a provider or client target.
export const capabilityMethods = Object.freeze({
  ingress: ['capture', 'verify', 'revalidateSync'],
  ownerContext: ['targetForSync', 'resolveOwnerGrant', 'verifyMainDispatchSync'],
  initialize: ['enrollMainTransport', 'verifyCompletion', 'verifyFinalInitializeP', 'observeActiveSync', 'observeLifecycleSync'],
  durability: ['verifyCommitReadbackSync', 'verifyActiveReadbackSync'],
  authority: ['verifySync', 'authorityReceiptSync', 'ownerReceiptSync', 'finalOwnershipSync', 'maximumGrantExpirySync', 'liveWriterFencedSync', 'tombstoneReceiptSync'],
  finalWriter: ['verifyActor', 'proveFinalWriteOwnership', 'inspectFinalSync', 'observeWriteSync'],
  casePublication: ['preparePublicationTarget', 'verifyTargetSync', 'holdF1'],
  privatePipes: ['inspectPrivatePipesSync'],
  native: ['inspectPairTopology', 'observeHandleClosure', 'correlateNativeOperation'],
  scenario: ['verifyPinnedSDKAndIndependentObservers', 'prepareRealScenario', 'executeWithRegisteredBarriers'],
  intervention: ['establishAntecedent', 'applyControl', 'connectHooks', 'disconnectHooks', 'executeVenueOperation', 'verifyControlSync'],
  barriers: ['register', 'reach'],
  rawEvidence: ['collectIndependentRaw', 'verifyArtifactSync'],
  executionAuthorization: ['requireSeparateExecutionAuthorization', 'revalidateAuthorizationSync']
});

export class CapabilityRegistry {
  #entries = new Map(); #last = -Infinity; #closed = false;
  constructor(root) {
    for (const name of ['verifyEnrollmentSync', 'currentBootSync', 'clock'])
      requireValue(typeof root?.[name] === 'function', 'VENUE_CAPABILITY_UNENROLLED:TRUST_ROOT');
    this.root = Object.freeze(Object.fromEntries(['verifyEnrollmentSync', 'currentBootSync', 'clock']
      .map(name => [name, root[name].bind(root)])));
    this.boot = this.root.currentBootSync();
    requireValue(typeof this.boot === 'string' && this.boot, 'TRUSTED_BOOT_REQUIRED');
  }
  now() {
    const value = this.root.clock();
    if (!Number.isSafeInteger(value) || value < this.#last) this.#closed = true;
    requireValue(!this.#closed && this.root.currentBootSync() === this.boot, 'VENUE_RESTART_OR_CLOCK_ROLLBACK');
    this.#last = value; return value;
  }
  enroll(name, provider, receipt) {
    requireValue(capabilityMethods[name] && !this.#entries.has(name), 'CAPABILITY_NAME_OR_DUPLICATE');
    const snapshot = frozen(receipt);
    requireValue(snapshot?.capability === name && snapshot.bootId === this.boot && snapshot.rawArtifactRef &&
      snapshot.owner && snapshot.issuer && snapshot.verifier && snapshot.expiresAt > this.now(), 'CAPABILITY_RECEIPT_MISMATCH');
    requireValue(this.root.verifyEnrollmentSync({ name, provider, receipt: snapshot }) === true, 'CAPABILITY_ENROLLMENT_UNVERIFIED');
    const methods = Object.fromEntries(capabilityMethods[name].map(method => {
      requireValue(typeof provider?.[method] === 'function', `VENUE_CAPABILITY_UNENROLLED:${name}.${method}`);
      return [method, provider[method].bind(provider)];
    }));
    this.#entries.set(name, { provider, methods: Object.freeze(methods), receipt: snapshot });
  }
  entry(name) {
    const entry = this.#entries.get(name);
    requireValue(entry && entry.receipt.expiresAt > this.now() &&
      this.root.verifyEnrollmentSync({ name, provider: entry.provider, receipt: entry.receipt }) === true,
    `VENUE_CAPABILITY_UNENROLLED:${name}`);
    return entry;
  }
  receipt(name) { return this.entry(name).receipt; }
  sync(name, method, input) {
    const result = this.entry(name).methods[method]?.(input);
    requireValue(result !== undefined && !result?.then, `VENUE_SYNC_RECEIPT_REQUIRED:${name}.${method}`);
    this.entry(name); return result;
  }
  async call(name, method, input) {
    const result = await this.entry(name).methods[method]?.(input);
    this.entry(name); return result;
  }
  require(names) { for (const name of names) this.entry(name); }
  close() { this.#closed = true; }
  status() { return Object.keys(capabilityMethods).map(name => ({ capability: name,
    registration: this.#entries.has(name) ? 'ENROLLED_REQUIRES_CURRENT_VERIFICATION' : 'VENUE_CAPABILITY_UNENROLLED' })); }
}
