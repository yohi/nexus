export class RequestLifecycle {
  constructor(incarnation) { this.incarnation = incarnation; this.pending = new Map(); this.sequence = 0; }
  ingress(id, nowMs, deadlineMs) {
    const protocolId = JSON.stringify(id);
    if (this.pending.has(protocolId)) return this.pending.get(protocolId);
    const request = { requestKey: JSON.stringify([this.incarnation, protocolId, ++this.sequence]), attempts: 0, deadline: nowMs + deadlineMs, claimed: false };
    this.pending.set(protocolId, request);
    return request;
  }
  attempt(request, nowMs, permanentlyRevoked) {
    if (request.claimed || permanentlyRevoked || nowMs >= request.deadline || request.attempts >= 2) return null;
    return { requestKey: request.requestKey, attemptId: ++request.attempts };
  }
  complete(id) { this.pending.delete(JSON.stringify(id)); }
}
