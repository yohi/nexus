import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export function describeBinding(manifest, id) {
  const found = [...manifest.bindings, ...manifest.extraBindings].find(binding => binding.bindingId === id);
  if (!found) throw new Error('UNKNOWN_BINDING_ID');
  return found;
}
export function rejectExecution() {
  // Deliberately no environment-variable "approval=true" bypass. A reviewed
  // subsequent revision must bind an enrolled OS/SDK context and authorization.
  throw new Error('NOT_AUTHORIZED: VENUE_AND_DYNAMIC_DRIVERS_UNBOUND');
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const [mode, id] = process.argv.slice(2);
  if (mode === '--describe' && id) {
    const manifest = JSON.parse(readFileSync(new URL('../R3_FROZEN_COMMAND_MANIFEST.json', import.meta.url), 'utf8'));
    process.stdout.write(`${JSON.stringify(describeBinding(manifest, id), null, 2)}\n`);
  } else {
    rejectExecution();
  }
}
