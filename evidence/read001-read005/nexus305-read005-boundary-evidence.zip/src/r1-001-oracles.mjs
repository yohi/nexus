// Additional counterexample inspection, not execution or a PASS-awarding proof.
// Requires separately validated input bindings, complete SQL readbacks and an
// independently validated single-owner causal trace. No such evidence is made up.
import { StoredEventDenied } from './stored-event-binding.mjs';
export const r1_001Limits = Object.freeze({
  'R1-001-01': { release: 0, claim: 0, write: 0 },
  'R1-001-02': { release: 0, claim: 0, write: 0 },
  'R1-001-03': { claim: 1 },
  'R1-001-04': { release: 0, claim: 0, write: 0, blocked: 'REPLAY_ENTITLEMENT_UNPROVEN' },
  'R1-001-05': { release: 0, claim: 0, write: 0 },
  'R1-001-06': { release: 0, claim: 0, write: 0 },
  'R1-001-07': { release: 0, claim: 0, write: 0 },
  'R1-001-08': { release: 0, claim: 0, write: 0 },
  'R1-001-09': { release: 0, claim: 0, write: 0 },
  'R1-001-10': { release: 0, claim: 0, write: 0 },
  'R1-001-11': { release: 0, claim: 0, write: 0 },
  'R1-001-12': { release: 0, claim: 0, write: 0 },
  'R1-001-13': { release: 0, claim: 0, write: 0 },
  'R1-001-14': { claim: 1, write: 1, frame: 0 },
  'R1-001-15': { release: 0, claim: 0, write: 0, blocked: 'REPLAY_ENTITLEMENT_UNPROVEN' }
});
export function inspectR1_001Counterexamples(caseId, evidence) {
  if (!Object.hasOwn(r1_001Limits, caseId)) throw new StoredEventDenied('UNKNOWN_R1_001_ORACLE');
  const limits = r1_001Limits[caseId];
  if (evidence.started !== true) return { classification: 'NOT_EXECUTED', counterexamples: [] };
  // Positive metadata/booleans alone cannot produce Safe Variant PASS.
  const missing = []; const counterexamples = [];
  const counts = { release: 0, claim: 0, write: 0, frame: 0 };
  const claims = new Set(); let previous = 0;
  for (const event of evidence.ownerEvents ?? []) {
    if (event.actorId !== 'gateowner' || !Number.isInteger(event.ownerSeq) || event.ownerSeq <= previous || !event.eventId) {
      missing.push('SINGLE_OWNER_CAUSAL_TRACE'); break;
    }
    previous = event.ownerSeq;
    const row = event.observation;
    if (!row) { missing.push('RAW_OBSERVATION'); continue; }
    // Raw independent observer events are scoped to this scenario by its binder.
    switch (event.event) {
      case 'EVENT_RELEASE_COMMIT': counts.release++; break;
      case 'TERMINAL_CLAIM':
        counts.claim++;
        if (claims.has(row.requestKey)) counterexamples.push({ eventId: event.eventId, violation: 'DUPLICATE_TERMINAL_CLAIM' });
        claims.add(row.requestKey); break;
      case 'P_WRITE_ACCEPT':
        counts.write++;
        if (row.publicationKind === 'sse-frame') counts.frame++;
        if (caseId === 'R1-001-13' && row.retrievalPairVerified === true) counterexamples.push({ eventId: event.eventId, violation: 'STORED_VERIFICATION_PROMOTION' });
        break;
      default: break;
    }
  }
  for (const [kind, maximum] of Object.entries(limits)) {
    if (typeof maximum === 'number' && counts[kind] > maximum) counterexamples.push({ violation: 'FORBIDDEN_CONSUMPTION', kind, observed: counts[kind], maximum });
  }
  if (!evidence.independentInputBindingRef) missing.push('INDEPENDENT_INPUT_BINDING');
  if (!evidence.completeSqlReadbackRef) missing.push('RELEASE_AND_CLAIM_SQL_READBACK');
  if (!evidence.completeObserverCoverageRef) missing.push('NO_TRACE_GAPS');
  if (!evidence.independentValidationReceiptRef) missing.push('INDEPENDENT_RAW_VALIDATOR');
  return { classification: counterexamples.length ? 'COUNTEREXAMPLES_FOUND' : limits.blocked ? 'BLOCKED' : 'INCONCLUSIVE',
    reason: limits.blocked ?? null, counts, counterexamples, missing: [...new Set(missing)],
    acceptanceOracleSatisfied: false, scope: 'ADDITIVE_NO_DYNAMIC_PASS_AWARD' };
}
