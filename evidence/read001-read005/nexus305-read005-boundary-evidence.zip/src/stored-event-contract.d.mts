import type { PublicationEnvelope } from './publication-contract.mjs';
declare const eventTicketBrand: unique symbol;
export type StoredEventTicket = Readonly<{ [eventTicketBrand]: true }>;
export type CurrentEventEnvelope = PublicationEnvelope & Readonly<{
  sessionId: string;
  streamId: string;
  transportInstance: string;
  connectionIncarnation: string;
}>;
export type EventPublication =
  | Readonly<{ mode: 'NEW'; envelope: CurrentEventEnvelope }>
  | Readonly<{ mode: 'REPLAY'; envelope: CurrentEventEnvelope; cursorId: string }>;
// No entitlement issuer, success type or grant constructor is defined here.
// A known ID/session or caller boolean cannot instantiate Replay permission.
export type ReplayAdmission = Readonly<{
  accepted: false;
  reason: 'REPLAY_ENTITLEMENT_UNPROVEN';
  classification: 'BLOCKED';
}>;
