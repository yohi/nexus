import { publishActualHTTP, publishActualStdout } from './integration.mjs';
import { requireValue } from '../replay/common.mjs';

// Case controls can choose an owner target, never supply a write callback.
// Actual response/FD ownership is independently proved by publishActual*.
export async function publishCaseFinal(ctx, queue) {
  const drivers = ctx.drivers;
  const registry = drivers?.registry;
  requireValue(registry, 'VENUE_CAPABILITY_UNENROLLED:CASE_PUBLICATION');
  const target = await registry.call('casePublication', 'preparePublicationTarget', { runId: ctx.runId, queue });
  const proof = registry.sync('casePublication', 'verifyTargetSync', { runId: ctx.runId, queue, target });
  requireValue(target?.envelope && target.signal && proof?.rawArtifactRef && proof.independentObserverRef &&
    proof.runId === ctx.runId && proof.target === target && proof.queue === queue, 'CASE_FINAL_TARGET_UNPROVEN');
  switch (target.kind) {
    case 'HTTP': return publishActualHTTP(drivers, target);
    case 'STDOUT': return publishActualStdout(drivers, target);
    default: throw new Error('CASE_FINAL_KIND_UNSUPPORTED');
  }
}

export async function holdF1ThenPublishCaseFinal(ctx) {
  const registry = ctx.drivers?.registry;
  requireValue(registry, 'VENUE_CAPABILITY_UNENROLLED:CASE_PUBLICATION');
  const receipt = await registry.call('casePublication', 'holdF1', { runId: ctx.runId });
  requireValue(receipt?.rawArtifactRef && receipt.independentObserverRef && receipt.runId === ctx.runId &&
    receipt.f1State === 'PENDING' && receipt.c0Recognized === true, 'CASE_F1_HOLD_UNPROVEN');
  return publishCaseFinal(ctx, 'OLD_CANDIDATE');
}
