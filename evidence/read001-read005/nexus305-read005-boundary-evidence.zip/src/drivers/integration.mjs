import { NativeLanceDriver } from '../adapters/native-lance.mjs';
import { VenueBoundary } from '../adapters/venue-boundary.mjs';
import { createFixedJournalDriver } from '../adapters/fixed-journal.mjs';
import { actualPrivateStdio, actualSDKWeb, actualV2Driver, actualBridgeDriver } from '../adapters/sdk-drivers.mjs';
import { enrollHTTPFinal, enrollStdoutFinal, publishPlan, bindStoredFrames } from '../adapters/http-publication.mjs';
import { DurableEventLedger, DurableSDKEventStore } from '../adapters/durable-events.mjs';
import { StoredEventDenied } from '../stored-event-binding.mjs';
import { Authority } from '../authority.mjs';
import { GateOwner } from '../gate-owner.mjs';
import { CASFaultDriver } from '../adapters/cas-fault-driver.mjs';
import { FaultController } from '../fault-controller.mjs';
import { boundedPinnedQuery } from './cutover.mjs';
import { assembleOptionAR } from '../replay/assembly.mjs';
import { FinalOwnerBoundary } from '../adapters/final-owner-boundary.mjs';
import { CapabilityRegistry } from '../adapters/capability-registry.mjs';
import { createCaseBoundary } from '../case-context/bootstrap.mjs';

// Callable assembly for review. Launcher never calls it in this revision.
export async function assembleDrivers({ modules, venueBinding, databasePath, emit, eventContext = null, replayBindings = null }) {
  if (!(venueBinding?.registry instanceof CapabilityRegistry) || (replayBindings && replayBindings.registry !== venueBinding.registry))
    throw new Error('VENUE_CAPABILITY_UNENROLLED:REGISTRY');
  venueBinding.registry.require(['finalWriter', 'durability']);
  if (replayBindings) venueBinding.registry.require(['ingress', 'ownerContext', 'initialize', 'authority']);
  const finalBoundary = new FinalOwnerBoundary(venueBinding.registry);
  const venue = new VenueBoundary({ ...venueBinding, finalBoundary });
  await venue.verifyActor({ role: 'gateowner' });
  const journal = await createFixedJournalDriver({ SqliteMetadataStore: modules.SqliteMetadataStore, databasePath, emit });
  const authority = new Authority(journal.store, emit);
  const faults = new FaultController(emit);
  // No session/envelope context is inferred from SDK JSON-RPC message fields.
  const eventLedger = eventContext ? new DurableEventLedger(journal.store, eventContext, emit) : null;
  const gate = new GateOwner(authority, journal.store, emit, eventLedger);
  gate.finalBoundary = finalBoundary;
  const native = new NativeLanceDriver({ lance: modules.lance, venue, store: journal.store, emit });
  const drivers = { registry: venueBinding.registry, venue, journal, authority, gate, faults, native, eventLedger,
    eventStore: eventLedger ? new DurableSDKEventStore(eventLedger, authority, faults) : null,
    cas: new CASFaultDriver(authority, faults, emit),
    stdio: pipes => actualPrivateStdio(modules, pipes, venueBinding.registry),
    sdkWeb: mainSession => actualSDKWeb(modules, mainSession, null, drivers.replay?.broker, drivers.replay?.requestBoundary, drivers.replay?.mainOwners),
    v2: (factory, options) => actualV2Driver(modules, factory, options, drivers.replay?.broker, drivers.replay?.requestBoundary),
    bridge: fixture => actualBridgeDriver(modules, fixture, drivers.replay?.broker, drivers.replay?.requestBoundary) };
  if (replayBindings) drivers.replay = assembleOptionAR(drivers, replayBindings, modules, emit);
  return drivers;
}
// Trusted bootstrap entry: only its issued facade, not this shell, goes to cases.
export async function assembleCaseBoundary({ modules, venueBinding, databasePath, emit,
  eventContext, replayBindings, serverSetup, authorize, identityEvidenceContext = null }) {
  if (typeof authorize !== 'function' || authorize() !== undefined)
    throw new Error('R3_EXECUTION_NOT_AUTHORIZED');
  const bindings = { ...replayBindings, mainServerSetup: serverSetup,
    authorizeMainDispatchSync: authorize, identityEvidenceContext };
  const drivers = await assembleDrivers({ modules, venueBinding, databasePath, emit, eventContext, replayBindings: bindings });
  return createCaseBoundary({ drivers, modules, registry: venueBinding.registry, serverSetup, authorize });
}
export async function publishActualHTTP(drivers, target) {
  await drivers.venue.proveFinalWriteOwnership({ kind: 'HTTP', identity: target.identity, response: target.response, envelope: target.envelope });
  if (target.publicationMode === 'REPLAY') throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
  // The venue await may lose to cutover. Do not consume lifecycle claim state
  // via an event-binding exception when R1 permits a fresh preclaim retry.
  if (drivers.journal.store.hasTerminalClaim(target.envelope.requestKey)) return { accepted: false, reason: 'TERMINAL_ALREADY_CLAIMED', claimCommitted: true };
  if (!drivers.authority.allows(target.envelope)) return { accepted: false, reason: 'TERMINAL_PRECLAIM_AUTHORITY_DENIED', claimCommitted: false };
  const plan = target.plan.some(step => step.kind === 'sse-frame')
    ? bindStoredFrames(target.plan, drivers.eventLedger, drivers.authority, { mode: target.publicationMode ?? 'NEW', envelope: target.envelope })
    : target.plan;
  const sink = enrollHTTPFinal(drivers.gate, target.response);
  return publishPlan({ ...target, plan, gate: drivers.gate, sink, finalStream: target.response });
}
export async function publishActualStdout(drivers, target) {
  await drivers.venue.proveFinalWriteOwnership({ kind: 'STDOUT', identity: target.identity, response: target.writable, envelope: target.envelope });
  const sink = enrollStdoutFinal(drivers.gate, target.writable);
  return publishPlan({ ...target, gate: drivers.gate, sink, finalStream: target.writable,
    plan: [{ kind: 'stdout', bytes: target.sdkFrame }] });
}
// These paths consume the actual pinned readback, not an old relabeled result.
// Encoders only create private bytes; authority/claim identity comes from the
// bounded query. Venue ownership waits still precede final preclaim admission.
export function publishPinnedHTTP(drivers, input) {
  return boundedPinnedQuery({ ...input, authority: drivers.authority, native: drivers.native,
    publish: (envelope, result) => publishActualHTTP(drivers, { ...input.target,
      envelope, plan: input.encodeResult(result) }) });
}
export function publishPinnedStdout(drivers, input) {
  return boundedPinnedQuery({ ...input, authority: drivers.authority, native: drivers.native,
    publish: (envelope, result) => publishActualStdout(drivers, { ...input.target,
      envelope, sdkFrame: input.encodeResult(result) }) });
}
export function rejectUnassembledScenario(binding) {
  // Distinct from the execution-authorization block. Do not silently dispatch
  // negative controls through the safe adapter or manufacture branch evidence.
  throw new Error(`DRIVER_SCENARIO_BINDING_REQUIRED:${binding.bindingId}`);
}
