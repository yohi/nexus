// Real pinned query and GateOwner publication composition. No clock/OS evidence
// is generated here; the enrolled context supplies those observations.
export async function boundedPinnedQuery({ lifecycle, request, authority, native, snapshot, query, clock, publish }) {
  const original = snapshot();
  const pins = [];
  while (true) {
    const permanentlyRevoked = authority.closedEpochs.has(original.epoch) || authority.closedGenerations.has(original.generation);
    const attempt = lifecycle.attempt(request, clock(), permanentlyRevoked);
    if (!attempt) return { reason: permanentlyRevoked ? 'COMPATIBILITY_REVOKED' : 'COMPATIBILITY_RETRY_EXHAUSTED', pins, requestKey: request.requestKey };
    if (authority.hold || authority.unknown) return { reason: 'AUTHORITY_HELD', pins, requestKey: request.requestKey };
    const fresh = snapshot();
    const handle = await native.openPublished(fresh);
    pins.push(handle);
    const result = await native.readback(handle, query);
    const envelope = { ...fresh, ...attempt, retrievalPairVerified: fresh.retrievalPairVerified };
    if (authority.closedEpochs.has(original.epoch) || authority.closedGenerations.has(original.generation)) return { reason: 'COMPATIBILITY_REVOKED', pins };
    if (!authority.allows(envelope)) {
      // Compatible replacement only, before any durable claim. No relabeling
      // of old results; a retry performs a new actual native read under a pin.
      if (authority.hold || authority.unknown || request.claimed) return { reason: 'AUTHORITY_HELD', pins };
      continue;
    }
    let publication;
    try {
      publication = await publish(envelope, result);
    } catch (error) {
      // Claim/write outcome is not proven absent. Never retry an unknown claim.
      request.claimed = true;
      throw error;
    }
    request.claimed = publication.claimCommitted !== false;
    if (publication.claimCommitted === false && publication.reason === 'TERMINAL_PRECLAIM_AUTHORITY_DENIED') {
      if (authority.closedEpochs.has(original.epoch) || authority.closedGenerations.has(original.generation)) return { reason: 'COMPATIBILITY_REVOKED', pins };
      if (authority.hold || authority.unknown) return { reason: 'AUTHORITY_HELD', pins };
      // No claim exists: next attempt re-pins and re-reads with the same key.
      continue;
    }
    return { publication, pins, attempt };
  }
}
export async function closeRetainedReaders(native, handles) {
  for (const handle of handles) await native.close(handle);
}
