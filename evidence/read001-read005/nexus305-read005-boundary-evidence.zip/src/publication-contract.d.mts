// Distinct concepts: at-most-once durable claim versus per-write admission.
declare const terminalBrand: unique symbol;
declare const permitBrand: unique symbol;
export type TerminalClaim = Readonly<{ requestKey: string; bytesDigest: string; [terminalBrand]: true }>;
export type PublicationPermit = Readonly<{ [permitBrand]: true }>;
// Stored provenance is deliberately unable to provide retrieval verification.
export type StoredFrameAuth = Readonly<{
  epoch: number;
  generation: string;
  pairId: string;
  publicationRevision: number;
}>;
export type PublicationEnvelope = StoredFrameAuth & Readonly<{
  requestKey: string;
  bytesDigest: string;
  retrievalPairVerified: boolean;
}>;
export type PublicationPlanResult =
  | Readonly<{ accepted: false; reason: 'TERMINAL_PRECLAIM_AUTHORITY_DENIED'; claimCommitted: false }>
  | Readonly<{ accepted: boolean | null; claimCommitted: true; reason?: string; delivery?: string; state?: PublicationState }>;
export type PublicationState = 'CLAIMED' | 'PARTIAL' | 'ENDED' | 'UNKNOWN_DELIVERY' | 'CLAIMED_NO_PUBLICATION';
export type PublicationResult =
  | Readonly<{ accepted: true; backpressure: boolean; state: PublicationState }>
  | Readonly<{ accepted: false; reason: string; state: PublicationState }>
  | Readonly<{ accepted: null; reason: 'UNKNOWN_DELIVERY_NO_RETRY'; state: PublicationState }>;
export interface PublicationBoundary {
  prepareTerminal(envelope: PublicationEnvelope): TerminalClaim | null;
  nextPermit(channel: object): PublicationPermit | null;
  publishPermit(permit: PublicationPermit): PublicationResult;
}
