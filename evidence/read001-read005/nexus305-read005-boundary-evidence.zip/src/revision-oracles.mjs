// Additive trace inspection, not a replacement for frozen R3 acceptance Oracles.
// Must receive a causally validated, single-owner trace and independently bound
// request inputs. This function never awards Safe Variant PASS or authorization.
export function inspectR1Counterexamples(events, requestInputs) {
  const counterexamples = []; const missing = [];
  const inputKey = row => JSON.stringify([row.requestKey, row.attemptId]);
  const inputs = new Map(requestInputs.map(input => [inputKey(input), input]));
  const claims = new Set(); const closedEpochs = new Set();
  let active = null; let previousSequence = 0;
  for (const event of events) {
    if (event.actorId !== 'gateowner') continue;
    if (!Number.isInteger(event.ownerSeq) || event.ownerSeq <= previousSequence) {
      missing.push('SINGLE_OWNER_CAUSAL_ORDER'); break;
    }
    previousSequence = event.ownerSeq;
    const row = event.observation;
    if (!row || !event.eventId) { missing.push('RAW_OWNER_OBSERVATION'); continue; }
    switch (event.event) {
      case 'ACTIVE_CAS_COMMIT': active = row; break;
      case 'C0_GATE_SYNC': closedEpochs.add(row.epoch); break;
      case 'TERMINAL_CLAIM': {
        if (claims.has(row.requestKey)) counterexamples.push({ finding: 'RG-305-R3-DRV-001', eventId: event.eventId, violation: 'SECOND_DURABLE_TERMINAL_CLAIM' });
        claims.add(row.requestKey);
        if (!active) missing.push('ACTIVE_TUPLE_BEFORE_CLAIM');
        else if (row.epoch !== active.epoch || row.generation !== active.generation || row.physicalPairId !== active.physicalPairId || row.publicationRevision !== active.publicationRevision) {
          counterexamples.push({ finding: 'RG-305-R3-DRV-001', eventId: event.eventId, violation: 'STALE_RESULT_CONSUMED_TERMINAL_KEY' });
        }
        if (closedEpochs.has(row.epoch)) counterexamples.push({ finding: 'RG-305-R3-DRV-001', eventId: event.eventId, violation: 'CLAIM_AFTER_C0' });
        const input = inputs.get(inputKey(row));
        if (!input) missing.push('INDEPENDENT_REQUEST_INPUT');
        else if (input.retrievalPairVerified !== true) counterexamples.push({ finding: 'RG-305-R3-DRV-002', eventId: event.eventId, violation: 'UNVERIFIED_REQUEST_CLAIMED' });
        break;
      }
      case 'P_WRITE_ACCEPT': {
        const input = inputs.get(inputKey(row));
        if (!input) missing.push('INDEPENDENT_REQUEST_INPUT');
        else if (input.retrievalPairVerified !== true) counterexamples.push({ finding: 'RG-305-R3-DRV-002', eventId: event.eventId, violation: 'STORED_AUTH_PROMOTED_UNVERIFIED_REQUEST' });
        if (closedEpochs.has(row.epoch)) counterexamples.push({ finding: 'RG-305-R3-DRV-002', eventId: event.eventId, violation: 'OLD_FRAME_ACCEPTED_AFTER_C0' });
        break;
      }
      default: break;
    }
  }
  return { classification: counterexamples.length ? 'COUNTEREXAMPLES_FOUND' : 'INCONCLUSIVE',
    counterexamples, missing: [...new Set(missing)], acceptanceOracleSatisfied: false,
    scope: 'ADDITIVE_TRACE_INSPECTION_NO_PASS_AWARD' };
}
