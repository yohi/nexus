import { forbiddenTransitions } from './readback-oracle.mjs';
// Evaluate real evidence only. Declarative expected milestones are not evidence.
const requirements = {
  A: ['legitimatePriorCommit', 'postC0OldPublicationDenied', 'atomicReadback'],
  B: ['activationProjectionUnchanged', 'noSuccessReceipt', 'finalCommitPredicate'],
  B2: ['casBeginBeforeC0BeforeCommitAttempt', 'activationProjectionUnchanged', 'noSuccessReceipt', 'finalCommitPredicate'],
  C: ['bothDurableOutcomes', 'semanticDeniedUntilReadback', 'consistentFiveWayReadback', 'revocationNotReopened'],
  D: ['allF1Branches', 'allPrivateQueues', 'postC0OldPublicationDenied', 'unknownNewSemanticDenied'],
  E: ['oldReaderContinues', 'oldPublicationDeniedAfterHold', 'freshS43PairVerified', 'attemptsBoundedTwo', 'terminalAtMostOnce', 'permanentRevocationNoRetry'],
  F: ['allReachableCrashCells', 'allSixPhasesAndFailed', 'legacyAPIsRejectedBeforeEffects', 'bootClosed', 'consistentFiveWayReadback', 'postCASFinalizeOnly', 'noPermitRevival', 'terminalAtMostOnce'],
};
const groupRequirements = {
  'R3-S01': ['allPublishedPathsDenied', 'parentRegistryMetadataDenied', 'retainedFDDirfdIPCDenied', 'backingMountBypassDenied', 'publisherPostSealDenied', 'completeHashTreeUnchanged', 'readerRowsSearchEqual'],
  'R3-S02': ['nativeEnterSignalDeliveryExitCorrelated', 'noObserverGaps', 'allWriterDescendantsGone', 'allWriteFDsWithdrawn', 'allMutationIPCRevoked', 'quiescenceSeparateFromInflight', 'oldPublishedHashesUnchanged'],
  'R3-S03': ['independentPhysicalCopyNoSharedWriteInodes', 'oldAndFreshReaderRowsSearchEqual', 'manifestCatalogHashTreeEqual', 'candidateOptimizePruneExercised', 'gcDeniedWhilePinned', 'gcOnlyAfterReleaseAndFDClosure'],
  'R3-S04': ['pinWinsDeleteRejected', 'intentWinsPinRejected', 'unknownWriterDeleteDenied', 'activePreparedDeleteDenied', 'intentDurableBeforePartialDelete', 'restartIdempotentComplete', 'revocationTombstoneNeverRevived'],
  'R3-S05': ['fullIncrementalSingleCAS', 'noLostUpdateSelfSlotConflict', 'uniqueCommitReceipt', 'allSixJournalPhasesAndFailed', 'merklePhaseAndCASOneTransaction', 'legacyOwnerAbsentModeMismatchDenied', 'actualFixedHeadJournalSchemaAndAPIs', 'oldRecoveryDeniedBeforeEffects', 'bothUnknownCommitOutcomes', 'casesAB_B2_CFComplete'],
  'R3-S06': ['sourceExpectedFrozenIndependently', 'fullAndIncrementalAllRowsBothTables', 'nativePersistedVectorReadback', 'providerPreparedRoleTaskUnicodeBound', 'keyBijectionNoMissingDuplicateExtraSwap', 'P1ThroughP7Denied', 'allRootsIndependentlyRecomputedAndBound', 'watchGapSourceChangeExpiryDeny', 'exactGrepSeparateAuthority'],
  'R3-T01': ['actualSDKHandlerAndFrame', 'privatePipeNoExternalFDInSDK', 'allThreeC0InjectionPoints', 'noPostC0OldFinalWrite', 'newErrorGrepAuthorityAndOneTerminal'],
  'R3-T02': ['actualPausedOSPipeHighWaterMark', 'falseWriteReturnRecordedAsAccepted', 'PBeforeC0CausalProof', 'C0BeforePNoOldAccept', 'cancelCloseDelayedDrainExercised', 'unresolvedSendBoundedIsolation', 'noDuplicateTerminal'],
  'R3-T03': ['actualSDKWebResponse', 'constructionBufferFinalWriteBarriers', 'noOldHeaderBodyAcceptAfterC0', 'headerFirstPartialAbortNoOldContinuation', 'clientStatusLengthBodyConsistent', 'safeReplacementOnlyBeforeClaim'],
  'R3-T04': ['actualSDKPrivateSSEFrames', 'event1PreC0AcceptanceProof', 'event2PostC0Denied', 'headerOnlyPartialAborted', 'noOldContinuationAccepted', 'deliveryUnknownNoRetractionClaim', 'terminalAtMostOnce'],
  'R3-T05': ['actualSDKStorePendingAcrossC0F1', 'privateRevokedAfterStoreComplete', 'releaseDenied', 'genuineValidCursorReplayCompletes', 'multipleReconnectsCompleteNoOldEvents', 'durableRestartNoEventRevival'],
  'R3-T06': ['actualServerAndNodeAdapter2', 'validHandshakeHeadersMeta', 'privateWebResponseGateOwnerSocket', 'beforeFinalWriteC0Denies', 'partialWriteIsolationDeliveryUnknown'],
  'R3-T07': ['fixedHeadBridgeActuallyExecuted', 'actualV1InternalAndV2External', 'internalSuccessIsNotP', 'allAwaitAndHandlerReturnBarriers', 'gateOwnerExternalSocketOnly', 'noOldPostC0Accept', 'terminalAtMostOnce'],
  'R3-T08': ['duplicatePendingStableIngressNoSideEffects', 'completedIDReuseNewSequence', 'newIncarnationNotRejected', 'semanticRevokedErrorFreshAuthority', 'hybridIndependentGrepNoSemantic', 'claimShutdownUnknownNoResend', 'oldBufferReplayDenied', 'caseEAllBranches'],
  'R3-T09': ['identityRecognitionSynchronousC0SameOwner', 'actualStdoutAndHTTPv2BothCovered', 'F1PendingFailedUnknownACKAllBranches', 'unknownBothDurableReadbacks', 'remoteObservationNotC0', 'noWorkerExternalFDLeak', 'bootMissingCorruptCleanFailClosed', 'claimBeforePAndPBeforeACKCrash', 'compatibleHoldCASFinalPOrdered', 'casesAThroughFAndB2Complete'],
};
export function evaluateCase(caseId, evidence) {
  if (!requirements[caseId]) throw new Error('UNKNOWN_CASE');
  const counterexamples = [...(evidence.counterexamples ?? []), ...forbiddenTransitions(evidence.events ?? [])];
  if (counterexamples.length) return { classification: 'FAIL', counterexamples };
  if (!evidence.started) return { classification: 'NOT_EXECUTED' };
  if (evidence.preconditionMissing?.length) return { classification: 'BLOCKED', missing: evidence.preconditionMissing };
  const missing = requirements[caseId].filter(name => {
    const witness = evidence.witnesses?.[name];
    return !witness || witness.satisfied !== true || !witness.rawArtifactRef || !witness.causalEventIds?.length || !witness.independentlyValidated;
  });
  if (!evidence.osFinalWriteOwnership || !evidence.nativePairVerified || !evidence.durableFSVerified || !evidence.causalGraphValidated) missing.push('COMMON_OS_NATIVE_DURABLE_CAUSAL_EVIDENCE');
  return { classification: missing.length ? 'INCONCLUSIVE' : 'PASS', missing, scope: 'INDEPENDENT_SPIKE_ONLY' };
}
export function evaluateGroup(binding, evidence) {
  if (!groupRequirements[binding.testId]) throw new Error('UNKNOWN_GROUP');
  const counterexamples = [...(evidence.counterexamples ?? []), ...forbiddenTransitions(evidence.events ?? [])];
  if (counterexamples.length) return { classification: 'FAIL', counterexamples };
  if (!evidence.started) return { classification: 'NOT_EXECUTED' };
  if (evidence.preconditionMissing?.length) return { classification: 'BLOCKED', missing: evidence.preconditionMissing };
  const missing = [
    ...binding.evidencePaths.filter(path => !/^[a-f0-9]{64}$/.test(evidence.artifactHashes?.[path] ?? '')),
    ...groupRequirements[binding.testId].filter(name => {
      const witness = evidence.witnesses?.[name];
      return !witness || witness.satisfied !== true || !witness.rawArtifactRef || !witness.causalEventIds?.length || !witness.independentlyValidated;
    }),
  ];
  if (!evidence.rawSemanticValidatorBound || !evidence.causalGraphValidated || evidence.unobservedMandatoryBranches?.length) missing.push('RAW_SEMANTIC_VALIDATOR_OR_BRANCH_COVERAGE_UNRESOLVED');
  // Raw witness validators must be independently bound and audited. Caller
  // assertions/file presence alone are not admitted as validated evidence.
  return { classification: missing.length ? 'INCONCLUSIVE' : 'PASS', missing, scope: 'INDEPENDENT_SPIKE_ONLY' };
}
export const caseRequirements = requirements;
export const originalGroupRequirements = groupRequirements;
