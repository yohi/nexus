import { hash, requireValue, frozen } from '../replay/common.mjs';
import { classifyReplayEvidence } from '../replay/oracle.mjs';

export const unsafeFields = Object.freeze(['unauthorizedRelease', 'terminalClaimDelta', 'terminalReplaySend', 'oldPayloadAfterC0',
  'wrongPrincipalP', 'wrongStreamP', 'primingPayloadP', 'provenanceRelabel', 'mainSessionClosed', 'lateCallbackP']);
export const rawRoles = Object.freeze(['AUTH', 'SDK', 'NODE', 'OS', 'DB', 'AUTHORITY', 'BARRIER']);

export class IndependentRawCollector {
  #verified = new WeakSet();
  constructor(registry) { this.registry = registry; }
  async collect(run, outcome, fixture) {
    const raw = await this.registry.call('rawEvidence', 'collectIndependentRaw', { run, outcome, fixture });
    requireValue(raw?.caseId === fixture.caseId && raw.scenario === fixture.scenario && raw.runId === run.runId &&
      Array.isArray(raw.artifacts), 'RAW_RUN_IDENTITY_MISMATCH');
    for (const role of rawRoles) requireValue(raw.artifacts.some(a => a.role === role), `INDEPENDENT_RAW_MISSING:${role}`);
    const observers = new Set(); const hashes = new Set();
    for (const artifact of raw.artifacts) {
      requireValue(rawRoles.includes(artifact.role) && artifact.bytes instanceof Uint8Array && artifact.rawArtifactRef &&
        artifact.independentObserverRef && artifact.origin !== 'HARNESS_EMIT' && artifact.origin !== 'SELF_ASSERTED',
      'SIMULATED_OR_SELF_ASSERTED_ONLY');
      const digest = hash(artifact.bytes);
      requireValue(artifact.sha256 === digest && !hashes.has(digest), 'RAW_HASH_OR_DUPLICATE');
      const proof = this.registry.sync('rawEvidence', 'verifyArtifactSync', { artifact, digest, run, fixture });
      requireValue(proof?.digest === digest && proof.rawArtifactRef === artifact.rawArtifactRef &&
        proof.independentObserverRef === artifact.independentObserverRef && proof.runId === run.runId &&
        proof.integrityVerified === true && proof.antecedentVerified === true, 'INDEPENDENT_RAW_UNVERIFIED');
      hashes.add(digest); observers.add(artifact.independentObserverRef);
    }
    requireValue(observers.size >= 4, 'INDEPENDENT_OBSERVER_SEPARATION_REQUIRED');
    const evidence = raw.evidence;
    requireValue(evidence && raw.evidenceDigest === hash(JSON.stringify(evidence)), 'RAW_EVIDENCE_DIGEST_MISMATCH');
    for (const field of [...unsafeFields, 'newReleaseDelta', 'forbiddenSemanticP'])
      requireValue(Number.isSafeInteger(evidence[field]) && evidence[field] >= 0, `RAW_FIELD_MISSING:${field}`);
    // Provider must prove each normalized oracle field against raw artifacts;
    // no default zero counters, local emit traces, or computed PASS receipts.
    const decoded = this.registry.sync('rawEvidence', 'verifyArtifactSync', {
      normalizedEvidence: evidence, evidenceDigest: raw.evidenceDigest, artifacts: raw.artifacts, run, fixture
    });
    requireValue(decoded?.evidenceDigest === raw.evidenceDigest && decoded.allFieldsBound === true &&
      decoded.antecedentScenario === fixture.scenario && decoded.rawArtifactRef &&
      fixture.rawFields.every(field => decoded.boundFields?.includes(field)) && decoded.runId === run.runId &&
      decoded.antecedentVerified === true && decoded.controlObserved === true && decoded.forbiddenActionOutcomeObserved === true &&
      decoded.providerSeparationVerified === true, 'NORMALIZED_RAW_FIELDS_UNBOUND');
    const snapshot = frozen(evidence); this.#verified.add(snapshot); return snapshot;
  }
  classify(fixture, evidence) {
    // Preserve the original oracle algorithm, add provenance before PASS.
    if (!evidence || !this.#verified.has(evidence)) return 'BLOCKED';
    return classifyReplayEvidence(fixture.caseId, fixture.scenario, evidence);
  }
}
