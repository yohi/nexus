import catalog from './scenario-catalog.json' with { type: 'json' };
import { frozen, requireValue, hash } from '../replay/common.mjs';

export const scenarioCatalog = frozen(catalog);
// Descriptor construction only: no fabricated principal, session, grant, FD,
// event, SDK result, authority receipt or negative-control measurement.
export function buildScenarioFixture(caseId, scenario) {
  const row = scenarioCatalog.find(cell => cell.caseId === caseId && cell.scenario === scenario);
  requireValue(row, 'ORIGINAL_ORACLE_CELL_REQUIRED');
  return frozen({ ...row, evidenceClass: 'DESCRIPTOR_ONLY_NOT_RUNTIME_EVIDENCE',
    enrolledInputs: null, actual: null, execution: 'NOT_EXECUTED' });
}

export class RegisteredBarriers {
  #plans = new WeakMap();
  constructor(registry) { this.registry = registry; }
  async register(fixture, run) {
    const receipt = await this.registry.call('barriers', 'register', { fixture, run, markers: fixture.barriers });
    requireValue(receipt?.rawArtifactRef && receipt.caseId === fixture.caseId && receipt.scenario === fixture.scenario &&
      receipt.runId === run.runId && JSON.stringify(receipt.markers) === JSON.stringify(fixture.barriers), 'BARRIER_REGISTRATION_MISMATCH');
    this.#plans.set(run, { fixture, receipt }); return receipt;
  }
  async reach(run, marker, context) {
    const plan = this.#plans.get(run);
    requireValue(plan && plan.fixture.barriers.includes(marker), 'UNREGISTERED_SCENARIO_BARRIER');
    const receipt = await this.registry.call('barriers', 'reach', { runId: run.runId, marker, context, registration: plan.receipt });
    requireValue(receipt?.rawArtifactRef && receipt.marker === marker && receipt.runId === run.runId, 'BARRIER_REACH_UNOBSERVED');
    requireValue(receipt.independentObserverRef && receipt.origin && !['HARNESS_EMIT', 'SELF_ASSERTED'].includes(receipt.origin) &&
      receipt.bytes instanceof Uint8Array && receipt.sha256 === hash(receipt.bytes), 'BARRIER_INDEPENDENT_ARTIFACT_REQUIRED');
    const proof = this.registry.sync('rawEvidence', 'verifyArtifactSync', { artifact: receipt, digest: receipt.sha256, run, fixture: plan.fixture });
    requireValue(proof?.runId === run.runId && proof.digest === receipt.sha256 && proof.integrityVerified === true &&
      proof.independentObserverRef === receipt.independentObserverRef && proof.rawArtifactRef === receipt.rawArtifactRef,
    'BARRIER_RAW_PROOF_UNVERIFIED');
    return receipt;
  }
}
