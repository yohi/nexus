import { buildScenarioFixture, RegisteredBarriers } from './fixtures.mjs';
import { IndependentRawCollector } from './raw-collector.mjs';
import { requireValue } from '../replay/common.mjs';
import { executeIntervention } from './intervention-runner.mjs';
import { ownData, projectData, projectCaseError, projectScenarioResult } from '../case-context/projection.mjs';

// Callable binding surface for a separately authorized executor, never called by
// the launcher or static checker. No run/--execute command is introduced.
export class ScenarioVenue {
  #runs = new WeakMap(); #outcomes = new WeakMap(); #authorization = null;
  #registry; #barriers; #collector;
  constructor(registry) {
    this.#registry = registry; this.#barriers = new RegisteredBarriers(registry);
    this.#collector = new IndependentRawCollector(registry);
    Object.freeze(this);
  }
  async requireSeparateExecutionAuthorization() {
    this.#authorization = null;
    const receipt = await this.#registry.call('executionAuthorization', 'requireSeparateExecutionAuthorization', {
      scope: 'R3_OPTION_AR_DYNAMIC', bootId: this.#registry.boot
    });
    requireValue(receipt?.rawArtifactRef && receipt.independentApprovalRef && receipt.scope === 'R3_OPTION_AR_DYNAMIC' &&
      receipt.bootId === this.#registry.boot && receipt.expiresAt > this.#registry.now(), 'R3_EXECUTION_NOT_AUTHORIZED');
    this.#authorization = receipt;
  }
  requireCurrentAuthorization() {
    this.#registry.entry('executionAuthorization');
    requireValue(this.#authorization?.expiresAt > this.#registry.now(), 'R3_EXECUTION_NOT_AUTHORIZED');
    requireValue(this.#registry.sync('executionAuthorization', 'revalidateAuthorizationSync', this.#authorization) === true,
      'R3_EXECUTION_AUTHORIZATION_REVOKED');
  }
  async verifyPinnedSDKAndIndependentObservers() {
    this.requireCurrentAuthorization();
    this.#registry.require(['ingress', 'ownerContext', 'initialize', 'durability', 'authority', 'finalWriter', 'scenario', 'barriers', 'rawEvidence', 'intervention']);
    const receipt = await this.#registry.call('scenario', 'verifyPinnedSDKAndIndependentObservers', {
      sdkVersion: '1.29.0', sdkHash: '177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6',
      serverVersion: '2.0.0', nodeVersion: '2.0.0', lanceVersion: '0.18.2'
    });
    requireValue(receipt?.rawArtifactRef && receipt.loadedSourceHash === '177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6' &&
      receipt.independentObserverRefs?.length >= 4, 'PINNED_SDK_AND_OBSERVERS_UNENROLLED');
  }
  async prepareRealScenario(caseId, scenario) {
    this.requireCurrentAuthorization();
    const fixture = buildScenarioFixture(caseId, scenario);
    const run = await this.#registry.call('scenario', 'prepareRealScenario', { fixture, authorization: this.#authorization });
    this.requireCurrentAuthorization();
    requireValue(run?.runId && run.rawArtifactRef && run.evidenceClass === 'REAL_SDK_SQLITE_AUTH_HTTP' &&
      fixture.inputs.every(name => run.enrollmentReceipts?.[name]), 'VENUE_CAPABILITY_UNENROLLED:SCENARIO_INPUTS');
    if (caseId === 'RP-19') requireValue(run.broker && run.firstRequest && run.secondRequest &&
      run.firstTarget && run.secondTarget, 'TWO_REAL_RECONNECT_INPUTS_REQUIRED');
    await this.#barriers.register(fixture, run);
    this.requireCurrentAuthorization();
    const prepared = Object.freeze(Object.assign(Object.create(null), {
      executeWithRegisteredBarriers: async () => {
        try {
          this.requireCurrentAuthorization();
          requireValue(!this.#outcomes.has(prepared), 'SCENARIO_ALREADY_EXECUTED');
          // Reserve synchronously: concurrent calls cannot run a scenario twice.
          this.#outcomes.set(prepared, { state: 'RUNNING' });
          const outcome = await executeIntervention({ registry: this.#registry, run, fixture, barriers: this.#barriers,
            authorize: () => this.requireCurrentAuthorization() });
          this.requireCurrentAuthorization();
          this.#outcomes.set(prepared, { state: 'COMPLETE', outcome });
          const evidence = await this.#collector.collect(run, outcome, fixture);
          this.requireCurrentAuthorization();
          return projectScenarioResult({ runId: run.runId, caseId, scenario,
            executionRef: ownData(evidence, 'executionRef') });
        } catch (error) { return projectCaseError(error); }
      }
    }));
    this.#runs.set(prepared, { run, fixture }); return prepared;
  }
  async collectIndependentRaw(prepared) {
    this.requireCurrentAuthorization();
    const binding = this.#runs.get(prepared);
    requireValue(binding, 'SCENARIO_RUN_NOT_REGISTERED');
    const execution = this.#outcomes.get(prepared);
    requireValue(execution?.state === 'COMPLETE', 'SCENARIO_OUTCOME_UNAVAILABLE');
    try {
      const result = await this.#collector.collect(binding.run, execution.outcome, binding.fixture);
      this.requireCurrentAuthorization();
      return projectData(result);
    } catch (error) { throw new Error(projectCaseError(error).code); }
  }
}
