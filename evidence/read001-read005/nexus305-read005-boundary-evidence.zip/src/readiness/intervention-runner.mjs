import { hash, requireValue } from '../replay/common.mjs';
import { interventionPlan } from './intervention-plans.mjs';

function observed(registry, run, plan, receipt, kind) {
  requireValue(receipt?.runId === run.runId && receipt.caseId === plan.caseId && receipt.scenario === plan.scenario &&
    receipt.kind === kind && receipt.bytes instanceof Uint8Array && receipt.rawArtifactRef && receipt.independentObserverRef &&
    receipt.origin && !['HARNESS_EMIT', 'SELF_ASSERTED'].includes(receipt.origin) &&
    receipt.sha256 === hash(receipt.bytes), 'INTERVENTION_RAW_PROOF_REQUIRED');
  const proof = registry.sync('intervention', 'verifyControlSync', { run, plan, receipt });
  requireValue(proof?.runId === run.runId && proof.digest === receipt.sha256 && proof.rawArtifactRef === receipt.rawArtifactRef &&
    proof.independentObserverRef === receipt.independentObserverRef && proof.kind === kind && proof.verified === true,
  'INTERVENTION_INDEPENDENT_PROOF_REQUIRED');
  return receipt;
}

// No substitute SDK/DB/OS operation exists here: unconnected hooks fail closed.
export async function executeIntervention({ registry, run, fixture, barriers, authorize }) {
  authorize(); registry.require(['intervention']);
  const plan = interventionPlan(fixture);
  observed(registry, run, plan, await registry.call('intervention', 'establishAntecedent', { run, plan }), 'ANTECEDENT');
  authorize();
  let applied = false;
  const apply = async context => {
    authorize();
    observed(registry, run, plan, await registry.call('intervention', 'applyControl', { run, plan, context }), 'CONTROL');
    authorize(); applied = true;
  };
  const reach = async (marker, context) => {
    authorize();
    const receipt = await barriers.reach(run, marker, context);
    if (!applied && marker === plan.marker && (plan.markerIndex === null || context?.index === plan.markerIndex))
      await apply({ ...context, barrierReceipt: receipt });
    return receipt;
  };
  const hooks = await registry.call('intervention', 'connectHooks', { run, plan, reach });
  observed(registry, run, plan, hooks, 'HOOK_REGISTRATION');
  try {
    if (plan.marker === 'ENTRY') await apply({ entry: true });
    authorize();
    switch (plan.operation) {
      case 'RECONNECT':
        requireValue(run.broker && run.request && run.target, 'REAL_RECONNECT_INPUTS_REQUIRED');
        return await run.broker.reconnect(run.request, run.target);
      case 'TWO_RECONNECT': {
        requireValue(run.broker && run.firstRequest && run.secondRequest && run.firstTarget && run.secondTarget,
          'TWO_REAL_RECONNECT_INPUTS_REQUIRED');
        const first = await run.broker.reconnect(run.firstRequest, run.firstTarget);
        authorize();
        const second = await run.broker.reconnect(run.secondRequest, run.secondTarget);
        requireValue(first.status === 200 && second.status === 200 && first.frameCount > 0 && second.frameCount > 0 &&
          first.sessionId === second.sessionId && first.streamId === second.streamId &&
          first.mainTransportId === second.mainTransportId && first.grantVersion === second.grantVersion &&
          first.rendererInstanceId !== second.rendererInstanceId &&
          first.frames.some(frame => frame.bytes.length > 0 && frame.bytes.toString().includes('event: message\n')) &&
          second.frames.some(frame => frame.bytes.length > 0 && frame.bytes.toString().includes('event: message\n')),
        'TWO_REPLAY_OWNER_IDENTITY_MISMATCH');
        return { first, second };
      }
      case 'INITIALIZE':
        requireValue(run.drivers?.replay && run.initializeInput, 'GENUINE_INITIALIZE_INPUTS_REQUIRED');
        return await run.drivers.replay.initialize(run.initializeInput);
      case 'VENUE_OPERATION':
        return await registry.call('intervention', 'executeVenueOperation', { run, plan, reach });
      default: throw new Error('SCENARIO_OPERATION_UNSUPPORTED');
    }
  } finally {
    // Hooks must be released by their enrolled owner, not by a harness callback.
    authorize();
    observed(registry, run, plan, await registry.call('intervention', 'disconnectHooks', { run, plan, hooks }), 'HOOK_RELEASE');
  }
}
