import { buildCandidate, mutateCandidate } from './actors/writer.mjs';
import { readPinnedPair } from './actors/reader.mjs';
import { collectRetired } from './actors/gc.mjs';
import { validateBijection } from './provenance.mjs';
import { caseFunctions } from './cases.mjs';
export async function storageGroup(binding, ctx) {
  switch (binding.testId) {
    case 'R3-S01': return ctx.attemptAllPublishedMutationRoutes(binding.branch);
    case 'R3-S02': return ctx.observeNativeThenSignalAndProveQuiescence(binding.branch);
    case 'R3-S03': {
      const reader = await readPinnedPair(ctx.store, ctx.native, ctx.oldPair, ctx.query);
      const candidate = await buildCandidate(ctx.native, ctx.candidate, ctx.rows, ctx.emit);
      for (const table of candidate.tables) await mutateCandidate(table, 'optimize', []);
      return ctx.verifyOldAndFreshReaderAndPinRetention(reader);
    }
    case 'R3-S04': return collectRetired(ctx.store, ctx.os, ctx.retiredPairId, await ctx.liveness());
    case 'R3-S05': return ctx.actualJournalCASAndRecovery(binding.branch, caseFunctions);
    case 'R3-S06': return validateBijection(await ctx.expectedFromSource(), await ctx.nativeReadbackAllRows(), await ctx.sourceReceipt(), await ctx.providerReceipts());
    default: throw new Error('UNKNOWN_STORAGE_TEST');
  }
}
export async function transportGroup(binding, ctx) {
  // SDK/Node-v2/Bridge fixture enrollment is mandatory; no raw synthetic write
  // substituted for a named library route.
  await ctx.requireActualRouteAndPrivateFDIsolation(binding.testId);
  switch (binding.testId) {
    case 'R3-T01': return ctx.stdioPrivateFrameBeforeFinalWrite(binding.branch);
    case 'R3-T02': return ctx.pausedPipeBackpressureCancelClose(binding.branch);
    case 'R3-T03': return ctx.httpJSONBufferAndFinalNodeWrite(binding.branch);
    case 'R3-T04': return ctx.ssePerFramePartialAbort(binding.branch);
    case 'R3-T05': return ctx.genuineSDKCursorReplayAndRestart(binding.branch);
    case 'R3-T06': return ctx.v2ValidHandshakeAndFinalAdapter(binding.branch);
    case 'R3-T07': return ctx.fixedHeadBridgeToRealV2(binding.branch);
    case 'R3-T08': return ctx.requestLifecycleAndCutover(binding.branch, caseFunctions.E);
    case 'R3-T09': return ctx.sameOwnerC0F1CASAndFinalWrite(binding.branch, binding.sink, caseFunctions);
    default: throw new Error('UNKNOWN_TRANSPORT_TEST');
  }
}
