import { digest } from './evidence-collector.mjs';
import { canonical } from './provenance.mjs';

// Codes only: no foreign request/event/session/payload is exposed in errors.
export class StoredEventDenied extends Error {
  constructor(code) { super(code); this.name = 'StoredEventDenied'; this.code = code; }
}
export function requireEventEnvelope(envelope) {
  for (const field of ['requestKey', 'streamId', 'sessionId', 'transportInstance', 'connectionIncarnation', 'generation', 'pairId']) {
    if (typeof envelope?.[field] !== 'string' || !envelope[field]) throw new StoredEventDenied('EVENT_CONTEXT_UNBOUND');
  }
  if (!Number.isInteger(envelope.epoch) || !Number.isInteger(envelope.publicationRevision) || typeof envelope.retrievalPairVerified !== 'boolean') throw new StoredEventDenied('EVENT_CONTEXT_UNBOUND');
}
export function eventIdentityDigest(row) {
  return digest(Buffer.from(canonical({ id: row.id, sequence: row.sequence, stream: row.stream,
    session: row.session, originalRequestKey: row.original_request,
    transportInstance: row.transport_instance, connectionIncarnation: row.connection_incarnation,
    auth: row.auth, terminal: row.terminal, payloadDigest: row.payload_digest })));
}
export function assertDurableEvent(row) {
  requireEventEnvelope(row.auth);
  if (row.message === null || typeof row.message !== 'object' || Array.isArray(row.message)) throw new StoredEventDenied('EVENT_MESSAGE_INVALID');
  if (eventIdentityDigest(row) !== row.identity_digest || digest(Buffer.from(row.message_wire)) !== row.payload_digest ||
      canonical(JSON.parse(row.message_wire)) !== canonical(row.message) ||
      row.original_request !== row.auth.requestKey || row.session !== row.auth.sessionId || row.stream !== row.auth.streamId ||
      row.transport_instance !== row.auth.transportInstance || row.connection_incarnation !== row.auth.connectionIncarnation ||
      !Number.isInteger(row.sequence) || row.sequence < 1 || row.terminal !== (('result' in row.message || 'error' in row.message) ? 1 : 0)) throw new StoredEventDenied('EVENT_PROVENANCE_MISMATCH');
}
export function assertStoredFrame(row, step) {
  // Fixed SDK 1.29.0 writeSSEEvent format, including the original JSON wire text.
  // Unknown format/partial frame is BLOCKED rather than guessed or relabeled.
  const expected = Buffer.from(`event: message\nid: ${row.id}\ndata: ${row.message_wire}\n\n`);
  if (step.kind !== 'sse-frame' || step.eventId !== row.id || !Buffer.isBuffer(step.bytes) || !step.bytes.equals(expected)) throw new StoredEventDenied('EVENT_PAYLOAD_BINDING_MISMATCH');
}
export function assertNewEventAuthorization(row, authority, publication) {
  const envelope = publication?.envelope;
  requireEventEnvelope(envelope);
  switch (publication?.mode) {
    case 'NEW':
      if (row.original_request !== envelope.requestKey) throw new StoredEventDenied('EVENT_REQUEST_MISMATCH');
      break;
    case 'REPLAY':
      // RequestKey equality is NOT used to decide Replay rights. No issuer,
      // authenticated principal or entitlement verifier is defined in Rev5.
      throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
    default: throw new StoredEventDenied('EVENT_PUBLICATION_MODE_UNBOUND');
  }
  if (row.session !== envelope.sessionId || row.stream !== envelope.streamId ||
      row.transport_instance !== envelope.transportInstance || row.connection_incarnation !== envelope.connectionIncarnation) throw new StoredEventDenied('EVENT_SESSION_STREAM_MISMATCH');
  for (const field of ['epoch', 'generation', 'pairId', 'publicationRevision']) {
    if (row.auth[field] !== envelope[field]) throw new StoredEventDenied('EVENT_AUTHORITY_MISMATCH_NO_RELABEL');
  }
  if (row.state === 'REVOKED' || !authority.allows(row.auth) || !authority.allows(envelope)) throw new StoredEventDenied('EVENT_AUTHORITY_DENIED');
}
export function assertNoUnprovenReplay(request) {
  if (request.headers.has('last-event-id')) throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
}
export function assertNoUnprovenNodeReplay(request) {
  if (Object.keys(request.headers ?? {}).some(name => name.toLowerCase() === 'last-event-id')) throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN');
}
