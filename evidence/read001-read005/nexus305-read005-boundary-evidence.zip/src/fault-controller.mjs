// No signal operation is hidden in a barrier. The adapter is separately enrolled.
export class FaultController {
  constructor(emit, timeoutMs = 30000) { this.emit = emit; this.timeoutMs = timeoutMs; this.waiters = new Map(); }
  pause(point, operationId) {
    const key = `${operationId}:${point}`;
    if (this.waiters.has(key)) throw new Error('DUPLICATE_BARRIER');
    this.emit('BARRIER_ENTER', { point, operationId, barrierId: key });
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.waiters.delete(key); reject(new Error('BARRIER_TIMEOUT')); }, this.timeoutMs);
      this.waiters.set(key, () => { clearTimeout(timer); this.waiters.delete(key); this.emit('BARRIER_RELEASE', { point, operationId, barrierId: key }); resolve(); });
    });
  }
  release(point, operationId) {
    const release = this.waiters.get(`${operationId}:${point}`);
    if (!release) throw new Error('UNKNOWN_BARRIER');
    release();
  }
  async signal(target, signal, enrollment, adapter) {
    if (!['SIGTERM', 'SIGKILL'].includes(signal)) throw new Error('SIGNAL_NOT_ALLOWLISTED');
    if (!enrollment.matches(target)) throw new Error('TARGET_NOT_ENROLLED');
    return adapter.deliverPidfdSignal(target, signal);
  }
}
