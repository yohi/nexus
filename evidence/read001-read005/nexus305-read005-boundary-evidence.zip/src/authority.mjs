// Experimental logic only. Not an OS isolation or durability proof.
export class Authority {
  constructor(store, emit) {
    this.store = store;
    this.emit = emit;
    this.closedEpochs = new Set();
    this.closedGenerations = new Set();
    this.unresolvedFences = new Map();
    this.bootReady = false;
    this.hold = true;
    this.unknown = true;
    this.active = null;
  }
  recognizeIdentity(epoch, nonce) {
    this.closedEpochs.add(epoch);
    if (this.active?.generation !== undefined) this.closedGenerations.add(this.active.generation);
    this.unresolvedFences.set(epoch, nonce);
    this.hold = true;
    this.emit('IDENTITY_RECOGNIZED', { epoch, nonce });
    this.emit('C0_GATE_SYNC', { epoch, nonce });
  }
  beginCAS(candidate) {
    this.hold = true;
    this.emit('CUTOVER_HOLD', { operationId: candidate.operationId });
    this.emit('ACTIVE_CAS_BEGIN', { operationId: candidate.operationId });
  }
  bindBoot(receipt) {
    const view = this.store.consistentReadback();
    if (!receipt?.rawArtifactRef || receipt.independentlyVerified !== true || !receipt.durableBeforeAdmission || !view.bootUnclean || view.bootIncarnation !== receipt.incarnation) throw new Error('BOOT_BINDING_REQUIRED');
    if (receipt.previousEpoch !== null && receipt.previousEpoch !== undefined) {
      this.closedEpochs.add(receipt.previousEpoch);
      if (receipt.previousGeneration !== undefined) this.closedGenerations.add(receipt.previousGeneration);
      // Never resume a pre-crash epoch even if C0 was lost before F1.
      if (view.epoch === receipt.previousEpoch) throw new Error('PRECRASH_EPOCH_QUARANTINED');
    }
    this.bootReady = true;
  }
  commitCAS(candidate) {
    // No await between closure check and actual synchronous SQLite commit.
    if (!this.bootReady || this.unresolvedFences.size > 0) {
      this.emit('ACTIVE_CAS_DENIED', { reason: 'BOOT_OR_FENCE_UNRESOLVED', operationId: candidate.operationId, epoch: candidate.epoch });
      return { committed: false, reason: 'BOOT_OR_FENCE_UNRESOLVED' };
    }
    if (this.closedEpochs.has(candidate.epoch) || this.closedGenerations.has(candidate.generation)) {
      this.emit('ACTIVE_CAS_DENIED', { reason: 'C0', operationId: candidate.operationId, epoch: candidate.epoch });
      return { committed: false, reason: 'C0' };
    }
    try {
      const receipt = this.store.activate(candidate);
      this.emit('ACTIVE_CAS_COMMIT', { receipt, epoch: candidate.epoch, operationId: candidate.operationId, physicalPairId: candidate.pairId, generation: candidate.generation, publicationRevision: receipt.publicationRevision });
      this.active = this.store.consistentReadback();
      this.unknown = false;
      this.hold = !this.bootReady || this.unresolvedFences.size > 0 || this.closedEpochs.has(candidate.epoch) || this.closedGenerations.has(candidate.generation);
      return { committed: true, receipt };
    } catch (error) {
      this.unknown = true;
      this.hold = true;
      this.emit('ACTIVE_CAS_UNKNOWN', { code: error.code ?? 'COMMIT_UNRESOLVED' });
      return { committed: null };
    }
  }
  reconcile(validate) {
    const view = this.store.consistentReadback();
    if (!validate(view) || (this.store.verifyReadback && !this.store.verifyReadback(view))) return { admitted: false, reason: 'READBACK_INCOHERENT' };
    this.active = view;
    for (const row of view.revocations ?? []) {
      this.closedEpochs.add(row.epoch);
      if (row.generation !== undefined) this.closedGenerations.add(row.generation);
      if (this.unresolvedFences.get(row.epoch) === row.nonce) this.unresolvedFences.delete(row.epoch);
    }
    this.unknown = false;
    this.hold = !this.bootReady || this.unresolvedFences.size > 0 || this.closedEpochs.has(view.epoch) || this.closedGenerations.has(view.generation);
    this.emit('RECOVERY_READBACK', { view });
    // A reconciled pointer never clears closedEpochs.
    return { admitted: !this.hold };
  }
  allows(envelope) {
    if (!this.bootReady || this.unresolvedFences.size || this.closedEpochs.has(envelope.epoch) || this.closedGenerations.has(envelope.generation) || this.unknown || this.hold) return false;
    if (this.active?.revocations?.some(row => row.epoch === envelope.epoch)) return false;
    return envelope.epoch === this.active?.epoch && envelope.pairId === this.active?.pairId &&
      envelope.publicationRevision === this.active?.publicationRevision &&
      envelope.generation === this.active?.generation && envelope.retrievalPairVerified === true;
  }
  async fence(epoch, nonce, sink) {
    if (!this.closedEpochs.has(epoch)) throw new Error('F1_REQUIRES_C0');
    if (this.unresolvedFences.has(epoch) && this.unresolvedFences.get(epoch) !== nonce) throw new Error('F1_NONCE_MISMATCH');
    this.emit('F1_BEGIN', { epoch, nonce });
    try {
      const outcome = await sink(epoch, nonce);
      this.emit(outcome === 'ACK' ? 'F1_ACK' : 'F1_UNKNOWN', { epoch, nonce });
      if (outcome !== 'ACK') this.unknown = true;
      else if (this.unresolvedFences.get(epoch) === nonce) this.unresolvedFences.delete(epoch);
      return outcome;
    } catch (error) {
      this.unknown = true;
      this.emit('F1_FAILED', { epoch, nonce, code: error.code ?? 'FENCE_FAILED' });
      return 'FAILED';
    }
  }
}
