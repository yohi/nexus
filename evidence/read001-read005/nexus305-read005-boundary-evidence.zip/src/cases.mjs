// Callable fault points, not executed during preparation. ctx is a real enrolled
// driver assembled after permission review, never a synthetic evidence producer.
import { publishCaseFinal, holdF1ThenPublishCaseFinal } from './drivers/case-final-publication.mjs';
export async function caseA(ctx) {
  await ctx.prepareCandidate();
  await ctx.casWithBarrier('BEFORE_COMMIT');
  await ctx.confirmCommittedReadback();
  ctx.recognizeC0();
  await holdF1ThenPublishCaseFinal(ctx);
}
export async function caseB(ctx) {
  await ctx.prepareCandidate(); ctx.recognizeC0();
  await ctx.attemptCAS(); await ctx.confirmNoActivationMutation();
}
export async function caseB2(ctx) {
  await ctx.prepareCandidate();
  const pending = ctx.beginCASPausedBeforeCommit();
  await ctx.waitBarrier('ACTIVE_CAS_BEGIN_BEFORE_COMMIT_DECISION');
  ctx.recognizeC0();
  ctx.releaseCommitBarrier();
  await pending; await ctx.confirmNoActivationMutation();
}
export async function caseC(ctx) {
  for (const outcome of ['COMMITTED_ACK_LOST', 'PRECOMMIT_CONNECTION_LOST']) {
    await ctx.freshRun(outcome);
    await ctx.injectCASOutcomeUnknown(outcome);
    await ctx.attemptSemanticWhileUnknown();
    await ctx.reconcilePointerRevisionJournalReceiptRevocation();
  }
}
export async function caseD(ctx) {
  for (const outcome of ['PENDING', 'FAILED', 'UNKNOWN_COMMITTED', 'UNKNOWN_NOT_COMMITTED', 'ACK']) {
    await ctx.freshRun(outcome); ctx.recognizeC0();
    await ctx.injectF1Outcome(outcome);
    for (const queue of ['SDK_COMPLETED', 'PRIVATE_QUEUE', 'WORKER_IPC']) await publishCaseFinal(ctx, queue);
    await ctx.attemptCAS();
  }
}
export async function caseE(ctx) {
  for (const branch of ['S43', 'S44', 'TIMEOUT', 'IDENTITY_C0', 'POST_CLAIM_CUTOVER']) {
    await ctx.freshRun(branch); await ctx.pinS42AndStartQuery();
    ctx.enterCutoverHold(); await ctx.activateS43AndReadback();
    await ctx.finishOldReader(); await publishCaseFinal(ctx, 'S42_RESULT');
    await ctx.boundedFreshRetryOrTerminal(branch, 2);
  }
}
export async function caseF(ctx) {
  const phases = ['building', 'legacy-swapped', 'structured-swapped', 'catalog-activated', 'merkle-activated', 'idle', 'failed'];
  const prefixes = ['CAS_CRASH_BEFORE_C0', 'CAS_C0_CRASH_BEFORE_F1', 'CAS_C0_F1_ACK', 'C0_CAS_DENIED', 'CAS_BEGIN_C0_DENIED', 'CAS_UNKNOWN_COMMITTED', 'CAS_UNKNOWN_NOT_COMMITTED', 'C0_F1_FAILED', 'C0_F1_UNKNOWN_COMMITTED', 'C0_F1_UNKNOWN_NOT_COMMITTED', 'C0_F1_ACK_CAS_DENIED', 'CLAIM_BEFORE_P', 'P_BEFORE_ACK'];
  for (const phase of phases) for (const prefix of prefixes) {
    const reachability = await ctx.proveReachability(phase, prefix);
    if (!reachability.reachable) { await ctx.recordUnreachableProof(phase, prefix, reachability.proof); continue; }
    await ctx.freshRun(`${phase}:${prefix}`);
    await ctx.advanceActualJournal(phase, prefix);
    await ctx.crashEnrolledOwnerAndRestart();
    await ctx.attemptLegacyAPIsBeforeNewRecovery();
    await ctx.readbackBootAndAllLedgers();
  }
}
export const caseFunctions = { A: caseA, B: caseB, B2: caseB2, C: caseC, D: caseD, E: caseE, F: caseF };
