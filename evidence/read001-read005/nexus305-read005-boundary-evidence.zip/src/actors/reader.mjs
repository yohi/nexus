export async function readPinnedPair(authority, native, pair, query) {
  const pin = authority.acquirePin(pair.pairId);
  if (!pin) throw new Error('PIN_DENIED');
  const connection = await native.connect(pair.path, { readConsistencyInterval: 0 });
  // OS mount/ownership, not this connect option, enforces read-only.
  const result = {};
  for (const name of ['legacy', 'structured']) {
    const table = await connection.openTable(name);
    result[name] = { rows: await table.query().toArray(), search: await table.vectorSearch(query).limit(10).toArray() };
  }
  return { pin, connection, result }; // Pin retained until OS handle closure proof.
}
