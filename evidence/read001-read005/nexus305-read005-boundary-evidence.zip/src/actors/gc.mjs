export async function collectRetired(authority, adapter, pairId, liveness) {
  if (!liveness.known || liveness.writers !== 0 || liveness.openReaderFDs !== 0) throw new Error('GC_BLOCKED');
  const intent = authority.startDeleteIntent(pairId);
  if (!intent) throw new Error('GC_INTENT_DENIED');
  await adapter.deleteEnrolledPairNoFollow(intent);
  authority.completeDeleteIntent(intent);
  return intent;
}
