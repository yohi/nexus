export async function sealPair(adapter, imported, pairId) {
  await adapter.withdrawPublisherFDs(imported);
  const receipt = await adapter.transferToSealOwnerAndPublish(imported, pairId);
  await adapter.fsyncPublishedParent(pairId);
  const coverage = await adapter.inspectAllMutationRoutes(pairId);
  if (!coverage.writerDenied || !coverage.publisherDenied || !coverage.parentDenied || !coverage.registryDenied || !coverage.openFDDenied || !coverage.ipcDenied || !coverage.backingMountDenied) throw new Error('SEAL_NOT_PROVEN');
  return { receipt, coverage };
}
