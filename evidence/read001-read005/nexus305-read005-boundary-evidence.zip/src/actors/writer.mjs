export async function buildCandidate(native, candidate, rows, emit) {
  emit('API_ENTER', { operationId: candidate.operationId });
  // API_ENTER is deliberately not NATIVE_ENTER: an OS observer supplies that.
  const connection = await native.connect(candidate.path);
  const tables = [];
  for (const tableKind of ['legacy', 'structured']) {
    tables.push(await connection.createTable(tableKind, rows[tableKind]));
  }
  emit('API_RETURN', { operationId: candidate.operationId });
  return { connection, tables };
}
export async function mutateCandidate(table, action, rows) {
  switch (action) {
    case 'append': return table.add(rows);
    case 'optimize': return table.optimize();
    default: throw new Error('UNBOUND_NATIVE_ACTION');
  }
}
