export async function privateImport(adapter, candidate, destination, quiescence) {
  if (!quiescence.allPrincipalsGone || !quiescence.noWritableFDs || !quiescence.noMutationIPC || !quiescence.futureWriteRevoked) throw new Error('QUARANTINED');
  const inventory = await adapter.enumerateNoFollow(candidate);
  if (inventory.some(entry => !['regular', 'directory'].includes(entry.kind) || entry.hardlinkCount > 1)) throw new Error('UNSAFE_IMPORT_ENTRY');
  const before = await adapter.hashTree(candidate);
  await adapter.copyBytesExclusiveNoFollow(inventory, destination);
  const after = await adapter.hashTree(candidate);
  const imported = await adapter.hashTree(destination);
  if (before.digest !== after.digest || before.contentDigest !== imported.contentDigest) throw new Error('IMPORT_HASH_MISMATCH');
  await adapter.fsyncFilesAndDirectories(destination);
  return { before, imported, status: 'IMPORT_ONLY_NOT_SEALED' };
}
