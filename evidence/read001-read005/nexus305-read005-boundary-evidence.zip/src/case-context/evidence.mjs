import { createHash } from 'node:crypto';
import { ownData, projectData } from './projection.mjs';

const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const unavailable = () => { throw new Error('IDENTITY_EVIDENCE_UNAVAILABLE'); };
const fields = ['kind', 'runId', 'bootId', 'sessionId', 'transportId', 'attemptNonce',
  'activeCommitToken', 'independentObserverRef', 'enrollmentRef'];

/** Validate a privately received observation, never a caller-supplied credential. */
export function projectIdentityEvidence({ receipt, artifact, proof, expected }) {
  if (!['ACTIVE', 'DISPATCH'].includes(expected.kind)) return unavailable();
  const keys = expected.kind === 'DISPATCH' ? [...fields, 'requestIdentity', 'principalKey'] : fields;
  if (!keys.every(key => typeof expected[key] === 'string' && expected[key])) return unavailable();
  const bytes = ownData(artifact, 'bytes');
  const ref = ownData(artifact, 'rawArtifactRef');
  const origin = ownData(artifact, 'origin');
  if (!(bytes instanceof Uint8Array) || !bytes.length || bytes.length > 1048576 ||
    typeof ref !== 'string' || !ref || typeof origin !== 'string' ||
    ['SELF_ASSERTED', 'HARNESS_EMIT'].includes(origin)) return unavailable();
  const sha256 = digest(bytes);
  if (ownData(artifact, 'sha256') !== sha256 || ownData(receipt, 'rawArtifactRef') !== ref ||
    ownData(artifact, 'independentObserverRef') !== expected.independentObserverRef) return unavailable();
  let observed;
  try { observed = JSON.parse(Buffer.from(bytes).toString('utf8')); } catch { return unavailable(); }
  if (!keys.every(key => ownData(observed, key) === expected[key]) ||
    ownData(observed, 'sameInitializeTransport') !== true || ownData(observed, 'sameInitializeServer') !== true)
    return unavailable();
  const identity = Object.fromEntries(keys.map(key => [key, expected[key]]));
  const identityDigest = digest(JSON.stringify(identity));
  if (ownData(proof, 'digest') !== sha256 || ownData(proof, 'rawArtifactRef') !== ref ||
    ownData(proof, 'runId') !== expected.runId || ownData(proof, 'independentObserverRef') !== expected.independentObserverRef ||
    ownData(proof, 'enrollmentRef') !== expected.enrollmentRef || ownData(proof, 'identityDigest') !== identityDigest ||
    ownData(proof, 'integrityVerified') !== true || ownData(proof, 'identityVerified') !== true) return unavailable();
  return projectData({ schemaVersion: 1, ...identity, rawArtifactRef: ref, rawArtifactSha256: sha256 });
}

/** Existing enrolled verifier only; missing identity-specific venue data blocks. */
export function verifyIdentityEvidence(registry, receipt, expected, context) {
  const artifact = ownData(receipt, 'artifact');
  const bytes = ownData(artifact, 'bytes');
  if (!context?.run || !context.fixture || context.run.runId !== expected.runId ||
    registry.receipt('rawEvidence').rawArtifactRef !== expected.enrollmentRef ||
    !(bytes instanceof Uint8Array) || !bytes.length || bytes.length > 1048576) return unavailable();
  const proof = registry.sync('rawEvidence', 'verifyArtifactSync', {
    artifact, digest: digest(bytes), run: context.run, fixture: context.fixture, identityExpected: expected
  });
  return projectIdentityEvidence({ receipt, artifact, proof, expected });
}
