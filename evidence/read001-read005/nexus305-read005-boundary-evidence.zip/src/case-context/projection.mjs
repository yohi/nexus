// Data boundary only. Never freeze/traverse raw SDK graphs to hide capabilities.
const allowedCodes = new Set(['CASE_RESULT_UNSAFE', 'CASE_REQUEST_HANDLE_REQUIRED',
  'MAIN_OWNER_HANDLE_REQUIRED', 'MAIN_OWNER_CLOSE_AUTHORITY_UNSPECIFIED',
  'R3_EXECUTION_NOT_AUTHORIZED', 'R3_EXECUTION_AUTHORIZATION_REVOKED',
  'MAIN_REQUEST_AUTHORITY_DENIED', 'OWNER_TARGET_MISMATCH',
  'REPLAY_ENTITLEMENT_UNPROVEN', 'IDENTITY_EVIDENCE_UNAVAILABLE']);
const unsafe = () => { throw new Error('CASE_RESULT_UNSAFE'); };

/** @param {unknown} value */
export function projectData(value) {
  const active = new WeakSet();
  const copy = (input, depth) => {
    if (input === null || typeof input === 'string' || typeof input === 'boolean') return input;
    if (typeof input === 'number') return Number.isFinite(input) ? input : unsafe();
    if (typeof input !== 'object' || active.has(input) || depth > 64) return unsafe();
    const array = Array.isArray(input);
    const prototype = Object.getPrototypeOf(input);
    if (prototype !== null && prototype !== (array ? Array.prototype : Object.prototype)) return unsafe();
    active.add(input);
    const descriptors = Object.getOwnPropertyDescriptors(input);
    const keys = Reflect.ownKeys(descriptors);
    if (keys.some(key => typeof key !== 'string')) return unsafe();
    if (array) {
      const length = descriptors.length.value;
      const indices = keys.filter(key => key !== 'length');
      if (indices.length !== length || indices.some(key => Number(key) >= length)) return unsafe();
    }
    const result = array ? [] : Object.create(null);
    for (const key of keys) {
      if (array && key === 'length') continue;
      const descriptor = descriptors[key];
      if (!Object.hasOwn(descriptor, 'value') || !descriptor.enumerable) return unsafe();
      if (array && !/^(0|[1-9][0-9]*)$/.test(key)) return unsafe();
      Object.defineProperty(result, key, { value: copy(descriptor.value, depth + 1), enumerable: true });
    }
    if (array && result.length !== descriptors.length.value) return unsafe();
    active.delete(input);
    return Object.freeze(result);
  };
  return copy(value, 0);
}

/** Extract one own data value without executing a getter. Trusted values only;
 * proxies and mutable trusted intrinsics require venue isolation. */
export function ownData(input, key) {
  if (input === null || !['object', 'function'].includes(typeof input)) return undefined;
  const descriptor = Object.getOwnPropertyDescriptor(input, key);
  return descriptor && Object.hasOwn(descriptor, 'value') ? descriptor.value : undefined;
}

/** @param {unknown} error */
export function projectCaseError(error) {
  const candidate = ownData(error, 'code') ?? ownData(error, 'message');
  const code = typeof candidate === 'string' && allowedCodes.has(candidate) ? candidate : 'CASE_OPERATION_FAILED';
  return projectData({ ok: false, code });
}

export function projectCaseResult(operation, raw) {
  if (!['route', 'reconnect'].includes(operation)) return unsafe();
  const requestKey = ownData(raw, 'requestKey');
  const evidenceRef = ownData(raw, 'evidenceRef');
  if (![requestKey, evidenceRef].every(value => typeof value === 'string' && value.length > 0)) return unsafe();
  return projectData({ ok: true, operation, requestKey, evidenceRef });
}

export function projectScenarioResult(raw) {
  const result = Object.create(null);
  for (const key of ['runId', 'caseId', 'scenario', 'executionRef']) {
    const value = ownData(raw, key);
    if (typeof value !== 'string' || !value) return unsafe();
    result[key] = value;
  }
  return projectData(result);
}
