import { projectCaseError, projectCaseResult, projectData } from './projection.mjs';

/** Trusted closures in; approved operations and opaque handles out. */
export function createMainCaseFacade({ authorize, initialize, route, snapshot, resolveRequest }) {
  const owned = new WeakSet();
  const requireMain = main => {
    if ((typeof main !== 'object' || main === null) || !owned.has(main)) throw new Error('MAIN_OWNER_HANDLE_REQUIRED');
  };
  const invoke = async (operation, main, requestHandle) => {
    try {
      authorize(); requireMain(main);
      const request = resolveRequest(requestHandle);
      const result = await route(operation, main, request);
      authorize();
      return projectCaseResult(operation, result);
    } catch (error) { return projectCaseError(error); }
  };
  return Object.freeze(Object.assign(Object.create(null), {
    initialize: async requestHandle => {
      try {
        authorize();
        const request = resolveRequest(requestHandle);
        const main = await initialize(request);
        authorize(); owned.add(main);
        return main;
      } catch (error) { throw new Error(projectCaseError(error).code); }
    },
    route: (main, requestHandle) => invoke('route', main, requestHandle),
    reconnect: (main, requestHandle) => invoke('reconnect', main, requestHandle),
    snapshot: async main => {
      try {
        authorize(); requireMain(main);
        const data = await snapshot(main);
        authorize(); return projectData(data);
      } catch (error) { return projectCaseError(error); }
    }
  }));
}
