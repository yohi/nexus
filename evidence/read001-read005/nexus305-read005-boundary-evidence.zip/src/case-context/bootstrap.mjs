import { createMainCaseFacade } from './facade.mjs';
import { publishActualHTTP } from '../drivers/integration.mjs';
import { ownData } from './projection.mjs';

/** Trusted composition only. Never pass this shell, dependencies, or input data
 * to ordinary cases. Venue enrollment must bind the actual loader/authorizer. */
export function createCaseBoundary({ drivers, modules, registry, serverSetup, authorize }) {
  if (!drivers?.replay || drivers.registry !== registry || !modules ||
    typeof serverSetup?.waitHandler !== 'function' || typeof authorize !== 'function')
    throw new Error('VENUE_CAPABILITY_UNENROLLED:CASE_BOUNDARY');
  const requests = new WeakMap();
  const replay = drivers.replay;
  const check = () => {
    if (authorize() !== undefined) throw new Error('R3_EXECUTION_NOT_AUTHORIZED');
  };
  const resolveRequest = (handle, issuance) => {
    const binding = handle && typeof handle === 'object' ? requests.get(handle) : undefined;
    if (!binding || binding.owner && binding.owner !== issuance) throw new Error('CASE_REQUEST_HANDLE_REQUIRED');
    const request = binding.request;
    check(); replay.requestBoundary.context(request);
    binding.owner = issuance;
    return request;
  };
  const route = async (operation, main, request) => {
    check();
    const isReplay = request.method === 'GET' && request.headers.has('last-event-id');
    if ((operation === 'reconnect') !== isReplay) throw new Error('REPLAY_ENTITLEMENT_UNPROVEN');
    const driver = await drivers.sdkWeb(main);
    check();
    // Canonical resolver targets must not be supplied back as external aliases.
    const outcome = await driver.route(request, undefined, request.signal);
    check();
    const target = replay.requestBoundary.targetFor(request);
    if (!isReplay) {
      const plan = ownData(outcome, 'privatePlan');
      if (!Array.isArray(plan)) throw new Error('CASE_RESULT_UNSAFE');
      const result = await publishActualHTTP(drivers, { ...target, plan, publicationMode: 'NEW' });
      if (result?.accepted === false) throw new Error('MAIN_REQUEST_AUTHORITY_DENIED');
    }
    check();
    const evidence = await replay.mainOwners.snapshotIdentity(main, request);
    check();
    return { requestKey: target.envelope.requestKey, evidenceRef: evidence.rawArtifactRef };
  };
  return Object.freeze(Object.assign(Object.create(null), {
    bindRequest: async (request, externalContext) => {
      check();
      await replay.requestBoundary.bindWeb(request, externalContext);
      check();
      const handle = Object.freeze(Object.create(null));
      requests.set(handle, { request, owner: null }); return handle;
    },
    issueCase: () => {
      check();
      const issuance = Object.freeze(Object.create(null));
      return createMainCaseFacade({ authorize: check, resolveRequest: handle => resolveRequest(handle, issuance),
        initialize: request => replay.initialize({ request }), route,
        snapshot: main => replay.mainOwners.snapshotIdentity(main) });
    }
  }));
}
