import { fileURLToPath } from 'node:url';
export async function stopEnrolledRun(enrollment, authority, observer, adapter) {
  authority.hold = true;
  authority.unknown = true;
  await observer.captureBeforeStop(enrollment);
  // An enrolled service/cgroup adapter must check starttime, nonce and unit
  // identity before stopping. No pkill, killall or PID-only targeting.
  return adapter.stopExactEnrolledUnit(enrollment);
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  throw new Error('STOP_BINDING_BLOCKED: NO_ENROLLED_UNIT_OR_PERMISSION');
}
