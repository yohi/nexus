export class NativeIOObserver {
  constructor(enrollment) { this.enrollment = enrollment; this.operations = new Map(); this.gaps = []; }
  observe(record) {
    if (!this.enrollment.matches(record.processIdentity)) throw new Error('OBSERVER_TARGET_MISMATCH');
    if (!record.rawArtifactRef || !record.tid || !record.fdInode || !record.operationId) throw new Error('UNBOUND_OS_OBSERVATION');
    if (record.event === 'NATIVE_ENTER') this.operations.set(record.operationId, record);
    if (record.event === 'NATIVE_EXIT') this.operations.delete(record.operationId);
    if (record.event === 'OBSERVER_GAP') this.gaps.push(record);
    if (record.event === 'SIGNAL_DELIVERY') {
      const active = this.operations.get(record.operationId);
      return { inFlight: Boolean(active && active.tid === record.tid && active.fdInode === record.fdInode && record.causalParents.includes(active.eventId)), gaps: this.gaps.length };
    }
    return null;
  }
}
