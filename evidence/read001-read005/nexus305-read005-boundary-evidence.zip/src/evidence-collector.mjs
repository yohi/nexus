import { createHash } from 'node:crypto';
export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
export class EvidenceCollector {
  constructor(identity, sink) {
    for (const field of ['runId', 'testId', 'variant', 'actorId', 'processIdentity']) if (!identity[field]) throw new Error(`UNBOUND_EVIDENCE_IDENTITY:${field}`);
    for (const field of ['pid', 'starttime', 'bootId', 'euid', 'egid', 'groups', 'capabilities']) if (identity.processIdentity[field] === undefined) throw new Error(`UNBOUND_PROCESS_IDENTITY:${field}`);
    this.identity = identity; this.sink = sink; this.sequence = 0; this.last = null;
  }
  event(event, observation, causalParents = []) {
    const eventId = `${this.identity.runId}:${++this.sequence}`;
    const record = { schemaVersion: 'r3-execution-evidence/1', ...this.identity,
      eventId, event, rawEvent: event, seq: this.sequence, ownerSeq: this.identity.actorId === 'gateowner' ? this.sequence : null,
      caseId: this.identity.caseId ?? null, barrierId: observation.barrierId ?? null,
      operationId: observation.operationId ?? null, requestKey: observation.requestKey ?? null, attemptId: observation.attemptId ?? null,
      epoch: observation.epoch ?? null, generation: observation.generation ?? null, physicalPairId: observation.physicalPairId ?? null,
      publicationRevision: observation.publicationRevision ?? null, authorityRevision: observation.authorityRevision ?? null, slotRevision: observation.slotRevision ?? null,
      artifactRefs: observation.artifactRefs ?? [],
      causalParents: [...new Set([...causalParents, ...(this.last ? [this.last] : [])])],
      monoNs: process.hrtime.bigint().toString(), wallTime: new Date().toISOString(), observation };
    this.sink(record); this.last = eventId;
    return eventId;
  }
}
