import { frozen, requireValue, hash, deny } from './common.mjs';

// Providers are owner-enrolled verifier implementations (real signature/chain,
// audience, replay protection, expiry and revocation), not client assertions.
// Until independently bound this interface cannot confer real authentication.
export class TrustedIngress {
  #receipts = new WeakMap(); #lastTime = -Infinity;
  constructor(provider, clock, emit) {
    requireValue(provider?.verify && provider?.revalidateSync && provider?.bindingReceipt,
      'VENUE_TRUST_BINDING_REQUIRED');
    this.provider = provider; this.clock = clock; this.emit = emit;
  }
  now() {
    const now = this.clock();
    requireValue(Number.isSafeInteger(now) && now >= this.#lastTime, 'TRUST_CLOCK_ROLLBACK');
    this.#lastTime = now; return now;
  }
  async authenticate(request) {
    const result = await this.provider.verify(request);
    for (const key of ['issuer', 'tenant', 'subject', 'authRealm', 'assuranceClass', 'credential_family',
      'credential_digest', 'issuer_key_generation', 'auth_policy_revision', 'rawArtifactRef']) {
      requireValue(typeof result?.[key] === 'string' && result[key], 'AUTHN_FAILED');
    }
    requireValue(result.expires_at > this.now() && Number.isInteger(result.revocation_version), 'AUTHN_FAILED');
    const fields = ['issuer', 'tenant', 'subject', 'authRealm', 'assuranceClass', 'credential_family',
      'credential_digest', 'issuer_key_generation', 'auth_policy_revision', 'rawArtifactRef',
      'expires_at', 'revocation_version', 'requestIdentity', 'trustRootRef', 'clockReceipt', 'rotationReceipt'];
    const principal = frozen({ ...Object.fromEntries(fields.map(key => [key, result[key]])), principal_key: hash(JSON.stringify([
      result.issuer, result.tenant, result.subject, result.authRealm, result.assuranceClass])) });
    const receipt = Object.freeze({}); this.#receipts.set(receipt, principal);
    this.emit('AUTHN_VERIFIED', { principal_key: principal.principal_key, rawArtifactRef: principal.rawArtifactRef });
    return receipt;
  }
  current(receipt) {
    const principal = this.#receipts.get(receipt) ?? deny('AUTHN_RECEIPT_REQUIRED');
    requireValue(principal.expires_at > this.now() && this.provider.revalidateSync(principal) === true, 'CREDENTIAL_REVOKED');
    return principal;
  }
}
