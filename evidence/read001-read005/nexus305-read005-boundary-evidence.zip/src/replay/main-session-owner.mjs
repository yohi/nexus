import { requireValue, match } from './common.mjs';

// Owner-local references, never reconstructed from an external session ID.
// A receipt is necessary but cannot replace actual Transport/Server identity.
export class MainSessionOwners {
  #sessions = new Map(); #handles = new WeakMap();
  #receipts; #observer; #requestBoundary;
  constructor({ receipts, observer, requestBoundary }) {
    this.#receipts = receipts; this.#observer = observer; this.#requestBoundary = requestBoundary;
    Object.freeze(this);
  }
  register({ transport, server, session, attempt }) {
    this.#observer.assertTransport(attempt, transport, server);
    this.#observer.assertActive(session);
    requireValue(transport.sessionId === session.session_id && session.transport_instance === attempt.transportId &&
      session.init_attempt_nonce === attempt.nonce && session.init_status === 'ACTIVE' &&
      session.active_commit_receipt && !this.#sessions.has(session.session_id), 'MAIN_OWNER_ACTIVE_BINDING_REQUIRED');
    // The WeakMap's object identity is the authority, not fields or serialization.
    const handle = Object.freeze(Object.create(null));
    const binding = Object.freeze({ transport, server, session, attempt, boot: this.#observer.bootId });
    this.#sessions.set(session.session_id, binding); this.#handles.set(handle, binding);
    return handle;
  }
  #binding(handle) {
    const binding = this.#handles.get(handle);
    requireValue(binding && this.#sessions.get(binding.session.session_id) === binding, 'MAIN_OWNER_HANDLE_REQUIRED');
    this.#observer.assertTransport(binding.attempt, binding.transport, binding.server);
    return binding;
  }
  assertHandle(handle) { this.#binding(handle); }
  async snapshotIdentity(handle, request) {
    const binding = this.#binding(handle);
    const admitted = request ? await this.#admit(handle, request) : null;
    const principal = this.#receipts.ingress.current(admitted?.ticket ?? binding.attempt.authTicket);
    const current = this.#receipts.ledger.activeSession(binding.session.session_id, principal);
    match(current, binding.session, ['session_id', 'transport_instance', 'init_attempt_nonce', 'active_commit_receipt'], 'MAIN_SESSION_TARGET_MISMATCH');
    requireValue(binding.boot === this.#observer.bootId, 'MAIN_REQUEST_AUTHORITY_DENIED');
    return this.#observer.projectActiveIdentity({ row: current, attempt: binding.attempt,
      transport: binding.transport, server: binding.server, principal,
      requestIdentity: request ? principal.requestIdentity : undefined });
  }
  // Public replay admission exposes neither binding nor authentication ticket.
  async admit(handle, request, target) { await this.#admit(handle, request, target); }
  async #admit(handle, request, target) {
    const binding = this.#binding(handle);
    const owner = this.#requestBoundary.targetFor(request, target);
    const ticket = await this.#receipts.ingress.authenticate(request);
    const principal = this.#receipts.ingress.current(ticket);
    const session = this.#receipts.ledger.activeSession(request.headers.get('mcp-session-id'), principal);
    match(session, binding.session, ['session_id', 'transport_instance', 'init_attempt_nonce', 'active_commit_receipt'], 'MAIN_SESSION_TARGET_MISMATCH');
    requireValue(owner.envelope.sessionId === session.session_id && owner.envelope.transportInstance === session.transport_instance &&
      owner.transportId === session.transport_instance && request.headers.get('mcp-protocol-version') &&
      request.headers.get('mcp-protocol-version') === session.protocol_version &&
      this.#requestBoundary.policy.protocolVersions.includes(session.protocol_version), 'MAIN_SESSION_TARGET_MISMATCH');
    requireValue(this.#receipts.gate.authority.allows(owner.envelope), 'MAIN_REQUEST_AUTHORITY_DENIED');
    return { binding, owner, ticket };
  }
  async dispatch(handle, request, target) {
    requireValue(!request.headers.has('last-event-id'), 'REPLAY_BROKER_REQUIRED');
    if (request.method === 'POST') requireValue((await request.clone().json())?.method !== 'initialize', 'FRESH_INITIALIZE_ROUTE_REQUIRED');
    const { binding, owner, ticket } = await this.#admit(handle, request, target);
    // Last checks are synchronous. Individual request abort is not session close.
    request.signal.throwIfAborted();
    const principal = this.#receipts.ingress.current(ticket);
    const current = this.#receipts.ledger.activeSession(binding.session.session_id, principal);
    requireValue(binding.boot === this.#observer.bootId && binding.transport.sessionId === current.session_id &&
      this.#receipts.gate.authority.allows(owner.envelope), 'MAIN_REQUEST_AUTHORITY_DENIED');
    this.#observer.assertTransport(binding.attempt, binding.transport, binding.server);
    const admission = this.#observer.verifyMainDispatchSync({
      request, owner, principal, session: current, transport: binding.transport, server: binding.server, attempt: binding.attempt
    });
    requireValue(admission?.rawArtifactRef && admission.independentObserverRef && admission.bootId === binding.boot &&
      admission.transport === binding.transport && admission.server === binding.server &&
      admission.sessionId === current.session_id && admission.activeCommitToken === current.active_commit_receipt &&
      admission.principalKey === principal.principal_key && admission.requestIdentity === principal.requestIdentity &&
      admission.authorityReceipt && admission.grantReceipt && admission.allowed === true, 'MAIN_DISPATCH_OWNER_AUTHORITY_UNPROVEN');
    return binding.transport.handleRequest(request);
  }
}
