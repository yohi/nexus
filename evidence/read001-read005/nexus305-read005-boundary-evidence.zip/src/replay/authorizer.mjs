import { frozen, nonce, requireValue, match, deny } from './common.mjs';
import { eligibleEvent, validateAnchor, eventKind } from './event-authorization.mjs';
import { assertStoredFrame } from '../stored-event-binding.mjs';

export class ReplayAuthorizer {
  #prepared = new WeakMap(); #closed = new Set();
  constructor({ ledger, events, ingress, authority, verifier, emit }) {
    requireValue(events && verifier?.verifySync && verifier?.authorityReceiptSync && verifier?.ownerReceiptSync &&
      verifier?.finalOwnershipSync && verifier?.maximumGrantExpirySync && verifier?.liveWriterFencedSync &&
      verifier?.bindingReceipt, 'AUTHORITY_BINDING_BLOCKED');
    Object.assign(this, { ledger, events, ingress, authority, verifier, emit });
  }
  current(ticket, envelope) {
    const principal = this.ingress.current(ticket);
    const authority = this.verifier.authorityReceiptSync(envelope);
    requireValue(this.authority.allows(envelope) && authority?.durableReceipt &&
      Number.isInteger(authority.fence_revision) && this.verifier.finalOwnershipSync() === true, 'AUTHORITY_BINDING_BLOCKED');
    return { principal, authority };
  }
  enrollStream(streamId, sessionId, ticket, origin) {
    const principal = this.ingress.current(ticket); const session = this.ledger.activeSession(sessionId, principal);
    const observed = this.verifier.ownerReceiptSync({ streamId, sessionId, origin });
    requireValue(observed?.rawArtifactRef && observed.streamId === streamId && observed.sessionId === sessionId &&
      observed.transportId === session.transport_instance, 'STREAM_OWNER_UNPROVEN');
    return this.ledger.commit('stream', streamId, () => this.ledger.insert('stream', { stream_id: streamId, session_id: sessionId },
      { principal_key: principal.principal_key, tenant: principal.tenant, lineage_root: session.lineage_root,
        transport_instance: session.transport_instance, source_receipt: observed.rawArtifactRef }));
  }
  enrollEvent(id, ticket) {
    const row = this.events.lookup(id); const principal = this.ingress.current(ticket);
    const session = this.ledger.activeSession(row.session, principal); const stream = this.ledger.read('stream', row.stream);
    requireValue(stream.session_id === row.session && row.transport_instance === session.transport_instance, 'EVENT_OWNER_DENIED');
    const proof = this.verifier.ownerReceiptSync({ row });
    requireValue(proof?.identityDigest === row.identity_digest && proof?.rawArtifactRef, 'EVENT_PROVENANCE_UNPROVEN');
    const kind = eventKind(row.message);
    return this.ledger.commit('event', id, () => this.ledger.insert('event', { event_id: id, event_kind: kind },
      { identity_digest: row.identity_digest, principal_key: principal.principal_key, tenant: principal.tenant,
        lineage_root: session.lineage_root, source_receipt: proof.rawArtifactRef,
        replay_safe_receipt: kind === 'NORMAL_REPLAY_SAFE' ? proof.replaySafeReceipt : null }));
  }
  storeAdmission(envelope, message, streamId) {
    const proof = this.verifier.ownerReceiptSync({ envelope, message, streamId });
    requireValue(proof?.authTicket && proof.rawArtifactRef && proof.sessionId === envelope.sessionId &&
      proof.transportId === envelope.transportInstance && streamId === envelope.streamId, 'STORE_OWNER_UNPROVEN');
    const { principal } = this.current(proof.authTicket, envelope);
    const session = this.ledger.read('session', envelope.sessionId);
    match(session, principal, ['principal_key', 'tenant'], 'STORE_OWNER_DENIED');
    if (session.init_status === 'STAGED' && eventKind(message) === 'PRIMING') {
      requireValue(proof.initAttemptNonce === session.init_attempt_nonce, 'INIT_PRIMING_OWNER_DENIED');
      return; // PRIVATE pending anchor only: no stream enrollment or grant.
    }
    this.ledger.activeSession(envelope.sessionId, principal);
    const stream = this.ledger.read('stream', streamId);
    requireValue(stream.session_id === envelope.sessionId && stream.transport_instance === envelope.transportInstance, 'STORE_STREAM_DENIED');
  }
  releaseAdmission(plan, envelope) {
    const proof = this.verifier.ownerReceiptSync({ envelope });
    requireValue(proof?.authTicket && proof.rawArtifactRef, 'RELEASE_OWNER_UNPROVEN');
    const { principal } = this.current(proof.authTicket, envelope);
    this.ledger.activeSession(envelope.sessionId, principal);
    for (const frame of plan) if (frame.kind === 'sse-frame') {
      const row = this.events.lookup(frame.eventId);
      requireValue(row.original_request === envelope.requestKey && row.session === envelope.sessionId &&
        this.verifier.verifySync(row, envelope, proof.rawArtifactRef) === true, 'RELEASE_CURRENT_VERIFICATION_FALSE');
    }
  }
  issue({ ticket, sessionId, streamId, envelope, cursorFloor, ceiling, eventIds, expiresAt, anchor = null }) {
    const { principal, authority } = this.current(ticket, envelope);
    const session = this.ledger.activeSession(sessionId, principal); const stream = this.ledger.read('stream', streamId);
    match(stream, session, ['principal_key', 'tenant', 'lineage_root'], 'STREAM_OWNER_DENIED');
    requireValue(envelope.sessionId === sessionId && (anchor || stream.session_id === sessionId), 'GRANT_SESSION_SCOPE_DENIED');
    requireValue(stream.transport_instance && Number.isInteger(cursorFloor) && Number.isInteger(ceiling) &&
      ceiling >= cursorFloor && expiresAt > this.ingress.now() && expiresAt <= principal.expires_at &&
      expiresAt <= session.expires_at && expiresAt <= this.verifier.maximumGrantExpirySync(session), 'GRANT_EXPIRY_OR_RANGE_INVALID');
    const grantId = nonce();
    const grant = { grant_id: grantId, grant_version: 1, status: 'ACTIVE', owner_session_id: sessionId,
      stream_id: streamId, expires_at: expiresAt, nonce: nonce(), principal_key: principal.principal_key, tenant: principal.tenant,
      credential_family: principal.credential_family, auth_policy_revision: principal.auth_policy_revision,
      revocation_version: 0, credential_revocation_version: principal.revocation_version,
      lineage_root: session.lineage_root, allowed_session_lineage_revision: session.lineage_revision,
      target_session_receipt: session.active_commit_receipt, original_session_id: envelope.sessionId,
      original_request_key: envelope.requestKey, transport_instance: stream.transport_instance,
      cursor_floor_sequence: cursorFloor, released_ceiling_sequence: ceiling, event_digests: {},
      authority: frozen(envelope), fence_revision: authority.fence_revision, created_authority_receipt: authority.durableReceipt,
      event_class_allowlist: ['notifications/progress'], allowed_transport: 'MCP_STREAMABLE_HTTP_SSE',
      grant_kind: anchor ? (eventIds.length ? 'ANCHOR_WITH_NEW_EVENTS' : 'ANCHOR_ONLY') : 'NORMAL',
      authorized_anchor_binding_id: anchor ? nonce() : null };
    for (const id of eventIds) grant.event_digests[id] = this.events.lookup(id).identity_digest;
    for (const id of eventIds) eligibleEvent(this.events.lookup(id), this.ledger.read('event', id), grant, session, envelope, this.authority, this.verifier);
    const binding = anchor ? { ...anchor.binding, anchor_binding_id: grant.authorized_anchor_binding_id, grant_id: grantId,
      grant_version: 1, successor_session_id: sessionId, successor_lineage_revision: session.lineage_revision, status: 'ACTIVE' } : null;
    if (anchor) {
      const cursor = this.events.lookup(anchor.eventId);
      const metadata = this.ledger.read('anchor', anchor.eventId);
      validateAnchor(metadata, binding, grant, session, cursor);
      const lineage = this.ledger.read('lineage', sessionId);
      requireValue(lineage.predecessor_id === cursor.session && lineage.migration_receipt &&
        lineage.monotonic_sequence_receipt, 'ANCHOR_LINEAGE_UNPROVEN');
    }
    return this.ledger.commit('grant', grantId, () => {
      this.current(ticket, envelope); this.ledger.activeSession(sessionId, principal);
      this.ledger.insert('grant', { grant_id: grantId, grant_version: 1, status: 'ACTIVE', owner_session_id: sessionId,
        stream_id: streamId, expires_at: expiresAt, nonce: grant.nonce }, grant);
      if (binding) this.ledger.insert('binding', { anchor_binding_id: binding.anchor_binding_id, grant_id: grantId,
        grant_version: 1, anchor_event_id: anchor.eventId, successor_session_id: sessionId,
        successor_lineage_revision: session.lineage_revision, status: 'ACTIVE' }, binding);
    });
  }
  verify(context, stage) {
    requireValue(context.deadline > this.ingress.now(), 'GRANT_INVOCATION_EXPIRED');
    if (stage !== 'ADMISSION') {
      const invocation = this.ledger.read('invocation', context.invocation_id);
      const lease = this.ledger.store.db.prepare('SELECT lease_key FROM replay_stream_leases WHERE invocation_id=?').get(context.invocation_id);
      requireValue(invocation.status === 'RESERVED' && lease && this.ledger.read('lease', lease.lease_key).state === 'HELD', 'SDK_CALLBACK_SEALED');
    }
    const { principal, authority } = this.current(context.authTicket, context.envelope);
    const session = this.ledger.activeSession(context.sessionId, principal);
    const grant = this.ledger.read('grant', context.grantId);
    requireValue(!this.#closed.has(grant.grant_id) && grant.status === 'ACTIVE' &&
      grant.grant_version === context.grantVersion && grant.owner_session_id === session.session_id &&
      grant.allowed_session_lineage_revision === session.lineage_revision && grant.target_session_receipt === session.active_commit_receipt &&
      grant.expires_at > this.ingress.now() && grant.credential_revocation_version === principal.revocation_version &&
      grant.fence_revision === authority.fence_revision, 'GRANT_REVOKED_OR_EXPIRED');
    match(grant, principal, ['principal_key', 'tenant', 'credential_family', 'auth_policy_revision'], 'GRANT_OWNER_DENIED');
    match(grant, session, ['lineage_root'], 'SESSION_LINEAGE_MISMATCH');
    const revocations = this.ledger.store.db.prepare('SELECT grant_id FROM replay_revocations WHERE grant_id=?').get(grant.grant_id);
    requireValue(!revocations, 'GRANT_REVOKED');
    const stream = this.ledger.read('stream', grant.stream_id);
    match(stream, session, ['principal_key', 'tenant', 'lineage_root'], 'STREAM_OWNER_DENIED');
    requireValue(context.streamId === grant.stream_id, 'STREAM_SCOPE_DENIED');
    const cursor = this.events.lookup(context.cursor);
    if (grant.authorized_anchor_binding_id) {
      const binding = this.ledger.read('binding', grant.authorized_anchor_binding_id);
      validateAnchor(this.ledger.read('anchor', cursor.id), binding, grant, session, cursor);
      const lineage = this.ledger.read('lineage', session.session_id);
      const tombstone = this.verifier.tombstoneReceiptSync?.(cursor);
      requireValue(lineage.predecessor_id === cursor.session && lineage.migration_receipt && lineage.monotonic_sequence_receipt &&
        tombstone?.reason === 'ORIGIN_EPOCH_SUPERSEDED' && tombstone.identityDigest === cursor.identity_digest &&
        tombstone.rawArtifactRef && !tombstone.compromised, 'ANCHOR_CURRENT_AUTHORITY_UNPROVEN');
      requireValue(context.anchorBindingId === binding.anchor_binding_id, 'ANCHOR_SCOPE_OR_VERSION_DENY');
    } else {
      requireValue(cursor.session === grant.original_session_id && cursor.stream === grant.stream_id &&
        cursor.original_request === grant.original_request_key && cursor.state !== 'REVOKED' && cursor.sequence >= grant.cursor_floor_sequence &&
        cursor.sequence <= grant.released_ceiling_sequence, 'CURSOR_SCOPE_DENIED');
      match(cursor.auth, grant.authority, ['epoch', 'generation', 'pairId', 'publicationRevision'], 'CURSOR_NO_RELABEL');
      const metadata = this.ledger.read('event', cursor.id);
      match(metadata, session, ['principal_key', 'tenant', 'lineage_root'], 'CURSOR_OWNER_DENIED');
    }
    for (const event of context.events) {
      const row = this.events.lookup(event.id);
      requireValue(row.sequence > cursor.sequence && row.identity_digest === event.identity_digest &&
        row.message_wire === event.message_wire && JSON.stringify(row.message) === JSON.stringify(event.message) &&
        row.sequence === event.sequence, 'EVENT_PLAN_MISMATCH');
      eligibleEvent(row, this.ledger.read('event', row.id), grant, session, context.envelope, this.authority, this.verifier);
    }
    if (stage !== 'FINAL_P') this.emit('REPLAY_AUTHORIZE', { stage, grantVersion: grant.grant_version, sessionId: session.session_id, cursor: cursor.id });
    return { session, grant, cursor };
  }
  assertFrames(context, frames) {
    requireValue(frames.length === context.events.length, 'PRIVATE_FRAME_COUNT_MISMATCH');
    frames.forEach((frame, index) => assertStoredFrame(context.events[index], frame));
  }
  verifyInitialization(context) {
    const { principal } = this.current(context.authTicket, context.envelope);
    const session = this.ledger.read('session', context.sessionId);
    match(session, principal, ['principal_key', 'tenant', 'credential_family', 'auth_policy_revision'], 'INIT_OWNER_DENIED');
    requireValue(session.init_status === 'VERIFIED' && session.init_verified_receipt &&
      session.init_attempt_nonce === context.attemptNonce && session.transport_instance === context.envelope.transportInstance,
      'INIT_VERIFIED_RECEIPT_REQUIRED');
    return session;
  }
  prepare(context) {
    const verified = this.verify(context, 'ADMISSION');
    const references = this.ledger.store.db.prepare('SELECT id FROM r3_bound_events_v2 WHERE stream=? AND sequence>? AND sequence<=? ORDER BY sequence')
      .all(context.streamId, verified.cursor.sequence, verified.grant.released_ceiling_sequence);
    requireValue(references.length === context.events.length && references.every((row, index) => row.id === context.events[index].id), 'EVENT_PLAN_NOT_EXACT');
    const ticket = Object.freeze({}); this.#prepared.set(ticket, context); return ticket;
  }
  context(ticket) { return this.#prepared.get(ticket) ?? deny('REPLAY_PUBLICATION_TICKET_REQUIRED'); }
  revoke(grantId, reason, decision) {
    this.#closed.add(grantId); // Synchronous deny BEFORE durable I/O.
    this.emit('REPLAY_REVOCATION_RECOGNIZED', { grantId, reason, decision });
    return this.ledger.revoke(grantId, reason, decision);
  }
}
