import { bufferPrivateResponse } from '../adapters/final-write.mjs';
import { frameSSE } from '../adapters/http-publication.mjs';
import { nonce, hash, requireValue, match } from './common.mjs';

// The trusted dispatch observer must bind an actual SDK send(result) completion
// to the authenticated request/transport; envelope success alone is insufficient.
export class InitializeReceipts {
  constructor({ ledger, ingress, gate, observer, emit }) {
    requireValue(observer?.verifyCompletion && observer?.bindingReceipt, 'VENUE_BINDING_REQUIRED:INIT_COMPLETION');
    Object.assign(this, { ledger, ingress, gate, observer, emit });
  }
  stage(sessionId, attempt) {
    const principal = this.ingress.current(attempt.authTicket);
    return this.ledger.commit('session', sessionId, () => this.ledger.insert('session', {
      session_id: sessionId, version: 1, init_status: 'STAGED', principal_key: principal.principal_key,
      tenant: principal.tenant, transport_instance: attempt.transportId, init_attempt_nonce: attempt.nonce
    }, { ...principal, sdk_session_id: sessionId, init_request_id: attempt.requestId,
      lineage_root: nonce(), lineage_revision: 1, authn_receipt: principal.rawArtifactRef }));
  }
  transition(sessionId, previous, status, patch) {
    return this.ledger.commit('session', sessionId, () => this.ledger.cas('session', sessionId, previous,
      patch, { init_status: status, version: previous.version + 1 }));
  }
  async complete({ response, sessionId, attempt, target, signal }) {
    let row = this.ledger.read('session', sessionId);
    try {
      requireValue(row.init_status === 'STAGED' && row.init_attempt_nonce === attempt.nonce, 'INIT_ATTEMPT_MISMATCH');
      requireValue(response.status === 200 && response.headers.get('mcp-session-id') === sessionId &&
        response.headers.get('content-type')?.startsWith('text/event-stream'), 'INIT_PRIVATE_RESPONSE_INVALID');
      const bytes = await bufferPrivateResponse(response, 1048576, { signal, timeoutMs: 10000 });
      const frames = frameSSE(bytes);
      const resultFrames = frames.filter(frame => frame.bytes.toString().startsWith('event: message\n'));
      requireValue(resultFrames.length === 1 && frames.length <= 2, 'INIT_PARTIAL_OR_EXTRA_RESULT');
      const resultFrame = resultFrames[0];
      const line = resultFrame.bytes.toString().split('\n').find(text => text.startsWith('data: '));
      const message = JSON.parse(line?.slice(6) ?? 'null');
      requireValue(message?.jsonrpc === '2.0' && message.id === attempt.requestId && !('error' in message) &&
        typeof message.result?.protocolVersion === 'string' && message.result.capabilities &&
        typeof message.result.serverInfo?.name === 'string' && typeof message.result.serverInfo?.version === 'string', 'INIT_RESULT_INVALID');
      const completion = await this.observer.verifyCompletion({ sessionId, attempt, result: message, frameDigest: hash(resultFrame.bytes) });
      requireValue(completion?.rawArtifactRef && completion.transportId === attempt.transportId &&
        completion.requestId === attempt.requestId && completion.resultDigest === hash(JSON.stringify(message)), 'INIT_SERVER_COMPLETION_UNPROVEN');
      this.ingress.current(attempt.authTicket);
      requireValue(this.gate.authority.allows(target.envelope), 'INIT_AUTHORITY_DENIED');
      const priming = frames.filter(frame => frame !== resultFrame);
      if (priming.length) requireValue(/^id: [^\r\n]+\ndata: \n\n$/.test(priming[0].bytes.toString()), 'INIT_PRIMING_WIRE_INVALID');
      row = this.transition(sessionId, row, 'VERIFIED', { init_result_digest: hash(resultFrame.bytes),
        init_verified_receipt: completion.rawArtifactRef, private_body_digest: hash(bytes), protocol_version: message.result.protocolVersion });
      const plan = [{ kind: 'header', status: 200, headers: {
        'content-type': 'text/event-stream', 'mcp-session-id': sessionId, 'cache-control': 'no-cache, no-transform'
      } }, ...frames, { kind: 'end', bytes: Buffer.alloc(0) }];
      const receipt = await target.publishInitialization(plan, () => {
        this.ingress.current(attempt.authTicket);
        const current = this.ledger.read('session', sessionId);
        match(current, row, ['version', 'init_status', 'durable_commit_receipt'], 'INIT_CAS_LOST');
        requireValue(this.gate.authority.allows(target.envelope), 'INIT_AUTHORITY_DENIED');
      });
      requireValue(receipt?.completeResultP && receipt?.endP && receipt.rawArtifactRef &&
        receipt.resultDigest === hash(resultFrame.bytes), 'INIT_P_UNKNOWN');
      row = this.transition(sessionId, row, 'PUBLISHED', { init_response_p_receipt: receipt.rawArtifactRef });
      await target.barrier?.('INIT_PUBLISHED_BEFORE_ACTIVE');
      signal.throwIfAborted(); this.ingress.current(attempt.authTicket);
      requireValue(this.gate.authority.allows(target.envelope) && !target.response.destroyed, 'INIT_ACTIVE_GAP_FENCED');
      row = this.ledger.commit('session', sessionId, () => {
        this.ledger.cas('session', sessionId, row, { active_commit_receipt: nonce() }, { init_status: 'ACTIVE', version: row.version + 1 });
        this.ledger.insert('lineage', { session_id: sessionId, predecessor_id: null, lineage_root: row.lineage_root, revision: 1 },
          { principal_key: row.principal_key, tenant: row.tenant, lineage_revision: 1, migration_receipt: 'INITIAL_ENROLLMENT' });
      });
      this.observer.confirmActive(row, attempt);
      return row;
    } catch (error) {
      const latest = this.ledger.read('session', sessionId);
      this.observer.fence(attempt.transportId, sessionId);
      this.transition(sessionId, latest,
        target.response.headersSent ? 'SUSPENDED' : 'FENCED', { fault_reason: error.message });
      this.emit('INIT_FENCED_GRANT_ZERO', { sessionId, reason: error.message });
      throw error;
    }
  }
  // Restart never restores SDK memory. Every historical ACTIVE session is
  // suspended; a fresh real initialize and explicit predecessor CAS are needed.
  suspendOnBoot() {
    for (const row of this.ledger.store.db.prepare("SELECT session_id FROM replay_session_owners WHERE init_status NOT IN ('FENCED','SUSPENDED')").all()) {
      const prior = this.ledger.read('session', row.session_id);
      this.transition(row.session_id, prior, 'SUSPENDED', { fault_reason: 'RESTART_FRESH_INITIALIZE_REQUIRED' });
    }
  }
  endSession(sessionId, transportId, reason) {
    // Close recognition denies synchronously, even if durable CAS fails later.
    this.observer.fence(transportId, sessionId);
    if (!sessionId) return;
    const previous = this.ledger.read('session', sessionId);
    requireValue(previous.transport_instance === transportId, 'SESSION_CLOSE_OWNER_MISMATCH');
    if (['FENCED', 'SUSPENDED'].includes(previous.init_status)) return;
    this.transition(sessionId, previous, 'SUSPENDED', { fault_reason: reason });
    for (const row of this.ledger.store.db.prepare('SELECT grant_id FROM replay_grants WHERE owner_session_id=?').all(sessionId))
      this.ledger.revoke(row.grant_id, reason, 'MAIN_SESSION_CLOSE');
  }
}
