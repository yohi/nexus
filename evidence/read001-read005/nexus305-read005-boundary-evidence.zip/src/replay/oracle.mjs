// Counterexample-first oracle, not an execution permit or design self-approval.
const positives = new Set(['genuine-progress', 'anchor-empty', 'anchor-new-event', 'restart-fresh-successor',
  'priming-empty', 'initialize-success', 'two-sequential-nonempty', 'different-request-key',
  'distinct-stream-concurrent', 'two-principal-parallel', 'cancel-public-close']);
const unsafe = ['unauthorizedRelease', 'terminalClaimDelta', 'terminalReplaySend', 'oldPayloadAfterC0',
  'wrongPrincipalP', 'wrongStreamP', 'primingPayloadP', 'provenanceRelabel', 'mainSessionClosed', 'lateCallbackP'];
const sequence = ['SDK_GET_ENTER', 'SDK_LOOKUP_OK', 'SDK_REPLAY_ENTER', 'SDK_REPLAY_CALLBACK_SETTLED',
  'PRIVATE_RESPONSE_OK', 'RENDERER_CLOSE_ENTER', 'RENDERER_CLOSE_OK', 'PRIVATE_BODY_DONE',
  'PRIVATE_FRAME_SET_COMPLETE', 'RENDERER_DISCARDED', 'P_HEADER', 'P_END', 'STREAM_LEASE_RELEASED'];

function complete(run, nonempty) {
  if (!run || run.sdkStatus !== 200 || run.externalStatus !== 200 || run.bodyEOF !== true ||
    run.closeOK !== true || !run.lookupCount || !run.replayCount || !run.endAccepted ||
    !run.realSessionActiveReceipt || !run.grantReadbackReceipt || !run.callbackCorrelation ||
    !run.exactFrames || (nonempty && !(run.framePAccepted >= 1))) return false;
  let previous = -1;
  for (const stage of sequence) {
    const index = run.trace.findIndex((entry, position) => position > previous && entry.stage === stage);
    if (index < 0) return false;
    previous = index;
  }
  return true;
}
export function classifyReplayEvidence(caseId, scenario, evidence) {
  // Unsafe measured P wins even when an AbortError or a missing observer exists.
  if (unsafe.some(field => evidence?.[field] > 0) || evidence?.rendererReused || evidence?.sessionSpoofed) return 'FAIL';
  if (evidence?.authorization !== 'SEPARATELY_AUTHORIZED' || !evidence?.venueTrustReceipt || !evidence?.fdOwnerReceipt) return 'BLOCKED';
  if (evidence.sdkErrorName === 'AbortError') return 'INCONCLUSIVE';
  if (!evidence.rawEvidencePath || !evidence.independentRawHashValidation || evidence.rawTraceMissing ||
    !evidence.antecedentsReached || evidence.simulatedOnly || evidence.cleanupUnknown) return 'INCONCLUSIVE';
  if (scenario === 'cancel-only-control') return 'NEGATIVE_CONTROL_OBSERVATION';
  if (caseId === 'RP-19') {
    if (evidence.runs?.[1]?.sdkStatus === 409) return 'FAIL';
    if (!complete(evidence.runs?.[0], true) || !complete(evidence.runs?.[1], true)) return 'INCONCLUSIVE';
    const [first, second] = evidence.runs;
    if (first.rendererInstanceId === second.rendererInstanceId || first.requestKey === second.requestKey ||
      ['sessionId', 'streamId', 'grantVersion', 'mainTransportId', 'eventIdentityDigest'].some(field =>
        !first[field] || first[field] !== second[field])) return 'FAIL';
    if (!(first.endClock < second.admissionClock)) return 'FAIL';
    return 'PASS';
  }
  if (scenario === 'initialize-success') {
    return evidence.initStages?.join('>') === 'STAGED>VERIFIED>PUBLISHED>ACTIVE' && evidence.serverCompletionReceipt &&
      evidence.completeResultP && evidence.activeReadbackReceipt ? 'PASS' : 'INCONCLUSIVE';
  }
  if (positives.has(scenario)) {
    const empty = ['anchor-empty', 'priming-empty'].includes(scenario);
    return complete(evidence.runs?.[0], !empty) ? 'PASS' : 'INCONCLUSIVE';
  }
  return evidence.rejectionReason && evidence.expectedRejectionObserved && evidence.newReleaseDelta === 0 &&
    evidence.terminalClaimDelta === 0 && evidence.forbiddenSemanticP === 0 ? 'PASS' : 'INCONCLUSIVE';
}
