import { replaySchema } from './schema.mjs';
import { frozen, nonce, requireValue, match, deny } from './common.mjs';

const tables = Object.freeze({
  session: ['replay_session_owners', 'session_id'], lineage: ['session_lineage', 'session_id'],
  grant: ['replay_grants', 'grant_id'], anchor: ['replay_cursor_anchors', 'anchor_event_id'],
  binding: ['replay_anchor_authorizations', 'anchor_binding_id'], invocation: ['replay_invocations', 'invocation_id'],
  lifecycle: ['replay_renderer_lifecycles', 'renderer_instance_id'], stream: ['replay_stream_owners', 'stream_id'],
  lease: ['replay_stream_leases', 'lease_key'], event: ['replay_event_provenance', 'event_id']
});
export class ReplayLedger {
  constructor(store, emit, registry, sessionObserver) {
    requireValue(registry && sessionObserver, 'VENUE_CAPABILITY_UNENROLLED:DURABILITY');
    this.store = store; this.emit = emit; this.registry = registry; this.sessionObserver = sessionObserver;
    store.db.exec(replaySchema);
  }
  read(kind, id) {
    const [table, key] = tables[kind] ?? deny('LEDGER_KIND_REQUIRED');
    const row = this.store.db.prepare(`SELECT * FROM ${table} WHERE ${key}=?`).get(id);
    requireValue(row, 'REPLAY_ENTITLEMENT_UNPROVEN');
    const record = JSON.parse(row.record);
    for (const [field, value] of Object.entries(row)) if (field !== 'record') {
      requireValue(record[field] === value, 'LEDGER_READBACK_INCOHERENT');
    }
    requireValue(record.durable_commit_receipt, 'DURABLE_RECEIPT_REQUIRED');
    return frozen(record);
  }
  insert(kind, columns, record) {
    const [table, key] = tables[kind] ?? deny('LEDGER_KIND_REQUIRED');
    requireValue(columns[key], 'LEDGER_KEY_REQUIRED');
    const value = { ...record, ...columns, durable_commit_receipt: nonce() };
    const names = Object.keys(columns);
    this.store.db.prepare(`INSERT INTO ${table} (${names.join(',')},record) VALUES(${names.map(() => '?').join(',')},?)`)
      .run(...Object.values(columns), JSON.stringify(value));
    return value;
  }
  cas(kind, id, previous, patch, columns) {
    const [table, key] = tables[kind] ?? deny('LEDGER_KIND_REQUIRED');
    const current = this.read(kind, id);
    requireValue(current.durable_commit_receipt === previous.durable_commit_receipt, 'REPLAY_CAS_LOST');
    const value = { ...current, ...patch, ...columns, durable_commit_receipt: nonce() };
    const names = Object.keys(columns);
    const changed = this.store.db.prepare(`UPDATE ${table} SET ${names.map(name => `${name}=?`).join(',')},record=? WHERE ${key}=? AND record=?`)
      .run(...Object.values(columns), JSON.stringify(value), id, JSON.stringify(current));
    requireValue(changed.changes === 1, 'REPLAY_CAS_LOST');
    return value;
  }
  commit(kind, id, fn) {
    this.store.transaction(fn);
    const result = this.read(kind, id);
    const proof = this.registry.sync('durability', 'verifyCommitReadbackSync', { kind, id, result });
    requireValue(proof?.rawArtifactRef && proof.independentObserverRef && proof.commitToken === result.durable_commit_receipt &&
      proof.bootId === this.registry.boot && proof.walReceipt && proof.fsyncReceipt, 'LEDGER_DURABILITY_UNPROVEN');
    this.emit('REPLAY_CAS_READBACK', { kind, id, receipt: result.durable_commit_receipt });
    return result;
  }
  activeSession(id, principal) {
    const session = this.read('session', id);
    this.sessionObserver.assertActive(session);
    match(session, principal, ['principal_key', 'tenant', 'credential_family', 'auth_policy_revision'], 'SESSION_OWNER_DENIED');
    requireValue(session.init_status === 'ACTIVE' && session.active_commit_receipt && session.init_response_p_receipt && session.init_verified_receipt,
      'SESSION_ACTIVE_RECEIPT_REQUIRED');
    const lineage = this.read('lineage', id);
    match(session, lineage, ['principal_key', 'tenant', 'lineage_root', 'lineage_revision'], 'SESSION_LINEAGE_MISMATCH');
    return session;
  }
  revoke(grantId, reason, decision) {
    const grant = this.read('grant', grantId);
    if (grant.status === 'REVOKED') return grant;
    return this.commit('grant', grantId, () => {
      const version = grant.revocation_version + 1; const receipt = nonce();
      this.store.db.prepare('INSERT INTO replay_revocations VALUES(?,?,?,?)').run(grantId, version, nonce(),
        JSON.stringify({ reason, effective_decision: decision, durable_commit_receipt: receipt }));
      this.cas('grant', grantId, grant, { reason, revocation_version: version }, { status: 'REVOKED', grant_version: grant.grant_version + 1 });
    });
  }
  decision(invocation, number, event, outcome) {
    this.store.transaction(() => this.store.db.prepare('INSERT INTO replay_frame_decisions VALUES(?,?,?,?,?)').run(
      invocation.invocation_id, event?.id ?? '', number, outcome,
      JSON.stringify({ original_request_key: event?.original_request ?? null, immutable_sequence: event?.sequence ?? null,
        candidate_digest: event?.payload_digest ?? null, permit_state: 'CONSUMED', p_outcome: outcome })));
  }
}
