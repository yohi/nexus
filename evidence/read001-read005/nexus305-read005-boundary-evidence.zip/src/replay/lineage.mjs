import { match, requireValue } from './common.mjs';

// Owner-side operations only; the external GET cannot create either capability.
export function attachSuccessor({ ledger, ingress, verifier, ticket, predecessorId, successorId }) {
  const principal = ingress.current(ticket); const successor = ledger.activeSession(successorId, principal);
  const predecessor = ledger.read('session', predecessorId);
  match(predecessor, successor, ['principal_key', 'tenant', 'credential_family'], 'SUCCESSOR_OWNER_DENIED');
  const proof = verifier.successorReceiptSync(predecessor, successor);
  requireValue(proof?.rawArtifactRef && proof.monotonic_sequence_receipt &&
    proof.predecessorId === predecessorId && proof.successorId === successorId && !proof.compromised, 'SUCCESSOR_CAS_UNPROVEN');
  const lineage = ledger.read('lineage', successorId);
  return ledger.commit('session', successorId, () => {
    ledger.cas('session', successorId, successor, { lineage_root: predecessor.lineage_root,
      lineage_revision: predecessor.lineage_revision + 1 }, { version: successor.version + 1 });
    ledger.cas('lineage', successorId, lineage, { principal_key: successor.principal_key, tenant: successor.tenant,
      lineage_revision: predecessor.lineage_revision + 1, migration_receipt: proof.rawArtifactRef,
      monotonic_sequence_receipt: proof.monotonic_sequence_receipt }, {
      predecessor_id: predecessorId, lineage_root: predecessor.lineage_root, revision: predecessor.lineage_revision + 1 });
  });
}
export function enrollAnchor({ ledger, events, verifier, eventId }) {
  const row = events.lookup(eventId); const metadata = ledger.read('event', eventId);
  const proof = verifier.tombstoneReceiptSync(row);
  requireValue(row.state === 'REVOKED' && proof?.rawArtifactRef && proof.reason === 'ORIGIN_EPOCH_SUPERSEDED' &&
    proof.identityDigest === row.identity_digest && proof.version > 0 && proof.authorityReceipt, 'ANCHOR_TOMBSTONE_UNPROVEN');
  return ledger.commit('anchor', eventId, () => ledger.insert('anchor', { anchor_event_id: eventId,
    immutable_sequence: row.sequence, immutable_identity_digest: row.identity_digest }, {
    principal_key: metadata.principal_key, tenant: metadata.tenant, lineage_root: metadata.lineage_root,
    origin_request_key: row.original_request, origin_session_id: row.session, origin_stream_id: row.stream,
    origin_epoch: row.auth.epoch, origin_generation: row.auth.generation, origin_pair_id: row.auth.pairId,
    origin_publication_revision: row.auth.publicationRevision, event_tombstone_version: proof.version,
    event_tombstone_reason: proof.reason, event_tombstone_authority_receipt: proof.authorityReceipt,
    anchor_metadata_commit_receipt: proof.rawArtifactRef }));
}
