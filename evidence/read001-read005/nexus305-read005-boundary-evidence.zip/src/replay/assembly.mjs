import { ReplayLedger } from './ledger.mjs';
import { TrustedIngress } from './trusted-ingress.mjs';
import { ReplayAuthorizer } from './authorizer.mjs';
import { ReplayBroker } from './broker.mjs';
import { InitializeReceipts } from './initialize.mjs';
import { initializeMainSession } from './initialize-driver.mjs';
import { attachSuccessor, enrollAnchor } from './lineage.mjs';
import { requireValue } from './common.mjs';
import { MainSessionObserver } from './session-observer.mjs';
import { IngressBridge } from '../adapters/ingress-bridge.mjs';
import { CapabilityRegistry } from '../adapters/capability-registry.mjs';
import { MainSessionOwners } from './main-session-owner.mjs';

export function assembleOptionAR(drivers, bindings, SDK, emit) {
  requireValue(drivers.eventLedger && bindings?.registry instanceof CapabilityRegistry && bindings?.ingressPolicy,
    'VENUE_TRUST_BINDING_REQUIRED');
  const registry = bindings.registry;
  registry.require(['ingress', 'ownerContext', 'initialize', 'durability', 'authority', 'finalWriter']);
  const requestBoundary = new IngressBridge(registry, bindings.ingressPolicy);
  const observer = new MainSessionObserver(registry, {
    authorizeMainDispatchSync: bindings.authorizeMainDispatchSync,
    identityEvidenceContext: bindings.identityEvidenceContext });
  const verifier = Object.fromEntries(['verifySync', 'authorityReceiptSync', 'ownerReceiptSync', 'finalOwnershipSync',
    'maximumGrantExpirySync', 'liveWriterFencedSync', 'tombstoneReceiptSync'].map(method => [method,
    (...args) => registry.sync('authority', method, { args })]));
  Object.defineProperty(verifier, 'bindingReceipt', { get: () => registry.receipt('authority') });
  const ledger = new ReplayLedger(drivers.journal.store, emit, registry, observer);
  const ingress = new TrustedIngress(requestBoundary, () => registry.now(), emit);
  const authorizer = new ReplayAuthorizer({ ledger, events: drivers.eventLedger, ingress,
    authority: drivers.authority, verifier, emit });
  const broker = new ReplayBroker({ SDK, authorizer, ledger, gate: drivers.gate,
    venue: drivers.venue, emit, hook: bindings.barrier, sdkBinding: bindings.sdkBinding, requestBoundary });
  const receipts = new InitializeReceipts({ ledger, ingress, gate: drivers.gate, observer, emit });
  const mainOwners = new MainSessionOwners({ receipts, observer, requestBoundary });
  // Before any external admission, all historical SDK sessions lose eligibility.
  receipts.suspendOnBoot();
  drivers.eventLedger.bindOwnerAdmission({ store: (...args) => authorizer.storeAdmission(...args),
    release: (...args) => authorizer.releaseAdmission(...args) });
  return { ledger, ingress, authorizer, broker, receipts, requestBoundary, mainOwners,
    initialize: input => initializeMainSession({ SDK, serverSetup: bindings.mainServerSetup,
      request: input.request, eventStore: drivers.eventStore,
      receipts, observer, requestBoundary, mainOwners }),
    successor: input => attachSuccessor({ ...input, ledger, ingress, verifier }),
    anchor: eventId => enrollAnchor({ ledger, events: drivers.eventLedger, verifier, eventId }) };
}
