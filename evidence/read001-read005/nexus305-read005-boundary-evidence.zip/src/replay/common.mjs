import { randomUUID, createHash } from 'node:crypto';
import { StoredEventDenied } from '../stored-event-binding.mjs';

export const nonce = () => randomUUID();
export const hash = value => createHash('sha256').update(value).digest('hex');
export function deny(code) { throw new StoredEventDenied(code); }
export function requireValue(value, code) { if (!value) deny(code); }
export function frozen(value) {
  const copy = JSON.parse(JSON.stringify(value));
  const freeze = item => {
    if (item && typeof item === 'object') { for (const child of Object.values(item)) freeze(child); Object.freeze(item); }
    return item;
  };
  return freeze(copy);
}
export function match(left, right, fields, code) {
  requireValue(left && right && fields.every(field => left[field] !== undefined && left[field] === right[field]), code);
}
export async function bounded(promise, deadline, clock, signal) {
  let timer; let abort;
  const stop = new Promise((resolve, reject) => {
    timer = setTimeout(() => reject(new Error('DEADLINE_INCONCLUSIVE')), Math.max(0, deadline - clock()));
    abort = () => reject(new DOMException('Aborted', 'AbortError'));
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
  });
  try { return await Promise.race([promise, stop]); }
  finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
}
