import { nonce, requireValue } from './common.mjs';
import { enrollHTTPFinal, drainOrClose } from '../adapters/http-publication.mjs';
import { createPrivateMcpServer } from '../adapters/mcp.mjs';

// Owns a real main stateful transport. Only the public callback/session APIs are
// used. No renderer is connected to a server or treated as SessionOwner.
export async function initializeMainSession({ SDK, serverSetup, receipts, request, target, eventStore, observer, requestBoundary, mainOwners }) {
  requireValue(typeof serverSetup?.waitHandler === 'function', 'VENUE_CAPABILITY_UNENROLLED:MAIN_SERVER_SETUP');
  target = requestBoundary.targetFor(request, target);
  requireValue(request.method === 'POST' && !request.headers.has('mcp-session-id'), 'FRESH_INITIALIZE_REQUIRED');
  const body = await request.clone().json();
  requireValue(body?.jsonrpc === '2.0' && body.method === 'initialize' &&
    (typeof body.id === 'string' || typeof body.id === 'number') && !Array.isArray(body), 'INIT_SINGLE_REQUEST_REQUIRED');
  const authTicket = await receipts.ingress.authenticate(request);
  const attempt = Object.freeze({ authTicket, nonce: nonce(), transportId: target.transportId, requestId: body.id });
  let sessionId;
  const server = createPrivateMcpServer(SDK, serverSetup.waitHandler);
  const transport = new SDK.WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: nonce, enableJsonResponse: false,
    eventStore, onsessioninitialized: id => { sessionId = id; receipts.stage(id, attempt); },
    onsessionclosed: id => receipts.endSession(id, attempt.transportId, 'SDK_SESSION_TERMINATED') });
  try {
    await observer.enrollMainTransport({ transport, server, attempt });
    await server.connect(transport);
    // Preserve protocol callbacks installed by connect; fence before delegating.
    const onclose = transport.onclose; const onerror = transport.onerror;
    transport.onclose = () => {
      receipts.endSession(sessionId, attempt.transportId, 'SDK_MAIN_TRANSPORT_CLOSED');
      onclose?.();
    };
    transport.onerror = error => {
      receipts.endSession(sessionId, attempt.transportId, 'SDK_MAIN_TRANSPORT_UNCERTAIN');
      onerror?.(error);
    };
    const response = await transport.handleRequest(request);
    requireValue(sessionId, 'SDK_INIT_CALLBACK_MISSING');
    await receipts.gate.authority.store.consistentReadback();
    const envelope = { ...target.envelope, sessionId, transportInstance: attempt.transportId };
    const result = await receipts.complete({ response, sessionId, attempt, signal: request.signal, target: {
      ...target, envelope,
      publishInitialization: async (plan, check) => {
        await target.venue.proveFinalWriteOwnership({ kind: 'HTTP', identity: target.identity, response: target.response, envelope });
        const sink = enrollHTTPFinal(receipts.gate, target.response);
        check();
        const channel = receipts.gate.openInitializePublication(sink, envelope, plan, sessionId, attempt.nonce, authTicket);
        const resultFrame = plan.find(step => step.kind === 'sse-frame' && step.bytes.toString().startsWith('event: message\n'));
        for (let index = 0; index < plan.length; index++) {
          await target.barrier?.('INIT_FINAL_P_BEFORE', index); request.signal.throwIfAborted(); check();
          const accepted = receipts.gate.publishPermit(receipts.gate.nextPermit(channel));
          requireValue(accepted.accepted === true, 'INIT_P_UNKNOWN');
          if (accepted.backpressure) await drainOrClose(target.response, request.signal, 10000);
        }
        return observer.verifyFinalInitializeP({ sessionId, attempt, resultFrame });
      }
    } });
    return mainOwners.register({ transport, server, session: result, attempt });
  } catch (error) {
    observer.fence(attempt.transportId, sessionId);
    target.response.destroy();
    if (sessionId) {
      const row = receipts.ledger.read('session', sessionId);
      if (!['FENCED', 'SUSPENDED'].includes(row.init_status)) receipts.transition(sessionId, row, 'FENCED', { fault_reason: error.message });
    }
    await transport.close(); throw error;
  }
}
