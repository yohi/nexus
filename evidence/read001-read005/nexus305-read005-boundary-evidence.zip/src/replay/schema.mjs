// Additive isolated SQLite schema only. Never migrate R1 rows by inference.
// JSON record preserves the complete Rev3 contract; indexed/CAS columns are
// cross-checked on every read. All writes belong to the sole GateOwner store.
export const replaySchema = `
CREATE TABLE IF NOT EXISTS replay_session_owners(
 session_id TEXT PRIMARY KEY, version INTEGER NOT NULL,
 init_status TEXT NOT NULL CHECK(init_status IN ('STAGED','VERIFIED','PUBLISHED','ACTIVE','FENCED','SUSPENDED')),
 principal_key TEXT NOT NULL, tenant TEXT NOT NULL, transport_instance TEXT NOT NULL,
 init_attempt_nonce TEXT NOT NULL UNIQUE, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS session_lineage(
 session_id TEXT PRIMARY KEY REFERENCES replay_session_owners(session_id), predecessor_id TEXT,
 lineage_root TEXT NOT NULL, revision INTEGER NOT NULL, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_grants(
 grant_id TEXT PRIMARY KEY, grant_version INTEGER NOT NULL CHECK(grant_version>0),
 status TEXT NOT NULL CHECK(status IN ('ACTIVE','SUSPENDED','REVOKED','EXPIRED')),
 owner_session_id TEXT NOT NULL REFERENCES replay_session_owners(session_id),
 stream_id TEXT NOT NULL, expires_at INTEGER NOT NULL, nonce TEXT NOT NULL UNIQUE,
 record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_revocations(
 grant_id TEXT NOT NULL REFERENCES replay_grants(grant_id), revocation_version INTEGER NOT NULL,
 nonce TEXT NOT NULL UNIQUE, record TEXT NOT NULL CHECK(json_valid(record)), PRIMARY KEY(grant_id,revocation_version));
CREATE TABLE IF NOT EXISTS replay_cursor_anchors(
 anchor_event_id TEXT PRIMARY KEY REFERENCES r3_bound_events_v2(id), immutable_sequence INTEGER NOT NULL,
 immutable_identity_digest TEXT NOT NULL, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_anchor_authorizations(
 anchor_binding_id TEXT PRIMARY KEY, grant_id TEXT NOT NULL REFERENCES replay_grants(grant_id),
 grant_version INTEGER NOT NULL, anchor_event_id TEXT NOT NULL REFERENCES replay_cursor_anchors(anchor_event_id),
 successor_session_id TEXT NOT NULL REFERENCES replay_session_owners(session_id),
 successor_lineage_revision INTEGER NOT NULL, status TEXT NOT NULL CHECK(status IN ('ACTIVE','REVOKED')),
 record TEXT NOT NULL CHECK(json_valid(record)),
 UNIQUE(grant_id,grant_version,anchor_event_id,successor_session_id,successor_lineage_revision));
CREATE TABLE IF NOT EXISTS replay_invocations(
 invocation_id TEXT PRIMARY KEY, renderer_instance_id TEXT NOT NULL UNIQUE,
 status TEXT NOT NULL, grant_id TEXT NOT NULL REFERENCES replay_grants(grant_id),
 grant_version INTEGER NOT NULL, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_renderer_lifecycles(
 renderer_instance_id TEXT PRIMARY KEY, invocation_id TEXT NOT NULL UNIQUE REFERENCES replay_invocations(invocation_id),
 state TEXT NOT NULL, record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_frame_decisions(
 invocation_id TEXT NOT NULL REFERENCES replay_invocations(invocation_id), original_event_id TEXT NOT NULL,
 permit_number INTEGER NOT NULL, p_outcome TEXT NOT NULL,
 record TEXT NOT NULL CHECK(json_valid(record)), PRIMARY KEY(invocation_id,permit_number));
CREATE TABLE IF NOT EXISTS replay_stream_owners(
 stream_id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES replay_session_owners(session_id),
 record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_stream_leases(
 lease_key TEXT PRIMARY KEY, version INTEGER NOT NULL, invocation_id TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL CHECK(state IN ('HELD','SEALED','QUARANTINED')), record TEXT NOT NULL CHECK(json_valid(record)));
CREATE TABLE IF NOT EXISTS replay_event_provenance(
 event_id TEXT PRIMARY KEY REFERENCES r3_bound_events_v2(id),
 event_kind TEXT NOT NULL CHECK(event_kind IN ('PRIMING','NORMAL_REPLAY_SAFE','TERMINAL','UNKNOWN_FRAME')),
 record TEXT NOT NULL CHECK(json_valid(record)));
`;
