import { bufferPrivateResponse } from '../adapters/final-write.mjs';
import { frameSSE } from '../adapters/http-publication.mjs';
import { assertStoredFrame } from '../stored-event-binding.mjs';
import { bounded, requireValue, hash, deny } from './common.mjs';

export async function renderReplay({ SDK, context, authorizer, signal, clock, hook, emit, ledger }) {
  let phase = 'NEW'; let lookup = false; let replayStarted = false; let settled = false; let closed = false; let renderer;
  const record = (stage, detail = {}) => {
    emit(stage, { invocationId: context.invocation_id, rendererInstanceId: context.renderer_instance_id, ...detail });
    const prior = ledger.read('lifecycle', context.renderer_instance_id);
    ledger.commit('lifecycle', context.renderer_instance_id, () => ledger.cas('lifecycle', context.renderer_instance_id,
      prior, { ...detail, [stage]: { observed: true } }, { state: stage }));
  };
  const checkpoint = async stage => {
    await bounded(Promise.resolve(hook?.(stage, context)), context.deadline, clock, signal);
    signal.throwIfAborted();
    requireValue(clock() < context.deadline, 'DEADLINE_INCONCLUSIVE');
  };
  const callbackCheck = cursor => {
    requireValue(phase === 'SDK_GET' && cursor === context.cursor, 'SDK_CALLBACK_UNBOUND');
    authorizer.verify(context, 'SDK_CALLBACK_ENTRY');
  };
  const facade = Object.freeze({
    storeEvent: async () => deny('RENDERER_STORE_FORBIDDEN'),
    getStreamIdForEventId: async cursor => {
      callbackCheck(cursor); requireValue(!lookup && !settled, 'SDK_CALLBACK_UNBOUND');
      lookup = true; record('SDK_LOOKUP_OK', { cursor, streamId: context.streamId });
      await checkpoint('LOOKUP_BEFORE_REPLAY');
      callbackCheck(cursor); return context.streamId;
    },
    replayEventsAfter: async (cursor, { send }) => {
      callbackCheck(cursor); requireValue(lookup && !replayStarted && !settled, 'SDK_CALLBACK_UNBOUND');
      replayStarted = true;
      record('SDK_REPLAY_ENTER', { cursor, streamId: context.streamId });
      for (const event of context.events) {
        await checkpoint('PRIVATE_SEND_BEFORE');
        callbackCheck(cursor); authorizer.verify(context, 'PRIVATE_RELEASE');
        await bounded(send(event.id, event.message), context.deadline, clock, signal);
        callbackCheck(cursor); record('SDK_PRIVATE_SEND', { eventId: event.id, sequence: event.sequence, digest: event.payload_digest });
      }
      settled = true; record('SDK_REPLAY_CALLBACK_SETTLED', { callback_settled_receipt: context.invocation_id });
      return context.streamId;
    }
  });
  const close = async () => {
    phase = 'SEALED'; record('RENDERER_CLOSE_ENTER');
    // Only this locally constructed private instance can be closed here.
    await bounded(renderer.close(), context.deadline, clock);
    closed = true; record('RENDERER_CLOSE_OK', { close_resolved_receipt: context.renderer_instance_id,
      public_mapping_cleanup_source: 'SDK_1_29_0_PUBLIC_CLOSE_630_639' });
  };
  try {
    renderer = new SDK.WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, eventStore: facade });
    record('ONE_SHOT_RENDERER_NEW', { renderer_mode: 'PRIVATE_STATELESS_ONE_SHOT' });
    renderer.onerror = error => record('SDK_ERROR', { errorName: error.name, fault_reason: error.message });
    await checkpoint('RENDERER_BEFORE_START');
    record('SDK_START_ENTER'); await bounded(renderer.start(), context.deadline, clock, signal); record('SDK_START_OK');
    await checkpoint('SDK_GET_BEFORE');
    phase = 'SDK_GET'; record('SDK_GET_ENTER');
    const request = new Request('https://private-renderer.invalid/mcp', { method: 'GET', signal, headers: {
      accept: 'text/event-stream', 'last-event-id': context.cursor, 'mcp-session-id': context.sessionId,
      'mcp-protocol-version': context.protocolVersion
    } });
    const response = await bounded(renderer.handleRequest(request), context.deadline, clock, signal);
    requireValue(response.status === 200 && lookup && settled, 'SDK_REPLAY_INCOMPLETE');
    record('PRIVATE_RESPONSE_OK', { private_response_status: response.status });
    await checkpoint('CALLBACK_SETTLED_BEFORE_CLOSE');
    await close();
    await checkpoint('CLOSE_OK_BEFORE_BODY');
    requireValue(response.body && response.headers.get('content-type')?.startsWith('text/event-stream'), 'PRIVATE_BODY_REQUIRED');
    const bytes = await bounded(bufferPrivateResponse(response, context.maximumBytes, { signal,
      timeoutMs: Math.max(1, context.deadline - clock()) }), context.deadline, clock, signal);
    // bufferPrivateResponse returns only after reader.read().done === true.
    record('PRIVATE_BODY_DONE', { private_reader_outcome: 'EOF_DONE_TRUE', private_body_digest: hash(bytes), byteCount: bytes.length });
    const frames = frameSSE(bytes);
    requireValue(frames.length === context.events.length, 'PRIVATE_FRAME_COUNT_MISMATCH');
    for (let index = 0; index < frames.length; index++) assertStoredFrame(context.events[index], frames[index]);
    record('PRIVATE_FRAME_SET_COMPLETE', { bodyFrameCount: frames.length });
    record('RENDERER_DISCARDED'); renderer = null;
    return { frames, closeOK: true, bodyEOF: true };
  } catch (error) {
    phase = 'SEALED'; record('FENCED_NEW_P', { fault_reason: error.message,
      observationClass: error.name === 'AbortError' ? 'INCONCLUSIVE' : 'BLOCKED_OR_INCONCLUSIVE' });
    throw error;
  } finally {
    phase = 'SEALED';
    if (renderer && !closed) {
      try { await close(); }
      catch (error) { record('RENDERER_QUARANTINED', { fault_reason: error.message, observationClass: 'INCONCLUSIVE' }); }
    }
    renderer = null;
  }
}
