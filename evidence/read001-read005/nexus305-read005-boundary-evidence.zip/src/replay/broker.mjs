import { frozen, nonce, requireValue, bounded } from './common.mjs';
import { renderReplay } from './renderer.mjs';
import { enrollHTTPFinal, drainOrClose } from '../adapters/http-publication.mjs';

export class ReplayBroker {
  constructor({ SDK, authorizer, ledger, gate, venue, emit, hook = null, sdkBinding, requestBoundary }) {
    requireValue(sdkBinding?.version === '1.29.0' &&
      sdkBinding.sha256 === '177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6' &&
      sdkBinding.loadedSourceReceipt && SDK?.WebStandardStreamableHTTPServerTransport, 'FIXED_SDK_BINDING_REQUIRED');
    requireValue(requestBoundary, 'VENUE_CAPABILITY_UNENROLLED:OWNER_CONTEXT');
    Object.assign(this, { SDK, authorizer, ledger, gate, venue, emit, hook, requestBoundary });
    gate.bindReplayAuthority(authorizer);
  }
  lease(context) {
    const principal = this.authorizer.ingress.current(context.authTicket);
    const session = this.ledger.activeSession(context.sessionId, principal);
    const key = JSON.stringify([principal.tenant, principal.principal_key, session.lineage_root, context.streamId]);
    const priorRow = this.ledger.store.db.prepare('SELECT lease_key FROM replay_stream_leases WHERE lease_key=?').get(key);
    const prior = priorRow ? this.ledger.read('lease', key) : null;
    requireValue(!prior || prior.state === 'SEALED', 'BROKER_STREAM_CONFLICT_409');
    const columns = { lease_key: key, version: (prior?.version ?? 0) + 1, invocation_id: context.invocation_id, state: 'HELD' };
    return this.ledger.commit('lease', key, () => {
      requireValue(this.authorizer.verifier.liveWriterFencedSync(context.streamId) === true, 'LIVE_STREAM_OWNER_UNPROVEN');
      if (prior) this.ledger.cas('lease', key, prior, { lease_nonce: nonce() }, columns);
      else this.ledger.insert('lease', columns, { lease_nonce: nonce() });
    });
  }
  seal(context, lease, success) {
    const state = success ? 'SEALED' : 'QUARANTINED';
    this.ledger.commit('lease', lease.lease_key, () => {
      this.ledger.cas('lease', lease.lease_key, lease, { final_end_or_isolation: success ? 'FINAL_END_ACCEPTED' : 'UNKNOWN_ISOLATION' }, { state });
      const invocation = this.ledger.read('invocation', context.invocation_id);
      this.ledger.cas('invocation', context.invocation_id, invocation, {}, { status: state });
    });
    this.emit(success ? 'STREAM_LEASE_RELEASED' : 'STREAM_LEASE_QUARANTINED', { invocationId: context.invocation_id, version: lease.version });
  }
  async reconnect(request, target) {
    target = this.requestBoundary.targetFor(request, target);
    requireValue(request.method === 'GET' && request.headers.has('last-event-id'), 'REPLAY_GET_REQUIRED');
    const authTicket = await this.authorizer.ingress.authenticate(request);
    // This resolver is GateOwner-side durable lookup, never a client Grant ID.
    const principal = this.authorizer.ingress.current(authTicket);
    const selected = await this.requestBoundary.resolveOwnerGrant(target, { principal, sessionId: request.headers.get('mcp-session-id'), cursor: request.headers.get('last-event-id') });
    await this.venue.proveFinalWriteOwnership({ kind: 'HTTP', identity: target.identity, response: target.response, envelope: target.envelope });
    const sessionId = request.headers.get('mcp-session-id');
    requireValue(sessionId && selected.sessionId === sessionId, 'SESSION_OWNER_DENIED');
    const activeSession = this.ledger.activeSession(sessionId, principal);
    requireValue(Array.isArray(selected.events) && selected.events.length <= 256, 'REPLAY_BOUND_PLAN_REQUIRED');
    // Only IDs from the owner-side selection are inputs. Message/digest/sequence
    // copies supplied by a resolver can never become the SDK or final wire plan.
    const events = selected.events.map(event => this.authorizer.events.lookup(event.id));
    const base = frozen({ ...selected, sessionId, cursor: request.headers.get('last-event-id'),
      events, mainTransportId: activeSession.transport_instance,
      principal_receipt: principal.rawArtifactRef, active_session_receipt: activeSession.active_commit_receipt,
      invocation_id: nonce(), renderer_instance_id: nonce(), requestKey: target.envelope.requestKey,
      envelope: target.envelope, protocolVersion: target.protocolVersion, maximumBytes: 1048576,
      deadline: this.authorizer.ingress.now() + 10000 });
    requireValue(base.events.length <= 256 && base.envelope.sessionId === sessionId &&
      base.envelope.streamId === base.streamId && base.protocolVersion, 'REPLAY_BOUND_PLAN_REQUIRED');
    const context = Object.freeze({ ...base, authTicket });
    const publicationTicket = this.authorizer.prepare(context);
    const lease = this.lease(context);
    let channel; let success = false;
    try {
      this.ledger.commit('invocation', context.invocation_id, () => {
        this.ledger.insert('invocation', { invocation_id: context.invocation_id, renderer_instance_id: context.renderer_instance_id,
          status: 'RESERVED', grant_id: context.grantId, grant_version: context.grantVersion },
          { ...base, principal_receipt: principal.rawArtifactRef, lease_nonce: lease.lease_nonce,
            logical_stream_lease_version: lease.version, renderer_mode: 'PRIVATE_STATELESS_ONE_SHOT' });
        this.ledger.insert('lifecycle', { renderer_instance_id: context.renderer_instance_id,
          invocation_id: context.invocation_id, state: 'NEW' }, { renderer_mode: 'PRIVATE_STATELESS_ONE_SHOT' });
      });
      const rendered = await renderReplay({ SDK: this.SDK, context, authorizer: this.authorizer, signal: request.signal,
        clock: () => this.authorizer.ingress.now(), hook: this.hook, emit: this.emit, ledger: this.ledger });
      await bounded(Promise.resolve(this.hook?.('PRIVATE_COMPLETE_BEFORE_HEADER', context)), context.deadline,
        () => this.authorizer.ingress.now(), request.signal);
      const sink = enrollHTTPFinal(this.gate, target.response);
      channel = this.gate.openReplayPublication(sink, publicationTicket, rendered.frames);
      for (let index = 0; index < rendered.frames.length + 2; index++) {
        request.signal.throwIfAborted();
        await bounded(Promise.resolve(this.hook?.('FINAL_P_BEFORE', { ...base, index })), context.deadline,
          () => this.authorizer.ingress.now(), request.signal);
        const result = this.gate.publishPermit(this.gate.nextPermit(channel));
        requireValue(result.accepted === true, result.reason ?? 'UNKNOWN_DELIVERY_NO_RETRY');
        this.emit(index === 0 ? 'P_HEADER' : index === rendered.frames.length + 1 ? 'P_END' : 'P_FRAME', {
          invocationId: context.invocation_id, rendererInstanceId: context.renderer_instance_id, index,
          accepted: true, backpressure: result.backpressure, delivery: 'ENQUEUED_NOT_PEER_ACKED' });
        if (result.backpressure) await drainOrClose(target.response, request.signal, Math.max(1, context.deadline - this.authorizer.ingress.now()));
      }
      success = true;
      return { status: 200, accepted: true, ...rendered, frameCount: rendered.frames.length,
        rendererInstanceId: context.renderer_instance_id, sessionId, streamId: context.streamId,
        grantVersion: context.grantVersion, requestKey: context.requestKey, mainTransportId: activeSession.transport_instance,
        delivery: 'ENQUEUED_NOT_PEER_ACKED', terminalClaimDelta: 0 };
    } catch (error) {
      if (channel) this.gate.abortPublication(channel, error.message);
      target.response.destroy();
      this.authorizer.revoke(context.grantId, 'INVOCATION_UNKNOWN', context.invocation_id);
      throw error;
    } finally { this.seal(context, lease, success); }
  }
}
