import { assertDurableEvent } from '../stored-event-binding.mjs';
import { requireValue, match } from './common.mjs';

export function eventKind(message) {
  if (Object.keys(message).length === 0) return 'PRIMING';
  if ('id' in message || 'result' in message || 'error' in message) return 'TERMINAL';
  if (message.jsonrpc === '2.0' && message.method === 'notifications/progress' && message.params &&
    Object.keys(message).every(key => ['jsonrpc', 'method', 'params'].includes(key))) return 'NORMAL_REPLAY_SAFE';
  return 'UNKNOWN_FRAME';
}
export function eligibleEvent(row, metadata, grant, session, current, authority, verifier) {
  assertDurableEvent(row);
  requireValue(eventKind(row.message) === 'NORMAL_REPLAY_SAFE' && row.terminal === 0, 'TERMINAL_REPLAY_UNSUPPORTED');
  requireValue(row.state === 'RELEASED' && row.sequence > grant.cursor_floor_sequence &&
    row.sequence <= grant.released_ceiling_sequence && row.original_request === grant.original_request_key &&
    row.stream === grant.stream_id && row.session === grant.original_session_id &&
    row.transport_instance === grant.transport_instance, 'EVENT_SCOPE_DENIED');
  match(metadata, session, ['principal_key', 'tenant', 'lineage_root'], 'EVENT_OWNER_DENIED');
  requireValue(metadata.event_kind === 'NORMAL_REPLAY_SAFE' && metadata.identity_digest === row.identity_digest &&
    metadata.replay_safe_receipt && metadata.source_receipt && grant.event_digests[row.id] === row.identity_digest, 'EVENT_PROVENANCE_UNPROVEN');
  for (const field of ['epoch', 'generation', 'pairId', 'publicationRevision']) {
    requireValue(row.auth[field] === grant.authority[field] && current[field] === grant.authority[field], 'EVENT_NO_RELABEL');
  }
  // Origin auth is only a four-field comparison, never a current verdict source.
  requireValue(authority.allows(current) && verifier.verifySync(row, current, metadata.replay_safe_receipt) === true, 'CURRENT_VERIFICATION_FALSE');
}
export function validateAnchor(anchor, binding, grant, session, cursor) {
  requireValue(cursor.state === 'REVOKED' && anchor.anchor_event_id === cursor.id &&
    anchor.immutable_identity_digest === cursor.identity_digest && anchor.immutable_sequence === cursor.sequence &&
    anchor.event_tombstone_reason === 'ORIGIN_EPOCH_SUPERSEDED' && anchor.event_tombstone_authority_receipt &&
    anchor.event_tombstone_version > 0, 'ANCHOR_TOMBSTONE_UNPROVEN');
  requireValue(anchor.origin_request_key === cursor.original_request && anchor.origin_session_id === cursor.session &&
    anchor.origin_stream_id === cursor.stream && anchor.origin_epoch === cursor.auth.epoch &&
    anchor.origin_generation === cursor.auth.generation && anchor.origin_pair_id === cursor.auth.pairId &&
    anchor.origin_publication_revision === cursor.auth.publicationRevision, 'ANCHOR_ORIGIN_MISMATCH');
  match(anchor, session, ['principal_key', 'tenant', 'lineage_root'], 'ANCHOR_OWNER_DENIED');
  requireValue(binding.status === 'ACTIVE' && binding.grant_id === grant.grant_id && binding.grant_version === grant.grant_version &&
    binding.anchor_event_id === cursor.id && binding.anchor_identity_digest === cursor.identity_digest &&
    binding.anchor_origin_request_key === cursor.original_request && binding.anchor_origin_session_id === cursor.session &&
    binding.anchor_origin_epoch === cursor.auth.epoch && binding.anchor_sequence === cursor.sequence &&
    binding.anchor_origin_stream_id === cursor.stream && binding.sdk_replay_stream_id === cursor.stream &&
    grant.stream_id === cursor.stream && binding.successor_session_id === session.session_id &&
    binding.successor_lineage_root === session.lineage_root && binding.successor_lineage_revision === session.lineage_revision &&
    binding.successor_receipt === session.active_commit_receipt && binding.target_request_key === grant.original_request_key &&
    binding.target_epoch === grant.authority.epoch && binding.target_generation === grant.authority.generation &&
    binding.target_pair === grant.authority.pairId && binding.authority_fence_revision === grant.fence_revision &&
    cursor.sequence >= binding.usable_floor_sequence && cursor.sequence <= binding.usable_ceiling_sequence &&
    binding.max_payload_sequence === grant.released_ceiling_sequence && binding.anchor_tombstone_version === anchor.event_tombstone_version &&
    binding.anchor_revocation_version === 0, 'ANCHOR_SCOPE_OR_VERSION_DENY');
  if (grant.grant_kind === 'ANCHOR_ONLY') requireValue(grant.cursor_floor_sequence === cursor.sequence &&
    grant.released_ceiling_sequence === cursor.sequence && Object.keys(grant.event_digests).length === 0, 'ANCHOR_ONLY_PAYLOAD_DENIED');
}
