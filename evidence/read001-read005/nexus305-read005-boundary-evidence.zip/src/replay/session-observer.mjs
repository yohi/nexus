import { requireValue } from './common.mjs';
import { verifyIdentityEvidence } from '../case-context/evidence.mjs';

// The adapter validates external SDK/send/Node/durability observations. It does
// not synthesize them and never treats onsessioninitialized as completion.
export class MainSessionObserver {
  #attempts = new WeakMap(); #closed = new Set(); #active = new Map();
  #registry; #authorize; #evidenceContext;
  constructor(registry, { authorizeMainDispatchSync, identityEvidenceContext = null } = {}) {
    requireValue(typeof authorizeMainDispatchSync === 'function', 'R3_EXECUTION_NOT_AUTHORIZED');
    this.#registry = registry; this.#authorize = authorizeMainDispatchSync;
    this.#evidenceContext = identityEvidenceContext;
    Object.freeze(this);
  }
  get bootId() { return this.#registry.boot; }
  get bindingReceipt() { return this.#registry.receipt('initialize'); }
  #authorizeSync() {
    requireValue(this.#authorize() === undefined, 'R3_EXECUTION_NOT_AUTHORIZED');
  }
  verifyMainDispatchSync(input) {
    this.#authorizeSync();
    return this.#registry.sync('ownerContext', 'verifyMainDispatchSync', input);
  }
  async enrollMainTransport(input) {
    const receipt = await this.#registry.call('initialize', 'enrollMainTransport', input);
    requireValue(receipt?.rawArtifactRef && receipt.transportId === input.attempt.transportId &&
      receipt.bootId === this.#registry.boot && receipt.independentObserverRef, 'INIT_MAIN_DISPATCH_OBSERVER_UNENROLLED');
    requireValue(receipt.transport === input.transport && receipt.server === input.server, 'INIT_TRANSPORT_OBJECT_IDENTITY_UNPROVEN');
    this.#attempts.set(input.attempt, { transport: input.transport, server: input.server, receipt });
  }
  assertTransport(attempt, transport, server) {
    const enrolled = this.#attempts.get(attempt);
    requireValue(enrolled?.transport === transport && enrolled?.server === server, 'MAIN_TRANSPORT_OBJECT_IDENTITY_MISMATCH');
    this.assertLive(attempt);
  }
  assertLive(attempt) {
    const enrolled = this.#attempts.get(attempt);
    requireValue(enrolled && !this.#closed.has(attempt.transportId), 'MAIN_SESSION_TERMINATED');
    const live = this.#registry.sync('initialize', 'observeLifecycleSync', { ...enrolled, attempt });
    requireValue(live?.rawArtifactRef && live.transportId === attempt.transportId && live.bootId === this.#registry.boot &&
      live.state === 'OPEN' && live.credentialCurrent === true && live.independentObserverRef &&
      live.transport === enrolled.transport && live.server === enrolled.server, 'MAIN_SESSION_LIFECYCLE_UNPROVEN');
  }
  async verifyCompletion(input) {
    this.assertLive(input.attempt);
    const receipt = await this.#registry.call('initialize', 'verifyCompletion', input);
    this.assertLive(input.attempt);
    requireValue(receipt?.rawArtifactRef && receipt.independentObserverRef && receipt.sdkSendCompletionRef &&
      receipt.serverProcessingCompletionRef && receipt.sessionId === input.sessionId &&
      receipt.attemptNonce === input.attempt.nonce, 'INIT_SERVER_COMPLETION_UNPROVEN');
    return receipt;
  }
  async verifyFinalInitializeP(input) {
    this.assertLive(input.attempt);
    const receipt = await this.#registry.call('initialize', 'verifyFinalInitializeP', input);
    this.assertLive(input.attempt);
    requireValue(receipt?.rawArtifactRef && receipt.independentObserverRef && receipt.headerP &&
      receipt.completeResultP && receipt.endP && receipt.transportId === input.attempt.transportId &&
      receipt.attemptNonce === input.attempt.nonce && receipt.sessionId === input.sessionId &&
      receipt.fdOwnerReceipt && receipt.gateOrderingReceipt && receipt.peerAckClaimed === false, 'INIT_P_UNKNOWN');
    return receipt;
  }
  confirmActive(row, attempt) {
    this.assertLive(attempt);
    const receipt = this.#registry.sync('durability', 'verifyActiveReadbackSync', { row, attempt });
    requireValue(receipt?.rawArtifactRef && receipt.independentObserverRef && receipt.sessionId === row.session_id &&
      receipt.activeCommitToken === row.active_commit_receipt && receipt.status === 'ACTIVE' &&
      receipt.walReceipt && receipt.fsyncReceipt && receipt.bootId === this.#registry.boot, 'ACTIVE_DURABILITY_UNPROVEN');
    const enrolled = this.#attempts.get(attempt);
    requireValue(enrolled.transport.sessionId === row.session_id && row.transport_instance === attempt.transportId &&
      row.init_attempt_nonce === attempt.nonce, 'ACTIVE_MAIN_OBJECT_BINDING_REQUIRED');
    this.#active.set(row.session_id, { ...enrolled, attempt, row, receipt }); return receipt;
  }
  assertActive(row) {
    const binding = this.#active.get(row.session_id);
    requireValue(binding && !this.#closed.has(row.transport_instance) &&
      binding.row.active_commit_receipt === row.active_commit_receipt &&
      binding.attempt.transportId === row.transport_instance, 'SESSION_ACTIVE_OBSERVER_REQUIRED');
    this.assertTransport(binding.attempt, binding.transport, binding.server);
    const receipt = this.#registry.sync('initialize', 'observeActiveSync', { row });
    requireValue(receipt?.rawArtifactRef && receipt.sessionId === row.session_id && receipt.transportId === row.transport_instance &&
      receipt.bootId === this.#registry.boot && receipt.state === 'ACTIVE' && receipt.credentialCurrent === true &&
      receipt.independentObserverRef && receipt.transport === binding.transport && receipt.server === binding.server,
    'SESSION_ACTIVE_LIFECYCLE_UNPROVEN');
  }
  projectActiveIdentity({ row, attempt, transport, server, principal, requestIdentity }) {
    this.#authorizeSync(); this.assertTransport(attempt, transport, server); this.assertActive(row);
    const context = this.#evidenceContext;
    requireValue(context?.run?.runId && context.fixture && context.enrollmentRef,
      'IDENTITY_EVIDENCE_UNAVAILABLE');
    const receipt = this.#registry.sync('initialize', 'observeActiveSync', { row });
    requireValue(receipt.transport === transport && receipt.server === server, 'IDENTITY_EVIDENCE_UNAVAILABLE');
    const expected = { kind: requestIdentity ? 'DISPATCH' : 'ACTIVE', runId: context.run.runId,
      bootId: this.bootId, sessionId: row.session_id, transportId: row.transport_instance,
      attemptNonce: attempt.nonce, activeCommitToken: row.active_commit_receipt,
      independentObserverRef: receipt.independentObserverRef, enrollmentRef: context.enrollmentRef,
      ...(requestIdentity ? { requestIdentity, principalKey: principal.principal_key } : {}) };
    const result = verifyIdentityEvidence(this.#registry, receipt, expected, context);
    this.#authorizeSync(); this.assertActive(row);
    return result;
  }
  fence(transportId, sessionId) {
    this.#closed.add(transportId); if (sessionId) this.#active.delete(sessionId);
  }
}
