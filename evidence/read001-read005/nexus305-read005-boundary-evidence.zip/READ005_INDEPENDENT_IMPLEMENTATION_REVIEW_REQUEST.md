# 独立実装レビュー依頼

対象: yohi/nexus Issue #305 READ-005 / READ-001 の限定 Harness 修正。
Baseline HEAD: `4fd4872d4baa4394dd3828040f4d52ac9cc9e02d`。
原本 Evidence SHA-256: `f98094211e2962ea21afd4187a2f1a93b80150cef7d6701c191f6aed27fff0ef`。
提出候補: **DESIGN_CLARIFICATION_REQUIRED**。

## レビュー事項

1. `READ005_INPUT_VERIFICATION.json`、外部 SHA manifest、内部 SHA256SUMS と Source Diff を独立検証。
2. register、reference 削除、public admit、Driver、close、反射、prototype、serialization の逃走経路を確認。
3. `drivers.registry`、`entry()` の Provider、`sync()` の実 Receipt、`receipts.observer.registry` の残存反例を判定。
4. Initialize caller の Server 所有権と Case Context の権限分配について設計責任者へ明確化を依頼。
5. private Binding と実 Initialize Object の同一性、Current Principal、ACTIVE、Boot、Lifecycle、Authority、最終同期 verify と即時 SDK call の非退行を確認。
6. close の fail-closed が Source-only 提案として妥当か、必要な正式認可契約を確認。
7. Replay Broker、Renderer cleanup、DES-001〜003、C0/F1/P、Terminal Claim、INV-01〜07、234/61 のバイト一致証拠を確認。
8. `tests/main-owner-capability.test.mjs` と更新 Test の Fixture 契約、Artifact Hash と独立 provenance の検証要件を確認。

レビュー時も動的 Test、SDK import、通信、Native、Fault、R3 実験はこの依頼で
許可されません。必要な実測は別途明示的な実験承認と Venue 供給が必要です。
提出者の静的チェックを独立レビューや全逃走経路の閉鎖と扱わないでください。
Finding の最終判断は独立レビュアー、設計判断は Requirements/Architecture Owner、
Execution 判断は別の Gate Owner に属します。
