# Trust Capability と残存 Venue Gap

全項目は未登録です。今回、権限、FD、IdP、OS、DB の状態を変更していません。

| 入力／Capability | 必要な実主体と観測 | 未接続時の停止 |
| --- | --- | --- |
| Trust Root | 別主体の Enrollment verifier、Boot、単調 Clock、期限／失効の再検証 | Registry admission deny |
| Current IdP／TLS ingress | 実 Request identity、Trust Root、現在 Principal／Tenant／Credential、rotation／revocation | authentication deny |
| Main dispatch | 同じ Transport／Server の実参照、ACTIVE Commit Token、Current Grant／Authority | MAIN_DISPATCH_OWNER_AUTHORITY_UNPROVEN |
| Initialize Completion | Server processing と SDK send Completion、attempt／Session／Transport／Result Digest | STAGED のまま失敗、fence |
| Durability | 実 CAS/readback、WAL／fsync／Boot の独立 Receipt | ACTIVE／Grant を認定しない |
| Final Writer | 元 Response、OS FD identity、排他所有、Pid／Tid／Role／Boot、Envelope Digest | Enrollment／Final P deny |
| Case Publication | Case A／D／E の Owner Target と F1 Hold の独立 proof | ケースの旧 callback は再許可しない |
| Raw Evidence | 各 Run／Cell、SHA-256、Origin、独立 Observer、Field-to-artifact binding | missing evidence は BLOCKED |
| Intervention | Antecedent、Control、Hook registration/release、Barrier 実 Source | 実 Runner は未接続のまま停止 |
| Native | LanceDB Reader／prune／retention、FD／Tid／closed handle、process liveness | S01〜S06 は SOURCE_PARTIAL |
| Crash／Restart | 実 Boot、pidfd、DB recovery、旧 Claim／Grant／Anchor の確認 | Venue operation 未接続 |
| v2／Bridge | Stateful Owner を固定 serving chain で取得する公開 API | SDK_API_CONTRACT_BLOCKED |

Venue Owner には Run単位の同一性、Observer の主体分離、Raw bytes と SHA、期限／Boot、対象 FD／Socket／DB を結合した入力を要求します。
Receipt の `true` や Harness 発行文字列だけでは不十分です。秘密情報を Evidence に含める必要はありません。
Registry の公開関数を実装するだけで実験権限が付くわけではありません。

## 許可が別途必要な操作

実通信、Native I/O、Signal、FD isolation、OS permission、DB state transition、Crash／Fault Injection、Clock／IdP mutation、
SDK callback 介入、Node final buffer／disconnect、独立 Raw Trace 採取は現在未承認です。
将来必要となる対象と操作は Matrix の missingHooks／Action に結合しています。
今回の依頼ではその承認、Provisioning、実行を行いません。
