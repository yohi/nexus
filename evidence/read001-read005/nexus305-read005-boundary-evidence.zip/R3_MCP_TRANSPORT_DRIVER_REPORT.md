# R3 MCP transport driver report

## Current Revision R2

Normal stored frames now use ledger-minted owner tickets bound to original
Request/Session/Stream/connection and exact saved SDK wire payload. Both EventStore
adapters share one implementation and hide the ledger behind private fields.
Replay callbacks, Web replay and cursor-bearing Web/Node capture requests are
closed as `REPLAY_ENTITLEMENT_UNPROVEN`. SDK Session support does not establish
authenticated read entitlement; the positive reconnect path remains unresolved.
See [Replay contract](R3_REPLAY_ENTITLEMENT_CONTRACT.md). Older R1 descriptions
below are historical; no Replay success is claimed for current R2 source.

R1 adds `publishPinnedHTTP` and `publishPinnedStdout`, connecting actual pinned
native readback to the existing final sink adapters, including the asynchronous
venue-ownership gap before final preclaim admission. Stored frame provenance is
projected and cannot promote request verification. These routes were not executed;
see the [R1 report](R3_DRIVER_INTEGRATION_REVISION_R1_REPORT.md).

## Fixed signatures and concrete routes

Direct installed versions match SDK 1.29.0 and server/node 2.0.0. Hashed declarations
and selected implementation files are preserved in `R3_API_SIGNATURE_EVIDENCE.json`.
This does not attest that all installed transitive dependencies match R2; the
unchanged R2 lockfile remains the execution dependency contract.

| Route | Source connection |
| --- | --- |
| stdio | Real `StdioServerTransport(privateReadable, privateWritable)`; no default stdout fallback |
| Private Client | Real SDK `Client` with SDK ReadBuffer/serializeMessage over enrolled private pipes |
| JSON/SSE v1 | Real `WebStandardStreamableHTTPServerTransport.handleRequest(Request)` produces a private Response |
| HTTP v2 | Real `createMcpHandler(factory, options)` and `toNodeHandler(handler)` write only to a private structural facade |
| Nexus Bridge | Original `createV1RuntimeToolBridge(v1Server)` connects real v1 Client/InMemoryTransport; injected v2 factory registers original handlers |

The old one-argument `v2PrivateHandler` is corrected. The actual v2 factory is
per request; options include `legacy`, `responseMode` and `keepAliveMs`. Modern
material uses `2026-07-28` and SDK-exported protocol-version/client-info/client-
capabilities metadata keys, with matching method/name headers. Legacy initialize
uses `2025-11-25`; sessionful v1 replay also requires the negotiated session header
and genuine stored cursor. No successful handshake is claimed without actual wire
evidence. A 400/error or synthetic transport response cannot award PASS.

## Output ownership and cancellation

SDK pipes, queues and private response facade contain no external final stream.
The Node Adapter's actual Header/Body/End route can be traversed against that
facade. Finite private results are then passed to the owner-only final sink.
Each external write requires a fresh opaque permit. Backpressure false is accepted
P, and drain/close/abort timeout runs outside the synchronous gate.

Private JSON buffering has byte/time bounds and cancellation. Incomplete private
JSONL is retained privately and dropped on close. Infinite SSE capture is not
supported: it times out rather than falsely reporting completed streaming.
Finite complete SSE frames receive separate permits. Partial publication uses
abort/isolation and unknown delivery; accepted bytes are not retracted.

`DurableSDKEventStore` keeps the SDK callback surface and durable
PRIVATE/RELEASED/REVOKED rows. Original auth is retained, but Replay callbacks now
reject before lookup/send because their authenticated entitlement context is
undefined. Normal `bindStoredFrames` supplies opaque tickets, not a current
verification verdict derived from stored data. Empty successful Replay remains
unresolved, not a prepared PASS or exactly-once terminal delivery claim.

## Outstanding integration

The actual modules are injected into driver assembly; future frozen runtime loading
is hash checked but is not performed here. Complete registry/tool factories,
private OS pipe enrollment, handler barriers, live SSE EventStore release/replay,
restart cursor/session contexts and every negative control remain incomplete.
SDK code executed in an unrestricted process could still access global stdout;
private constructor arguments alone do not prove OS FD exclusion. Runtime worker
FD/topology ownership must be independently established before semantic admission.
