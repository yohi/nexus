# READ-003 Final Writer 移行

判定案: `PARTIALLY_INTEGRATED`。全 Venue の FD 所有は未認定です。

## 改訂経路

- `stdoutFinal` は callback／Writable 受渡しを廃止し、個別 Publication Permit を消費します。旧引数形式は拒否します。
- `GateOwner.publish` の無条件拒否は保持しました。
- Case A の旧 Hold＋Publication と Case D／E の `ctx.attemptOldPublication` は、`src/drivers/case-final-publication.mjs` の Owner Target 解決へ移しました。
- `casePublication.preparePublicationTarget/verifyTargetSync/holdF1` は Trusted Composition Root の登録を必要とします。Case ctx が直接 write callback を指定する経路ではありません。
- HTTP／STDOUT の分岐は既存 `publishActualHTTP/publishActualStdout` → Final Ownership Proof → `enrollHTTPFinal/enrollStdoutFinal` → `publishPlan` → `nextPermit/publishPermit` を使用します。
- Final Boundary は元 Response の実参照、Envelope Digest、Pid／Tid／Role／Boot、独立 Observer、FD topology／排他所有を要求します。
- Header も個別 P です。Barrier 後にも Abort を再確認します。`write(false)` は accepted bytes として Permit を消費し、Drain 待機を行います。

## Inventory と未接続箇所

`WRITER_PATH_INVENTORY.json` は全 `src/**/*.mjs` の AST Writer／connect 呼出と local import graph を列挙します。
private Node buffering、private SDK pipe output、Enrolled HTTP／STDOUT Final Sink、Launcher の静的説明出力を区別します。
分類はソース上の用途であり、OS 上の FD 所有の実測ではありません。

private Stdio／Client pipe は `privatePipes.inspectPrivatePipesSync` の独立した Pipe Enrollment を要求するよう変更しました。
元 input／output の実参照、FD Artifact、排他的 Private Topology と Final FD 非到達性が必要です。
`pipes.enrollmentRef` の文字列だけでは許可しません。Client の send ごとにも再検証します。
`PrivateTransport` の任意 `emitFrame` callback は廃止し、有限の内部 Memory Frame Queue に変更しました。

Case C の `attemptSemanticWhileUnknown`、Case E の `boundedFreshRetryOrTerminal`、Case F の `attemptLegacyAPIsBeforeNewRecovery`、
`storageGroup/transportGroup` の外部 ctx メソッド本体は原本にも存在しません。
これらの Body、個別 Node／Stdio Writer、Negative Control の禁止行為観測は未接続です。
Case A／D／E の新 `casePublication` Provider も未登録です。全234 Binding を移行済みとは主張しません。

## 失敗意味論

C0／F1／Final Gate の同期順序、Terminal Claim at-most-once、Stored Auth 非昇格を保持しました。
Final Permit の再利用は禁止です。Unknown Delivery／部分出力／Disconnect は no-retry です。
Terminal Replay は既存の claim=0 経路です。C0 後 old P=0 は Oracle 期待値であり実測値ではありません。
実 Callback／SDK／FD の試験ソースは未実行です。
