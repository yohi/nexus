# READ-001 Main Owner 非退行のソース証拠

状態: **PASS_STATIC_ONLY**。Finding Closure と実測 PASS は未判定です。
全 Composition 境界は **DESIGN_CLARIFICATION_REQUIRED**。

## 実 Object Identity と Opaque Handle

`initialize-driver.mjs` は変更していません。実 Initialize で作成した Transport
と接続 Server を `register()` に渡す経路は維持しています。
Owner の private Binding は同じ Transport、Server、Attempt を保持します。
同一 ID の別 Object を再構築しません。公開 Handle は空の frozen
null-prototype Object で、WeakMap 登録の Object Identity だけを認めます。
`assertHandle()` は成功値や生参照を返しません。

Handle の共有そのものは Request の認可ではありません。別 Principal は
`ledger.activeSession()` の principal_key、tenant、credential_family、
auth_policy_revision の照合で拒否する既存経路を維持します。
clone、spread、JSON、文字列、同じ ID、prototype 継承は登録済み Object では
ないため private Binding に到達できません。

## 最終同期境界

1. private `#admit()` が Target、認証、Current Principal、ACTIVE、Protocol、Authority を検査。
2. await 後に Request abort、Current Principal、ACTIVE、Boot、Authority を再検査。
3. Observer が同じ Transport と Server の Lifecycle を検査。
4. `verifyMainDispatchSync` に同一実 Object を渡す。
5. rawArtifactRef、独立 Observer、Boot、Object Identity、Session、ACTIVE Token、Principal、Request Identity、Authority Receipt、Grant Receipt、allowed を同期照合。
6. 直後に同じ `binding.transport.handleRequest(request)` を呼ぶ。

4から6の間に await はありません。private Binding を公開 admit に戻さず、
外部から公開認可メソッドを差し替えて Binding を注入する経路を除去しました。

## 非退行の範囲

Initialize Receipt、Session Observer、Ledger、Broker、Renderer、Lineage、GateOwner、
Lifecycle、Authority、Stored Event のファイルは原本とバイト単位で一致します。
DES-001〜003 の Anchor、Initialize、Mapping cleanup、C0/F1/P、Terminal Claim、
INV-01〜07 の規範を変更していません。234 Binding は Safe117、Negative117、
61 Oracle Cell とともに内容、ID、BLOCKED/NOT_EXECUTED を維持しています。

Replay GET は Driver の公開 admit の後に ReplayBroker の独立認証へ進みます。
Main dispatch は Last-Event-ID を拒否します。Replay Broker と fresh private
stateless Renderer のコード、Renderer の cleanup は変更していません。
Driver の任意 close は拒否し、既存 SDK close/error callback の
`receipts.endSession()` による fence、SUSPENDED、Grant revoke は維持します。
Request abort を Session close として扱う変更はありません。

close API の通常操作契約は未定義であり、close が使えるという互換性は
主張しません。正式な Owner-side close 認可の設計が別途必要です。

実同一性の証拠は Owner の自己申告 Token ではなく、独立 Venue が private な
Initialize/Dispatch 同一性を照合した Artifact の Hash と provenance を検証する
Test Source に変更しました。その Fixture、Raw Artifact の生成と検証、
実 Callback 観測は未接続です。**NOT_EXECUTED / UNKNOWN** を維持します。

公開 Artifact の必要項目は固定 Source Hash、実行 ID、Boot、Session、
ACTIVE Commit Token、Principal/Request Identity、Initialize と Dispatch の
独立観測記録、同一性照合結果、観測者と検証者の provenance、Raw Artifact の
SHA-256 です。Verifier は信頼済み別チャネルから得る immutable な Raw Bytes の
Hash と enrollment を照合し、Owner の自己申告 Boolean や Hash 字句一致だけで
受理してはいけません。Transport/Server の参照を公開 Artifact に含めません。
現在の Provider API は生参照 Receipt を返すので、この公開 Artifact 設計だけで
既存の Registry 逃走経路が解消したとは扱いません。
