# READ-001 Main Stateful Transport 所有と再利用

判定案: `SOURCE_FIXED_REVIEW_REQUIRED`（Web 経路のみ）。Node／Bridge は READ-002 により BLOCKED。
実行結果は `NOT_EXECUTED`。この文書は独立レビューの代用ではありません。

## 原因と修正経路

入力の `actualSDKWeb` は Initialize の Transport と別の SDK Transport を生成していました。
改訂版では同関数から生成と `server.connect` を除去し、Initialize の返す不透明な Owner Handle を要求します。

1. `src/replay/assembly.mjs` が限定用途の `MainSessionOwners` を生成します。
2. `initializeMainSession` が実 Transport を一つ生成し、実 Server とともに独立 Observer へ登録します。
3. `onsessioninitialized` は従来どおり STAGED のみです。Result Completion、Final P、ACTIVE durability は既存の Receipt 経路を通ります。
4. `MainSessionObserver.confirmActive` は同じ Transport／Server 参照と ACTIVE Commit Token を保持します。
5. `MainSessionOwners.register` が ACTIVE 後にだけ Handle を登録します。
6. `drivers.sdkWeb(handle)` → `actualSDKWeb` → `mainOwners.dispatch` → 登録された同じ `transport.handleRequest` へ到達します。

## 境界と否定条件

- Handle の clone は WeakMap に存在しないため拒否します。Session ID は検索キーであり、所有証明に使用しません。
- 各 Request で Trusted Ingress の現在 Principal、ACTIVE Receipt、Tenant／Credential Family／Policy、Transport Instance、Boot、Protocol、現在 Authority を確認します。
- `ownerContext.verifyMainDispatchSync` は同じ Transport／Server／Principal／Request と Authority／Grant Receipt を同期検証します。未登録なら拒否します。
- SDK dispatch の直前までに認証を再検証します。最後の同期検証から SDK 呼出までに `await` を置きません。
- GET Cursor は Broker にだけ送ります。`MainSessionObserver.assertActive` が同じ実 Main Object の生存を検証し、Replay は従来の private stateless renderer を使用します。
- Owner close、SDK onclose／session close／不確実な SDK error は Observer を先に fence します。Durable Session は SUSPENDED、Future Grant は失効経路へ進みます。
- 通常 Request の Abort は当該 Request の中止であり、Main Session close と同一視しません。Replay renderer の close は Main close と混同しません。

## 未接続要件と検証限界

Venue の Initialize／Lifecycle Receipt に実 `transport` と `server` の参照が必要です。
自己申告の ID 一致や `credentialCurrent: true` のみでは登録できません。
外部 Trust Root、独立 Lifecycle Observer、Durability、Current IdP と Grant Receipt は未登録です。
Crash／Reboot は現在 Boot の再検証と既存 suspend-on-boot で拒否しますが、Crash 試験は実施していません。

`tests/source-closure.test.mjs` に同一 Object、clone、Principal／Credential／Boot／close の否定試験ソースを追加しました。
SDK と実 Callback を使う試験は未実行です。静的確認は `STATIC_VERIFICATION.json` を参照してください。
