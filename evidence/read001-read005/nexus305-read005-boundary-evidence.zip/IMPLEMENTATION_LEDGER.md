# Option A-R implementation ledger

Contract: `01_CODEX_IMPLEMENTATION_PROMPT.md` in the immutable handoff input.

- Input CRC and all internal member digests verified before edits.
- Ruling: explicit prohibition on dynamic execution overrides TDD RED/GREEN
  execution. Test source is written first; no claim of observed RED or GREEN.
- Ruling: isolated archive workspace replaces a Git worktree because product
  repository changes and Git operations are outside this task's authority.
- Ruling: independent implementation review belongs to a separate owner; no
  subagent review or self-approval is performed in this implementation session.
- Pre-flight: initialize ACTIVE receipt is required by grant issuance, anchor
  authorization and admission; renderer lifecycle receipt is required by final
  publication; stream lease is held through external end or quarantine.
- Trust providers, authenticated main-session dispatch/send observations, final
  FD ownership and SQLite durability remain venue-bound, never fixture facts.
- Static verifier first invoked from archive workspace could not resolve Node
  typings (TS2688). The unchanged integration verifier requires repository cwd;
  rerunning there passed. No dependency was installed and no harness was loaded.
- Source inspection found resolver-provided payload copies could diverge from
  immutable ledger wire. Broker now reloads rows by ID and rechecks exact wire
  and sequence before callbacks/P. Dynamic RED/GREEN remains prohibited.
- SDK optional generator declaration lacks explicit undefined under exact optional
  properties. JavaScript uses the mandated explicit undefined; the strict virtual
  public API probe uses omission (equivalent stateless constructor semantics).
