import { readFileSync, writeFileSync, readdirSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { relative, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = path => readFileSync(join(root, path));
const json = path => JSON.parse(read(path));
const write = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const list = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? list(join(dir, entry.name)) : [join(dir, entry.name)]);
const baseline = '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d';
const prior = json('reference/prior-command-manifest.json');
const sourceFiles = list(join(root, 'src')).map(path => ({ path: relative(root, path), sha256: sha(readFileSync(path)), bytes: readFileSync(path).length }));
mkdirSync(join(root, 'reference/fixed-head'), { recursive: true });
const fixedPaths = ['src/storage/interfaces/structured-catalog.ts', 'src/storage/metadata-store.ts', 'src/indexer/pipeline.ts', 'src/storage/vector-store.ts', 'src/server/http-v2/v1-runtime-bridge.ts'];
const fixedSources = fixedPaths.map(path => {
  let bytes;
  try { bytes = execFileSync('git', ['show', `${baseline}:${path}`], { stdio: ['ignore', 'pipe', 'pipe'] }); }
  catch { return { path, status: 'PATH_NOT_FOUND_AT_FIXED_HEAD' }; }
  const destination = `reference/fixed-head/${path.replaceAll('/', '__')}`;
  writeFileSync(join(root, destination), bytes);
  return { originalPath: path, path: destination, sha256: sha(bytes), status: 'READ_ONLY_FIXTURE_NOT_LOADED' };
});
const actors = {
  writer: { account: 'r3-writer', proposedUID: 62001, proposedGID: 62001 },
  publisher: { account: 'r3-publisher', proposedUID: 62002, proposedGID: 62002 },
  seal: { account: 'r3-seal', proposedUID: 62003, proposedGID: 62003 },
  reader: { account: 'r3-reader', proposedUID: 62004, proposedGID: 62004 },
  gc: { account: 'r3-gc', proposedUID: 62005, proposedGID: 62005 },
  gateowner: { account: 'r3-gateowner', proposedUID: 62006, proposedGID: 62006 },
  observer: { account: 'r3-observer', proposedUID: 62007, proposedGID: 62007 },
};
const commonSource = ['src/authority.mjs', 'src/gate-owner.mjs', 'src/fault-controller.mjs', 'src/evidence-collector.mjs', 'src/oracles.mjs', 'src/readback-oracle.mjs', 'src/launcher.mjs', 'src/stop.mjs'];
const groupSource = {
  'R3-S01': ['src/actors/publisher.mjs', 'src/actors/seal.mjs', 'src/adapters/unbound-os.mjs'],
  'R3-S02': ['src/actors/writer.mjs', 'src/native-observer.mjs', 'src/adapters/unbound-os.mjs'],
  'R3-S03': ['src/actors/writer.mjs', 'src/actors/reader.mjs', 'src/actors/gc.mjs'],
  'R3-S04': ['src/actors/gc.mjs', 'src/adapters/sqlite-authority.mjs', 'src/adapters/unbound-os.mjs'],
  'R3-S05': ['src/cases.mjs', 'src/adapters/cas-fault-driver.mjs', 'src/adapters/sqlite-authority.mjs', 'src/adapters/legacy-recovery.mjs'],
  'R3-S06': ['src/provenance.mjs', 'src/actors/reader.mjs'],
  'R3-T01': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs'],
  'R3-T02': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs'],
  'R3-T03': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs'],
  'R3-T04': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs'],
  'R3-T05': ['src/adapters/private-event-store.mjs', 'src/adapters/mcp.mjs'],
  'R3-T06': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs', 'src/adapters/dependency-loader.mjs'],
  'R3-T07': ['src/adapters/mcp.mjs', 'src/adapters/final-write.mjs', 'src/adapters/dependency-loader.mjs'],
  'R3-T08': ['src/lifecycle.mjs', 'src/cases.mjs', 'src/adapters/final-write.mjs'],
  'R3-T09': ['src/cases.mjs', 'src/adapters/cas-fault-driver.mjs', 'src/adapters/sqlite-authority.mjs', 'src/adapters/final-write.mjs'],
};
const gaps = {
  'R3-S01': ['OS_SAFE_PATH_COPY_SEAL_AND_ATTACK_MATRIX_UNBOUND'],
  'R3-S02': ['PIDFD_SIGNAL_ADAPTER_UNBOUND', 'KERNEL_NATIVE_TID_FD_CORRELATION_UNBOUND'],
  'R3-S03': ['REAL_PAIR_FIXTURE_AND_NATIVE_PRUNE_DRIVER_UNBOUND', 'READER_FD_RELEASE_PROOF_UNBOUND'],
  'R3-S04': ['ENROLLED_DELETE_ALLOWLIST_UNBOUND', 'PIN_INTENT_RACE_CRASH_DRIVER_UNBOUND'],
  'R3-S05': ['FIXED_HEAD_JOURNAL_SCHEMA_API_EXECUTABLE_ADAPTER_UNBOUND', 'DURABLE_CAS_FAULT_CONTEXT_UNBOUND'],
  'R3-S06': ['INDEPENDENT_SOURCE_ENUMERATOR_UNBOUND', 'PROVIDER_AND_PERSISTED_NATIVE_READBACK_UNBOUND'],
  'R3-T01': ['REAL_SDK_PRIVATE_PIPE_AND_EXTERNAL_FD_ENROLLMENT_UNBOUND'],
  'R3-T02': ['OS_PIPE_BACKPRESSURE_DRAIN_CLOSE_DRIVER_UNBOUND'],
  'R3-T03': ['REAL_SDK_WEB_RESPONSE_ADAPTER_UNBOUND', 'HTTP_HEADER_BODY_MULTIWRITE_ADMISSION_UNBOUND'],
  'R3-T04': ['REAL_SSE_PER_FRAME_ADMISSION_DRIVER_UNBOUND'],
  'R3-T05': ['DURABLE_EVENT_LEDGER_AND_GENUINE_REPLAY_DRIVER_UNBOUND'],
  'R3-T06': ['ACTUAL_V2_CREATE_MCP_HANDLER_SIGNATURE_HANDSHAKE_UNVERIFIED', 'NODE_2_ADAPTER_UNBOUND'],
  'R3-T07': ['FIXED_HEAD_BRIDGE_EXECUTABLE_ADAPTER_UNBOUND', 'ACTUAL_V2_HANDLER_AND_NODE_ADAPTER_UNBOUND'],
  'R3-T08': ['REAL_QUERY_PINS_FRESH_RETRY_AND_TERMINAL_DRIVER_UNBOUND'],
  'R3-T09': ['SAME_OWNER_DURABLE_FAULT_CONTEXT_AND_REAL_FINAL_WRITE_UNBOUND'],
};
const bind = old => {
  const sourcePaths = [...new Set([...commonSource, 'src/group-drivers.mjs', ...groupSource[old.testId]])];
  const sources = sourcePaths.map(path => sourceFiles.find(file => file.path === path));
  const reasons = ['ADMIN_VENUE_NOT_PROVISIONED', 'REAL_UID_GID_MOUNT_FD_SOCKET_NOT_ENROLLED', 'EXPLICIT_EXECUTION_AUTHORIZATION_ABSENT', ...gaps[old.testId]];
  if (old.variant === 'NEGATIVE_CONTROL') reasons.push('UNSAFE_CONTROL_CONTEXT_NOT_IMPLEMENTED_OR_AUTHORIZED');
  const caseLetter = old.caseId?.split('-').at(-1);
  return { ...old, version: 'r3-binding-preparation/3', status: 'BLOCKED', classification: 'NOT_EXECUTED',
    sourceBindingStatus: 'BOUND_TO_EXISTING_SOURCE', sources,
    entryPoint: { path: 'src/group-drivers.mjs', function: old.testId.startsWith('R3-S') ? 'storageGroup' : 'transportGroup' },
    caseFunction: caseLetter ? { path: 'src/cases.mjs', functions: caseLetter === 'B' ? ['caseB', 'caseB2'] : [`case${caseLetter}`] } : null,
    oracleFunctions: { path: 'src/oracles.mjs', function: caseLetter ? 'evaluateCase' : 'evaluateGroup', completeSemanticGroupEvaluator: false },
    argv: ['node', 'src/launcher.mjs', '--execute', '--binding', old.bindingId],
    describeArgv: ['node', 'src/launcher.mjs', '--describe', old.bindingId],
    argvStatus: 'FIXED_ENTRYPOINT_EXECUTION_HARD_BLOCKED',
    workingDirectory: '.', workingDirectoryResolution: 'Package root; deployment realpath/device/inode must be supplied by administrator',
    envAllowlist: ['R3_ROOT', 'R3_ENROLLMENT_FILE', 'R3_DEPENDENCY_ROOT'],
    environment: { R3_ROOT: null, R3_ENROLLMENT_FILE: null, R3_DEPENDENCY_ROOT: null },
    actor: 'gateowner', requiredActors: actors, actualUIDsGIDs: null,
    capabilities: { ordinaryActors: [], adminSealBroker: ['CAP_CHOWN', 'CAP_SYS_ADMIN_SETUP_ONLY'], observer: 'approved child ptrace or scoped privileged kernel probe; actual grants unresolved' },
    targetBindings: { directory: null, fd: null, socket: null, pidfd: null, device: null, inode: null, mountNamespace: null },
    permittedSideEffects: { currently: ['read binding description only'], proposedAfterSeparateApproval: old.sideEffects },
    resourceLimits: { ...old.resourceLimits, aggregateCPUQuotaPercent: 100, limitEnforcement: 'administrator cgroup v2 + disk quota; not configured' },
    stopCommand: ['node', 'src/stop.mjs', '--binding', old.bindingId], stopStatus: 'SOURCE_BOUND_OS_UNIT_UNBOUND',
    harnessSha256: sha(read('src/group-drivers.mjs')), adapterSha256: sha(read(old.testId.startsWith('R3-S') ? 'src/adapters/unbound-os.mjs' : 'src/adapters/final-write.mjs')),
    launcherSha256: sha(read('src/launcher.mjs')), observerSha256: sha(read('src/native-observer.mjs')),
    evidenceOutputTemplate: `evidence/results/${old.testId.slice(3)}/<approved-run-nonce>/`,
    runEvidenceRoot: null, evidencePathBinding: 'ORIGINAL_PATHS_PRESERVED_RUN_NONCE_UNBOUND',
    reasons, branchExpansionStatus: old.branch.includes('ALL_REQUIRED_BRANCHES_NOT_YET_EXPANDED') ? 'CASE_FUNCTION_EXPANDED_VENUE_CONTEXT_UNBOUND' : 'ORIGINAL_SELECTOR_PRESERVED',
  };
};
const bindings = prior.bindings.map(bind), extraBindings = prior.extraBindings.map(bind);
if (bindings.length + extraBindings.length !== 234) throw new Error('BASELINE_BINDING_COUNT_CHANGED');
write('R3_HARNESS_SOURCE_MANIFEST.json', { schemaVersion: 'r3-source-manifest/1', baseline, sources: sourceFiles, fixedSources, dynamicExecuted: false });
write('R3_FROZEN_COMMAND_MANIFEST.json', { ...prior, schemaVersion: 'r3-frozen-command-manifest/3', status: 'PARTIALLY_BOUND_ENVIRONMENT_BLOCKED', approved: false, experimentExecuted: false,
  nodeRequirement: '>=24; preparation Node 26.10.0; execution binary not enrolled',
  coverage: { ...prior.coverage, sourceReferencedBindings: 234, fixedEntryPointArgv: 234, executableExperimentCommands: 0, concreteExecutableCommands: 0 },
  bindings, extraBindings, groupDriverGaps: gaps, permissions: prior.permissions.map(permission => ({ ...permission, used: false, status: 'BLOCKED' })) });
write('R3_EXECUTION_GATE_STATUS.json', { schemaVersion: 'r3-gate/1', finalState: 'PARTIALLY_BOUND_ENVIRONMENT_BLOCKED', executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED', section4_1: 'BLOCKED', designSpec: 'NOT_APPROVED', implementationPlan: 'NOT_APPROVED', productImplementation: 'NOT_APPROVED', sourceBindingCount: 234, runnableExperimentCount: 0, independentReview: 'NOT_PERFORMED', authorization: null, venue: null, remainingDriverWork: gaps });
write('R3_TRACEABILITY.json', { groups: prior.tests.map(test => ({ testId: test.testId, sourcePaths: groupSource[test.testId], sourceFunction: test.testId.startsWith('R3-S') ? 'storageGroup' : 'transportGroup', requiredBranches: test.requiredBranches, oracle: test.acceptance, bindings: [...bindings, ...extraBindings].filter(binding => binding.testId === test.testId).map(binding => binding.bindingId), gaps: gaps[test.testId] })), extraCases: ['A', 'B', 'B2', 'C', 'D', 'E', 'F'].map(id => ({ id, source: 'src/cases.mjs', function: `case${id}`, oracle: 'src/oracles.mjs#evaluateCase', dynamicStatus: 'NOT_EXECUTED' })) });
console.log(`Bound source references and entrypoint argv for ${bindings.length + extraBindings.length} original records. All experiment commands remain blocked.`);
