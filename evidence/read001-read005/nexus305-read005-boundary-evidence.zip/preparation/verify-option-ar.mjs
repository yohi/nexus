// STATIC ONLY: parse source, never import it or execute a scenario.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = resolve(process.argv[2]);
const require = createRequire(join(repo, 'package.json'));
const ts = require('typescript'); const Ajv = require('ajv');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = path => readFileSync(join(root, path), 'utf8');
const json = path => JSON.parse(text(path));
const check = (value, detail) => { if (!value) throw new Error(detail); };
const checks = [];
const walk = (path = '') => readdirSync(join(root, path), { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(join(path, entry.name)) : [join(path, entry.name)]);
const files = walk(); const checked = [];
for (const path of files.filter(path => /\.(js|mjs)$/.test(path))) {
  execFileSync(process.execPath, ['--check', join(root, path)], { stdio: 'pipe' }); checked.push(path);
}
checks.push({ check: 'all-javascript-node-check', files: checked.length, status: 'PASS_STATIC_ONLY' });
const units = new Map();
for (const path of files.filter(path => /^(src|tests)\/.*\.mjs$/.test(path))) {
  const ast = ts.createSourceFile(path, text(path), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  check(ast.parseDiagnostics.length === 0, `PARSE:${path}`); units.set(path, ast);
}
for (const [path, ast] of units) {
  const visit = node => {
    if (ts.isPropertyAccessExpression(node) && ['_streamMapping', '_initialized', '_requestToStreamMapping'].includes(node.name.text)) check(false, `SDK_PRIVATE_ACCESS:${path}`);
    if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && ['kill', 'chmod', 'chown', 'mount'].includes(node.expression.name.text)) check(false, `FORBIDDEN_OPERATION:${path}`);
    ts.forEachChild(node, visit);
  }; visit(ast);
}
checks.push({ check: 'no-sdk-private-state-access-or-os-permission-call', status: 'PASS_STATIC_ONLY' });
const renderer = text('src/replay/renderer.mjs');
check(renderer.includes('new SDK.WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, eventStore: facade })'), 'FRESH_STATELESS_RENDERER');
check(renderer.includes('renderer.start()') && renderer.includes('renderer.handleRequest(request)') && renderer.includes('renderer.close()'), 'PUBLIC_API_CHAIN');
check(renderer.indexOf('await close();') < renderer.indexOf('bufferPrivateResponse(response'), 'CLOSE_BEFORE_EOF');
const broker = text('src/replay/broker.mjs');
check(broker.indexOf('await renderReplay(') < broker.indexOf('openReplayPublication('), 'RENDER_BEFORE_EXTERNAL_HEADER');
const gate = text('src/gate-owner.mjs');
const gateAST = units.get('src/gate-owner.mjs');
let awaits = 0;
const visitGate = node => { if (ts.isAwaitExpression(node)) awaits++; ts.forEachChild(node, visitGate); }; visitGate(gateAST);
check(awaits === 0, 'NO_AWAIT_IN_GATE');
const replayOpen = gate.slice(gate.indexOf('openReplayPublication('), gate.indexOf('openPublication('));
check(!replayOpen.includes('this.prepareTerminal(') && !replayOpen.includes('releasePublicationPlan('), 'REPLAY_TERMINAL_ZERO');
check(gate.includes("this.#replay.verify(state.replay, 'FINAL_P')"), 'FINAL_REAUTHORIZATION');
checks.push({ check: 'public-api-lifecycle-order-and-replay-final-gate', status: 'PASS_STATIC_ONLY',
  limitation: 'Source-shape checks; not proof of real callback, close, EOF or C0/P behavior' });
const schema = text('src/replay/schema.mjs');
for (const table of ['replay_grants', 'replay_revocations', 'replay_session_owners', 'session_lineage',
  'replay_cursor_anchors', 'replay_anchor_authorizations', 'replay_invocations', 'replay_renderer_lifecycles', 'replay_frame_decisions']) {
  check(schema.includes(`CREATE TABLE IF NOT EXISTS ${table}(`), `SCHEMA:${table}`);
}
checks.push({ check: 'additive-sql-schema-source-coverage', status: 'PASS_STATIC_ONLY',
  limitation: 'SQL not executed; SQLite migration/runtime constraints require separate dynamic authorization' });
const matrix = json('R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json');
const validate = new Ajv({ allErrors: true }).compile(json('schemas/option-ar-oracles.schema.json'));
check(validate(matrix), `ORACLE_SCHEMA:${JSON.stringify(validate.errors)}`);
const ids = new Set(matrix.rows.map(row => row.caseId));
for (const id of ['RP-01', 'RP-07', 'RP-07A', 'RP-07B', 'RP-09', 'RP-10', 'RP-13', 'RP-14', 'RP-17', 'RP-18', 'RP-19', 'RP-19A', 'RP-19B', 'R1-001-04']) check(ids.has(id), `ORACLE_ID:${id}`);
check(matrix.rows.every(row => row.status === 'NOT_EXECUTED' && row.actual === null), 'NO_FABRICATED_ACTUAL');
check(text('tests/option-ar.test.mjs').includes('const second = await run.broker.reconnect('), 'TWO_REAL_BROKER_CALL_TEST');
checks.push({ check: 'unexecuted-oracle-schema-and-required-case-coverage', cells: matrix.rows.length, caseIds: ids.size, status: 'PASS_STATIC_ONLY' });
const sdk = 'reference/api/@modelcontextprotocol/sdk/dist/esm/server/webStandardStreamableHttp';
check(sha(readFileSync(join(root, `${sdk}.js`))) === '177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6', 'SDK_JS_HASH');
check(sha(readFileSync(join(root, `${sdk}.d.ts`))) === '8e2bc703c3acfded33705833379c9eb01e96988814246b627233c517ad287c6a', 'SDK_TYPES_HASH');
checks.push({ check: 'fixed-sdk-js-and-declaration-hashes', status: 'PASS_STATIC_ONLY' });
// Compile-only virtual source: no file is written into the product repository.
const probe = join(repo, '__option_ar_public_api_probe__.mts');
const probeSource = `import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import type { EventStore } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
declare const eventStore: EventStore;
// Omitted optional generator is stateless; explicit undefined is used in JS.
const renderer = new WebStandardStreamableHTTPServerTransport({ eventStore });
export async function publicAPISignatures(request: Request): Promise<Response> {
 await renderer.start(); const response = await renderer.handleRequest(request);
 await renderer.close(); return response;
}
export type Lookup = NonNullable<EventStore['getStreamIdForEventId']>;
export type Replay = EventStore['replayEventsAfter'];\n`;
const options = { noEmit: true, strict: true, exactOptionalPropertyTypes: true,
  noUncheckedIndexedAccess: true, verbatimModuleSyntax: true, skipLibCheck: true,
  module: ts.ModuleKind.NodeNext, moduleResolution: ts.ModuleResolutionKind.NodeNext,
  target: ts.ScriptTarget.ES2023, types: ['node'], typeRoots: [join(repo, 'node_modules/@types')] };
const host = ts.createCompilerHost(options);
const getSource = host.getSourceFile.bind(host); const exists = host.fileExists.bind(host); const read = host.readFile.bind(host);
host.fileExists = path => path === probe || exists(path);
host.readFile = path => path === probe ? probeSource : read(path);
host.getSourceFile = (path, version, error, create) => path === probe
  ? ts.createSourceFile(path, probeSource, version, true) : getSource(path, version, error, create);
const diagnostics = ts.getPreEmitDiagnostics(ts.createProgram([probe], options, host));
check(diagnostics.length === 0, ts.formatDiagnostics(diagnostics, {
  getCanonicalFileName: path => path, getCurrentDirectory: () => repo, getNewLine: () => '\n' }));
checks.push({ check: 'strict-compile-only-public-start-handleRequest-close-and-eventstore-signatures', status: 'PASS_STATIC_ONLY',
  virtualSourceSha256: sha(Buffer.from(probeSource)), experimentalImports: 0,
  limitation: 'SDK declaration omits explicit undefined in optional generator type; probe uses omission. Harness is JavaScript.' });
const baselineManifest = JSON.parse(execFileSync('unzip', ['-p', join(root, 'inputs/option-ar-r2-original.zip'), 'R3_FROZEN_COMMAND_MANIFEST.json'], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }));
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
const rows = [...manifest.bindings, ...manifest.extraBindings]; const old = [...baselineManifest.bindings, ...baselineManifest.extraBindings];
check(rows.length === 234 && new Set(rows.map(row => row.bindingId)).size === 234, '234_BINDING');
for (const row of rows) {
  const origin = old.find(item => item.bindingId === row.bindingId);
  check(origin && origin.variant === row.variant && origin.testId === row.testId &&
    JSON.stringify(origin.oracle) === JSON.stringify(row.oracle), `ORIGINAL_BINDING:${row.bindingId}`);
  check(row.status === 'BLOCKED' && row.classification === 'NOT_EXECUTED', 'BINDING_UNEXECUTED');
  for (const source of row.sources) check(sha(readFileSync(join(root, source.path))) === source.sha256, `SOURCE_HASH:${source.path}`);
}
const safe = rows.filter(row => row.variant === 'SAFE_VARIANT').length;
const negative = rows.filter(row => row.variant === 'NEGATIVE_CONTROL').length;
check(safe === 117 && negative === 117, 'VARIANT_COUNTS');
const frozen = ['src/launcher.mjs', 'src/authority.mjs', 'src/publication-admission.mjs', 'src/stored-event-binding.mjs',
  'src/adapters/private-event-store.mjs', 'src/adapters/http-publication.mjs', 'src/drivers/cutover.mjs',
  'reference/SECTION4_1_REV5_PROPOSAL.md', 'reference/R3_TARGETED_SPIKE_PLAN.md', 'R3_R1_001_ORACLE_MATRIX.json'];
for (const path of frozen) check(execFileSync('unzip', ['-p', join(root, 'inputs/option-ar-r2-original.zip'), path], { maxBuffer: 4 * 1024 * 1024 })
  .equals(readFileSync(join(root, path))), `FROZEN_BYTES:${path}`);
checks.push({ check: '234-binding-117-safe-117-negative-original-oracles-and-frozen-guards', status: 'PASS_STATIC_ONLY', safe, negative });
const status = json('R3_EXECUTION_GATE_STATUS.json');
check(status.executionGate === 'NOT_AUTHORIZED' && status.experiment === 'NOT_EXECUTED' && status.authorization === null, 'NO_EXECUTION_AUTHORITY');
const report = { status: 'PASS_STATIC_ONLY', checks, syntaxCheckedPaths: checked, node: process.version, typescript: ts.version,
  independentReview: 'NOT_PERFORMED', integration: 'PARTIALLY_INTEGRATED', experimentalImports: 0, dynamicTests: 0,
  limitations: ['No dynamic SQL/SDK/HTTP/Native/permission/fault calls', 'JS harness is not fully semantically typechecked',
    'Source shape is not behavioral correctness proof', 'Venue scenario fixture and independent raw observer not enrolled'] };
writeFileSync(join(root, 'R3_T05_STATIC_VERIFICATION.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, syntaxFiles: checked.length, checks: checks.length, oracleCells: matrix.rows.length }));
