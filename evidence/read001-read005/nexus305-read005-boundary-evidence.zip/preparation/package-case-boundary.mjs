// Preparation artifacts only. No harness, test, SDK or native modules execute.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = path.resolve(process.argv[2]);
const previous = path.resolve(process.argv[3]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const bytes = (base, name) => fs.readFileSync(path.join(base, name));
const write = (name, data) => fs.writeFileSync(path.join(root, name), JSON.stringify(data, null, 2) + '\n');
for (const name of ['specs/2026-10-23-read005-capability-boundary-design.md',
  'plans/2026-10-23-read005-capability-boundary-plan.md']) {
  const target = path.join(root, 'docs/superpowers', name);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, bytes(repo, `docs/superpowers/${name}`));
}
const walk = (base, prefix = '') => fs.readdirSync(path.join(base, prefix), { withFileTypes: true }).flatMap(e => {
  if (e.isSymbolicLink()) throw new Error(`UNSAFE_SYMLINK:${prefix}/${e.name}`);
  return e.isDirectory() ? walk(base, path.join(prefix, e.name)) : [path.join(prefix, e.name)];
});
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
if (head !== '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d') throw new Error('BASELINE_DRIFT:HEAD');
const allowedChangedSources = new Set(['src/adapters/mcp.mjs', 'src/drivers/integration.mjs',
  'src/replay/assembly.mjs', 'src/replay/initialize-driver.mjs', 'src/replay/main-session-owner.mjs',
  'src/replay/session-observer.mjs', 'src/readiness/scenario-runner.mjs',
  'tests/main-owner-capability.test.mjs', 'tests/source-closure.test.mjs', 'tests/readiness-boundaries.test.mjs',
  'preparation/verify-main-owner-capability.mjs', 'preparation/verify-frozen-api.mjs']);
const allowedReports = new Set(['README.md', 'SHA256SUMS', 'STATIC_VERIFICATION.json',
  'FROZEN_API_STATIC_VERIFICATION.json', 'WRITER_PATH_INVENTORY.json',
  'READ_004_SCENARIO_RUNNER_MATRIX.json', 'SOURCE_CLOSURE_DEPENDENCY_GRAPH.json']);
const priorManifest = JSON.parse(bytes(previous, 'READ005_SOURCE_MANIFEST.json'));
for (const row of priorManifest.sources)
  if (sha(bytes(previous, row.path)) !== row.sha256) throw new Error(`BASELINE_DRIFT:${row.path}`);
const oldFiles = walk(previous); const before = new Set(oldFiles);
for (const name of oldFiles) {
  if (!fs.existsSync(path.join(root, name))) throw new Error(`DELETED_INPUT:${name}`);
  if (!bytes(root, name).equals(bytes(previous, name)) && !allowedChangedSources.has(name) && !allowedReports.has(name))
    throw new Error(`UNAUTHORIZED_CHANGE:${name}`);
}
const sources = walk(root).filter(n => /^(src|tests|preparation)\//.test(n)).sort();
for (const name of sources.filter(n => !before.has(n))) {
  if (!/^src\/case-context\/[^/]+\.mjs$/.test(name) &&
    !['tests/case-boundary.test.mjs', 'tests/fixtures/ordinary-main-case.mjs',
      'preparation/boundary-checks.mjs', 'preparation/verify-case-boundary.mjs',
      'preparation/capture-boundary-check.mjs', 'preparation/run-boundary-suite.mjs',
      'preparation/package-case-boundary.mjs'].includes(name)) throw new Error(`NEW_SOURCE_OUTSIDE_PLAN:${name}`);
}
const staticReport = JSON.parse(bytes(root, 'BOUNDARY_STATIC_VERIFICATION.json'));
if (staticReport.status !== 'PASS_STATIC_ONLY') throw new Error('STATIC_SUITE_NOT_GREEN');
for (const row of staticReport.sourceHashes)
  if (sha(bytes(root, row.path)) !== row.sha256) throw new Error(`STALE_STATIC_EVIDENCE:${row.path}`);
if (sources.filter(n => n.endsWith('.mjs')).length !== staticReport.sourceHashes.length) throw new Error('STATIC_SOURCE_COVERAGE');
const changed = sources.filter(n => !before.has(n) || !bytes(root, n).equals(bytes(previous, n)));
const patch = execFileSync('python3', ['-c', `
import difflib,pathlib,sys
old,new=map(pathlib.Path,sys.argv[1:3])
for name in sys.argv[3:]:
 p=old/name; a=p.read_text().splitlines(keepends=True) if p.exists() else []
 b=(new/name).read_text().splitlines(keepends=True)
 sys.stdout.write(''.join(difflib.unified_diff(a,b,fromfile='a/'+name if p.exists() else '/dev/null',tofile='b/'+name)))
`, previous, root, ...changed], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
fs.writeFileSync(path.join(root, 'BOUNDARY_SOURCE_DIFF.patch'), patch);
write('BOUNDARY_SOURCE_MANIFEST.json', { status: 'PARTIALLY_INTEGRATED', baselineHead: head,
  parentArchive: 'nexus305-read001-read005-capability-evidence.zip', patchSha256: sha(patch),
  changes: changed.map(name => ({ path: name, previousSha256: before.has(name) ? sha(bytes(previous, name)) : null, sha256: sha(bytes(root, name)) })),
  sources: sources.map(name => ({ path: name, sha256: sha(bytes(root, name)) })),
  testsExecuted: false, SDKExecuted: false, experimentsExecuted: false });
const immutable = oldFiles.filter(n => /^(reference|schemas|fixtures)\//.test(n) ||
  ['R3_FROZEN_COMMAND_MANIFEST.json', 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json',
    'src/readiness/scenario-catalog.json', 'R3_EXECUTION_GATE_STATUS.json'].includes(n));
write('BOUNDARY_IMMUTABILITY_COMPARISON.json', { status: 'PASS_STATIC_ONLY',
  files: immutable.map(n => ({ path: n, previousSha256: sha(bytes(previous, n)), sha256: sha(bytes(root, n)), identical: true })),
  bindings: 234, safe: 117, negative: 117, oracleCells: 61, execution: 'NOT_EXECUTED' });
const classes = [
  ['Identity', 'tests/source-closure.test.mjs#sameMainObjectAfterInitialize'],
  ['Transitive escape', 'tests/case-boundary.test.mjs#caseFacadeHasOnlyApprovedOperations'],
  ['Handle forgery', 'tests/case-boundary.test.mjs#requestAndSessionCopiesDoNotAuthorize'],
  ['Direct bypass', 'tests/main-owner-capability.test.mjs#caseContextCannotReadProviderRawIdentity'],
  ['Current authorization', 'tests/case-boundary.test.mjs#currentAuthorizationCannotBeCached'],
  ['Final boundary', 'tests/main-owner-capability.test.mjs#staleOrForeignAuthorityDenied'],
  ['Lifecycle', 'tests/main-owner-capability.test.mjs#publicationAndLifecycleRemainDistinct'],
  ['Receipt forgery', 'tests/case-boundary.test.mjs#publicReceiptCannotAuthorizeDispatch'],
  ['Catalog preservation', 'preparation/verify-case-boundary.mjs']
];
const focus = ['projectionRejectsLiveValues', 'requestAndSessionCopiesDoNotAuthorize',
  'initializeConnectsAfterObservation', 'publicReceiptCannotAuthorizeDispatch', 'currentAuthorizationCannotBeCached'];
write('BOUNDARY_ORACLE_MATRIX.json', { status: 'SOURCE_ONLY_AWAITING_VENUE',
  originalCells: 61, originalBindings: 234, supplementaryNotBindingPromotion: true,
  rows: classes.map(([designClass, source]) => ({ designClass, source, execution: 'NOT_EXECUTED', actual: null, negativeObservation: 'UNKNOWN' })),
  reviewFocus: focus.map((name, i) => ({ id: i + 1, source: `tests/case-boundary.test.mjs#${name}`, execution: 'NOT_EXECUTED' })),
  scenarioRevocation: 'tests/readiness-boundaries.test.mjs#scenarioRevocationBlocksSecondReplay' });
const parents = [
  ['nexus305-read001-read005-capability-evidence.zip', 'fbdf5cc1a89beda640b041af85731b40e471aa421d9486c9688b967d71bc92bd'],
  ['nexus305-r3-read001-004-source-closure-evidence.zip', 'f98094211e2962ea21afd4187a2f1a93b80150cef7d6701c191f6aed27fff0ef']
];
for (const [name, expected] of parents) if (sha(bytes(repo, name)) !== expected) throw new Error(`BASELINE_DRIFT:${name}`);
write('BOUNDARY_DELIVERY_INPUTS.json', { inputs: parents.map(([archive, sha256]) => ({ archive, sha256, included: false })),
  omittedPrefix: 'inputs/', reason: 'Nested historical inputs are retained byte-identically in the parent archive; both deliveries are required.' });
const archiveName = 'nexus305-read005-boundary-evidence.zip';
const archive = path.join(path.dirname(root.replace(/\/$/, '')), archiveName);
if (fs.existsSync(archive)) throw new Error('REFUSE_ARCHIVE_OVERWRITE');
const packageResult = execFileSync('python3', ['-c', `
import pathlib,sys,zipfile,hashlib,json
root=pathlib.Path(sys.argv[1]); output=pathlib.Path(sys.argv[2]); h=lambda b:hashlib.sha256(b).hexdigest()
names=sorted(p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.relative_to(root).parts[0]!='inputs' and p.relative_to(root).as_posix()!='SHA256SUMS')
sums=''.join(h((root/n).read_bytes())+'  '+n+'\\n' for n in names)
(root/'SHA256SUMS').write_text(sums)
with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in names+['SHA256SUMS']: z.write(root/n,n)
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts and '\\\\' not in n for n in z.namelist())
 rows=[]
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,n=line.split(None,1); assert h(z.read(n))==digest; rows.append({'path':n,'sha256':digest,'bytes':len(z.read(n))})
 assert set(r['path'] for r in rows)==set(z.namelist())-{'SHA256SUMS'}
 manifest=json.loads(z.read('BOUNDARY_SOURCE_MANIFEST.json'))
 assert h(z.read('BOUNDARY_SOURCE_DIFF.patch'))==manifest['patchSha256']
 for r in manifest['sources']: assert h(z.read(r['path']))==r['sha256']
data={'archive':output.name,'sha256':h(output.read_bytes()),'bytes':output.stat().st_size,'entries':len(rows)+1,'internalChecksumEntries':len(rows),'status':'PARTIALLY_INTEGRATED','files':rows}
output.with_suffix(output.suffix+'.manifest.json').write_text(json.dumps(data,indent=2)+'\\n')
output.with_suffix(output.suffix+'.sha256').write_text(data['sha256']+'  '+output.name+'\\n')
print(json.dumps({k:v for k,v in data.items() if k!='files'}))
`, root, archive], { encoding: 'utf8', timeout: 120000 });
console.log(packageResult.trim());
