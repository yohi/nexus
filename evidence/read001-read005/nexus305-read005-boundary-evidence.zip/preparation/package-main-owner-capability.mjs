// Evidence artifacts only; never import or execute Harness/test/SDK modules.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const repo = path.resolve(process.argv[2]);
const baseline = path.resolve(process.argv[3]);
const sha = data => createHash('sha256').update(data).digest('hex');
const source = (dir, name) => fs.readFileSync(path.join(dir, name));
const json = (name, value) => fs.writeFileSync(path.join(root, name), JSON.stringify(value, null, 2) + '\n');
const walk = (dir, prefix = '') => fs.readdirSync(path.join(dir, prefix), { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(dir, path.join(prefix, entry.name)) : [path.join(prefix, entry.name)]);
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
if (head !== '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d') throw new Error('BASELINE_DRIFT:HEAD');
const fixed = {
  'reference/api/@modelcontextprotocol/sdk/dist/esm/server/webStandardStreamableHttp.js': '177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6',
  'reference/SECTION4_1_REV5_PROPOSAL.md': 'e7a556379fb9fb8aa04cbc1ab0871f84ba24f1f6d8f61d26a7609f93776db48b',
  'reference/R3_TARGETED_SPIKE_PLAN.md': 'c265a155673ac76b27d996f8af199869cd2cd0bceb7ad03e6db2a4c6b6e74a5f'
};
for (const [name, hash] of Object.entries(fixed)) if (sha(source(root, name)) !== hash) throw new Error(`BASELINE_DRIFT:${name}`);
const inputNames = ['nexus305-read001-read005-codex-handoff.zip', 'nexus305-r3-read001-004-source-closure-evidence.zip'];
const inputResults = JSON.parse(execFileSync('python3', ['-c', `
import zipfile,hashlib,json,pathlib,sys
results=[]
for n in sys.argv[1:]:
 p=pathlib.Path(n); z=zipfile.ZipFile(p); bad=z.testzip(); rows=[]
 if bad: raise RuntimeError('CRC:'+bad)
 for line in z.read('SHA256SUMS').decode().splitlines():
  if not line.strip(): continue
  expected,name=line.split(None,1); name=name.lstrip(' *'); actual=hashlib.sha256(z.read(name)).hexdigest()
  if actual!=expected: raise RuntimeError('CHECKSUM:'+name)
  rows.append({'path':name,'sha256':actual})
 results.append({'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'crc':'VERIFIED','internalChecksums':len(rows),'manifest':rows})
print(json.dumps(results))
`, ...inputNames.map(name => path.join(repo, name))], { encoding: 'utf8' }));
if (inputResults[1].sha256 !== 'f98094211e2962ea21afd4187a2f1a93b80150cef7d6701c191f6aed27fff0ef') throw new Error('BASELINE_DRIFT:EVIDENCE');
for (const row of inputResults[1].manifest) if (sha(source(baseline, row.path)) !== row.sha256) throw new Error(`BASELINE_DRIFT:EXTRACTION:${row.path}`);
const handoffSourceComparison = inputResults[0].manifest.filter(row => row.path.startsWith('sources/')).map(row => {
  const name = row.path.slice('sources/'.length);
  if (sha(source(baseline, name)) !== row.sha256) throw new Error(`BASELINE_DRIFT:HANDOFF_SOURCE:${name}`);
  return { path: name, sha256: row.sha256, identical: true };
});
const handoff = path.join(root, 'inputs/read005-handoff-original.zip');
fs.copyFileSync(path.join(repo, inputNames[0]), handoff);
const instructions = execFileSync('python3', ['-c', "import zipfile,sys; sys.stdout.buffer.write(zipfile.ZipFile(sys.argv[1]).read('00_INSTRUCTIONS.md'))", handoff]);
fs.writeFileSync(path.join(root, 'inputs/READ005_WORK_CONTRACT.md'), instructions);
json('READ005_INPUT_VERIFICATION.json', { status: 'PASS_STATIC_ONLY', head, inputs: inputResults, fixed, handoffSourceComparison,
  authoritativeSource: inputNames[1], originalArchivesModified: false, baselineExtractionByteIdentical: true });

const original = walk(baseline);
const changed = original.filter(name => !fs.existsSync(path.join(root, name)) || sha(source(root, name)) !== sha(source(baseline, name)));
const newSource = walk(root).filter(name => /^(src|tests|preparation)\//.test(name) && !fs.existsSync(path.join(baseline, name)));
const sourceChanges = changed.filter(name => /^(src|tests|preparation)\//.test(name));
const allowed = ['src/replay/main-session-owner.mjs', 'src/adapters/sdk-drivers.mjs', 'tests/source-closure.test.mjs'];
if (sourceChanges.some(name => !allowed.includes(name))) throw new Error('SOURCE_SCOPE_EXPANDED');
const immutable = original.filter(name => /^(src|reference|schemas|fixtures)\//.test(name) && !allowed.includes(name));
immutable.push('R3_FROZEN_COMMAND_MANIFEST.json', 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json', 'R3_EXECUTION_GATE_STATUS.json');
const comparison = immutable.map(name => ({ path: name, baselineSha256: sha(source(baseline, name)), currentSha256: sha(source(root, name)), identical: source(baseline, name).equals(source(root, name)) }));
if (comparison.some(row => !row.identical)) throw new Error('IMMUTABLE_SOURCE_DRIFT');
json('READ005_IMMUTABILITY_COMPARISON.json', { status: 'PASS_STATIC_ONLY', files: comparison,
  bindings: 234, safe: 117, negative: 117, oracleCells: 61, execution: 'NOT_EXECUTED',
  limitation: 'Byte identity is non-modification evidence, not runtime invariant proof.' });
const diffFiles = [...sourceChanges, ...newSource].sort();
const patch = execFileSync('python3', ['-c', `
import difflib,pathlib,sys
before=pathlib.Path(sys.argv[1]); after=pathlib.Path(sys.argv[2])
for name in sys.argv[3:]:
 p=before/name; old=p.read_text().splitlines(keepends=True) if p.exists() else []
 new=(after/name).read_text().splitlines(keepends=True)
 sys.stdout.write(''.join(difflib.unified_diff(old,new,fromfile='a/'+name if p.exists() else '/dev/null',tofile='b/'+name)))
`, baseline, root, ...diffFiles], { encoding: 'utf8' });
fs.writeFileSync(path.join(root, 'READ005_SOURCE_DIFF.patch'), patch);
const rows = diffFiles.map(name => ({ path: name, previousSha256: fs.existsSync(path.join(baseline, name)) ? sha(source(baseline, name)) : null, sha256: sha(source(root, name)) }));
json('READ005_SOURCE_MANIFEST.json', { status: 'DESIGN_CLARIFICATION_REQUIRED', baselineHead: head, changes: rows,
  patchSha256: sha(patch), sources: walk(root).filter(name => /^(src|tests|preparation)\//.test(name)).sort().map(name => ({ path: name, sha256: sha(source(root, name)) })),
  sourceEditsOnly: true, SDKExecuted: false, experimentsExecuted: false, dependenciesUpdated: false });

const oracleSources = [
  ['P1', 'tests/source-closure.test.mjs#sameMainObjectAfterInitialize', 'Same private Initialize/Dispatch objects, independent artifact hash and provenance; no raw public identity'],
  ['N1', 'tests/main-owner-capability.test.mjs#fabricatedHandlesDenied', 'clone/spread/JSON/prototype/string/ID fail before SDK'],
  ['N1-AUTH', 'tests/main-owner-capability.test.mjs#staleOrForeignAuthorityDenied', 'Foreign Principal/Boot, expired ACTIVE, revoked Authority, lifecycle/abort and final-sync revocation: SDK delta=0'],
  ['N2', 'tests/main-owner-capability.test.mjs#opaqueHandleEscapeDenied', 'Reflection/destructuring, direct driver transport, early close, dependency replacement: SDK/Final/fence bypass delta=0'],
  ['N3', 'tests/main-owner-capability.test.mjs#replayUsesOnlyIndependentBroker', 'Authenticated Broker only, fresh private renderer, main dispatch/close=0, revoked payload/claim revival=0'],
  ['N4', 'tests/main-owner-capability.test.mjs#publicationAndLifecycleRemainDistinct', 'C0/F1/P, Stored Auth, Terminal Claim, INV-01-07 and close/crash/abort remain distinct'],
  ['N5-RESIDUAL', 'tests/main-owner-capability.test.mjs#caseContextCannotReadProviderRawIdentity', 'Remaining Case Context Registry raw-receipt counterexample; not satisfied by current local source fix']
];
json('READ005_ORACLE_MATRIX.json', { status: 'DESIGN_CLARIFICATION_REQUIRED', immutableOriginalCells: 61, immutableOriginalBindings: 234,
  supplementaryOraclesNotBindingPromotion: true, venueFixtureContract: 'Independent enrollment, observation windows reset after Initialize, hashed immutable artifacts, provenance checked by separate verifier; no fake counters or self-reported owner tokens.',
  rows: oracleSources.map(([id, source, expected]) => ({ id, source, expected, execution: 'NOT_EXECUTED', actual: null, negativeObservation: 'UNKNOWN',
    sourceStatus: id === 'N5-RESIDUAL' ? 'RESIDUAL_COUNTEREXAMPLE' : 'SOURCE_ONLY_AWAITING_VENUE', missing: ['Genuine enrolled venue', 'Independent raw artifact producer and verifier', 'Separately authorized execution'] })) });
const paths = [
  ['E01', 'MainSessionOwners.register()', 'Handle.transport/server/attempt/session/close', 'Empty identity-registered handle', 'REMOVED_STATICALLY'],
  ['E02', 'MainSessionOwners.reference()', 'Binding.transport/server', 'Public API removed; private #binding', 'REMOVED_STATICALLY'],
  ['E03', 'MainSessionOwners.admit()', 'Binding and Ticket in public return', 'Private #admit; public method returns undefined', 'REMOVED_STATICALLY'],
  ['E04', 'actualSDKWeb()', 'driver.transport.handleRequest(request)', 'No transport return or direct raw access', 'REMOVED_STATICALLY'],
  ['E05', 'Handle.close / Driver.close', 'Unrestricted transport close before owner fence', 'Handle close removed; Driver close denied', 'FAIL_CLOSED_STATICALLY'],
  ['E06', 'MainSessionOwners public dependency fields', 'Replace receipts/observer/requestBoundary', 'Private dependencies and frozen instance', 'REMOVED_STATICALLY'],
  ['E07', 'Handle reflection/spread/JSON/prototype/destructuring/key/string', 'Copy/fabricate raw binding or callable', 'Empty null prototype; no ID lookup; WeakMap identity required', 'REJECTED_IN_SOURCE_ONLY'],
  ['E08', 'Initialize callbacks onclose/onerror/onsessionclosed', 'Lifecycle callback with transport closure', 'No callback escapes through Handle or Driver; trusted SDK retains callback', 'TRUSTED_INTERNAL_SOURCE_ONLY'],
  ['E09', 'MainSessionObserver / verifyMainDispatchSync', 'Actual objects in independent observer input/receipt', 'Local equality checks maintained; external provider trust unproved', 'TRUSTED_PROVIDER_BOUNDARY_UNPROVEN'],
  ['E10', 'assembleDrivers().registry.sync / entry().methods / entry().provider', 'observeActiveSync raw Transport/Server receipt outside Owner', 'No repair in this limited normative contract; concrete N5 counterexample', 'RESIDUAL_ESCAPE_DESIGN_CLARIFICATION_REQUIRED'],
  ['E11', 'assembleOptionAR().receipts.observer.registry / ledger.sessionObserver.registry', 'Alternative public Registry/Provider access', 'No claim that hiding one top-level property eliminates nested paths', 'RESIDUAL_ESCAPE_DESIGN_CLARIFICATION_REQUIRED'],
  ['E12', 'assembleOptionAR().initialize(input.server)', 'Caller retains raw Server input and its SDK authority', 'Owner-side Server construction/transfer contract undefined', 'RESIDUAL_OWNERSHIP_DESIGN_CLARIFICATION_REQUIRED'],
  ['E13', 'MainSessionOwners.register(input)', 'Trusted caller already owns raw registration input', 'Independent observer registration binding checked; registration is not an untrusted factory', 'TRUSTED_COMPOSITION_INPUT_UNPROVEN'],
  ['E14', 'ReplayBroker / renderReplay', 'Renderer handleRequest/send/close', 'Separate fresh private stateless renderer, unchanged; no Main raw getter', 'UNCHANGED_SOURCE_ONLY'],
  ['E15', 'SDKPipeClientTransport / actualPrivateStdio', 'send/onmessage/close on separate private pipe transport', 'Not Main Stateful Transport; unchanged pipe enrollment controls', 'OUTSIDE_MAIN_OWNER_SCOPE']
];
const before = JSON.parse(source(root, 'READ005_BASELINE_STATIC.json'));
const after = JSON.parse(source(root, 'READ005_STATIC_VERIFICATION.json'));
json('CAPABILITY_ESCAPE_PATH_INVENTORY.json', { status: 'DESIGN_CLARIFICATION_REQUIRED', coverage: 'All src/tests .mjs AST property accesses plus manual composition and callback review; not a whole-program dynamic alias proof',
  publicOwnerDriverRawCapabilityPathsAfter: 0, allExternalRawCapabilityPathsZero: 'NOT_PROVEN',
  paths: paths.map(([id, location, before, after, status]) => ({ id, location, before, after, status, runtime: 'NOT_EXECUTED' })),
  beforePropertyAccessInventory: before.inventory, afterPropertyAccessInventory: after.inventory });
json('READ005_SUBMISSION_STATUS.json', { status: 'DESIGN_CLARIFICATION_REQUIRED', localSourceIntegration: 'PARTIALLY_INTEGRATED',
  READ005Finding: 'OPEN_PENDING_INDEPENDENT_REVIEW', READ001Finding: 'UNRESOLVED_PENDING_INDEPENDENT_REVIEW',
  executionGate: 'NOT_AUTHORIZED', R3: 'NOT_EXECUTED', section4_1: 'BLOCKED', R1_001_04: 'UNRESOLVED',
  bindings: { count: 234, safe: 117, negative: 117, status: 'BLOCKED', execution: 'NOT_EXECUTED' }, oracleCells: 61,
  SDKDispatchObservation: 'UNKNOWN', negativeObservation: 'UNKNOWN', independentReview: 'NOT_PERFORMED', stopAfterSubmission: true });
console.log(JSON.stringify({ prepared: true, sourceChanges: diffFiles, immutableFiles: comparison.length, status: 'DESIGN_CLARIFICATION_REQUIRED' }, null, 2));
