import { readFileSync, writeFileSync, copyFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const original = resolve(process.argv[2]); const prompt = resolve(process.argv[3]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const originalSha = 'dd8fe5ac588ad9642709c9e3ad311a9eaaf3afc9a7098d3b443a483f95288cbe';
if (sha(readFileSync(original)) !== originalSha) throw new Error('R1_INPUT_SHA_MISMATCH');
const inputPath = 'inputs/driver-integration-r1-original.zip';
copyFileSync(original, join(root, inputPath));
const contractPath = 'inputs/NEXUS305_R3_R1_001_FIX_PROMPT.md';
copyFileSync(prompt, join(root, contractPath));
const readOriginal = path => execFileSync('unzip', ['-p', original, path], { maxBuffer: 16 * 1024 * 1024 });
const json = path => JSON.parse(readFileSync(join(root, path), 'utf8'));
const put = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const oldSources = JSON.parse(readOriginal('R3_HARNESS_SOURCE_MANIFEST.json'));
const oldRows = JSON.parse(readOriginal('R3_FROZEN_COMMAND_MANIFEST.json'));
const originalSources = new Map([...oldSources.sources, ...oldSources.typeSources].map(row => [row.path, row.sha256]));
for (const path of ['src/authority.mjs', 'src/adapters/sqlite-authority.mjs', 'src/drivers/cutover.mjs', 'src/publication-admission.mjs', 'src/oracles.mjs', 'src/readback-oracle.mjs', 'src/cases.mjs', 'src/launcher.mjs', 'src/revision-oracles.mjs', 'fixtures/r1-counterexample-oracles.json', 'preparation/verify-revision.mjs']) {
  if (!readOriginal(path).equals(readFileSync(join(root, path)))) throw new Error(`R1_NONREGRESSION_BYTES:${path}`);
}
const source = json('R3_HARNESS_SOURCE_MANIFEST.json');
const summary = { revision: 'R2', finding: 'RG-305-R3-R1-001', completion: 'DESIGN_CLARIFICATION_REQUIRED',
  inputArchive: { path: inputPath, sha256: originalSha }, contract: { path: contractPath, sha256: sha(readFileSync(join(root, contractPath))) },
  oracleMatrix: { path: 'R3_R1_001_ORACLE_MATRIX.json', sha256: sha(readFileSync(join(root, 'R3_R1_001_ORACLE_MATRIX.json'))), cases: 15, execution: 'NOT_EXECUTED' },
  counterexampleInspector: { path: 'src/r1-001-oracles.mjs', function: 'inspectR1_001Counterexamples', sha256: sha(readFileSync(join(root, 'src/r1-001-oracles.mjs'))) },
  replayAdmission: 'REPLAY_ENTITLEMENT_UNPROVEN', authenticatedEntitlementVerifier: 'UNDEFINED_NOT_IMPLEMENTED', dynamicExecuted: false };
source.revisionEvidence = summary; put('R3_HARNESS_SOURCE_MANIFEST.json', source);
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
manifest.revisionEvidence = summary;
const rows = [...manifest.bindings, ...manifest.extraBindings]; const baselineRows = [...oldRows.bindings, ...oldRows.extraBindings];
if (rows.length !== 234 || new Set(rows.map(row => row.bindingId)).size !== 234 || rows.filter(row => row.variant === 'SAFE_VARIANT').length !== 117 || rows.filter(row => row.variant === 'NEGATIVE_CONTROL').length !== 117) throw new Error('R1_BINDING_COVERAGE');
for (const row of rows) {
  const old = baselineRows.find(item => item.bindingId === row.bindingId);
  if (!old || old.testId !== row.testId || old.variant !== row.variant || JSON.stringify(old.oracle) !== JSON.stringify(row.oracle)) throw new Error('R1_BINDING_ORACLE_CHANGED');
  if (row.testId.startsWith('R3-T')) row.r1_001OracleSupplement = summary.oracleMatrix;
  if (row.testId === 'R3-T05' && !row.reasons.includes('DESIGN_CLARIFICATION_REQUIRED:REPLAY_ENTITLEMENT_UNPROVEN')) row.reasons.push('DESIGN_CLARIFICATION_REQUIRED:REPLAY_ENTITLEMENT_UNPROVEN');
  row.status = 'BLOCKED'; row.classification = 'NOT_EXECUTED';
}
put('R3_FROZEN_COMMAND_MANIFEST.json', manifest);
const trace = json('R3_TRACEABILITY.json'); trace.revisionEvidence = summary;
for (const group of trace.groups) if (group.testId.startsWith('R3-T')) {
  group.r1_001OracleSupplement = summary.oracleMatrix;
  group.sourcePaths = [...new Set([...group.sourcePaths, 'src/stored-event-binding.mjs', 'src/r1-001-oracles.mjs'])];
  group.r1_001SourceFunctions = ['DurableEventLedger.bindFrame', 'DurableEventLedger.assertPublicationPlan', 'DurableEventLedger.releasePublicationPlan', 'GateOwner.openPublication', 'GateOwner.publishPermit'];
}
put('R3_TRACEABILITY.json', trace);
const gate = json('R3_EXECUTION_GATE_STATUS.json'); gate.revisionEvidence = summary;
gate.finalState = 'REVISION_REQUIRED'; gate.completion = summary.completion;
gate.independentReview = 'NOT_PERFORMED'; gate.independentReviewScope = 'R2_REVISED_PACKAGE';
gate.priorIndependentReviewReported = { DRV_001: 'RESOLVED_STATIC_ONLY', DRV_002_verification: 'RESOLVED_STATIC_ONLY', R1_001: 'MAJOR_REVISION_REQUIRED' };
put('R3_EXECUTION_GATE_STATUS.json', gate);
const sourceChanges = [...source.sources, ...source.typeSources].filter(row => originalSources.get(row.path) !== row.sha256)
  .map(row => ({ path: row.path, beforeSha256: originalSources.get(row.path) ?? null, afterSha256: row.sha256 }));
const toolingSources = readdirSync(join(root, 'preparation')).filter(name => /\.(mjs|mts)$/.test(name))
  .map(name => ({ path: `preparation/${name}`, sha256: sha(readFileSync(join(root, 'preparation', name))) }));
put('R3_R1_001_SOURCE_CHANGES.json', { ...summary, sourceChanges, toolingSources });
const validation = JSON.parse(execFileSync('python3', ['-c', `import zipfile,hashlib,json,sys
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 sums={r.split(None,1)[1].lstrip(' *'):r.split()[0] for r in z.read('SHA256SUMS').decode().splitlines()}
 assert set(names)==set(sums)|{'SHA256SUMS'}
 for name,h in sums.items(): assert hashlib.sha256(z.read(name)).hexdigest()==h,name
 s=json.loads(z.read('R3_HARNESS_SOURCE_MANIFEST.json')); assert len(s['sources'])==38
 for r in s['sources']: assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
 print(json.dumps({'crc':'VERIFIED','members':len(names),'allMemberHashes':'MATCH','originalHarnessSources':38}))`, join(root, inputPath)], { encoding: 'utf8' }));
put('R3_R1_001_INPUT_VERIFICATION.json', { inputSha256: originalSha, ...validation, bindingCount: 234, safe: 117, negative: 117,
  byteIdenticalR1Nonregressions: true, oracleExecutions: 0, experimentalImports: 0 });
console.log(JSON.stringify({ completion: summary.completion, sourceChanges: sourceChanges.length, bindings: 234, ...validation }));
