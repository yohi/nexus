import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve, join } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repository = resolve(process.argv[2] ?? process.cwd());
const baseline = '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d';
const expected = '7e43da564c22979b249eaaf488909b0abef4ca7e927cae745a1fa225ec820042';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const zip = join(repository, 'nexus305-r3-provisioning-v3-final-evidence.zip');
if (hash(readFileSync(zip)) !== expected) throw new Error('INPUT_ZIP_MISMATCH');
if (execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repository, encoding: 'utf8' }).trim() !== baseline) throw new Error('FIXED_HEAD_MISMATCH');
// Archive inspection only: no experimental module or native dependency is loaded.
const script = `import io,zipfile,hashlib,json,sys
records=[]
def inspect(data,label,depth=0):
 z=zipfile.ZipFile(io.BytesIO(data)); assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 assert all(not n.startswith('/') and '..' not in n.split('/') for n in names)
 count=0
 for n in names:
  if n.split('/')[-1] in ('SHA256SUMS','HANDOFF_SHA256SUMS'):
   parent=n.rsplit('/',1)[0]+'/' if '/' in n else ''
   for line in z.read(n).decode().splitlines():
    if not line.strip(): continue
    h,p=line.split(None,1); p=p.lstrip('*'); target=parent+p
    if target not in names: target=p
    assert hashlib.sha256(z.read(target)).hexdigest()==h,(label,target)
    count+=1
 records.append({'archive':label,'sha256':hashlib.sha256(data).hexdigest(),'crc':'VERIFIED','manifestEntriesVerified':count})
 assert depth<12
 for n in names:
  if n.endswith('.zip'): inspect(z.read(n),label+'!'+n,depth+1)
inspect(open(sys.argv[1],'rb').read(),'provisioning-v3-original.zip')
print(json.dumps(records))`;
const archives = JSON.parse(execFileSync('python3', ['-c', script, zip], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }));
const manifest = JSON.parse(readFileSync(join(root, 'R3_HARNESS_SOURCE_MANIFEST.json')));
for (const source of manifest.sources) {
  if (hash(readFileSync(join(root, source.path))) !== source.sha256) throw new Error(`INPUT_SOURCE:${source.path}`);
}
for (const source of manifest.fixedSources) {
  const original = execFileSync('git', ['show', `${baseline}:${source.originalPath}`], { cwd: repository });
  if (hash(original) !== source.sha256 || !original.equals(readFileSync(join(root, source.path)))) throw new Error(`FIXED_SOURCE:${source.originalPath}`);
}
copyFileSync(zip, join(root, 'inputs/provisioning-v3-original.zip'));
writeFileSync(join(root, 'R3_INPUT_VERIFICATION.json'), JSON.stringify({ baseline, head: baseline, expectedZipSha256: expected, archives, originalSources: manifest.sources.length, fixedSources: manifest.fixedSources.length, status: 'VERIFIED', experimentalModulesImported: 0 }, null, 2) + '\n');
console.log(JSON.stringify({ status: 'VERIFIED', archives: archives.length, sources: manifest.sources.length, fixedSources: manifest.fixedSources.length }));
