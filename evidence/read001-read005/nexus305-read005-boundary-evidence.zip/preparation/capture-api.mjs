import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { join, dirname, resolve } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = resolve(process.argv[2] ?? process.cwd());
const ts = createRequire(join(repo, 'package.json'))('typescript');
const baseline = '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const put = (path, bytes) => { mkdirSync(dirname(join(root, path)), { recursive: true }); writeFileSync(join(root, path), bytes); };
const fixed = [];
// Frozen source and side-effect-free transpilation; never import generated files.
const visit = path => {
  for (const entry of readdirSync(join(repo, path), { withFileTypes: true })) {
    const relative = `${path}/${entry.name}`;
    if (entry.isDirectory()) visit(relative);
    else if (relative.endsWith('.ts')) {
      const bytes = execFileSync('git', ['show', `${baseline}:${relative}`], { cwd: repo });
      const originalPath = `reference/baseline/${relative}`;
      const runtimePath = `reference/runtime/${relative.replace(/\.ts$/, '.js')}`;
      put(originalPath, bytes);
      if (relative.endsWith('.d.ts')) {
        fixed.push({ originalPath: relative, path: originalPath, sha256: sha(bytes), runtimePath: null, runtimeSha256: null });
        continue;
      }
      let output;
      try { output = ts.transpileModule(bytes.toString(), { fileName: relative, compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ESNext, isolatedModules: true } }); }
      catch (error) { throw new Error(`TRANSPILE_INPUT:${relative}`, { cause: error }); }
      if (output.diagnostics?.some(item => item.category === ts.DiagnosticCategory.Error)) throw new Error(`TRANSPILE:${relative}`);
      put(runtimePath, output.outputText);
      fixed.push({ originalPath: relative, path: originalPath, sha256: sha(bytes), runtimePath, runtimeSha256: sha(Buffer.from(output.outputText)) });
    }
  }
};
visit('src');
put('reference/runtime/package.json', '{"type":"module","private":true}\n');
const declarations = [];
const capture = (packageName, version, names) => {
  const base = join(repo, 'node_modules', packageName);
  const packageBytes = readFileSync(join(base, 'package.json'));
  if (JSON.parse(packageBytes).version !== version) throw new Error(`VERSION:${packageName}`);
  for (const name of ['package.json', ...names]) {
    const bytes = readFileSync(join(base, name));
    const path = `reference/api/${packageName}/${name}`;
    put(path, bytes); declarations.push({ packageName, version, originalPath: `node_modules/${packageName}/${name}`, path, sha256: sha(bytes) });
  }
};
capture('@lancedb/lancedb', '0.18.2', ['dist/index.d.ts', 'dist/connection.d.ts', 'dist/table.d.ts', 'dist/query.d.ts']);
capture('@modelcontextprotocol/sdk', '1.29.0', ['dist/esm/server/stdio.d.ts', 'dist/esm/server/stdio.js', 'dist/esm/server/webStandardStreamableHttp.d.ts', 'dist/esm/server/webStandardStreamableHttp.js', 'dist/esm/client/index.d.ts', 'dist/esm/inMemory.d.ts']);
const serverDecl = readdirSync(join(repo, 'node_modules/@modelcontextprotocol/server/dist')).filter(name => name.startsWith('createMcpHandler-') && name.endsWith('.d.mts'));
capture('@modelcontextprotocol/server', '2.0.0', ['dist/index.d.mts', ...serverDecl.map(name => `dist/${name}`)]);
capture('@modelcontextprotocol/node', '2.0.0', ['dist/index.d.mts', 'dist/index.mjs']);
put('R3_API_SIGNATURE_EVIDENCE.json', JSON.stringify({ baseline, fixed, declarations, nativeLoaded: false, sdkLoaded: false, entireR2RuntimeTreeVerified: false, compiler: ts.version, scope: 'Installed matching direct versions; hashed declarations and source only. R2 transitive runtime enrollment remains required.' }, null, 2) + '\n');
console.log(JSON.stringify({ fixedSources: fixed.length, apiEvidenceFiles: declarations.length, experimentalImports: 0 }));
