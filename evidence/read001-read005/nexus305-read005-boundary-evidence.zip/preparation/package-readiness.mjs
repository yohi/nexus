// Archive/evidence generation only. Never imports experimental source or SDK.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { join, resolve, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const [repo, original, externalManifest, handoff, design, archive] = process.argv.slice(2).map(p => resolve(p));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = p => readFileSync(join(root, p), 'utf8');
const json = p => JSON.parse(text(p));
const write = (p, value) => writeFileSync(join(root, p), JSON.stringify(value, null, 2) + '\n');
const walk = (base, path = '') => readdirSync(join(base, path), { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(base, join(path, e.name)) : [join(path, e.name)]);
const commands = json('R3_FROZEN_COMMAND_MANIFEST.json');
const bindings = [...commands.bindings, ...commands.extraBindings];
const originalGate = json('R3_EXECUTION_GATE_STATUS.json');
const capabilityText = text('src/adapters/capability-registry.mjs');
const methods = [...capabilityText.slice(capabilityText.indexOf('Object.freeze({'), capabilityText.indexOf('\n});')).matchAll(/(\w+): \[([^\]]+)\]/g)]
  .map(m => ({ name: m[1], methods: [...m[2].matchAll(/'([^']+)'/g)].map(s => s[1]) }));
write('TRUST_AND_CAPABILITY_BINDING_MATRIX.json', {
  schemaVersion: 'readiness-capabilities/1', status: 'PARTIALLY_INTEGRATED', trustRootEnrolled: false,
  compositionEntrances: ['src/adapters/capability-registry.mjs#CapabilityRegistry', 'src/drivers/integration.mjs#assembleDrivers',
    'src/replay/assembly.mjs#assembleOptionAR', 'src/readiness/scenario-runner.mjs#ScenarioVenue'],
  rows: methods.map(capability => ({ capability: capability.name, methods: capability.methods,
    provider: null, issuer: null, verifier: null, owner: capability.name === 'executionAuthorization' ? 'independent-execution-owner' : `venue-${capability.name}-owner`,
    SDK_DB_FD: capability.name === 'finalWriter' ? 'OS final FD / same GateOwner' : ['initialize', 'scenario'].includes(capability.name) ? 'pinned SDK / genuine main session' :
      capability.name === 'durability' ? 'real SQLite WAL/fsync/ACTIVE readback' : 'independent venue inputs',
    trustedReceipt: null, requiredReceiptFields: ['capability', 'issuer', 'verifier', 'owner', 'bootId', 'expiresAt', 'rawArtifactRef'],
    registration: 'VENUE_CAPABILITY_UNENROLLED', failClosedReason: `VENUE_CAPABILITY_UNENROLLED:${capability.name}`,
    positiveDecisionNow: 'UNAVAILABLE', scope: 'composition-root only, never HTTP/IPC client enrollment' }))
});
const catalog = json('src/readiness/scenario-catalog.json');
write('SCENARIO_RUNNER_AND_ORACLE_MATRIX.json', {
  schemaVersion: 'readiness-scenario-oracles/1', status: 'PARTIALLY_INTEGRATED', executionGate: 'NOT_AUTHORIZED',
  experiment: 'NOT_EXECUTED', oracleCellCount: 61, originalBindingCount: 234, safe: 117, negative: 117,
  distinction: '61 Option A-R oracle cells are not replacements for 234 original command bindings',
  oracleCells: catalog,
  originalBindings: bindings.map(row => ({ bindingId: row.bindingId, testId: row.testId, variant: row.variant,
    originalOracle: row.oracle, originalOracleHash: sha(JSON.stringify(row.oracle)),
    sources: row.sources.map(source => ({ path: source.path, originalHash: source.sha256, currentHash: sha(readFileSync(join(root, source.path))) })),
    status: 'BLOCKED', execution: 'NOT_EXECUTED', actual: null,
    requiredVenueInputs: originalGate.remainingDriverWork[row.testId] ?? ['ORIGINAL_OWNER_SCENARIO_BINDING_REQUIRED'],
    executionAuthorization: 'NOT_AUTHORIZED', readiness: 'SOURCE_AND_VENUE_INCOMPLETE' })),
  groups: Object.entries(originalGate.remainingDriverWork).map(([testId, blockers]) => ({ testId, blockers,
    sourcePaths: [...new Set(bindings.filter(r => r.testId === testId).flatMap(r => r.sources.map(s => s.path)))],
    bindingIds: bindings.filter(r => r.testId === testId).map(r => r.bindingId),
    owner: `venue-${testId}-owner`, status: 'BLOCKED', execution: 'NOT_EXECUTED', actual: null,
    fixtureReadiness: testId === 'R3-T05' ? '61 descriptors / registration / independent raw interfaces; real controls unregistered' : 'original source only; dedicated venue barriers and controls unregistered' }))
});
const gate = { ...originalGate, finalState: 'PARTIALLY_INTEGRATED', integrationStatus: 'PARTIALLY_INTEGRATED',
  independentReview: 'NOT_PERFORMED', independentReviewScope: 'EXECUTION_READINESS_SOURCE_INTEGRATION',
  authorization: null, venue: null, runnableExperimentCount: 0,
  readinessSubmission: { disposition: 'PARTIALLY_INTEGRATED', staticVerification: 'PASS_STATIC_ONLY',
    independentApproval: 'NONE', experimentEvidence: 'NONE', R1_001_04: 'UNRESOLVED',
    designFindings: { DES_001: 'RESOLVED_DESIGN_ONLY', DES_002: 'RESOLVED_DESIGN_ONLY', DES_003: 'RESOLVED_DESIGN_ONLY' } } };
write('R3_EXECUTION_GATE_STATUS.json', gate);
// Preserve full original archive and external manifest; original provenance
// inside the source package remains immutable, including all nested ZIPs.
for (const [from, to] of [
  [join(repo, 'nexus305-r3-t05-option-ar-evidence.zip'), 'inputs/readiness-evidence-original.zip'],
  [join(repo, 'nexus305-r3-option-ar-execution-readiness-handoff.zip'), 'inputs/readiness-handoff-original.zip'],
  [join(repo, 'nexus305_r3_t05_replay_design_addendum_rev3.zip'), 'inputs/readiness-rev3-original.zip'],
  [externalManifest, 'inputs/readiness-evidence-original.manifest.json'],
  [join(handoff, '01_CODEX_PROMPT.md'), 'inputs/READINESS_WORK_CONTRACT.md']
]) writeFileSync(join(root, to), readFileSync(from));
const inputs = [
  { path: 'inputs/readiness-evidence-original.zip', expected: 'c0a5737cfd28a36006874daffdd7ad6c18a91ab83db5973ea8a054e8ef188940' },
  { path: 'inputs/readiness-rev3-original.zip', expected: '9166a4021136bdcc88d73e62b75e169c128f9ce69a0bfaa0d0bb0e893973f200' }
];
for (const input of inputs) if (sha(readFileSync(join(root, input.path))) !== input.expected) throw new Error(`BASELINE_DRIFT:${input.path}`);
const baseline = json('READINESS_INPUT_VERIFICATION.json');
write('READINESS_INPUT_VERIFICATION.json', { ...baseline, inputCRC: 'ALL_THREE_ZIPS_PASS', inputSHA256SUMS: 'ALL_THREE_MATCH',
  fixedArchives: inputs, handoffHash: sha(readFileSync(join(root, 'inputs/readiness-handoff-original.zip'))),
  rev3FilenameDifference: 'Local filename lacks (1); archive bytes match fixed original SHA-256',
  externalManifestHash: sha(readFileSync(externalManifest)), navigationMatchesOriginal: true,
  sdkPinsAndRev5Plan: 'MATCH', originalBindingsAndOracles: 'MATCH' });
const inputLogs = [];
for (const dir of [original, handoff, design]) {
  const output = execFileSync('sha256sum', ['-c', 'SHA256SUMS', '--quiet'], { cwd: dir, encoding: 'utf8' });
  inputLogs.push({ command: 'sha256sum -c SHA256SUMS --quiet', workingDirectory: dir === original ? 'original-extraction' : dir === handoff ? 'handoff-extraction' : 'rev3-extraction', exitCode: 0, output });
}
const staticOutput = execFileSync(process.execPath, [join(root, 'preparation/verify-readiness.mjs'), repo, original], { encoding: 'utf8' });
write('READINESS_STATIC_COMMAND_LOG.json', { commands: [...inputLogs,
  { command: 'node preparation/verify-readiness.mjs $REPO $ORIGINAL_EXTRACTION', exitCode: 0, output: staticOutput }],
  packagingTool: 'python3 standard-library zipfile; external zip executable unavailable (ENOENT), no dependency installed',
  limitations: ['No runtime tests; no SDK/HTTP/Native/fault/migration execution', 'No independent review', 'No full JS semantic typecheck'],
  experimentalImports: 0, dynamicTests: 0 });
const sourceFiles = walk(root).filter(p => /^(src|tests|preparation)\//.test(p));
const rows = sourceFiles.map(path => ({ path, originalHash: existsInOriginal(path), sha256: sha(readFileSync(join(root, path))) }));
function existsInOriginal(path) {
  try { return sha(readFileSync(join(original, path))); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
write('SOURCE_DIFF_SHA256.json', { fixedHead: baseline.fixedHead, status: 'PARTIALLY_INTEGRATED', allSourceHashes: rows,
  changed: rows.filter(r => r.originalHash !== r.sha256), launcherHash: sha(readFileSync(join(root, 'src/launcher.mjs'))),
  frozenInputPins: baseline.pins, originalOracleCount: 61, originalBindingCount: 234 });
let diff = '';
for (const directory of ['src', 'tests']) {
  try { diff += execFileSync('git', ['diff', '--no-index', '--no-ext-diff', join(original, directory), join(root, directory)], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }); }
  catch (error) { if (error.status !== 1) throw error; diff += error.stdout; }
}
diff = diff.replaceAll('a' + original + '/', 'a/').replaceAll('b' + root, 'b/').replaceAll('a' + root, 'a/')
  .replaceAll(original + '/', '').replaceAll(root, '');
if (diff.includes(original) || diff.includes(root)) throw new Error('MACHINE_PATH_IN_DIFF');
writeFileSync(join(root, 'SOURCE_DIFF.patch'), diff);
const members = walk(root).filter(p => p !== 'SHA256SUMS').sort().map(path => ({ path, bytes: readFileSync(join(root, path)).length,
  sha256: sha(readFileSync(join(root, path))) }));
writeFileSync(join(root, 'SHA256SUMS'), members.map(m => `${m.sha256}  ${m.path}`).join('\n') + '\n');
execFileSync('sha256sum', ['-c', 'SHA256SUMS', '--quiet'], { cwd: root, stdio: 'pipe' });
execFileSync('python3', ['-c',
  'import pathlib,sys,zipfile; root=pathlib.Path(sys.argv[1]); z=zipfile.ZipFile(sys.argv[2],"w",zipfile.ZIP_DEFLATED); [z.write(p,p.relative_to(root)) for p in sorted(root.rglob("*")) if p.is_file()]; z.close()',
  root, archive], { stdio: 'pipe' });
const crcLog = execFileSync('unzip', ['-t', archive], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
if (!crcLog.includes('No errors detected')) throw new Error('OUTPUT_CRC');
const archiveHash = sha(readFileSync(archive));
writeFileSync(archive + '.sha256', `${archiveHash}  ${basename(archive)}\n`);
const checksumMember = { path: 'SHA256SUMS', bytes: readFileSync(join(root, 'SHA256SUMS')).length, sha256: sha(readFileSync(join(root, 'SHA256SUMS'))) };
writeFileSync(archive + '.manifest.json', JSON.stringify({ archive: basename(archive), sha256: archiveHash, crc: 'PASS',
  finalDisposition: 'PARTIALLY_INTEGRATED', executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED',
  sourceHashes: 'MATCH', originals: 'FIXED_SHA256_MATCH', inputVerification: baseline,
  memberCount: members.length + 1, members: [...members, checksumMember], outputCRCLog: crcLog.split('\n').at(-2) }, null, 2) + '\n');
console.log(JSON.stringify({ archive: basename(archive), sha256: archiveHash, members: members.length + 1,
  changedSources: rows.filter(r => r.originalHash !== r.sha256).length, oracleCells: catalog.length, originalBindings: bindings.length,
  disposition: 'PARTIALLY_INTEGRATED', staticOutput: JSON.parse(staticOutput) }));
