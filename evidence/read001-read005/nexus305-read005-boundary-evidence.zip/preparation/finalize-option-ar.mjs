// Packaging metadata only; never loads experiment source.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(join(root, path), 'utf8'));
const put = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const walk = (path = '') => readdirSync(join(root, path), { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(join(path, entry.name)) : [join(path, entry.name)]).sort();
const staticReport = json('R3_STATIC_VERIFICATION.json');
const supplement = json('R3_T05_STATIC_VERIFICATION.json');
staticReport.taskRevision = 'OPTION_A_R'; staticReport.completion = 'PARTIALLY_INTEGRATED';
staticReport.replayEntitlement = 'SOURCE_IMPLEMENTED_VENUE_BINDING_REQUIRED';
staticReport.optionARChecks = supplement.checks;
staticReport.limitations = supplement.limitations;
const resolution = 'TS2688 on first workspace invocation: unchanged verifier needs repository cwd; rerun passed with existing Node typings';
if (!staticReport.toolingFailuresResolved.includes(resolution)) staticReport.toolingFailuresResolved.push(resolution);
put('R3_STATIC_VERIFICATION.json', staticReport);
const original = join(root, 'inputs/option-ar-r2-original.zip');
const oldHashes = new Map(execFileSync('unzip', ['-p', original, 'SHA256SUMS'], { encoding: 'utf8' }).trim().split('\n').map(line => {
  const [digest, ...path] = line.split(/\s+/); return [path.join(' ').replace(/^\*/, ''), digest];
}));
const files = walk().filter(path => path !== 'SHA256SUMS' && path !== 'R3_T05_SOURCE_DIFF_MANIFEST.json');
const oldPaths = execFileSync('unzip', ['-Z1', original], { encoding: 'utf8' }).trim().split('\n');
put('R3_T05_SOURCE_DIFF_MANIFEST.json', { inputSha256: sha(readFileSync(original)),
  changes: files.map(path => {
    const before = oldHashes.get(path) ?? null; const after = sha(readFileSync(join(root, path)));
    return { path, beforeSha256: before, afterSha256: after,
      disposition: before === after ? 'UNCHANGED' : before ? 'MODIFIED' : 'ADDED',
      function: path.startsWith('src/replay/') ? 'Replay owner/ledger/renderer/receipt/Oracle implementation'
        : path.startsWith('src/') ? 'Existing harness preservation or integration' : 'Evidence, test or static preparation' };
  }), removedPaths: oldPaths.filter(path => !files.includes(path) && path !== 'SHA256SUMS'),
  exclusions: ['Self-hash excluded; complete SHA256SUMS includes this file'] });
const inputs = [
  ['inputs/option-ar-r2-original.zip', '4d328ad3eeaefdd52979f1fd6140bb7d01b5c0f7635f020004be49f44e486e22'],
  ['inputs/option-ar-rev3-original.zip', '9166a4021136bdcc88d73e62b75e169c128f9ce69a0bfaa0d0bb0e893973f200'],
  ['inputs/option-ar-handoff-original.zip', 'e419fe788f2e4b19ca0e5cd3da5576f5546a6972864bd5203535102cb7901f80']
];
for (const [path, expected] of inputs) if (sha(readFileSync(join(root, path))) !== expected) throw new Error(`ORIGINAL_DRIFT:${path}`);
put('R3_T05_INPUT_VERIFICATION.json', { inputs: inputs.map(([path, sha256]) => ({ path, sha256,
  crc: 'VERIFIED_BEFORE_EXTRACTION', internalMemberSHA256: 'VERIFIED_BEFORE_EDITS' })),
  fixedHead: '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d', workContractRead: 'FULL_TEXT_144_LINES',
  productChanges: 0, githubWrites: 0, dynamicExperiments: 0, executionGate: 'NOT_AUTHORIZED' });
writeFileSync(join(root, 'SHA256SUMS'), walk().filter(path => path !== 'SHA256SUMS').map(path => `${sha(readFileSync(join(root, path)))}  ${path}`).join('\n') + '\n');
console.log(JSON.stringify({ membersWithHashes: walk().length - 1, originalsVerified: inputs.length,
  staticStatus: supplement.status, finalDisposition: 'PARTIALLY_INTEGRATED' }));
