// Static source inspection only: NEVER import Harness, SDK or test modules.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const source = name => fs.readFileSync(path.join(root, name), 'utf8');
const checks = [];
function check(id, pass) { checks.push({ id, result: pass ? 'PASS_STATIC_ONLY' : 'FAIL' }); }
const web = source('src/adapters/sdk-drivers.mjs');
const webBody = web.slice(web.indexOf('export async function actualSDKWeb'), web.indexOf('export function actualV2Driver'));
check('READ001_NO_FRESH_WEB_TRANSPORT', !webBody.includes('new WebStandardStreamableHTTPServerTransport'));
check('READ001_OWNER_DISPATCH', webBody.includes('mainOwners.dispatch('));
check('READ002_FAIL_CLOSED_API_BLOCKER', web.includes('SDK_API_CONTRACT_BLOCKED:V2_MAIN_STATEFUL_OWNER'));
check('READ003_NO_CALLBACK_STDOUT', !source('src/adapters/final-write.mjs').includes('gate.publish('));
check('READ003_CASE_OLD_WRITERS_MIGRATED', !source('src/cases.mjs').includes('ctx.attemptOldPublication(') && !source('src/cases.mjs').includes('ctx.holdF1AndAttemptOldPublication('));
check('READ003_NO_SELF_ASSERTED_PRIVATE_PIPE', !web.includes('pipes.enrollmentRef') && web.includes('inspectPrivatePipes('));
check('READ003_NO_EMIT_FRAME_CALLBACK', !source('src/adapters/mcp.mjs').includes('this.emitFrame'));
check('READ004_CONCRETE_INTERVENTION', source('src/readiness/scenario-runner.mjs').includes('executeIntervention('));
check('READ004_BARRIER_INDEPENDENCE', source('src/readiness/fixtures.mjs').includes('independentObserverRef'));
check('LAUNCHER_LOCKED', source('src/launcher.mjs').includes('NOT_AUTHORIZED'));
console.log(JSON.stringify({ status: checks.every(c => c.result === 'PASS_STATIC_ONLY') ? 'PASS_STATIC_ONLY' : 'FAIL', runtimeImported: false, testsExecuted: false, checks }, null, 2));
if (checks.some(c => c.result === 'FAIL')) process.exitCode = 1;

// Additional AST/inventory gates use the existing toolchain, never install one.
if (process.argv[2]) {
  const ts = createRequire(path.join(path.resolve(process.argv[2]), 'package.json'))('typescript');
  const sha = bytes => createHash('sha256').update(bytes).digest('hex');
  const walk = dir => fs.readdirSync(path.join(root, dir), { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]);
  const files = ['src', 'tests', 'preparation'].flatMap(walk).filter(p => p.endsWith('.mjs'));
  const asts = new Map(); const syntax = [];
  for (const name of files) {
    execFileSync(process.execPath, ['--check', path.join(root, name)], { stdio: 'pipe' });
    const ast = ts.createSourceFile(name, source(name), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
    if (ast.parseDiagnostics.length) throw new Error(`AST_PARSE:${name}`);
    asts.set(name, ast); syntax.push({ path: name, sha256: sha(source(name)), result: 'PASS_STATIC_ONLY' });
  }
  const exports = ast => new Set(ast.statements.flatMap(s => {
    if (ts.isExportDeclaration(s) && s.exportClause && ts.isNamedExports(s.exportClause)) return s.exportClause.elements.map(e => e.name.text);
    if (!s.modifiers?.some(m => m.kind === ts.SyntaxKind.ExportKeyword)) return [];
    if (s.name) return [s.name.text];
    return ts.isVariableStatement(s) ? s.declarationList.declarations.map(d => d.name.getText(ast)) : [];
  }));
  const graph = []; const writers = []; const callGraph = [];
  for (const [name, ast] of asts) {
    for (const statement of ast.statements) if (ts.isImportDeclaration(statement)) {
      const spec = statement.moduleSpecifier.text;
      if (!spec.startsWith('.')) continue;
      const target = path.normalize(path.join(path.dirname(name), spec));
      if (!fs.existsSync(path.join(root, target))) throw new Error(`MISSING_IMPORT:${name}:${target}`);
      const named = statement.importClause?.namedBindings;
      if (asts.has(target) && named && ts.isNamedImports(named)) {
        for (const symbol of named.elements) if (!exports(asts.get(target)).has((symbol.propertyName ?? symbol.name).text)) throw new Error(`MISSING_EXPORT:${name}:${symbol.name.text}`);
      }
      graph.push({ from: name, to: target, import: spec, targetSha256: sha(fs.readFileSync(path.join(root, target))) });
    }
    const visit = node => {
      if (name === 'src/gate-owner.mjs' && ts.isAwaitExpression(node)) throw new Error('ASYNC_GATEOWNER');
      if (ts.isPropertyAccessExpression(node) && ['_initialized', '_streamMapping', '_requestToStreamMapping'].includes(node.name.text)) throw new Error(`PRIVATE_SDK_STATE:${name}`);
      if (name.startsWith('src/') && ts.isCallExpression(node)) {
        const callee = node.expression.getText(ast);
        let parent = node.parent;
        while (parent && !ts.isFunctionDeclaration(parent) && !ts.isMethodDeclaration(parent) && !ts.isArrowFunction(parent)) parent = parent.parent;
        const owner = parent?.name?.getText(ast) ?? (parent?.parent?.name?.getText(ast) ?? '<closure>');
        const position = ast.getLineAndCharacterOfPosition(node.getStart(ast));
        callGraph.push({ path: name, line: position.line + 1, caller: owner, callee, resolution: 'STATIC_CALL_EXPRESSION_NOT_DYNAMIC_DISPATCH_PROOF' });
        if (/(writeHead|\.write|\.end|send|publish|prepareTerminal|enroll.*Final|connect|emitFrame|stdoutFinal)$/.test(callee) || /(?:publish|Publication|Permit|Final)/.test(callee)) {
          let classification = 'OWNER_GATE_OR_PRIVATE_DISPATCH';
          if (name === 'src/launcher.mjs') classification = 'STATIC_DESCRIPTION_STDOUT_NOT_EXPERIMENT';
          else if (name === 'src/adapters/http-publication.mjs' && callee.startsWith('response.')) classification = 'ENROLLED_HTTP_FINAL_SINK';
          else if (name === 'src/adapters/http-publication.mjs' && callee === 'writable.write') classification = 'ENROLLED_STDOUT_FINAL_SINK';
          else if (name === 'src/adapters/sdk-drivers.mjs' || name === 'src/adapters/mcp.mjs') classification = 'PRIVATE_SDK_OUTPUT_REQUIRES_PIPE_ENROLLMENT';
          else if (name === 'src/replay/renderer.mjs' && callee === 'send') classification = 'PRIVATE_STATELESS_SDK_REPLAY_SEND_NOT_FINAL_P';
          writers.push({ path: name, line: position.line + 1, owner, callee, classification, sourceHash: sha(source(name)), runtimeExecuted: false });
        }
      }
      ts.forEachChild(node, visit);
    }; visit(ast);
  }
  const catalog = JSON.parse(source('src/readiness/scenario-catalog.json'));
  const original = JSON.parse(source('R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json')).rows;
  check('READ004_61_ORIGINAL_IDS', catalog.length === 61 && catalog.every((r, i) => r.caseId === original[i].caseId && r.scenario === original[i].scenario && r.actual === null && r.execution === 'NOT_EXECUTED'));
  const controlAst = asts.get('src/readiness/intervention-plans.mjs'); const controls = new Map();
  const visitControl = node => {
    if (ts.isPropertyAssignment(node) && ts.isArrayLiteralExpression(node.initializer) && node.initializer.elements.length === 3 && node.initializer.elements.every(ts.isStringLiteral)) {
      controls.set(node.name.text, node.initializer.elements.map(e => e.text));
    }
    ts.forEachChild(node, visitControl);
  }; visitControl(controlAst);
  check('READ004_61_CONTROL_MAPPINGS', catalog.every(r => controls.has(r.scenario) && (controls.get(r.scenario)[1] === 'ENTRY' || r.barriers.includes(controls.get(r.scenario)[1]))));
  const manifest = JSON.parse(source('R3_FROZEN_COMMAND_MANIFEST.json')); const bindings = [...manifest.bindings, ...manifest.extraBindings];
  check('READ004_234_IMMUTABLE_IDS', bindings.length === 234 && new Set(bindings.map(b => b.bindingId)).size === 234 && bindings.filter(b => b.variant === 'SAFE_VARIANT').length === 117 && bindings.filter(b => b.variant === 'NEGATIVE_CONTROL').length === 117 && bindings.every(b => b.status === 'BLOCKED' && b.classification === 'NOT_EXECUTED'));
  const cells = catalog.map((r, i) => ({ caseId: r.caseId, scenario: r.scenario, actor: r.actor,
    variant: original[i].variant, originalExpected: original[i].expected, originalVerdictRule: original[i].verdictRule,
    originalRawEvidencePath: original[i].rawEvidencePath, originalOracle: original[i],
    interventionSource: 'src/readiness/intervention-plans.mjs#interventionPlan', action: controls.get(r.scenario)[0],
    marker: controls.get(r.scenario)[1], operation: controls.get(r.scenario)[2],
    runnerSource: 'src/readiness/intervention-runner.mjs#executeIntervention', barriers: r.barriers,
    antecedent: r.inputs, expectedCounterexample: r.rawFields, observerRequirements: r.rawObservers,
    collectorSource: 'src/readiness/raw-collector.mjs#IndependentRawCollector.collect',
    missingHooks: ['intervention.establishAntecedent', 'intervention.applyControl', 'intervention.connectHooks', 'intervention.disconnectHooks', 'intervention.verifyControlSync', ...(controls.get(r.scenario)[2] === 'VENUE_OPERATION' ? ['intervention.executeVenueOperation:' + controls.get(r.scenario)[0]] : [])],
    sourceStatus: controls.get(r.scenario)[2] === 'VENUE_OPERATION' ? 'SOURCE_PARTIAL' : 'VENUE_BLOCKED',
    status: 'BLOCKED', execution: 'NOT_EXECUTED', actual: null }));
  const bindingRows = bindings.map(b => ({ bindingId: b.bindingId, testId: b.testId, variant: b.variant,
    branch: b.branch, sink: b.sink, actor: b.actor, caseFunction: b.caseFunction,
    originalEntryPoint: b.entryPoint, originalOracleRef: b.oracleRef, originalControlScope: b.controlScope,
    originalRequiredEvidence: b.requiredIntegrationEvidence,
    originalSourceBindings: b.sources, originalOracle: b.oracle,
    runnerSource: `${b.entryPoint.path}#${b.entryPoint.function}`,
    sourceStatus: ['R3-T06', 'R3-T07'].includes(b.testId) ? 'SDK_API_BLOCKED' : 'SOURCE_PARTIAL',
    missingHook: 'Independently enrolled concrete context for exact binding branch; original context method bodies are not implemented here',
    status: b.status, classification: b.classification, actual: null }));
  const output = (name, data) => fs.writeFileSync(path.join(root, name), JSON.stringify(data, null, 2) + '\n');
  output('WRITER_PATH_INVENTORY.json', { status: 'PASS_STATIC_ONLY', scope: 'All src/**/*.mjs AST calls plus import graph; private/final labels are source classifications, not FD ownership observations', runtimeExecuted: false, paths: writers, importGraph: graph,
    callGraph, blockedPaths: [{ path: 'GateOwner.publish', reason: 'LEGACY_DIRECT_WRITER always throws' }, { path: 'actualV2Driver.routeNode/capture', reason: 'SDK_API_CONTRACT_BLOCKED' }, { path: 'actualBridgeDriver', reason: 'SDK_API_CONTRACT_BLOCKED before bridge creation' }],
    caseDriverContract: { cases: 'src/cases.mjs#caseFunctions A/B/B2/C/D/E/F', storage: 'src/group-drivers.mjs#storageGroup', transport: 'src/group-drivers.mjs#transportGroup', status: 'SOURCE_PARTIAL', reason: 'Injected ctx bodies and native/FD enrollment remain external; no callback unblocked' } });
  output('READ_004_SCENARIO_RUNNER_MATRIX.json', { status: 'PARTIALLY_INTEGRATED', oracleCells: 61, immutableBindings: 234, safe: 117, negative: 117, cells, bindings: bindingRows });
  output('SOURCE_CLOSURE_DEPENDENCY_GRAPH.json', graph);
  output('STATIC_VERIFICATION.json', { status: checks.every(c => c.result === 'PASS_STATIC_ONLY') ? 'PASS_STATIC_ONLY' : 'FAIL', node: process.version, typescript: ts.version, checks, syntax,
    experimentalImports: 0, testsExecuted: 0, independentReview: 'NOT_PERFORMED', limitation: 'Syntax, AST import/export, source guards and counts only; not behavioral proof, full semantic JS typecheck, API execution or venue certification.' });
  console.log(JSON.stringify({ ast: 'PASS_STATIC_ONLY', files: files.length, writers: writers.length, cells: cells.length, bindings: bindingRows.length, checks }, null, 2));
  if (checks.some(c => c.result === 'FAIL')) process.exitCode = 1;
}
