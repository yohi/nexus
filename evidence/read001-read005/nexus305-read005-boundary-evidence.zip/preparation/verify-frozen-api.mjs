// Compile-only in-memory probes. No generated probe file or SDK import executes.
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = resolve(process.argv[2]);
const ts = createRequire(join(repo, 'package.json'))('typescript');
const options = { noEmit: true, strict: true, exactOptionalPropertyTypes: true, noUncheckedIndexedAccess: true,
  skipLibCheck: true, target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.NodeNext,
  moduleResolution: ts.ModuleResolutionKind.NodeNext, types: ['node'], typeRoots: [join(repo, 'node_modules/@types')] };
const sdk = './reference/api/@modelcontextprotocol/sdk/dist/esm/server/webStandardStreamableHttp.js';
const server = './reference/api/@modelcontextprotocol/server/dist/index.mjs';
const node = './reference/api/@modelcontextprotocol/node/dist/index.mjs';
const probes = [
  { id: 'SDK129_MAIN_PUBLIC_API', expected: [], text: `import { WebStandardStreamableHTTPServerTransport } from '${sdk}';
declare const request: Request;
const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: () => 'compile-only', onsessioninitialized: id => { void id; }, onsessionclosed: id => { void id; } });
const response: Promise<Response> = transport.handleRequest(request);
const session: string | undefined = transport.sessionId;
void response; void session; void transport.close();` },
  { id: 'V2_HANDLER_NO_MAIN_TRANSPORT_GETTER', expected: [2339], text: `import { createMcpHandler } from '${server}';
declare const factory: Parameters<typeof createMcpHandler>[0];
const handler = createMcpHandler(factory);
handler.getMainTransport('compile-only');` },
  { id: 'V2_HANDLER_NO_SESSION_GENERATOR_OPTION', expected: [2353], text: `import { createMcpHandler } from '${server}';
declare const factory: Parameters<typeof createMcpHandler>[0];
createMcpHandler(factory, { sessionIdGenerator: () => 'compile-only' });` },
  { id: 'NODE_WRAPPER_NO_OWNER_ACCESSOR', expected: [2339], text: `import { toNodeHandler } from '${node}';
declare const handler: Parameters<typeof toNodeHandler>[0];
const nodeHandler = toNodeHandler(handler);
nodeHandler.getMainTransport('compile-only');` }
];
const results = probes.map(probe => {
  const filename = join(root, '__compile_only_probe__.mts');
  const host = ts.createCompilerHost(options); const original = host.getSourceFile.bind(host);
  host.getSourceFile = (name, version, error, create) => name === filename ? ts.createSourceFile(name, probe.text, version, true) : original(name, version, error, create);
  const diagnostics = ts.getPreEmitDiagnostics(ts.createProgram([filename], options, host)).map(d => ({ code: d.code,
    message: ts.flattenDiagnosticMessageText(d.messageText, '\n') }));
  const pass = JSON.stringify(diagnostics.map(d => d.code).sort()) === JSON.stringify(probe.expected.slice().sort());
  return { id: probe.id, result: pass ? 'PASS_STATIC_ONLY' : 'FAIL', expectedDiagnosticCodes: probe.expected,
    source: probe.text, sourceSha256: createHash('sha256').update(probe.text).digest('hex'), diagnostics };
});
const report = { status: results.every(r => r.result === 'PASS_STATIC_ONLY') ? 'PASS_STATIC_ONLY' : 'FAIL',
  additionalContractBlockers: existsSync(join(root, 'reference/api/@modelcontextprotocol/sdk/dist/esm/server/mcp.d.ts'))
    ? ['MAIN_SERVER_CONSTRUCTION_PROBE_REQUIRED'] : ['SDK_API_CONTRACT_BLOCKED:MAIN_SERVER_CONSTRUCTION'],
  results, sdkModulesExecuted: 0, probesEmitted: 0, declarations: [sdk, server, node].map(p => ({ path: p,
    sha256: createHash('sha256').update(readFileSync(join(root, p.replace(/\.mjs$/, '.d.mts').replace(/\.js$/, '.d.ts')))).digest('hex') })),
  limitation: 'Frozen public signatures only; skipLibCheck for captured dependency declarations. No API behavior or venue execution proof.' };
writeFileSync(join(root, 'FROZEN_API_STATIC_VERIFICATION.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (report.status === 'FAIL') process.exitCode = 1;
