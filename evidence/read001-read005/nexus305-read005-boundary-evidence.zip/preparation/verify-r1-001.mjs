import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';

// Source/AST inspection only. No harness/Oracle module is imported or evaluated.
const root = fileURLToPath(new URL('../', import.meta.url));
const ts = createRequire(join(resolve(process.argv[2]), 'package.json'))('typescript');
const phase = process.argv[3] ?? 'revised';
const baseline = resolve(process.argv[4] ?? join(root, 'inputs/driver-integration-r1-original.zip'));
const checks = []; const inspected = [];
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = path => {
  const bytes = phase === 'baseline'
    ? execFileSync('unzip', ['-p', baseline, path], { maxBuffer: 4 * 1024 * 1024 })
    : readFileSync(join(root, path));
  inspected.push({ path, sha256: sha(bytes) });
  return bytes.toString('utf8');
};
const check = (id, value) => checks.push({ id, status: value ? 'PASS_STATIC' : 'FAIL_STATIC' });
const http = read('src/adapters/http-publication.mjs');
const durable = read('src/adapters/durable-events.mjs');
const gate = read('src/gate-owner.mjs');
const privateStore = read('src/adapters/private-event-store.mjs');
const sdk = read('src/adapters/sdk-drivers.mjs');
const integration = read('src/drivers/integration.mjs');
const validation = phase !== 'baseline' && existsSync(join(root, 'src/stored-event-binding.mjs')) ? read('src/stored-event-binding.mjs') : '';
const bindStart = http.indexOf('export function bindStoredFrames');
const bindEnd = http.indexOf('export function enrollHTTPFinal', bindStart);
const bind = http.slice(bindStart, bindEnd);
check('R1-001-normal-all-events-request-key-bound', validation.includes('row.original_request !== envelope.requestKey') && !validation.includes('row.terminal && row.original_request'));
check('R1-001-session-and-stream-bound', validation.includes('row.session !== envelope.sessionId') && validation.includes('row.stream !== envelope.streamId'));
check('R1-001-bind-before-release-no-terminal-only-exception', bind.includes('ledger.bindFrame(step, authority, publication)') && !bind.includes('row.terminal &&') && !bind.includes('ledger.release('));
check('R1-001-empty-replay-plan-cannot-claim-or-write', bind.indexOf("publication?.mode === 'REPLAY'") >= 0 && bind.indexOf("publication?.mode === 'REPLAY'") < bind.indexOf('return plan.map'));
check('R1-001-venue-await-preserves-R1-preclaim-cutover-retry', integration.includes('drivers.journal.store.hasTerminalClaim(target.envelope.requestKey)') && integration.includes("reason: 'TERMINAL_PRECLAIM_AUTHORITY_DENIED', claimCommitted: false") && integration.indexOf('if (!drivers.authority.allows(target.envelope))') < integration.indexOf('bindStoredFrames(target.plan'));
check('R1-001-durable-payload-and-identity-hashes', durable.includes('payload_digest TEXT NOT NULL') && durable.includes('identity_digest TEXT NOT NULL') && validation.includes('eventIdentityDigest(row) !== row.identity_digest') && validation.includes('digest(Buffer.from(row.message_wire)) !== row.payload_digest'));
check('R1-001-wire-frame-exactly-bound-to-event', validation.includes('!step.bytes.equals(expected)') && validation.includes('step.eventId !== row.id'));
check('R1-001-opaque-ledger-tickets', durable.includes('#tickets = new WeakMap()') && durable.includes('this.#tickets.get(step.eventTicket)'));
check('R1-001-gate-plan-validation-before-claim', gate.includes('this.#events.assertPublicationPlan(plan, envelope, this.authority)') && gate.indexOf('this.#events.assertPublicationPlan') < gate.indexOf('const claim = this.prepareTerminal(bound)'));
check('R1-001-gate-release-before-claim-but-after-validation', gate.includes('this.#events.releasePublicationPlan(plan, envelope, this.authority)') && gate.indexOf('this.#events.assertPublicationPlan') < gate.indexOf('this.#events.releasePublicationPlan') && gate.indexOf('this.#events.releasePublicationPlan') < gate.indexOf('const claim = this.prepareTerminal(bound)'));
check('R1-001-event-recheck-before-each-final-admission', gate.includes('this.#events.assertPublicationPlan(state.plan, state.envelope, this.authority)') && gate.indexOf('this.#events.assertPublicationPlan(state.plan') < gate.indexOf('const result = this.#admit(envelope, () => sink(step))'));
check('R1-001-raw-stored-provenance-cannot-bypass-gate', gate.includes('STORED_EVENT_LEDGER_UNBOUND') && gate.includes('SSE_FRAME_BINDING_REQUIRED'));
const ast = ts.createSourceFile('durable.mjs', durable, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
let replay;
const visit = node => { if (ts.isMethodDeclaration(node) && node.name.getText(ast) === 'replayEventsAfter') replay = node.getText(ast); ts.forEachChild(node, visit); }; visit(ast);
check('R1-001-sdk-replay-never-sends-without-entitlement', replay?.includes("throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN')") && !replay.includes('send('));
check('R1-001-private-store-no-alternative-replay-bypass', privateStore.includes('extends DurableSDKEventStore') && !privateStore.includes('await send('));
check('R1-001-sdk-http-reconnect-closed-before-handleRequest', sdk.includes('assertNoUnprovenReplay(request)') && sdk.includes("replay: () => { throw new StoredEventDenied('REPLAY_ENTITLEMENT_UNPROVEN')"));
check('R1-001-node-reconnect-closed-before-handler', sdk.indexOf('assertNoUnprovenNodeReplay(request)') >= 0 && sdk.indexOf('assertNoUnprovenNodeReplay(request)') < sdk.indexOf('await nodeHandler(request, response, parsedBody)'));
check('R1-001-sdk-cannot-access-public-ledger-capability', durable.includes('#ledger; #authority; #faults;') && !durable.slice(durable.indexOf('export class DurableSDKEventStore')).includes('this.ledger ='));
check('R1-001-genuine-cursor-sequence-before-unproven-entitlement', durable.includes('cursor.stream !== envelope.streamId') && durable.includes('cursor.session !== envelope.sessionId') && durable.includes('row.sequence <= cursor.sequence') && durable.includes('REPLAY_ENTITLEMENT_UNPROVEN'));
const matrixPath = 'R3_R1_001_ORACLE_MATRIX.json';
if (existsSync(join(root, matrixPath))) {
  const matrix = JSON.parse(readFileSync(join(root, matrixPath), 'utf8'));
  check('R1-001-fifteen-additive-unexecuted-oracles', matrix.cases.length === 15 && new Set(matrix.cases.map(row => row.id)).size === 15 && matrix.dynamicExecution === 'NOT_EXECUTED' && matrix.cases.every(row => row.given && row.when && row.then && row.requiredEvidence && row.decision));
  const oracle = phase !== 'baseline' && existsSync(join(root, 'src/r1-001-oracles.mjs')) ? read('src/r1-001-oracles.mjs') : '';
  const oracleAst = ts.createSourceFile('oracle.mjs', oracle, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const codeIds = [];
  const collectIds = node => { if (ts.isPropertyAssignment(node) && ts.isStringLiteral(node.name) && /^R1-001-\d{2}$/.test(node.name.text)) codeIds.push(node.name.text); ts.forEachChild(node, collectIds); };
  collectIds(oracleAst);
  check('R1-001-code-and-matrix-cover-same-fifteen-IDs', JSON.stringify(codeIds.sort()) === JSON.stringify(matrix.cases.map(row => row.id).sort()));
}
const report = { schemaVersion: 'r3-r1-001-static/1', phase, status: checks.every(row => row.status === 'PASS_STATIC') ? 'PASS_STATIC_ONLY' : 'FAIL_STATIC',
  checks, inspectedSources: inspected, verifierSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
  completion: 'DESIGN_CLARIFICATION_REQUIRED', experimentalImports: 0, oracleExecutions: 0, dynamicTests: 0,
  limits: ['AST/source-shape checks do not execute Oracles or prove SDK reachability, durable runtime behavior or authorization.', 'Replay entitlement semantics and authenticated SDK session binding remain undefined.'] };
writeFileSync(join(root, phase === 'baseline' ? 'R3_R1_001_BASELINE_STATIC.json' : 'R3_R1_001_STATIC_REGRESSION.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ phase, status: report.status, checks }, null, 2));
if (report.status !== 'PASS_STATIC_ONLY') process.exitCode = 1;
