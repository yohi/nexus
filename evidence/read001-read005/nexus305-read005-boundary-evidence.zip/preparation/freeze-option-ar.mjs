// Artifact generation only. Never import harness/test modules.
import { readFileSync, writeFileSync, readdirSync, copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = resolve(process.argv[2]);
const ts = createRequire(join(repo, 'package.json'))('typescript');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = path => readFileSync(join(root, path), 'utf8');
const json = path => JSON.parse(text(path));
const put = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const walk = (path = '') => readdirSync(join(root, path), { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(join(path, entry.name)) : [join(path, entry.name)]).sort();
const input = join(root, '../inputs/nexus305-r3-driver-integration-r2-evidence.zip');
const baseline = path => execFileSync('unzip', ['-p', input, path], { maxBuffer: 32 * 1024 * 1024 });
copyFileSync(input, join(root, 'inputs/option-ar-r2-original.zip'));
copyFileSync(join(root, '../inputs/nexus305_r3_t05_replay_design_addendum_rev3.zip'), join(root, 'inputs/option-ar-rev3-original.zip'));
copyFileSync(join(repo, 'nexus305-r3-t05-option-ar-harness-implementation-handoff.zip'), join(root, 'inputs/option-ar-handoff-original.zip'));
copyFileSync(join(root, '../01_CODEX_IMPLEMENTATION_PROMPT.md'), join(root, 'inputs/01_CODEX_IMPLEMENTATION_PROMPT.md'));
const files = walk();
const sources = files.filter(path => path.startsWith('src/') && /\.mjs$/.test(path)).map(path => ({ path,
  bytes: readFileSync(join(root, path)).length, sha256: sha(readFileSync(join(root, path))) }));
const tests = files.filter(path => path.startsWith('tests/')).map(path => ({ path, sha256: sha(readFileSync(join(root, path))) }));
const source = json('R3_HARNESS_SOURCE_MANIFEST.json');
source.sources = sources; source.testSources = tests;
source.optionAREvidence = { integration: 'PARTIALLY_INTEGRATED', dynamicStatus: 'NOT_EXECUTED', sourceFiles: sources.length,
  oracle: 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json', runtimeClaims: 0 };
put('R3_HARNESS_SOURCE_MANIFEST.json', source);
const sourceMap = new Map(sources.map(row => [row.path, row]));
const oldManifest = JSON.parse(baseline('R3_FROZEN_COMMAND_MANIFEST.json'));
const manifest = JSON.parse(JSON.stringify(oldManifest));
const refresh = value => {
  if (!value || typeof value !== 'object') return;
  if (typeof value.path === 'string' && sourceMap.has(value.path) && typeof value.sha256 === 'string') value.sha256 = sourceMap.get(value.path).sha256;
  for (const child of Object.values(value)) refresh(child);
};
refresh(manifest);
const replaySources = sources.filter(row => row.path.startsWith('src/replay/'));
for (const row of [...manifest.bindings, ...manifest.extraBindings]) {
  if (row.testId === 'R3-T05') {
    row.sources = [...row.sources, ...replaySources.filter(source => !row.sources.some(item => item.path === source.path))];
    row.optionARSupplement = { path: 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json', execution: 'NOT_EXECUTED' };
    row.driverEntryPoints.push({ path: 'src/replay/assembly.mjs', function: 'assembleOptionAR' },
      { path: 'src/replay/broker.mjs', function: 'ReplayBroker' });
  }
}
manifest.optionAREvidence = source.optionAREvidence;
put('R3_FROZEN_COMMAND_MANIFEST.json', manifest);
const trace = json('R3_TRACEABILITY.json'); refresh(trace);
trace.optionARSupplement = { sourcePaths: replaySources.map(row => row.path), testSources: tests,
  oraclePath: 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json', status: 'NOT_EXECUTED', bindingPolicy: 'ADDITIVE_NO_ORIGINAL_ORACLE_CHANGE' };
put('R3_TRACEABILITY.json', trace);
const gate = json('R3_EXECUTION_GATE_STATUS.json');
gate.completion = 'PARTIALLY_INTEGRATED';
gate.optionAR = { sourceIntegration: 'PARTIALLY_INTEGRATED', venueReadiness: 'BLOCKED', execution: 'NOT_EXECUTED',
  designFindings: { DES_001: 'DESIGN_ONLY', DES_002: 'DESIGN_ONLY', DES_003: 'DESIGN_ONLY_REPORTED_BY_USER' },
  R1_001_04: 'UNRESOLVED', independentImplementationReview: 'NOT_PERFORMED', designApprovalArtifact: 'NOT_SUPPLIED_SEPARATELY' };
gate.remainingDriverWork['R3-T05'] = ['VENUE_TRUST_BINDING_REQUIRED', 'AUTHORITY_BINDING_BLOCKED',
  'INIT_MAIN_DISPATCH_OBSERVER_UNENROLLED', 'NODE_BRIDGE_PRIVATE_REQUEST_CONVERSION_UNENROLLED',
  'SDK_CLOSE_EOF_TWO_RECONNECT_NOT_EXECUTED', 'SCENARIO_FIXTURE_AND_FAULT_RUNNER_UNENROLLED', 'LIVE_STREAM_DRAIN_PROOF_REQUIRED'];
put('R3_EXECUTION_GATE_STATUS.json', gate);
const ast = ts.createSourceFile('tests/option-ar.test.mjs', text('tests/option-ar.test.mjs'), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
let cases;
const visit = node => {
  if (ts.isVariableDeclaration(node) && node.name.getText(ast) === 'scenarios') cases = node.initializer.arguments[0].properties;
  ts.forEachChild(node, visit);
}; visit(ast);
const oracle = { schemaVersion: 'r3-option-ar-oracles/1', status: 'NOT_EXECUTED', executionGate: 'NOT_AUTHORIZED',
  sourceOracle: 'src/replay/oracle.mjs', testSource: 'tests/option-ar.test.mjs', rows: [] };
for (const property of cases) {
  const caseId = property.name.text;
  for (const element of property.initializer.elements) {
    const scenario = element.text;
    oracle.rows.push({ caseId, source: { path: 'tests/option-ar.test.mjs', function: 'testOptionAR',
      sha256: tests[0].sha256 }, scenario, variant: scenario.endsWith('-control') ? 'NEGATIVE_CONTROL' : 'SAFE_VARIANT',
    'trigger/barrier': scenario === 'two-sequential-nonempty' ? 'KR1_END_LEASE_SEAL_BEFORE_KR2_ADMISSION' : scenario,
    expected: { terminalReplayClaim: 0, oldPayloadAfterC0: 0, grantBeforeActive: 0,
      ...(caseId === 'RP-19' ? { successfulSDKGETs: 2, nonemptyFinalFrameP: '>=1 each', freshRenderers: 2, staleMapping409: 0 } : {}) },
    rawEvidencePath: `T05-RP/raw/${caseId}/${scenario}/`, observationClass: 'REQUIRES_REAL_SDK_SQLITE_AUTH_HTTP',
    verdictRule: 'Counterexample first; AbortError/unknown close/EOF/missing raw/simulated positive => INCONCLUSIVE; unbound venue => BLOCKED',
    status: 'NOT_EXECUTED', actual: null, runnerBinding: caseId === 'RP-19' ? 'TWO_REAL_BROKER_CALLS_IMPLEMENTED' : 'VENUE_SCENARIO_RUNNER_REQUIRED' });
  }
}
put('R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json', oracle);
const oldNames = execFileSync('unzip', ['-Z1', input], { encoding: 'utf8' }).trim().split('\n');
const oldHashes = new Map(baseline('SHA256SUMS').toString().trim().split('\n').map(line => {
  const [digest, ...path] = line.split(/\s+/); return [path.join(' ').replace(/^\*/, ''), digest];
}));
const currentFiles = walk().filter(path => path !== 'SHA256SUMS' && path !== 'R3_T05_SOURCE_DIFF_MANIFEST.json');
const changes = currentFiles.map(path => {
  const after = sha(readFileSync(join(root, path))); const before = oldHashes.get(path) ?? null;
  return { path, beforeSha256: before, afterSha256: after,
    disposition: before === after ? 'UNCHANGED' : before ? 'MODIFIED' : 'ADDED',
    function: path.startsWith('src/replay/') ? 'Replay authorization/ledger/renderer/receipts' : path.startsWith('tests/') ? 'Unexecuted test source' : 'Harness/evidence/static preparation' };
});
put('R3_T05_SOURCE_DIFF_MANIFEST.json', { inputSha256: sha(readFileSync(input)), changes,
  removedPaths: oldNames.filter(path => !currentFiles.includes(path) && path !== 'SHA256SUMS' && path !== 'R3_T05_SOURCE_DIFF_MANIFEST.json'),
  note: 'Regenerate after final static reports; this manifest excludes its own hash.' });
console.log(JSON.stringify({ sources: sources.length, oracleCells: oracle.rows.length, bindings: manifest.bindings.length + manifest.extraBindings.length }));
