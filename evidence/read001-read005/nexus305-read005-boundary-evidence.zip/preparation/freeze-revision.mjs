import { readFileSync, writeFileSync, readdirSync, copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const baseline = resolve(process.argv[2]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const baselineSha = '663c39b237d2d4c555a38f1b7b6021a8a5985efe87b2acfbf5fda8a7b94324d1';
if (sha(readFileSync(baseline)) !== baselineSha) throw new Error('BASELINE_ARCHIVE_MISMATCH');
const retained = join(root, 'inputs/driver-integration-original.zip');
copyFileSync(baseline, retained);
const json = path => JSON.parse(readFileSync(join(root, path), 'utf8'));
const put = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const fromBaseline = path => execFileSync('unzip', ['-p', baseline, path], { maxBuffer: 16 * 1024 * 1024 });
const baselineManifest = JSON.parse(fromBaseline('R3_HARNESS_SOURCE_MANIFEST.json'));
const current = json('R3_HARNESS_SOURCE_MANIFEST.json');
const oldByPath = new Map([...baselineManifest.sources, ...baselineManifest.typeSources].map(row => [row.path, row.sha256]));
const sourceChanges = [...current.sources, ...current.typeSources].filter(row => oldByPath.get(row.path) !== row.sha256)
  .map(row => ({ path: row.path, beforeSha256: oldByPath.get(row.path) ?? null, afterSha256: row.sha256 }));
const oraclePath = 'fixtures/r1-counterexample-oracles.json';
const oracles = json(oraclePath);
if (oracles.classification !== 'SPECIFIED_NOT_EXECUTED' || new Set(oracles.cases.map(row => row.id)).size !== oracles.cases.length) throw new Error('ORACLE_SPECIFICATION');
const revision = { revision: 'R1', baselineArchive: 'inputs/driver-integration-original.zip', baselineSha256: baselineSha,
  majorFindings: ['RG-305-R3-DRV-001', 'RG-305-R3-DRV-002'],
  counterexampleOracles: { path: oraclePath, sha256: sha(readFileSync(join(root, oraclePath))), count: oracles.cases.length, execution: 'NOT_EXECUTED' },
  disposition: 'SOURCE_REVISED_STATIC_ONLY_PENDING_INDEPENDENT_REVIEW',
  priorRevisionInstructionText: 'NOT_AVAILABLE_IN_CURRENT_CONVERSATION_OR_LOCAL_SESSION_SEARCH' };
current.revisionEvidence = revision;
put('R3_HARNESS_SOURCE_MANIFEST.json', current);
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
manifest.revisionEvidence = revision;
for (const row of [...manifest.bindings, ...manifest.extraBindings]) {
  if (row.testId.startsWith('R3-T')) row.revisionOracleSupplement = revision.counterexampleOracles;
}
put('R3_FROZEN_COMMAND_MANIFEST.json', manifest);
const trace = json('R3_TRACEABILITY.json'); trace.revisionEvidence = revision;
put('R3_TRACEABILITY.json', trace);
const gate = json('R3_EXECUTION_GATE_STATUS.json');
gate.revisionEvidence = revision;
gate.independentReview = 'NOT_PERFORMED';
gate.independentReviewScope = 'R1_REVISED_PACKAGE';
gate.baselineIndependentReview = 'COMPLETED_REPORTED_BY_USER_REPORT_NOT_SUPPLIED';
put('R3_EXECUTION_GATE_STATUS.json', gate);
const toolingSources = readdirSync(join(root, 'preparation')).filter(name => /\.(mjs|mts)$/.test(name))
  .map(name => ({ path: `preparation/${name}`, sha256: sha(readFileSync(join(root, 'preparation', name))) }));
put('R3_R1_SOURCE_CHANGES.json', { ...revision, sourceChanges, toolingSources });
writeFileSync(join(root, 'reference/driver-integration-baseline-static.json'), fromBaseline('R3_STATIC_VERIFICATION.json'));
const input = JSON.parse(execFileSync('python3', ['-c', `import zipfile,hashlib,json,sys
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 sums={line.split(None,1)[1].lstrip(' *'):line.split()[0] for line in z.read('SHA256SUMS').decode().splitlines()}
 assert set(names)==set(sums)|{'SHA256SUMS'}
 for name,digest in sums.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 print(json.dumps({'crc':'VERIFIED','allBaselineMemberHashes':'MATCH','members':len(names)}))`, retained], { encoding: 'utf8' }));
put('R3_R1_INPUT_VERIFICATION.json', { baselineSha256: baselineSha, ...input, sourceChanges: sourceChanges.length,
  originalRetained: true, originalOracleFilesChanged: false, experimentalImports: 0 });
console.log(JSON.stringify({ revision: 'R1', sourceChanges: sourceChanges.length, oracleCases: oracles.cases.length, baseline: input }));
