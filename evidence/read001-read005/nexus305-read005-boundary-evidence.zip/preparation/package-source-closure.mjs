// Evidence generation only. No Harness/SDK/test module is imported or run.
import { readFileSync, writeFileSync, readdirSync, copyFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, join, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const [repo, inputZip, handoffZip, outputZip] = process.argv.slice(2).map(p => resolve(p));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const json = p => JSON.parse(readFileSync(join(root, p), 'utf8'));
const write = (p, value) => writeFileSync(join(root, p), JSON.stringify(value, null, 2) + '\n');
const walk = (dir = '') => readdirSync(join(root, dir), { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(dir, e.name)) : [join(dir, e.name)]);
const fixedHead = '4fd4872d4baa4394dd3828040f4d52ac9cc9e02d';
if (execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim() !== fixedHead) throw new Error('BASELINE_DRIFT:HEAD');
execFileSync('git', ['diff', '--quiet'], { cwd: repo });
const verificationCode = `import zipfile,hashlib,json,sys,difflib,pathlib
root=pathlib.Path(sys.argv[1]); paths=[pathlib.Path(sys.argv[2]),pathlib.Path(sys.argv[3])]; reports=[]
for p in paths:
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  assert len(z.namelist()) == len(set(z.namelist()))
  sha=hashlib.sha256(p.read_bytes()).hexdigest()
  sums=z.read('SHA256SUMS').decode().splitlines()
  for line in sums:
   digest,name=line.split('  ',1); assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
  external=pathlib.Path(str(p)+'.manifest.json')
  m=json.loads(external.read_text()) if external.exists() else json.loads(z.read('SOURCE_FILE_MANIFEST.json'))
  records=m['members']; records=[dict(path=k,**v) for k,v in records.items()] if isinstance(records,dict) else records
  for r in records:
   b=z.read(r['path']); assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
  if external.exists(): assert m['sha256']==sha
  reports.append(dict(archive=p.name,sha256=sha,crc='PASS',memberCount=len(z.namelist()),sumEntries=len(sums),manifestEntries=len(records)))
assert reports[0]['sha256']=='e259e8f9d1cad1602698c9ce675cb1d7af47eed81265000026a4395947d0dd83'
with zipfile.ZipFile(paths[0]) as z, zipfile.ZipFile(paths[1]) as h:
 snapshots=[n for n in h.namelist() if n.startswith('source_snapshot/')]
 for n in snapshots: assert h.read(n)==z.read(n.removeprefix('source_snapshot/')),n
 pins={'reference/api/@modelcontextprotocol/sdk/dist/esm/server/webStandardStreamableHttp.js':'177d73106a8dbed5950e26e326bad5864817dc54c571959b070a95d502ba08a6','reference/SECTION4_1_REV5_PROPOSAL.md':'e7a556379fb9fb8aa04cbc1ab0871f84ba24f1f6d8f61d26a7609f93776db48b','reference/R3_TARGETED_SPIKE_PLAN.md':'c265a155673ac76b27d996f8af199869cd2cd0bceb7ad03e6db2a4c6b6e74a5f'}
 for n,d in pins.items(): assert hashlib.sha256(z.read(n)).hexdigest()==d and hashlib.sha256((root/n).read_bytes()).hexdigest()==d,n
 frozen=[n for n in z.namelist() if n.startswith(('reference/','inputs/'))]+['R3_FROZEN_COMMAND_MANIFEST.json','R3_TRACEABILITY.json','R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json','R3_R1_001_ORACLE_MATRIX.json','src/launcher.mjs','src/authority.mjs','src/gate-owner.mjs','src/publication-admission.mjs','src/stored-event-binding.mjs','src/replay/renderer.mjs','src/replay/authorizer.mjs','src/replay/broker.mjs','src/replay/lineage.mjs','src/replay/schema.mjs','src/replay/event-authorization.mjs','tests/option-ar.test.mjs']
 for n in frozen: assert (root/n).read_bytes()==z.read(n),n
 diff=[]; sources=[]
 for p in sorted(root.rglob('*')):
  if not p.is_file(): continue
  n=p.relative_to(root).as_posix()
  if not n.startswith(('src/','tests/','preparation/')): continue
  b=p.read_bytes(); prior=z.read(n) if n in z.namelist() else b''
  sources.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),originalSha256=hashlib.sha256(prior).hexdigest() if n in z.namelist() else None,changed=b!=prior))
  if b!=prior: diff.extend(difflib.unified_diff(prior.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n))
 (root/'SOURCE_DIFF.patch').write_text(''.join(diff))
 (root/'SOURCE_CLOSURE_SOURCE_MANIFEST.json').write_text(json.dumps(dict(fixedHead='${fixedHead}',originalArchiveSha256=reports[0]['sha256'],sources=sources),indent=2)+'\\n')
 (root/'FROZEN_BYTE_COMPARISON.json').write_text(json.dumps(dict(status='PASS_STATIC_ONLY',snapshotMatches=len(snapshots),frozenMemberCount=len(frozen),pins=pins,immutablePaths=frozen),indent=2)+'\\n')
print(json.dumps(dict(status='PASS_STATIC_ONLY',archives=reports,pins=pins,snapshotsMatched=len(snapshots),frozenMembersMatched=len(frozen),originalInputStorage='BYTE_IDENTICAL_EXTERNAL_ATTACHMENT',omissionReason='Avoid duplicate full preceding archive; existing nested inputs retained')))
`;
const inputReport = JSON.parse(execFileSync('python3', ['-c', verificationCode, root, inputZip, handoffZip], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 }));
copyFileSync(handoffZip, join(root, 'inputs/source-closure-handoff-original.zip'));
copyFileSync(inputZip + '.manifest.json', join(root, 'inputs/source-closure-input-external.manifest.json'));
copyFileSync(inputZip + '.sha256', join(root, 'inputs/source-closure-input-external.sha256'));
const prompt = execFileSync('python3', ['-c', 'import zipfile,sys; sys.stdout.buffer.write(zipfile.ZipFile(sys.argv[1]).read("01_CODEX_SOURCE_CLOSURE_PROMPT.md"))', handoffZip]);
writeFileSync(join(root, 'inputs/SOURCE_CLOSURE_WORK_CONTRACT.md'), prompt);
write('SOURCE_CLOSURE_INPUT_VERIFICATION.json', inputReport);
// Read-only capture of installed fixed-version implementations, never loaded.
// Matching frozen declarations/version/lock entries is not runtime attestation.
mkdirSync(join(root, 'api-evidence'), { recursive: true });
const r2Lock = json('reference/R2-package-lock.json');
const repoLock = JSON.parse(readFileSync(join(repo, 'package-lock.json'), 'utf8'));
const apiCaptures = ['server', 'node'].map(name => {
  const key = `node_modules/@modelcontextprotocol/${name}`;
  const packageRoot = join(repo, key);
  const packageJson = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  const fixed = r2Lock.packages[key]; const installed = repoLock.packages[key];
  if (packageJson.version !== '2.0.0' || fixed.version !== packageJson.version || fixed.integrity !== installed.integrity) throw new Error(`SDK_PACKAGE_DRIFT:${name}`);
  const declaration = readFileSync(join(packageRoot, 'dist/index.d.mts'));
  if (!declaration.equals(readFileSync(join(root, `reference/api/@modelcontextprotocol/${name}/dist/index.d.mts`)))) throw new Error(`SDK_DECLARATION_DRIFT:${name}`);
  const destination = `api-evidence/${name}-2.0.0-index.mjs`;
  copyFileSync(join(packageRoot, 'dist/index.mjs'), join(root, destination));
  return { package: packageJson.name, version: packageJson.version, path: destination,
    sha256: hash(readFileSync(join(root, destination))), declarationSha256: hash(declaration), lockIntegrity: fixed.integrity,
    frozenDeclarationBytes: 'MATCH', lockEntryIntegrity: 'MATCH', modulesExecuted: 0,
    limitation: 'Installed source capture plus matching declaration/version/lock entry; package tarball integrity was not independently revalidated.' };
});
write('FROZEN_API_SOURCE_CAPTURE.json', { status: 'PASS_STATIC_ONLY', captures: apiCaptures });
const gate = json('R3_EXECUTION_GATE_STATUS.json');
if (gate.executionGate !== 'NOT_AUTHORIZED' || gate.experiment !== 'NOT_EXECUTED' || gate.section4_1 !== 'BLOCKED' || gate.authorization !== null || gate.productImplementation !== 'NOT_APPROVED') throw new Error('GATE_DRIFT');
write('R3_EXECUTION_GATE_STATUS.json', { ...gate, finalState: 'SDK_API_CONTRACT_BLOCKED', integrationStatus: 'PARTIALLY_INTEGRATED',
  sourceClosureSubmission: { disposition: 'SDK_API_CONTRACT_BLOCKED', staticEvidence: 'PASS_STATIC_ONLY', runtimeEvidence: 'NONE', independentReview: 'NOT_PERFORMED', R1_001_04: 'UNRESOLVED' } });
const log = [];
for (const tool of ['verify-source-closure.mjs', 'verify-frozen-api.mjs']) {
  const output = execFileSync(process.execPath, [join(root, 'preparation', tool), repo], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 });
  log.push({ command: `node preparation/${tool} "$REPO"`, exitCode: 0, output });
}
write('STATIC_COMMAND_LOG.json', { status: 'PASS_STATIC_ONLY', commands: log, experimentalImports: 0, runtimeTests: 0,
  redSourceChecks: { checksFailedBeforeEdit: ['READ001_NO_FRESH_WEB_TRANSPORT', 'READ001_OWNER_DISPATCH', 'READ002_FAIL_CLOSED_API_BLOCKER', 'READ003_NO_CALLBACK_STDOUT', 'READ004_CONCRETE_INTERVENTION', 'READ004_BARRIER_INDEPENDENCE'], evidence: 'Initial source-only checker output; this is not a dynamic failing test' },
  excluded: ['Runtime test execution', 'SDK communication', 'Native/OS/fault/crash execution', 'Independent review'],
  limitation: 'No full semantic JS typecheck or markdownlint CLI execution; existing compiler and static parser only.' });
// Hash source once more after verifier output, including this package tool itself.
const manifest = json('SOURCE_CLOSURE_SOURCE_MANIFEST.json');
manifest.sources = manifest.sources.map(r => ({ ...r, sha256: hash(readFileSync(join(root, r.path))) }));
write('SOURCE_CLOSURE_SOURCE_MANIFEST.json', manifest);
const japaneseReports = walk().filter(p => /^(READ_00.*\.md|TRUST_CAPABILITY_AND_VENUE_GAPS\.md|FRESH_INDEPENDENT_IMPLEMENTATION_REVIEW_REQUEST\.md|VENUE_CAPABILITY_REQUEST\.md|REMAINING_BLOCKERS_AND_HANDOFF\.md)$/.test(p));
const languageCode = `import sys,pathlib,json
root=pathlib.Path(sys.argv[1]); files=json.loads(sys.argv[2]); count=0
for n in files:
 for c in (root/n).read_text():
  v=ord(c)
  assert not (0x1100<=v<=0x11ff or 0x3130<=v<=0x318f or 0xac00<=v<=0xd7af),n
  if 0x3400<=v<=0x9fff or 0xf900<=v<=0xfaff or 0x20000<=v<=0x3134f:
   c.encode('iso2022_jp_2004'); count+=1
print(json.dumps(dict(status='PASS_STATIC_ONLY',files=files,hanCharactersChecked=count,repertoire='JIS X 0213 via iso2022_jp_2004',hangul='ABSENT')))
`;
write('JAPANESE_REPORT_VERIFICATION.json', JSON.parse(execFileSync('python3', ['-c', languageCode, root, JSON.stringify(japaneseReports)], { encoding: 'utf8' })));
const members = walk().filter(p => p !== 'SHA256SUMS').sort().map(p => ({ path: p, bytes: readFileSync(join(root, p)).length, sha256: hash(readFileSync(join(root, p))) }));
writeFileSync(join(root, 'SHA256SUMS'), members.map(m => `${m.sha256}  ${m.path}`).join('\n') + '\n');
execFileSync('sha256sum', ['-c', 'SHA256SUMS', '--quiet'], { cwd: root, stdio: 'pipe' });
const archiveCode = `import pathlib,sys,zipfile,json,hashlib
root=pathlib.Path(sys.argv[1]); archive=pathlib.Path(sys.argv[2])
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file(): z.write(p,p.relative_to(root))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,n=line.split('  ',1); assert hashlib.sha256(z.read(n)).hexdigest()==digest,n
 members=[dict(path=n,bytes=len(z.read(n)),sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in z.namelist()]
 print(json.dumps(dict(crc='PASS',memberCount=len(members),members=members)))
`;
const archive = JSON.parse(execFileSync('python3', ['-c', archiveCode, root, outputZip], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 }));
const archiveHash = hash(readFileSync(outputZip));
writeFileSync(outputZip + '.sha256', `${archiveHash}  ${basename(outputZip)}\n`);
const external = { archive: basename(outputZip), sha256: archiveHash, ...archive, finalDisposition: 'SDK_API_CONTRACT_BLOCKED',
  executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED', inputVerification: inputReport };
writeFileSync(outputZip + '.manifest.json', JSON.stringify(external, null, 2) + '\n');
writeFileSync(outputZip + '.verification.json', JSON.stringify({ status: 'PASS_STATIC_ONLY', archive: basename(outputZip), sha256: archiveHash,
  crc: archive.crc, memberCount: archive.memberCount, memberSHA256: 'ALL_MATCH', fixedHashes: 'MATCH', frozenBytes: 'MATCH',
  sourceManifest: 'MATCH', sourceDiff: 'LATEST_INPUT_TO_CURRENT', executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED',
  independentReview: 'NOT_PERFORMED', inputArchivesOmitted: [basename(inputZip)], reason: inputReport.omissionReason }, null, 2) + '\n');
console.log(JSON.stringify({ archive: basename(outputZip), sha256: archiveHash, memberCount: archive.memberCount,
  crc: archive.crc, changedSources: manifest.sources.filter(r => r.changed).length, disposition: external.finalDisposition,
  sourceVerification: json('STATIC_VERIFICATION.json').status, apiVerification: json('FROZEN_API_STATIC_VERIFICATION.json').status }));
