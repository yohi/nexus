// Compile only; this module is never imported or executed.
import { connect } from '@lancedb/lancedb';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { McpServer as V1Server } from '@modelcontextprotocol/sdk/server/mcp.js';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { InMemoryTransport } from '@modelcontextprotocol/sdk/inMemory.js';
import { ReadBuffer, serializeMessage } from '@modelcontextprotocol/sdk/shared/stdio.js';
import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import type { EventStore } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import { createMcpHandler, McpServer as V2Server, PROTOCOL_VERSION_META_KEY, CLIENT_INFO_META_KEY, CLIENT_CAPABILITIES_META_KEY } from '@modelcontextprotocol/server';
import { toNodeHandler } from '@modelcontextprotocol/node';
import type { NodeIncomingMessageLike, NodeServerResponseLike } from '@modelcontextprotocol/node';
import type { Readable, Writable } from 'node:stream';

export async function nativeProbe(root: string) {
  const connection = await connect(root, { readConsistencyInterval: 0 });
  const table = await connection.createTable('legacy', [{ id: 'synthetic', vector: [0, 1] }], { mode: 'create' });
  await table.add([{ id: 'other', vector: [1, 0] }]);
  await table.optimize({ cleanupOlderThan: new Date(), deleteUnverified: false });
  await table.query().toArray(); await table.vectorSearch([0, 1]).limit(10).toArray();
  await table.version(); await table.countRows(); table.close(); connection.close();
}
export async function transportProbe(input: Readable, output: Writable, events: EventStore) {
  const stdio = new StdioServerTransport(input, output);
  const v1 = new V1Server({ name: 'r3-private', version: '1.0.0' });
  await v1.connect(stdio);
  const [a, b] = InMemoryTransport.createLinkedPair();
  const client = new Client({ name: 'r3-private', version: '1.0.0' });
  await client.connect(a); await new V1Server({ name: 'r3-private', version: '1.0.0' }).connect(b);
  const web = new WebStandardStreamableHTTPServerTransport({ enableJsonResponse: true, eventStore: events });
  await web.handleRequest(new Request('http://localhost/mcp'));
  const buffer = new ReadBuffer(); buffer.append(Buffer.from(serializeMessage({ jsonrpc: '2.0', method: 'notifications/initialized' }))); buffer.readMessage();
  return { stdio, web, client };
}
export function nodeProbe(request: NodeIncomingMessageLike, response: NodeServerResponseLike) {
  const handler = createMcpHandler(() => new V2Server({ name: 'r3-private', version: '1.0.0' }), { legacy: 'stateless', responseMode: 'json', keepAliveMs: 0 });
  return toNodeHandler(handler)(request, response, { jsonrpc: '2.0', id: 1, method: 'server/discover', params: {
    _meta: { [PROTOCOL_VERSION_META_KEY]: '2026-07-28', [CLIENT_INFO_META_KEY]: { name: 'r3-private', version: '1.0.0' }, [CLIENT_CAPABILITIES_META_KEY]: {} } } });
}
