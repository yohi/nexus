import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const json = path => JSON.parse(readFileSync(join(root, path), 'utf8'));
const put = (path, value) => writeFileSync(join(root, path), JSON.stringify(value, null, 2) + '\n');
const walk = dir => readdirSync(join(root, dir), { withFileTypes: true }).flatMap(entry => entry.isDirectory() ? walk(`${dir}/${entry.name}`) : [`${dir}/${entry.name}`]);
const oldSource = json('R3_HARNESS_SOURCE_MANIFEST.json');
const sources = walk('src').filter(path => path.endsWith('.mjs')).map(path => {
  const bytes = readFileSync(join(root, path)); return { path, bytes: bytes.length, sha256: sha(bytes) };
});
const types = walk('src').filter(path => path.endsWith('.d.mts')).map(path => ({ path, sha256: sha(readFileSync(join(root, path))) }));
const api = json('R3_API_SIGNATURE_EVIDENCE.json');
put('R3_HARNESS_SOURCE_MANIFEST.json', { ...oldSource, sources, typeSources: types,
  baselineRuntimeSources: api.fixed, apiSources: api.declarations, dynamicExecuted: false,
  integrationStatus: 'PARTIALLY_INTEGRATED' });
const native = { path: 'src/adapters/native-lance.mjs', function: 'NativeLanceDriver' };
const journal = { path: 'src/adapters/fixed-journal.mjs', function: 'createFixedJournalDriver' };
const publication = { path: 'src/gate-owner.mjs', function: 'GateOwner' };
const http = { path: 'src/adapters/http-publication.mjs', function: 'publishPlan' };
const components = {
  'R3-S01': [native], 'R3-S02': [native], 'R3-S03': [native], 'R3-S04': [native, journal], 'R3-S05': [journal], 'R3-S06': [native],
  'R3-T01': [{ path: 'src/adapters/sdk-drivers.mjs', function: 'actualPrivateStdio' }, { path: 'src/adapters/sdk-frame-queue.mjs', function: 'SDKFrameQueue' }, publication],
  'R3-T02': [{ path: 'src/adapters/http-publication.mjs', function: 'drainOrClose' }, publication],
  'R3-T03': [{ path: 'src/adapters/sdk-drivers.mjs', function: 'actualSDKWeb' }, http, publication],
  'R3-T04': [{ path: 'src/adapters/http-publication.mjs', function: 'frameSSE' }, http, publication],
  'R3-T05': [{ path: 'src/adapters/durable-events.mjs', function: 'DurableSDKEventStore' },
    { path: 'src/adapters/durable-events.mjs', function: 'DurableEventLedger' },
    { path: 'src/adapters/private-event-store.mjs', function: 'PrivateEventStore' },
    { path: 'src/stored-event-binding.mjs', function: 'assertNewEventAuthorization' },
    { path: 'src/adapters/http-publication.mjs', function: 'bindStoredFrames' }, publication],
  'R3-T06': [{ path: 'src/adapters/sdk-drivers.mjs', function: 'actualV2Driver' }, http, publication],
  'R3-T07': [{ path: 'src/adapters/sdk-drivers.mjs', function: 'actualBridgeDriver' }, { path: 'src/adapters/frozen-runtime.mjs', function: 'loadFrozenRuntime' }, publication],
  'R3-T08': [{ path: 'src/drivers/cutover.mjs', function: 'boundedPinnedQuery' },
    { path: 'src/drivers/integration.mjs', function: 'publishPinnedHTTP' },
    { path: 'src/drivers/integration.mjs', function: 'publishPinnedStdout' }, publication],
  'R3-T09': [journal, { path: 'src/drivers/integration.mjs', function: 'publishActualStdout' }, { path: 'src/drivers/integration.mjs', function: 'publishActualHTTP' }, publication]
};
const gaps = {
  'R3-S01': ['OS_COPY_SEAL_AND_MUTATION_ROUTE_MATRIX_REQUIRED'],
  'R3-S02': ['PIDFD_OBSERVER_AND_SIGNAL_CONTEXT_REQUIRED'],
  'R3-S03': ['NATIVE_RETENTION_BRANCH_CONTEXT_AND_OS_CLOSE_PROOF_REQUIRED'],
  'R3-S04': ['GC_ALLOWLIST_AND_PIN_INTENT_CRASH_CONTEXT_REQUIRED'],
  'R3-S05': ['LEGACY_DISPATCH_CAPABILITY_AUDIT_AND_CRASH_CELL_CONTEXT_REQUIRED'],
  'R3-S06': ['INDEPENDENT_SOURCE_ENUMERATOR_PROVIDER_RECEIPTS_AND_P1_P7_CONTEXT_REQUIRED'],
  'R3-T01': ['REAL_PRIVATE_OS_PIPE_AND_WORKER_FD_TOPOLOGY_REQUIRED'],
  'R3-T02': ['PAUSED_OS_PIPE_AND_PENDING_SDK_SEND_CONTEXT_REQUIRED'],
  'R3-T03': ['REAL_EXTERNAL_HTTP_CONTEXT_AND_WIRE_OBSERVER_REQUIRED'],
  'R3-T04': ['UNBOUNDED_LIVE_SSE_AND_FRAME_CONTINUATION_CONTEXT_REQUIRED'],
  'R3-T05': ['REPLAY_SESSION_CURSOR_RESTART_AND_LIVE_STREAM_CONTEXT_REQUIRED',
    'REPLAY_ENTITLEMENT_CONTRACT_UNDEFINED', 'AUTHENTICATED_OWNER_SESSION_STREAM_MAPPING_UNENROLLED', 'R1_EVENT_ROWS_QUARANTINED_NO_PROVENANCE_MIGRATION'],
  'R3-T06': ['SUCCESSFUL_MODERN_HANDSHAKE_AND_EXTERNAL_NODE_CONTEXT_REQUIRED'],
  'R3-T07': ['FROZEN_RUNTIME_DEPENDENCY_RESOLUTION_AND_TOOL_FACTORY_CONTEXT_REQUIRED'],
  'R3-T08': ['ALL_FALLBACK_CUTOVER_BRANCHES_AND_PRIVATE_IPC_ADMISSION_CONTEXT_REQUIRED'],
  'R3-T09': ['COMPLETE_SAME_OWNER_A_F_B2_BOOT_CRASH_AND_TWO_SINK_CONTEXT_REQUIRED']
};
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
manifest.status = 'PARTIALLY_INTEGRATED'; manifest.approved = false; manifest.experimentExecuted = false;
manifest.integrationStatus = 'PARTIALLY_INTEGRATED'; manifest.groupDriverGaps = gaps;
for (const row of [...manifest.bindings, ...manifest.extraBindings]) {
  row.sources = sources;
  row.driverEntryPoints = components[row.testId].map(entry => ({ ...entry, sha256: sources.find(source => source.path === entry.path).sha256 }));
  row.assemblyEntryPoint = { path: 'src/drivers/integration.mjs', function: 'assembleDrivers' };
  row.integrationBindingStatus = 'COMPONENT_SOURCE_BOUND_SCENARIO_CONTEXT_INCOMPLETE';
  row.status = 'BLOCKED'; row.classification = 'NOT_EXECUTED';
  row.reasons = ['EXECUTION_NOT_AUTHORIZED', 'VENUE_BINDING_REQUIRED', 'R2_TRANSITIVE_RUNTIME_NOT_ENROLLED', ...gaps[row.testId], ...(row.variant === 'NEGATIVE_CONTROL' ? ['DISTINCT_UNSAFE_CONTEXT_NOT_IMPLEMENTED'] : [])];
  row.inputFixture = { path: 'fixtures/native-pair.json', sha256: sha(readFileSync(join(root, 'fixtures/native-pair.json'))), kind: 'SYNTHETIC_INPUT_NOT_EVIDENCE', variant: row.variant, root: `VENUE_BINDING_REQUIRED:${row.variant}` };
  row.requiredIntegrationEvidence = ['R3_API_SIGNATURE_EVIDENCE.json', 'OS principal/FD/mount enrollment', 'actual library load and R2 transitive tree hashes', 'single sequencer with real write/SQLite/kernel causal witnesses', ...row.evidencePaths];
}
put('R3_FROZEN_COMMAND_MANIFEST.json', manifest);
const trace = json('R3_TRACEABILITY.json');
for (const group of trace.groups) {
  group.driverEntryPoints = components[group.testId];
  group.sourcePaths = [...new Set([...group.sourcePaths, ...components[group.testId].map(entry => entry.path)])];
  group.gaps = gaps[group.testId]; group.integrationStatus = 'PARTIALLY_INTEGRATED';
}
trace.integrationStatus = 'PARTIALLY_INTEGRATED'; trace.bindingCount = 234;
put('R3_TRACEABILITY.json', trace);
const gate = json('R3_EXECUTION_GATE_STATUS.json');
gate.integrationStatus = 'PARTIALLY_INTEGRATED'; gate.remainingDriverWork = gaps;
gate.finalState = 'PARTIALLY_BOUND_ENVIRONMENT_BLOCKED';
gate.executionGate = 'NOT_AUTHORIZED'; gate.experiment = 'NOT_EXECUTED'; gate.authorization = null; gate.venue = null;
put('R3_EXECUTION_GATE_STATUS.json', gate);
console.log(JSON.stringify({ sources: sources.length, bindings: 234, integrationStatus: manifest.status, executionGate: gate.executionGate }));
