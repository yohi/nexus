// Static only: TS AST parser and node --check. No target/SDK module is imported.
import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const [repo, original] = process.argv.slice(2).map(p => resolve(p));
const ts = createRequire(join(repo, 'package.json'))('typescript');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = p => readFileSync(join(root, p), 'utf8');
const json = p => JSON.parse(text(p));
const checks = [];
const check = (ok, name, detail = {}) => { if (!ok) throw new Error(name); checks.push({ name, status: 'PASS_STATIC_ONLY', ...detail }); };
const walk = (path = '') => readdirSync(join(root, path), { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(path, e.name)) : [join(path, e.name)]);
const paths = walk().filter(p => /^(src|tests|preparation)\/.*\.mjs$/.test(p));
for (const path of paths) execFileSync(process.execPath, ['--check', join(root, path)], { stdio: 'pipe' });
check(true, 'node-syntax', { paths, count: paths.length });
const asts = new Map(paths.map(p => [p, ts.createSourceFile(p, text(p), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS)]));
const exports = ast => new Set(ast.statements.flatMap(s => {
  if (ts.isExportDeclaration(s) && s.exportClause && ts.isNamedExports(s.exportClause)) return s.exportClause.elements.map(e => e.name.text);
  if (!s.modifiers?.some(m => m.kind === ts.SyntaxKind.ExportKeyword)) return [];
  if (s.name) return [s.name.text];
  if (ts.isVariableStatement(s)) return s.declarationList.declarations.map(d => d.name.getText(ast));
  return [];
}));
const graph = [];
for (const [path, ast] of asts) {
  if (ast.parseDiagnostics.length) throw new Error(`PARSE:${path}`);
  for (const statement of ast.statements) if (ts.isImportDeclaration(statement)) {
    const spec = statement.moduleSpecifier.text;
    if (!spec.startsWith('.')) continue;
    const absolute = resolve(root, dirname(path), spec);
    if (!existsSync(absolute)) throw new Error(`IMPORT_PATH:${path}:${spec}`);
    const target = absolute.slice(root.length);
    const names = statement.importClause?.namedBindings;
    if (asts.has(target) && names && ts.isNamedImports(names)) {
      const available = exports(asts.get(target));
      for (const name of names.elements) if (!available.has((name.propertyName ?? name.name).text)) throw new Error(`IMPORT_EXPORT:${path}:${name.name.text}`);
    }
    graph.push({ from: path, to: target, sourceHash: sha(readFileSync(absolute)) });
  }
}
check(true, 'local-import-export-ast', { edges: graph.length });
writeFileSync(join(root, 'READINESS_DEPENDENCY_GRAPH.json'), JSON.stringify(graph, null, 2) + '\n');
let awaits = 0;
const visit = node => { if (ts.isAwaitExpression(node)) awaits++; ts.forEachChild(node, visit); };
visit(asts.get('src/gate-owner.mjs'));
check(awaits === 0, 'synchronous-gateowner-no-await');
for (const [path, ast] of asts) {
  const visit = node => {
    if (ts.isPropertyAccessExpression(node) && ['_initialized', '_streamMapping', '_requestToStreamMapping'].includes(node.name.text)) throw new Error(`PRIVATE_SDK_ACCESS:${path}`);
    ts.forEachChild(node, visit);
  }; visit(ast);
}
check(true, 'no-sdk-private-state-access');
const immutable = ['src/launcher.mjs', 'src/authority.mjs', 'src/publication-admission.mjs', 'src/stored-event-binding.mjs',
  'src/drivers/cutover.mjs', 'src/replay/renderer.mjs', 'src/replay/oracle.mjs', 'src/replay/lineage.mjs', 'src/replay/schema.mjs',
  'src/replay/event-authorization.mjs', 'tests/option-ar.test.mjs', 'R3_FROZEN_COMMAND_MANIFEST.json', 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json',
  'R3_R1_001_ORACLE_MATRIX.json', 'reference/SECTION4_1_REV5_PROPOSAL.md', 'reference/R3_TARGETED_SPIKE_PLAN.md'];
for (const path of immutable) check(readFileSync(join(root, path)).equals(readFileSync(join(original, path))), `original-bytes:${path}`);
const originalMatrix = json('R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json').rows;
const catalog = json('src/readiness/scenario-catalog.json');
check(catalog.length === 61 && catalog.every((r, i) => r.caseId === originalMatrix[i].caseId && r.scenario === originalMatrix[i].scenario &&
  r.actual === null && r.execution === 'NOT_EXECUTED'), '61-exact-original-oracle-cells');
const commands = json('R3_FROZEN_COMMAND_MANIFEST.json'); const bindings = [...commands.bindings, ...commands.extraBindings];
check(bindings.length === 234 && bindings.filter(r => r.variant === 'SAFE_VARIANT').length === 117 &&
  bindings.filter(r => r.variant === 'NEGATIVE_CONTROL').length === 117 && bindings.every(r => r.status === 'BLOCKED' && r.classification === 'NOT_EXECUTED'), '234-117-117-blocked');
const driver = text('src/adapters/sdk-drivers.mjs'); const broker = text('src/replay/broker.mjs');
check(!driver.includes('target.toPrivateWebRequest(') && !broker.includes('target.resolveOwnerGrant('), 'no-client-target-trust-method');
check(driver.includes('requestBoundary.fromNode(') && broker.includes('this.requestBoundary.resolveOwnerGrant('), 'owner-conversion-and-selection-boundaries');
check(text('src/replay/initialize.mjs').includes('this.observer.confirmActive(row, attempt)') &&
  text('src/replay/ledger.mjs').includes('this.sessionObserver.assertActive(session)'), 'active-external-receipt-boundaries');
check(text('src/adapters/http-publication.mjs').includes('gate.finalBoundary.enroll(') &&
  text('src/gate-owner.mjs').includes('this.finalBoundary?.owns(ownershipToken)'), 'final-sink-ownership-token');
const gate = json('R3_EXECUTION_GATE_STATUS.json');
check(gate.executionGate === 'NOT_AUTHORIZED' && gate.experiment === 'NOT_EXECUTED' && gate.authorization === null &&
  gate.productImplementation === 'NOT_APPROVED' && gate.section4_1 === 'BLOCKED', 'gate-status-unchanged-denial');
// Compile-only virtual probe verifies public API declarations without SDK execution.
const probe = join(repo, '__readiness_virtual_probe__.mts');
const probeSource = `import { WebStandardStreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
import type { EventStore } from '@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js';
declare const eventStore: EventStore;
const transport = new WebStandardStreamableHTTPServerTransport({ eventStore, onsessioninitialized: id => { void id; }, onsessionclosed: id => { void id; } });
export async function probe(request: Request): Promise<Response> { await transport.start(); const response = await transport.handleRequest(request); await transport.close(); return response; }
export type Lookup = NonNullable<EventStore['getStreamIdForEventId']>;
export type Replay = EventStore['replayEventsAfter'];\n`;
const options = { noEmit: true, strict: true, exactOptionalPropertyTypes: true, noUncheckedIndexedAccess: true, skipLibCheck: true,
  module: ts.ModuleKind.NodeNext, moduleResolution: ts.ModuleResolutionKind.NodeNext, target: ts.ScriptTarget.ES2023,
  types: ['node'], typeRoots: [join(repo, 'node_modules/@types')] };
const host = ts.createCompilerHost(options); const getSource = host.getSourceFile.bind(host);
host.getSourceFile = (path, version, error, create) => path === probe ? ts.createSourceFile(path, probeSource, version, true) : getSource(path, version, error, create);
const diagnostics = ts.getPreEmitDiagnostics(ts.createProgram([probe], options, host));
check(diagnostics.length === 0, 'sdk-public-api-compile-only', { virtualSourceHash: sha(probeSource), diagnostics: diagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')) });
const report = { status: 'PASS_STATIC_ONLY', checks, experimentalImports: 0, dynamicTests: 0, node: process.version, typescript: ts.version,
  independentReview: 'NOT_PERFORMED', experimentEvidence: 'NONE', limitation: 'Syntax/AST/hash/public API declaration checks only; no behavioral or full JS semantic type proof.' };
writeFileSync(join(root, 'READINESS_STATIC_VERIFICATION.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, checks: checks.length, syntaxFiles: paths.length, experimentalImports: 0, dynamicTests: 0 }));
