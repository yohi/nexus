import { readFileSync, writeFileSync, readdirSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, relative } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
  const path = join(dir, entry.name);
  if (lstatSync(path).isSymbolicLink()) throw new Error('PACKAGE_SYMLINK_FORBIDDEN');
  return entry.isDirectory() ? walk(path) : [path];
});
const files = walk(root).filter(path => relative(root, path) !== 'SHA256SUMS').sort();
const expected = files.map(path => ({ path: relative(root, path), sha256: sha(readFileSync(path)) }));
writeFileSync(join(root, 'SHA256SUMS'), expected.map(file => `${file.sha256}  ${file.path}\n`).join(''));
const destination = fileURLToPath(new URL('../../nexus305-r3-provisioning-v3-final-evidence.zip', import.meta.url));
const python = `import pathlib,zipfile,hashlib,json,sys
root=pathlib.Path(sys.argv[1]); destination=pathlib.Path(sys.argv[2])
files=sorted(p for p in root.rglob('*') if p.is_file())
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files: z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(destination) as z:
 assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 sums=z.read('SHA256SUMS').decode().splitlines()
 expected={line.split(None,1)[1].lstrip(' *'):line.split()[0] for line in sums}
 assert set(names)==set(expected)|{'SHA256SUMS'}
 for name,digest in expected.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 assert all(z.read(p.relative_to(root).as_posix())==p.read_bytes() for p in files)
 print(json.dumps({'crc':'VERIFIED','exactMemberCoverage':True,'files':len(names),'manifestEntries':len(expected),'allMemberReadbackHashes':'MATCH'},indent=2))
`;
const readback = JSON.parse(execFileSync('python3', ['-c', python, root, destination], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }));
const sidecar = { archive: destination.split('/').at(-1), zipSha256: sha(readFileSync(destination)), manifestSha256: sha(readFileSync(join(root, 'SHA256SUMS'))), files: [...expected, { path: 'SHA256SUMS', sha256: sha(readFileSync(join(root, 'SHA256SUMS'))) }], readback, executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED', finalState: 'PARTIALLY_BOUND_ENVIRONMENT_BLOCKED' };
writeFileSync(`${destination}.manifest.json`, JSON.stringify(sidecar, null, 2) + '\n');
writeFileSync(`${destination}.sha256`, `${sidecar.zipSha256}  ${sidecar.archive}\n`);
console.log(JSON.stringify({ archive: sidecar.archive, sha256: sidecar.zipSha256, ...readback }, null, 2));
