// Static tooling only: inspected harness, test, and SDK modules never execute.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { inspectBoundary, inspectOrdinaryImports } from './boundary-checks.mjs';

const repo = path.resolve(process.argv[2]);
const root = path.resolve(process.argv[3] ?? fileURLToPath(new URL('../', import.meta.url)));
const section = process.argv[4];
const ts = createRequire(path.join(repo, 'package.json'))('typescript');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const source = name => fs.existsSync(path.join(root, name)) ? fs.readFileSync(path.join(root, name), 'utf8') : '';
const walk = prefix => fs.readdirSync(path.join(root, prefix), { withFileTypes: true }).flatMap(e =>
  e.isDirectory() ? walk(path.join(prefix, e.name)) : [path.join(prefix, e.name)]);
const checks = [];
const add = (group, id, condition) => {
  if (!section || group === section || group === 'frozen')
    checks.push({ group, id, result: condition ? 'PASS_STATIC_ONLY' : 'FAIL' });
};
const asts = new Map(); const sourceHashes = [];
for (const name of ['src', 'tests', 'preparation'].flatMap(walk).filter(n => n.endsWith('.mjs'))) {
  const text = source(name);
  execFileSync(process.execPath, ['--check', path.join(root, name)], { stdio: 'pipe' });
  const ast = ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (ast.parseDiagnostics.length) throw new Error(`AST_PARSE:${name}`);
  asts.set(name, ast); sourceHashes.push({ path: name, sha256: hash(text) });
}
inspectBoundary(ts, asts, source, add);
inspectOrdinaryImports(ts, asts, add);
const original = JSON.parse(source('READ005_IMMUTABILITY_COMPARISON.json')).files;
const frozenNames = ['R3_FROZEN_COMMAND_MANIFEST.json', 'R3_T05_ORACLE_IMPLEMENTATION_MATRIX.json',
  'src/readiness/scenario-catalog.json', 'R3_EXECUTION_GATE_STATUS.json'];
for (const name of frozenNames) {
  const row = original.find(r => r.path === name);
  add('frozen', `UNCHANGED:${name}`, !!row && hash(source(name)) === row.baselineSha256);
}
const bindingsFile = JSON.parse(source(frozenNames[0]));
const bindings = [...bindingsFile.bindings, ...bindingsFile.extraBindings];
const cells = JSON.parse(source(frozenNames[2]));
add('frozen', '234_BINDINGS_117_117_UNEXECUTED', bindings.length === 234 &&
  bindings.filter(b => b.variant === 'SAFE_VARIANT').length === 117 &&
  bindings.filter(b => b.variant === 'NEGATIVE_CONTROL').length === 117 &&
  bindings.every(b => b.status === 'BLOCKED' && b.classification === 'NOT_EXECUTED'));
add('frozen', '61_CELLS_UNEXECUTED', cells.length === 61 && cells.every(c => c.execution === 'NOT_EXECUTED' && c.actual === null));
const status = checks.every(c => c.result === 'PASS_STATIC_ONLY') ? 'PASS_STATIC_ONLY' : 'FAIL';
console.log(JSON.stringify({ status, section: section ?? 'all', checks, sourceHashes,
  experimentalImports: 0, testsExecuted: 0, negativeObservation: 'UNKNOWN',
  limitation: 'Structural AST/syntax evidence only. Fixture import closure is not venue loader isolation or runtime non-reachability.' }, null, 2));
if (status === 'FAIL') process.exitCode = 1;
