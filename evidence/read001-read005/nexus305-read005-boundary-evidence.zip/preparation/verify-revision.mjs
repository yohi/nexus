import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';

// Compile/inspect only: never import, evaluate or execute harness expressions.
const root = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(join(resolve(process.argv[2]), 'package.json'));
const ts = require('typescript');
const phase = process.argv[3] ?? 'revised';
const checks = [];
const sourceBytes = path => phase === 'baseline'
  ? execFileSync('unzip', ['-p', join(root, 'inputs/driver-integration-original.zip'), path], { maxBuffer: 4 * 1024 * 1024 })
  : readFileSync(join(root, path));
const load = path => {
  const text = sourceBytes(path).toString('utf8');
  return ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
};
const nodes = (rootNode, predicate) => {
  const found = [];
  const visit = node => { if (predicate(node)) found.push(node); ts.forEachChild(node, visit); };
  visit(rootNode); return found;
};
const method = (ast, name) => nodes(ast, node => ts.isMethodDeclaration(node) && node.name.getText(ast) === name)[0];
const check = (id, value) => checks.push({ id, status: value ? 'PASS_STATIC' : 'FAIL_STATIC' });
const gate = load('src/gate-owner.mjs');
const prepare = method(gate, 'prepareTerminal');
const guard = nodes(prepare, node => ts.isIfStatement(node) && node.expression.getText(gate) === '!this.authority.allows(envelope)')[0];
const claim = nodes(prepare, node => ts.isCallExpression(node) && node.expression.getText(gate) === 'this.store.claimTerminal')[0];
check('DRV-001-owner-preclaim-guard-before-durable-claim', guard && claim && guard.end < claim.pos && nodes(guard.thenStatement, ts.isThrowStatement).length === 1);
check('DRV-001-durable-claim-bound-to-envelope', claim?.arguments.length === 3 && claim.arguments[2].getText(gate) === 'envelope');
check('DRV-001-existing-claim-not-reclassified-as-preclaim-denial', prepare.getText(gate).indexOf('this.store.hasTerminalClaim') >= 0 && prepare.getText(gate).indexOf('this.store.hasTerminalClaim') < prepare.getText(gate).indexOf('!this.authority.allows'));
const store = load('src/adapters/sqlite-authority.mjs');
const durable = method(store, 'claimTerminal');
const durableText = durable.getText(store);
check('DRV-001-duplicate-check-inside-claim-transaction', durableText.includes('if (this.hasTerminalClaim(requestKey)) return null') && durableText.indexOf('this.hasTerminalClaim') < durableText.indexOf('view.epoch !== envelope.epoch'));
check('DRV-001-sqlite-preclaim-current-view-and-revocation-check', ['view.epoch !== envelope.epoch', 'view.pairId !== envelope.pairId', 'view.generation !== envelope.generation', 'view.publicationRevision !== envelope.publicationRevision', 'SELECT epoch FROM revocations WHERE epoch=? OR generation=?'].every(part => durableText.includes(part)) && durableText.includes('throw new PreclaimAdmissionDenied()') && durableText.indexOf('throw new PreclaimAdmissionDenied()') < durableText.indexOf('INSERT OR IGNORE INTO terminals'));
const permit = method(gate, 'publishPermit');
check('DRV-002-no-stored-auth-spread-into-publication-envelope', !nodes(permit, node => ts.isSpreadAssignment(node) && node.expression.getText(gate).includes('auth')).length);
check('DRV-002-publication-verification-owned-by-request-envelope', permit.getText(gate).includes('...state.envelope') && !nodes(permit, node => ts.isPropertyAssignment(node) && node.name.getText(gate) === 'retrievalPairVerified').length);
const open = method(gate, 'openPublication');
check('DRV-002-stored-auth-explicit-field-projection', open.getText(gate).includes('projectStoredFrameAuth(step.auth)') && !nodes(open, node => ts.isSpreadAssignment(node) && node.expression.getText(gate) === 'step.auth').length);
const projection = phase === 'baseline' ? null : load('src/publication-admission.mjs');
const projectedKeys = projection ? nodes(projection, ts.isPropertyAssignment).map(node => node.name.getText(projection)).sort() : [];
check('DRV-002-projection-allowlist-excludes-verification-and-request-identity', JSON.stringify(projectedKeys) === JSON.stringify(['epoch', 'generation', 'pairId', 'publicationRevision']));
const authority = load('src/authority.mjs');
check('DRV-002-current-epoch-required', method(authority, 'allows').getText(authority).includes('envelope.epoch === this.active?.epoch'));
const cutover = load('src/drivers/cutover.mjs');
const cutoverText = cutover.getText();
const publishAwait = nodes(cutover, node => ts.isAwaitExpression(node) && node.expression.getText(cutover) === 'publish(envelope, result)')[0];
const speculativeClaims = nodes(cutover, node => ts.isBinaryExpression(node) && node.left.getText(cutover) === 'request.claimed' && node.right.kind === ts.SyntaxKind.TrueKeyword && node.pos < (publishAwait?.pos ?? Infinity));
check('DRV-001-no-speculative-request-claim', !speculativeClaims.length && cutoverText.includes('request.claimed = publication.claimCommitted !== false'));
check('DRV-001-retry-only-explicit-preclaim-denial', cutoverText.includes("publication.reason === 'TERMINAL_PRECLAIM_AUTHORITY_DENIED'") && cutoverText.includes('publication.claimCommitted === false'));
const http = load('src/adapters/http-publication.mjs').getText();
check('DRV-001-publication-reports-durable-claim-state', http.includes('error instanceof PreclaimAdmissionDenied') && http.includes('claimCommitted: false') && http.includes('claimCommitted: true'));
const integration = load('src/drivers/integration.mjs').getText();
check('R1-pinned-native-read-wired-to-both-final-sinks', integration.includes('export function publishPinnedHTTP') && integration.includes('export function publishPinnedStdout') && integration.includes('boundedPinnedQuery({ ...input, authority: drivers.authority, native: drivers.native') && integration.includes('plan: input.encodeResult(result)') && integration.includes('sdkFrame: input.encodeResult(result)'));
const oracles = JSON.parse(readFileSync(join(root, 'fixtures/r1-counterexample-oracles.json'), 'utf8'));
check('R1-counterexample-fixtures-use-distinct-request-and-stored-verdicts', oracles.inputTemplates.unverifiedRequest.retrievalPairVerified === false && oracles.inputTemplates.maliciousStoredAuth.retrievalPairVerified === true && oracles.cases.length === 13 && new Set(oracles.cases.map(row => row.id)).size === 13 && oracles.classification === 'SPECIFIED_NOT_EXECUTED');
const sources = ['src/gate-owner.mjs', 'src/authority.mjs', 'src/adapters/sqlite-authority.mjs', 'src/adapters/http-publication.mjs', 'src/drivers/cutover.mjs', 'src/drivers/integration.mjs'];
const report = { schemaVersion: 'r3-driver-revision-static/1', phase, status: checks.every(row => row.status === 'PASS_STATIC') ? 'PASS_STATIC_ONLY' : 'FAIL_STATIC', checks,
  verifierSha256: createHash('sha256').update(readFileSync(fileURLToPath(import.meta.url))).digest('hex'),
  inspectedSources: sources.map(path => ({ path, sha256: createHash('sha256').update(sourceBytes(path)).digest('hex') })),
  experimentalImports: 0, dynamicTests: 0, oracleExecution: 'NOT_EXECUTED',
  limitations: ['AST/source-shape regression checks are not behavioral execution or concurrency proof.', 'Counterexample Oracles specify expected outcomes for future separately authorized execution.'] };
writeFileSync(join(root, phase === 'baseline' ? 'R3_R1_BASELINE_STATIC_REGRESSION.json' : 'R3_R1_STATIC_REGRESSION.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (report.status !== 'PASS_STATIC_ONLY') process.exitCode = 1;
