import { readFileSync, writeFileSync, readdirSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, relative } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const verification = JSON.parse(readFileSync(join(root, 'R3_STATIC_VERIFICATION.json')));
if (verification.status !== 'PASS_STATIC_ONLY' || verification.importedExperimentalModules !== 0) throw new Error('STATIC_VERIFICATION_REQUIRED');
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
  const path = join(dir, entry.name);
  if (lstatSync(path).isSymbolicLink()) throw new Error('PACKAGE_SYMLINK_FORBIDDEN');
  return entry.isDirectory() ? walk(path) : [path];
});
const files = walk(root).filter(path => relative(root, path) !== 'SHA256SUMS').sort();
const expected = files.map(path => ({ path: relative(root, path), sha256: sha(readFileSync(path)) }));
writeFileSync(join(root, 'SHA256SUMS'), expected.map(file => `${file.sha256}  ${file.path}\n`).join(''));
const destination = fileURLToPath(new URL('../../nexus305-r3-driver-integration-r1-evidence.zip', import.meta.url));
const script = `import pathlib,zipfile,hashlib,json,sys
root=pathlib.Path(sys.argv[1]); destination=pathlib.Path(sys.argv[2])
files=sorted(p for p in root.rglob('*') if p.is_file())
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files: z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(destination) as z:
 assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 sums=z.read('SHA256SUMS').decode().splitlines()
 expected={line.split(None,1)[1].lstrip(' *'):line.split()[0] for line in sums}
 assert set(names)==set(expected)|{'SHA256SUMS'}
 for name,digest in expected.items(): assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
 assert all(z.read(p.relative_to(root).as_posix())==p.read_bytes() for p in files)
 sources=json.loads(z.read('R3_HARNESS_SOURCE_MANIFEST.json'))
 for source in sources['sources']+sources['fixedSources']+sources['typeSources']+sources['apiSources']:
  assert hashlib.sha256(z.read(source['path'])).hexdigest()==source['sha256']
 for source in sources['baselineRuntimeSources']:
  assert hashlib.sha256(z.read(source['path'])).hexdigest()==source['sha256']
  if source['runtimePath']: assert hashlib.sha256(z.read(source['runtimePath'])).hexdigest()==source['runtimeSha256']
 original=z.read('inputs/provisioning-v3-original.zip')
 assert hashlib.sha256(original).hexdigest()=='7e43da564c22979b249eaaf488909b0abef4ca7e927cae745a1fa225ec820042'
 baseline=z.read('inputs/driver-integration-original.zip')
 assert hashlib.sha256(baseline).hexdigest()=='663c39b237d2d4c555a38f1b7b6021a8a5985efe87b2acfbf5fda8a7b94324d1'
 revision=json.loads(z.read('R3_R1_STATIC_REGRESSION.json'))
 assert revision['status']=='PASS_STATIC_ONLY' and revision['experimentalImports']==0
 baseline_regression=json.loads(z.read('R3_R1_BASELINE_STATIC_REGRESSION.json'))
 assert baseline_regression['status']=='FAIL_STATIC' and baseline_regression['verifierSha256']==revision['verifierSha256']
 assert hashlib.sha256(z.read('preparation/verify-revision.mjs')).hexdigest()==revision['verifierSha256']
 oracles=json.loads(z.read('fixtures/r1-counterexample-oracles.json'))
 assert oracles['classification']=='SPECIFIED_NOT_EXECUTED' and len(oracles['cases'])==13
 changes=json.loads(z.read('R3_R1_SOURCE_CHANGES.json'))
 for source in changes['toolingSources']: assert hashlib.sha256(z.read(source['path'])).hexdigest()==source['sha256']
 for source in changes['sourceChanges']: assert hashlib.sha256(z.read(source['path'])).hexdigest()==source['afterSha256']
 manifest=json.loads(z.read('R3_FROZEN_COMMAND_MANIFEST.json')); rows=manifest['bindings']+manifest['extraBindings']
 assert len(rows)==234 and len(set(r['bindingId'] for r in rows))==234
 assert all(r['status']=='BLOCKED' and r['classification']=='NOT_EXECUTED' for r in rows)
 gate=json.loads(z.read('R3_EXECUTION_GATE_STATUS.json'))
 assert gate['executionGate']=='NOT_AUTHORIZED' and gate['authorization'] is None
 print(json.dumps({'crc':'VERIFIED','exactMemberCoverage':True,'files':len(names),'manifestEntries':len(expected),'allMemberReadbackHashes':'MATCH','allSourceHashes':'MATCH','originalZip':'UNCHANGED','bindings':234,'executionGate':'NOT_AUTHORIZED'}))`;
const readback = JSON.parse(execFileSync('python3', ['-c', script, root, destination], { encoding: 'utf8' }));
const sidecar = { archive: destination.split('/').at(-1), zipSha256: sha(readFileSync(destination)), manifestSha256: sha(readFileSync(join(root, 'SHA256SUMS'))), files: [...expected, { path: 'SHA256SUMS', sha256: sha(readFileSync(join(root, 'SHA256SUMS'))) }], readback, integrationStatus: 'PARTIALLY_INTEGRATED', executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED' };
writeFileSync(`${destination}.manifest.json`, JSON.stringify(sidecar, null, 2) + '\n');
writeFileSync(`${destination}.sha256`, `${sidecar.zipSha256}  ${sidecar.archive}\n`);
console.log(JSON.stringify({ archive: sidecar.archive, sha256: sidecar.zipSha256, manifestSha256: sidecar.manifestSha256, ...readback }, null, 2));
