// CRC/member/SHA verification of a fixed archive. No scenario imports.
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { basename, resolve } from 'node:path';
const archive = resolve(process.argv[2]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
execFileSync('unzip', ['-t', archive], { stdio: 'pipe', maxBuffer: 16 * 1024 * 1024 });
const all = execFileSync('unzip', ['-Z1', archive], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }).trim().split('\n');
if (new Set(all).size !== all.length) throw new Error('DUPLICATE_ARCHIVE_MEMBER');
const names = all.filter(name => !name.endsWith('/'));
const get = name => execFileSync('unzip', ['-p', archive, name], { maxBuffer: 256 * 1024 * 1024 });
const sums = new Map(get('SHA256SUMS').toString().trim().split('\n').map(line => {
  const [digest, ...path] = line.split(/\s+/); return [path.join(' ').replace(/^\*/, ''), digest];
}));
if (names.length !== sums.size + 1 || names.some(name => name !== 'SHA256SUMS' && !sums.has(name))) throw new Error('INCOMPLETE_MEMBER_MANIFEST');
const members = names.map(path => {
  const bytes = get(path); const digest = sha(bytes);
  if (path !== 'SHA256SUMS' && sums.get(path) !== digest) throw new Error(`MEMBER_DRIFT:${path}`);
  return { path, bytes: bytes.length, sha256: digest, crc: 'VERIFIED_BY_UNZIP_TEST' };
});
const manifest = JSON.parse(get('R3_HARNESS_SOURCE_MANIFEST.json'));
for (const source of [...manifest.sources, ...manifest.typeSources, ...manifest.testSources]) {
  if (sha(get(source.path)) !== source.sha256) throw new Error(`SOURCE_DRIFT:${source.path}`);
}
for (const [path, expected] of [
  ['inputs/option-ar-r2-original.zip', '4d328ad3eeaefdd52979f1fd6140bb7d01b5c0f7635f020004be49f44e486e22'],
  ['inputs/option-ar-rev3-original.zip', '9166a4021136bdcc88d73e62b75e169c128f9ce69a0bfaa0d0bb0e893973f200'],
  ['inputs/option-ar-handoff-original.zip', 'e419fe788f2e4b19ca0e5cd3da5576f5546a6972864bd5203535102cb7901f80']
]) if (sha(get(path)) !== expected) throw new Error(`ORIGINAL_DRIFT:${path}`);
const zipHash = sha(readFileSync(archive));
writeFileSync(`${archive}.sha256`, `${zipHash}  ${basename(archive)}\n`);
const report = { archive: basename(archive), sha256: zipHash, crc: 'PASS', memberCount: names.length,
  allInternalSHA256: 'MATCH', sourceSHA256: 'MATCH', originalsSHA256: 'MATCH',
  finalDisposition: 'PARTIALLY_INTEGRATED', executionGate: 'NOT_AUTHORIZED', experiments: 'NOT_EXECUTED', members };
writeFileSync(`${archive}.manifest.json`, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ sha256: zipHash, crc: 'PASS', members: names.length, sourceSHA256: 'MATCH', originals: 'MATCH' }));
