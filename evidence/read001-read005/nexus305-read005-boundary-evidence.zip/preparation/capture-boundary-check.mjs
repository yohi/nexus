// Runs static preparation tooling only; never imports a harness module.
import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const stage = process.argv[3] ?? 'all';
if (!['projection', 'server', 'facade', 'evidence', 'scenario', 'all'].includes(stage)) throw new Error('UNKNOWN_STATIC_STAGE');
const result = spawnSync(process.execPath, [path.join(root, 'preparation/verify-case-boundary.mjs'),
  path.resolve(process.argv[2]), root, ...(stage === 'all' ? [] : [stage])], { encoding: 'utf8' });
if (result.error) throw result.error;
if (result.stderr) process.stderr.write(result.stderr);
const report = JSON.parse(result.stdout);
writeFileSync(path.join(root, `BOUNDARY_${stage.toUpperCase()}_STATIC.json`), result.stdout);
console.log(JSON.stringify({ status: report.status, stage, exit: result.status,
  checks: report.checks.length, failed: report.checks.filter(c => c.result === 'FAIL').map(c => c.id),
  syntaxFiles: report.sourceHashes.length, testsExecuted: 0, experimentalImports: 0 }, null, 2));
process.exitCode = result.status ?? 1;
