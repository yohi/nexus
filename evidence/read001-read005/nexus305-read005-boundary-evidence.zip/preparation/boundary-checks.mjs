// Preparation-only AST inspection. Never import the inspected modules.
export function inspectBoundary(ts, asts, source, add) {
  const visit = (node, predicate) => {
    if (predicate(node)) return true;
    let found = false;
    ts.forEachChild(node, child => { found ||= visit(child, predicate); });
    return found;
  };
  const exists = name => asts.has(name);
  const has = (name, fragment) => source(name).includes(fragment);
  const projection = 'src/case-context/projection.mjs';
  const facade = 'src/case-context/facade.mjs';
  const bootstrap = 'src/case-context/bootstrap.mjs';
  const evidence = 'src/case-context/evidence.mjs';
  const observer = 'src/replay/session-observer.mjs';
  const owner = 'src/replay/main-session-owner.mjs';
  const scenario = 'src/readiness/scenario-runner.mjs';
  add('projection', 'PROJECTION_DESCRIPTOR_COPY', exists(projection) &&
    has(projection, 'Object.getOwnPropertyDescriptors') && has(projection, 'WeakSet') &&
    has(projection, 'CASE_RESULT_UNSAFE') && has(projection, 'Number.isFinite'));
  add('projection', 'ERROR_ALLOWLIST_NO_CAUSE', has(projection, 'CASE_OPERATION_FAILED') &&
    has(projection, 'projectCaseError') && !has(projection, 'error.message'));
  add('projection', 'DENSE_ARRAY_ELEMENTS_ONLY', has(projection, 'indices.length !== length') &&
    has(projection, 'Number(key) >= length') && has('tests/case-boundary.test.mjs', 'new Array(3)'));
  add('projection', 'SOURCE_ONLY_ADVERSARIAL_ORACLES', exists('tests/case-boundary.test.mjs') &&
    ['projectionRejectsLiveValues', 'errorProjectionDoesNotLeak'].every(n =>
      has('tests/case-boundary.test.mjs', `function ${n}(`)));
  add('server', 'SERVER_CREATED_INTERNALLY', has('src/adapters/mcp.mjs', 'function createPrivateMcpServer(') &&
    has('src/replay/initialize-driver.mjs', 'createPrivateMcpServer(SDK, serverSetup.waitHandler)') &&
    !has('src/replay/initialize-driver.mjs', '{ SDK, server,'));
  add('server', 'SERVER_OBSERVE_BEFORE_CONNECT', source('src/replay/initialize-driver.mjs').indexOf('observer.enrollMainTransport(') <
    source('src/replay/initialize-driver.mjs').indexOf('server.connect(transport)'));
  add('server', 'INITIALIZE_NO_INPUT_SPREAD', !has('src/replay/assembly.mjs', '{ ...input, SDK'));
  add('facade', 'PRIVATE_REQUEST_AND_ISSUANCE_MAPS', exists(bootstrap) &&
    has(bootstrap, 'new WeakMap()') && has(bootstrap, 'bindWeb(request, externalContext)') && has(bootstrap, 'issueCase'));
  const facadeAST = asts.get(facade);
  const facadeKeys = facadeAST ? facadeAST.statements.flatMap(statement => {
    if (!ts.isFunctionDeclaration(statement) || statement.name?.text !== 'createMainCaseFacade') return [];
    const objects = [];
    visit(statement, node => {
      if (ts.isCallExpression(node) && node.expression.getText(facadeAST) === 'Object.assign' &&
        node.arguments[1] && ts.isObjectLiteralExpression(node.arguments[1])) {
        objects.push(...node.arguments[1].properties.map(p => p.name?.getText(facadeAST)));
      }
      return false;
    });
    return objects;
  }) : [];
  add('facade', 'CASE_EXACT_APPROVED_SURFACE', JSON.stringify(facadeKeys.sort()) ===
    JSON.stringify(['initialize', 'reconnect', 'route', 'snapshot']));
  add('facade', 'CASE_PROJECTS_RESULTS_AND_ERRORS', has(facade, 'projectCaseError(') &&
    has(facade, 'projectCaseResult(') && has(facade, 'MAIN_OWNER_HANDLE_REQUIRED'));
  add('evidence', 'OBSERVER_PRIVATE_REGISTRY', has(observer, '#registry') &&
    !has(observer, 'this.registry') && !has(owner, '#observer.registry'));
  add('evidence', 'PUBLIC_ARTIFACT_VERIFIED_NOT_SELF_ASSERTED', exists(evidence) &&
    has(evidence, 'verifyArtifactSync') && has(evidence, 'createHash') &&
    has(evidence, 'IDENTITY_EVIDENCE_UNAVAILABLE') && has(evidence, 'SELF_ASSERTED'));
  const ownerAST = asts.get(owner);
  let synchronous = false;
  if (ownerAST) visit(ownerAST, node => {
    if (ts.isMethodDeclaration(node) && node.name.getText(ownerAST) === 'dispatch') {
      const statements = node.body.statements;
      const index = statements.findIndex(s => s.getText(ownerAST).includes('this.#observer.verifyMainDispatchSync('));
      synchronous = index >= 0 && statements.length === index + 3 &&
        statements[index + 1].getText(ownerAST).includes('MAIN_DISPATCH_OWNER_AUTHORITY_UNPROVEN') &&
        statements[index + 2].getText(ownerAST) === 'return binding.transport.handleRequest(request);' &&
        !statements.slice(index).some(s => visit(s, ts.isAwaitExpression));
    }
    return false;
  });
  add('evidence', 'SYNC_FINAL_VERIFY_GUARD_DISPATCH', synchronous &&
    ['admission.transport === binding.transport', 'admission.server === binding.server',
      'admission.activeCommitToken === current.active_commit_receipt'].every(f => has(owner, f)));
  add('scenario', 'SCENARIO_NO_RAW_RESULT_SPREAD', !has(scenario, '{ ...run') &&
    has(scenario, '#runs') && has(scenario, '#outcomes') && has(scenario, 'projectScenarioResult'));
  add('scenario', 'SCENARIO_PRIVATE_DEPENDENCIES', has(scenario, '#registry') &&
    !has(scenario, 'this.registry') && !has(scenario, 'this.collector') && !has(scenario, 'this.barriers'));
  add('scenario', 'TWO_RECONNECT_REVALIDATED', has('src/readiness/intervention-runner.mjs', 'authorize();\n        const second = await run.broker.reconnect('));
}

export function inspectOrdinaryImports(ts, asts, add) {
  const entry = 'tests/fixtures/ordinary-main-case.mjs';
  const ast = asts.get(entry);
  let safe = !!ast;
  if (ast) {
    const scan = node => {
      if (ts.isImportDeclaration(node) || ts.isExportDeclaration(node) && node.moduleSpecifier) safe = false;
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        const text = node.expression.getText(ast);
        if (['eval', 'Function', 'import', 'require'].includes(text)) safe = false;
      }
      ts.forEachChild(node, scan);
    };
    scan(ast);
  }
  add('projection', 'ORDINARY_FIXTURE_IMPORT_CLOSURE', safe);
}
