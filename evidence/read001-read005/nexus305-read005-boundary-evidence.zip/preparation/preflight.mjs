import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const command = (file, args) => {
  try { return { exit: 0, output: execFileSync(file, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim() }; }
  catch (error) { return { exit: error.status ?? null, output: String(error.stdout ?? '').trim(), error: String(error.stderr ?? '').trim() }; }
};
const read = (path) => {
  try { return readFileSync(path, 'utf8').trim(); }
  catch (error) { return { unavailable: error.code }; }
};
const observations = {
  runtime: { node: process.version, executableSha256: createHash('sha256').update(readFileSync(process.execPath)).digest('hex'), npm: command('npm', ['--version']) },
  identity: { uid: process.getuid(), gid: process.getgid(), groups: process.getgroups(), status: read('/proc/self/status').split('\n').filter(line => /^(Cap|NoNewPrivs|Seccomp)/.test(line)) },
  kernel: command('uname', ['-sr']),
  preparationMount: command('findmnt', ['--target', '/tmp/opencode', '--json', '--output', 'TARGET,SOURCE,FSTYPE,OPTIONS']),
  productMount: command('findmnt', ['--target', process.cwd(), '--json', '--output', 'TARGET,SOURCE,FSTYPE,OPTIONS']),
  namespaces: read('/proc/self/uid_map'),
  cgroup: read('/proc/self/cgroup'), limits: read('/proc/self/limits'),
  policies: { ptraceScope: read('/proc/sys/kernel/yama/ptrace_scope'), unprivilegedBpf: read('/proc/sys/kernel/unprivileged_bpf_disabled'), userns: read('/proc/sys/kernel/unprivileged_userns_clone') },
  principals: command('getent', ['passwd', 'r3-writer', 'r3-publisher', 'r3-reader', 'r3-gc', 'r3-seal', 'r3-gateowner', 'r3-observer']),
  tools: Object.fromEntries(['strace', 'bpftrace', 'setpriv', 'getfacl', 'setfacl', 'systemd-run', 'prlimit'].map(tool => [tool, command('which', [tool])])),
  retainedDependencyTree: existsSync('/tmp/opencode/nexus305-spike-r2/environment/node_modules'),
  baseline: command('git', ['rev-parse', 'HEAD']),
  trackedDiff: command('git', ['diff', '--stat', 'HEAD']),
};
const conditions = [
  [1, 'Node >=24', 'AVAILABLE_AND_VERIFIED', 'runtime.node'],
  [2, 'Pinned libraries reproducible', 'AVAILABLE_NOT_CONFIGURED', 'R2 lock retained; no new install or native load performed'],
  [3, 'Independent OS principals', 'ADMIN_ACTION_REQUIRED', 'named principals absent; current uid=1000'],
  [4, 'OS write enforcement', 'ADMIN_ACTION_REQUIRED', 'no enrolled mount/ownership topology; effective caps=0'],
  [5, 'Post-seal Writer/Publisher cannot mutate', 'ADMIN_ACTION_REQUIRED', 'seal ownership/FD withdrawal not configured'],
  [6, 'FD/IPC/parent/shared metadata inspection', 'ADMIN_ACTION_REQUIRED', 'cross-UID inspection and ACL tools not granted'],
  [7, 'Native in-flight I/O observer', 'ADMIN_ACTION_REQUIRED', 'strace/bpftrace present; no attach/probe; ptrace/BPF policies restrict access'],
  [8, 'Durable filesystem for WAL/fsync/recovery', 'AVAILABLE_NOT_CONFIGURED', 'host ext4 observed; no dedicated disk venue; tmpfs preparation excluded'],
  [9, 'Exclusive final stdout/HTTP owner', 'AVAILABLE_NOT_CONFIGURED', 'GateOwner source supplied; no real experiment FD/socket exists'],
  [10, 'PID/UID/mount/network/resource scope', 'ADMIN_ACTION_REQUIRED', 'dedicated VM/cgroups/network allowlist not provisioned'],
].map(([id, requirement, classification, evidence]) => ({ id, requirement, classification, evidence }));
writeFileSync(new URL('R3_PREFLIGHT_READONLY.json', root), JSON.stringify({ schemaVersion: 'r3-preflight/1', observedAt: new Date().toISOString(), readOnly: true, venue: null, observations, conditions, nativeLoaded: false, experimentExecuted: false }, null, 2) + '\n');
console.log('Read-only host preflight recorded; no namespace, privilege, native load or experiment operation attempted.');
