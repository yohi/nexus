// Static commands only. Never invoke experiment, SDK or source-only test modules.
import { spawnSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repo = path.resolve(process.argv[2]);
const jobs = [
  ['verify-case-boundary.mjs', 'BOUNDARY_STATIC_VERIFICATION.json'],
  ['verify-main-owner-capability.mjs', 'BOUNDARY_OWNER_STATIC.json'],
  ['verify-source-closure.mjs', 'BOUNDARY_SOURCE_CLOSURE_COMMAND.txt'],
  ['verify-frozen-api.mjs', 'BOUNDARY_FROZEN_API_COMMAND.json']
];
const commands = [];
for (const [script, output] of jobs) {
  const result = spawnSync(process.execPath, [path.join(root, 'preparation', script), repo], { encoding: 'utf8' });
  if (result.error) throw result.error;
  const sanitize = text => text.split(root).join('$CANDIDATE/').split(repo).join('$REPO');
  writeFileSync(path.join(root, output), sanitize(result.stdout));
  if (result.stderr) writeFileSync(path.join(root, `${output}.stderr.txt`), sanitize(result.stderr));
  commands.push({ command: `node preparation/${script} "$REPO"`, exit: result.status,
    stdoutArtifact: output, stderrPresent: !!result.stderr, result: result.status === 0 ? 'PASS_STATIC_ONLY' : 'FAIL' });
}
const status = commands.every(c => c.exit === 0) ? 'PASS_STATIC_ONLY' : 'FAIL';
const report = { status, commands, node: process.version, experimentsExecuted: false,
  testsExecuted: false, independentReview: 'NOT_PERFORMED', limitation: 'No runtime correctness or identity attestation.' };
writeFileSync(path.join(root, 'BOUNDARY_STATIC_COMMANDS.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (status === 'FAIL') process.exitCode = 1;
