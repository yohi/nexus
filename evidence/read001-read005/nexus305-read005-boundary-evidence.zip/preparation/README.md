# Preparation tooling

Only archive verification, read-only host discovery and static source checks may
run during this handoff. No experiment module is imported or executed by these
tools. This directory is outside the Nexus repository.
