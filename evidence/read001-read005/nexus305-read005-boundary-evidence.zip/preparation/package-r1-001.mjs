import { readFileSync, writeFileSync, readdirSync, lstatSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, relative } from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const verification = JSON.parse(readFileSync(join(root, 'R3_STATIC_VERIFICATION.json')));
if (verification.status !== 'PASS_STATIC_ONLY' || verification.importedExperimentalModules !== 0 || verification.dynamicTests !== 0) throw new Error('STATIC_ONLY_VERIFICATION_REQUIRED');
const walk = directory => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
  const path = join(directory, entry.name);
  if (lstatSync(path).isSymbolicLink()) throw new Error('PACKAGE_SYMLINK_FORBIDDEN');
  return entry.isDirectory() ? walk(path) : [path];
});
const files = walk(root).filter(path => relative(root, path) !== 'SHA256SUMS').sort();
const expected = files.map(path => ({ path: relative(root, path), sha256: sha(readFileSync(path)) }));
writeFileSync(join(root, 'SHA256SUMS'), expected.map(row => `${row.sha256}  ${row.path}\n`).join(''));
const destination = fileURLToPath(new URL('../../nexus305-r3-driver-integration-r2-evidence.zip', import.meta.url));
const readback = JSON.parse(execFileSync('python3', ['-c', `import pathlib,zipfile,hashlib,json,io,sys
root=pathlib.Path(sys.argv[1]); destination=pathlib.Path(sys.argv[2])
files=sorted(p for p in root.rglob('*') if p.is_file())
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files: z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(destination) as z:
 assert z.testzip() is None
 names=z.namelist(); assert len(names)==len(set(names))
 sums={r.split(None,1)[1].lstrip(' *'):r.split()[0] for r in z.read('SHA256SUMS').decode().splitlines()}
 assert set(names)==set(sums)|{'SHA256SUMS'}
 for name,h in sums.items(): assert hashlib.sha256(z.read(name)).hexdigest()==h,name
 for p in files: assert z.read(p.relative_to(root).as_posix())==p.read_bytes()
 original=z.read('inputs/driver-integration-r1-original.zip')
 assert hashlib.sha256(original).hexdigest()=='dd8fe5ac588ad9642709c9e3ad311a9eaaf3afc9a7098d3b443a483f95288cbe'
 with zipfile.ZipFile(io.BytesIO(original)) as old:
  assert old.testzip() is None
  old_sums={r.split(None,1)[1].lstrip(' *'):r.split()[0] for r in old.read('SHA256SUMS').decode().splitlines()}
  for name,h in old_sums.items(): assert hashlib.sha256(old.read(name)).hexdigest()==h
  for name in ['src/authority.mjs','src/adapters/sqlite-authority.mjs','src/drivers/cutover.mjs','src/publication-admission.mjs','src/oracles.mjs','src/readback-oracle.mjs','src/cases.mjs','src/launcher.mjs','src/revision-oracles.mjs','fixtures/r1-counterexample-oracles.json','preparation/verify-revision.mjs']:
   assert old.read(name)==z.read(name),name
  previous=json.loads(old.read('R3_FROZEN_COMMAND_MANIFEST.json')); old_rows=previous['bindings']+previous['extraBindings']
  current=json.loads(z.read('R3_FROZEN_COMMAND_MANIFEST.json')); rows=current['bindings']+current['extraBindings']
  assert len(rows)==len(set(r['bindingId'] for r in rows))==234
  assert sum(r['variant']=='SAFE_VARIANT' for r in rows)==117 and sum(r['variant']=='NEGATIVE_CONTROL' for r in rows)==117
  for r in rows:
   before=next(o for o in old_rows if o['bindingId']==r['bindingId'])
   assert all(before[k]==r[k] for k in ['testId','variant','oracle'])
   assert r['status']=='BLOCKED' and r['classification']=='NOT_EXECUTED'
  source_changes=json.loads(z.read('R3_R1_001_SOURCE_CHANGES.json'))
  for r in source_changes['sourceChanges']:
   assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['afterSha256']
   if r['beforeSha256']: assert hashlib.sha256(old.read(r['path'])).hexdigest()==r['beforeSha256']
  for r in source_changes['toolingSources']: assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
 sources=json.loads(z.read('R3_HARNESS_SOURCE_MANIFEST.json'))
 for r in sources['sources']+sources['typeSources']+sources['fixedSources']+sources['apiSources']:
  assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
 for r in sources['baselineRuntimeSources']:
  assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
  if r['runtimePath']: assert hashlib.sha256(z.read(r['runtimePath'])).hexdigest()==r['runtimeSha256']
 regression=json.loads(z.read('R3_R1_STATIC_REGRESSION.json')); assert regression['status']=='PASS_STATIC_ONLY' and len(regression['checks'])==15
 fix=json.loads(z.read('R3_R1_001_STATIC_REGRESSION.json')); assert fix['status']=='PASS_STATIC_ONLY' and fix['oracleExecutions']==0
 baseline=json.loads(z.read('R3_R1_001_BASELINE_STATIC.json')); assert baseline['status']=='FAIL_STATIC'
 assert fix['verifierSha256']==baseline['verifierSha256']==hashlib.sha256(z.read('preparation/verify-r1-001.mjs')).hexdigest()
 matrix=json.loads(z.read('R3_R1_001_ORACLE_MATRIX.json'))
 assert {r['id'] for r in matrix['cases']}=={f'R1-001-{i:02d}' for i in range(1,16)}
 assert matrix['dynamicExecution']=='NOT_EXECUTED'
 gate=json.loads(z.read('R3_EXECUTION_GATE_STATUS.json'))
 assert gate['executionGate']=='NOT_AUTHORIZED' and gate['experiment']=='NOT_EXECUTED' and gate['authorization'] is None
 assert gate['completion']=='DESIGN_CLARIFICATION_REQUIRED' and gate['section4_1']=='BLOCKED'
 print(json.dumps({'crc':'VERIFIED','members':len(names),'manifestEntries':len(sums),'exactMemberCoverage':True,'allMemberHashes':'MATCH','sourceAndToolingHashes':'MATCH','R1Original':'BYTE_IDENTICAL','originalOraclesAnd15Regressions':'PRESERVED','bindingIDs':234,'safe':117,'negative':117,'additionalOracles':15,'oracleExecution':'NOT_EXECUTED'}))`, root, destination], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }));
const sidecar = { archive: destination.split('/').at(-1), zipSha256: sha(readFileSync(destination)),
  manifestSha256: sha(readFileSync(join(root, 'SHA256SUMS'))),
  files: [...expected, { path: 'SHA256SUMS', sha256: sha(readFileSync(join(root, 'SHA256SUMS'))) }], readback,
  completion: 'DESIGN_CLARIFICATION_REQUIRED', integrationStatus: 'PARTIALLY_INTEGRATED', executionGate: 'NOT_AUTHORIZED', experiment: 'NOT_EXECUTED' };
writeFileSync(`${destination}.manifest.json`, JSON.stringify(sidecar, null, 2) + '\n');
writeFileSync(`${destination}.sha256`, `${sidecar.zipSha256}  ${sidecar.archive}\n`);
console.log(JSON.stringify({ archive: sidecar.archive, sha256: sidecar.zipSha256, completion: sidecar.completion, ...readback }, null, 2));
