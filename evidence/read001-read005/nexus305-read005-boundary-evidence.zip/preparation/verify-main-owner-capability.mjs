// Static tooling only. No Harness, SDK, scenario or test module is imported.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[3] ?? fileURLToPath(new URL('../', import.meta.url)));
const ts = createRequire(path.join(path.resolve(process.argv[2]), 'package.json'))('typescript');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const sha = text => createHash('sha256').update(text).digest('hex');
const walk = dir => fs.readdirSync(path.join(root, dir), { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
const checks = [];
const check = (id, pass) => checks.push({ id, result: pass ? 'PASS_STATIC_ONLY' : 'FAIL' });
const asts = new Map(); const inventory = []; const syntax = [];
for (const name of ['src', 'tests'].flatMap(walk).filter(name => name.endsWith('.mjs'))) {
  const text = read(name);
  execFileSync(process.execPath, ['--check', path.join(root, name)], { stdio: 'pipe' });
  const ast = ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (ast.parseDiagnostics.length) throw new Error(`AST_PARSE:${name}`);
  asts.set(name, ast); syntax.push({ path: name, sha256: sha(text) });
  const visit = node => {
    const relevant = ts.isPropertyAccessExpression(node) && /^(transport|server|reference|handleRequest|close|send|onmessage|admit|assertHandle)$/.test(node.name.text);
    if (relevant) inventory.push({ path: name, line: ast.getLineAndCharacterOfPosition(node.getStart(ast)).line + 1,
      access: node.getText(ast), context: name.startsWith('tests/') ? 'SOURCE_ONLY_ORACLE' : 'REQUIRES_BOUNDARY_CLASSIFICATION' });
    ts.forEachChild(node, visit);
  };
  visit(ast);
}
const ownerAST = asts.get('src/replay/main-session-owner.mjs');
const owner = ownerAST.statements.find(node => ts.isClassDeclaration(node) && node.name.text === 'MainSessionOwners');
const members = new Map(owner.members.filter(node => node.name || ts.isConstructorDeclaration(node))
  .map(node => [ts.isConstructorDeclaration(node) ? 'constructor' : node.name.getText(ownerAST), node]));
const text = name => members.get(name)?.getText(ownerAST) ?? '';
const returns = node => {
  const found = [];
  const visit = item => { if (ts.isReturnStatement(item)) found.push(item.expression?.getText(ownerAST) ?? ''); ts.forEachChild(item, visit); };
  if (node) visit(node); return found;
};
check('OWNER_NO_PUBLIC_REFERENCE', !members.has('reference'));
check('OWNER_PRIVATE_DEPENDENCIES', ['#receipts', '#observer', '#requestBoundary', '#handles', '#sessions'].every(name => members.has(name)));
check('OWNER_PRIVATE_BINDING_AND_ADMISSION', members.has('#binding') && members.has('#admit'));
check('HANDLE_EMPTY_NULL_PROTOTYPE', text('register').includes('Object.freeze(Object.create(null))') && JSON.stringify(returns(members.get('register'))) === '["handle"]');
check('HANDLE_IDENTITY_WEAKMAP', text('#handles').includes('new WeakMap()') && text('#binding').includes('this.#handles.get(handle)') && text('#binding').includes('this.#sessions.get(binding.session.session_id) === binding'));
check('PUBLIC_ADMIT_NO_RETURN', returns(members.get('admit')).length === 0 && text('admit').includes('await this.#admit('));
check('PUBLIC_ASSERT_HANDLE_NO_RETURN', returns(members.get('assertHandle')).length === 0 && text('assertHandle').includes('this.#binding(handle)'));
check('OWNER_FROZEN_INSTANCE', text('constructor').includes('Object.freeze(this)'));
check('PUBLIC_OWNER_SURFACE', JSON.stringify([...members.keys()].filter(name => !name.startsWith('#')).sort()) === JSON.stringify(['admit', 'assertHandle', 'constructor', 'dispatch', 'register', 'snapshotIdentity']));
const dispatch = members.get('dispatch');
const body = dispatch.body.statements;
const sdkIndex = body.findIndex(node => ts.isReturnStatement(node) && node.expression?.getText(ownerAST) === 'binding.transport.handleRequest(request)');
const verifyIndex = body.findIndex(node => node.getText(ownerAST).includes('this.#observer.verifyMainDispatchSync('));
let finalAwait = false;
for (const node of body.slice(verifyIndex)) {
  const visit = item => { if (ts.isAwaitExpression(item)) finalAwait = true; ts.forEachChild(item, visit); }; visit(node);
}
check('SYNC_VERIFY_GUARD_IMMEDIATE_SDK_CALL', sdkIndex === verifyIndex + 2 && !finalAwait && body[verifyIndex + 1]?.getText(ownerAST).includes('MAIN_DISPATCH_OWNER_AUTHORITY_UNPROVEN'));
check('FINAL_IDENTITY_PRINCIPAL_ACTIVE_BOOT_AUTHORITY', ['ingress.current(ticket)', 'ledger.activeSession(', 'binding.boot ===', 'authority.allows(owner.envelope)', 'assertTransport(',
  'admission.transport === binding.transport', 'admission.server === binding.server', 'admission.activeCommitToken === current.active_commit_receipt',
  'admission.principalKey === principal.principal_key', 'admission.requestIdentity === principal.requestIdentity', 'admission.authorityReceipt && admission.grantReceipt'].every(fragment => text('dispatch').includes(fragment)));
check('DISPATCH_PRIVATE_ADMISSION', text('dispatch').includes('await this.#admit(') && !text('dispatch').includes('await this.admit('));
const webAST = asts.get('src/adapters/sdk-drivers.mjs');
const web = webAST.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'actualSDKWeb');
const webText = web.getText(webAST);
const publicKeys = [];
const visitWeb = node => {
  if (ts.isPropertyAssignment(node) && node.parent.parent && ts.isCallExpression(node.parent.parent) && node.parent.parent.expression.getText(webAST) === 'Object.assign') publicKeys.push(node.name.getText(webAST));
  ts.forEachChild(node, visitWeb);
}; visitWeb(web);
check('DRIVER_LIMITED_FROZEN_NULL_PROTOTYPE_SURFACE', webText.includes('Object.freeze(Object.assign(Object.create(null),') && JSON.stringify(publicKeys.sort()) === JSON.stringify(['close', 'plan', 'replay', 'route']));
check('DRIVER_NO_RAW_CAPABILITY_ACCESS', !/\.(transport|server|reference|handleRequest|onmessage|send)\b/.test(webText));
check('DRIVER_VALIDATES_HANDLE', webText.includes('mainOwners.assertHandle(mainSession)'));
check('DRIVER_CLOSE_FAIL_CLOSED', webText.includes("close: async () => { throw new Error('MAIN_OWNER_CLOSE_AUTHORITY_UNSPECIFIED'); }") && !webText.includes('mainSession.close('));
check('REPLAY_BROKER_AUTHENTICATED_ROUTE', webText.includes('await mainOwners.admit(mainSession, request, target);') && webText.includes('return replayBroker.reconnect(request, target)') && text('dispatch').includes('REPLAY_BROKER_REQUIRED'));
const manifest = JSON.parse(read('R3_FROZEN_COMMAND_MANIFEST.json'));
const bindings = [...manifest.bindings, ...manifest.extraBindings];
const cells = JSON.parse(read('src/readiness/scenario-catalog.json'));
check('BINDINGS_234_117_117_BLOCKED', bindings.length === 234 && bindings.filter(b => b.variant === 'SAFE_VARIANT').length === 117 && bindings.filter(b => b.variant === 'NEGATIVE_CONTROL').length === 117 && bindings.every(b => b.status === 'BLOCKED' && b.classification === 'NOT_EXECUTED'));
check('ORACLE_61_NOT_EXECUTED', cells.length === 61 && cells.every(c => c.execution === 'NOT_EXECUTED' && c.actual === null));
check('LAUNCHER_NOT_AUTHORIZED', read('src/launcher.mjs').includes('NOT_AUTHORIZED'));
const report = { status: checks.every(c => c.result === 'PASS_STATIC_ONLY') ? 'PASS_STATIC_ONLY' : 'FAIL',
  node: process.version, typescript: ts.version, checks, syntax, inventory,
  bindings: 234, oracleCells: 61, experimentalImports: 0, testsExecuted: 0, SDKDispatchesExecuted: 0,
  negativeObservation: 'UNKNOWN', independentReview: 'NOT_PERFORMED',
  limitation: 'AST structural and syntax evidence only; not behavioral, object-identity, observer-trust or full semantic JS type proof.' };
console.log(JSON.stringify(report, null, 2));
if (report.status === 'FAIL') process.exitCode = 1;
