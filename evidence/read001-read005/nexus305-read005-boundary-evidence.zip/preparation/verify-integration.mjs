import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve, join, dirname, relative } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const repository = resolve(process.argv[2] ?? process.cwd());
const require = createRequire(join(repository, 'package.json'));
const ts = require('typescript'); const Ajv = require('ajv');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = path => readFileSync(join(root, path), 'utf8');
const json = path => JSON.parse(text(path));
const assert = (value, detail) => { if (!value) throw new Error(detail); };
const originalText = execFileSync('unzip', ['-p', join(root, 'inputs/provisioning-v3-original.zip'), 'R3_FROZEN_COMMAND_MANIFEST.json'], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
const original = JSON.parse(originalText);
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
const sourceManifest = json('R3_HARNESS_SOURCE_MANIFEST.json');
const rows = [...manifest.bindings, ...manifest.extraBindings];
const oldRows = [...original.bindings, ...original.extraBindings];
const checks = [];
const units = new Map();
for (const source of sourceManifest.sources) {
  assert(sha(readFileSync(join(root, source.path))) === source.sha256, `SOURCE_HASH:${source.path}`);
  execFileSync(process.execPath, ['--check', join(root, source.path)]);
  const ast = ts.createSourceFile(source.path, text(source.path), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const exports = new Set();
  for (const statement of ast.statements) {
    if (!statement.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword)) continue;
    if (statement.name) exports.add(statement.name.text);
    if (ts.isVariableStatement(statement)) for (const declaration of statement.declarationList.declarations) if (ts.isIdentifier(declaration.name)) exports.add(declaration.name.text);
  }
  units.set(source.path, { ast, exports });
}
for (const [path, unit] of units) for (const statement of unit.ast.statements) {
  if (!ts.isImportDeclaration(statement)) continue;
  const specifier = statement.moduleSpecifier.text;
  if (specifier.startsWith('node:')) { assert(specifier !== 'node:child_process', `PROCESS_IMPORT:${path}`); continue; }
  assert(specifier.startsWith('.'), `UNPINNED_IMPORT:${path}`);
  const target = relative(root, resolve(root, dirname(path), specifier));
  assert(units.has(target), `MISSING_MODULE:${path}:${specifier}`);
  const names = statement.importClause?.namedBindings;
  if (names && ts.isNamedImports(names)) for (const name of names.elements) assert(units.get(target).exports.has((name.propertyName ?? name.name).text), `MISSING_EXPORT:${path}:${name.name.text}`);
}
checks.push({ check: 'source-syntax-hashes-import-export', status: 'PASS_STATIC', count: units.size });
for (const name of readdirSync(join(root, 'preparation')).filter(name => name.endsWith('.mjs'))) execFileSync(process.execPath, ['--check', join(root, 'preparation', name)]);
// Resolve imports against the existing installation using virtual compiler files;
// write nothing to the Nexus repository and import no experimental modules.
const probePath = join(repository, '__r3_api_probe__.mts');
const contractPath = join(repository, '__r3_publication_contract__.mts');
const sourceByPath = new Map([[probePath, text('preparation/api-probe.mts')], [contractPath, text('src/publication-contract.d.mts')]]);
const options = { noEmit: true, strict: true, skipLibCheck: true, noUncheckedIndexedAccess: true, exactOptionalPropertyTypes: true, verbatimModuleSyntax: true, module: ts.ModuleKind.NodeNext, moduleResolution: ts.ModuleResolutionKind.NodeNext, target: ts.ScriptTarget.ES2023, types: ['node'] };
const host = ts.createCompilerHost(options); const getSource = host.getSourceFile.bind(host);
const fileExists = host.fileExists.bind(host); const readFile = host.readFile.bind(host);
host.fileExists = path => sourceByPath.has(path) || fileExists(path);
host.readFile = path => sourceByPath.get(path) ?? readFile(path);
host.getSourceFile = (path, languageVersion, onError, shouldCreateNewSourceFile) => sourceByPath.has(path) ? ts.createSourceFile(path, sourceByPath.get(path), languageVersion, true) : getSource(path, languageVersion, onError, shouldCreateNewSourceFile);
const program = ts.createProgram([...sourceByPath.keys()], options, host);
const diagnostics = ts.getPreEmitDiagnostics(program);
assert(!diagnostics.length, ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCanonicalFileName: path => path, getCurrentDirectory: () => repository, getNewLine: () => '\n' }));
checks.push({ check: 'fixed-api-signature-probe-and-publication-types', status: 'PASS_STATIC', scope: 'strict compile-only probes; JS adapters are syntax/AST checked, not fully typechecked' });
const negativePath = join(repository, '__r3_claim_permit_negative__.mts');
sourceByPath.set(negativePath, `import type { TerminalClaim, PublicationBoundary } from './__r3_publication_contract__.mjs';\ndeclare const claim: TerminalClaim;\ndeclare const gate: PublicationBoundary;\ngate.publishPermit(claim);\n`);
const negative = ts.getPreEmitDiagnostics(ts.createProgram([...sourceByPath.keys()], options, host));
assert(negative.length === 1 && negative[0].code === 2345 && negative[0].file?.fileName === negativePath, `CLAIM_MUST_NOT_TYPECHECK_AS_PERMIT:${ts.formatDiagnostics(negative, { getCanonicalFileName: path => path, getCurrentDirectory: () => repository, getNewLine: () => '\n' })}`);
checks.push({ check: 'terminal-claim-as-publication-permit-negative-type-probe', status: 'PASS_STATIC', expectedDiagnostic: 2345, experimentalCodeExecuted: false });
sourceByPath.delete(negativePath);
const storedPath = join(repository, '__r3_stored_auth_negative__.mts');
sourceByPath.set(storedPath, `import type { StoredFrameAuth } from './__r3_publication_contract__.mjs';\ndeclare const stored: StoredFrameAuth;\nstored.retrievalPairVerified;\n`);
const storedDiagnostics = ts.getPreEmitDiagnostics(ts.createProgram([...sourceByPath.keys()], options, host));
assert(storedDiagnostics.length === 1 && storedDiagnostics[0].code === 2339 && storedDiagnostics[0].file?.fileName === storedPath, 'STORED_AUTH_MUST_NOT_OWN_RETRIEVAL_VERIFICATION');
sourceByPath.delete(storedPath);
const envelopePath = join(repository, '__r3_stored_envelope_negative__.mts');
sourceByPath.set(envelopePath, `import type { StoredFrameAuth, PublicationEnvelope } from './__r3_publication_contract__.mjs';\ndeclare const stored: StoredFrameAuth;\nconst envelope: PublicationEnvelope = stored;\n`);
const envelopeDiagnostics = ts.getPreEmitDiagnostics(ts.createProgram([...sourceByPath.keys()], options, host));
assert(envelopeDiagnostics.length === 1 && envelopeDiagnostics[0].code === 2322 && envelopeDiagnostics[0].file?.fileName === envelopePath, 'STORED_AUTH_MUST_NOT_TYPECHECK_AS_REQUEST_ENVELOPE');
checks.push({ check: 'stored-provenance-cannot-own-verification-or-replace-request-envelope', status: 'PASS_STATIC', expectedDiagnostics: [2339, 2322], experimentalCodeExecuted: false });
sourceByPath.delete(envelopePath);
const storedContract = join(repository, '__r3_stored_event_contract__.mts');
sourceByPath.set(storedContract, text('src/stored-event-contract.d.mts').replace('./publication-contract.mjs', './__r3_publication_contract__.mjs'));
assert(ts.getPreEmitDiagnostics(ts.createProgram([...sourceByPath.keys()], options, host)).length === 0, 'STORED_EVENT_CONTRACT_COMPILE');
const ticketNegativePath = join(repository, '__r3_event_id_ticket_negative__.mts');
sourceByPath.set(ticketNegativePath, `import type { StoredEventTicket } from './__r3_stored_event_contract__.mjs';\ndeclare const knownId: string;\nconst ticket: StoredEventTicket = knownId;\n`);
const ticketDiagnostics = ts.getPreEmitDiagnostics(ts.createProgram([...sourceByPath.keys()], options, host));
assert(ticketDiagnostics.length === 1 && ticketDiagnostics[0].code === 2322 && ticketDiagnostics[0].file?.fileName === ticketNegativePath, 'EVENT_ID_IS_NOT_OWNER_TICKET');
sourceByPath.delete(ticketNegativePath);
checks.push({ check: 'stored-event-ticket-not-event-id-negative-type-probe', status: 'PASS_STATIC', expectedDiagnostic: 2322, experimentalCodeExecuted: false });
execFileSync(process.execPath, [join(repository, 'node_modules/typescript/bin/tsc'), '--noEmit'], { cwd: repository });
checks.push({ check: 'fixed-repository-tsc-noEmit', status: 'PASS_STATIC', productSourceChanged: false });
assert(rows.length === 234 && new Set(rows.map(row => row.bindingId)).size === 234, 'BINDING_IDS');
for (const row of rows) {
  const old = oldRows.find(item => item.bindingId === row.bindingId);
  assert(old && old.testId === row.testId && old.variant === row.variant && JSON.stringify(old.oracle) === JSON.stringify(row.oracle), `ORACLE_OR_ID_CHANGED:${row.bindingId}`);
  assert(row.status === 'BLOCKED' && row.classification === 'NOT_EXECUTED', 'EXECUTION_UPGRADE');
  assert(row.argv[1] === 'src/launcher.mjs' && row.argv.at(-1) === row.bindingId && existsSync(join(root, row.argv[1])), 'LAUNCHER_BINDING');
  for (const entry of [row.entryPoint, ...row.driverEntryPoints]) assert(units.get(entry.path)?.exports.has(entry.function), `DRIVER_EXPORT:${entry.path}:${entry.function}`);
  for (const source of row.sources) assert(units.get(source.path) && sha(readFileSync(join(root, source.path))) === source.sha256, 'BINDING_SOURCE_SHA');
  assert(row.inputFixture.variant === row.variant && row.inputFixture.root.endsWith(row.variant), 'VARIANT_FIXTURE');
}
assert(new Set(rows.map(row => row.testId)).size === 15, 'GROUP_COUNT');
for (const name of ['caseA', 'caseB', 'caseB2', 'caseC', 'caseD', 'caseE', 'caseF']) assert(units.get('src/cases.mjs').exports.has(name), `CASE:${name}`);
// Frozen Oracle and plans are compared directly with the input archive, not
// updated hashes generated by this integration task.
for (const path of ['src/oracles.mjs', 'src/readback-oracle.mjs', 'src/cases.mjs', 'src/launcher.mjs', 'reference/SECTION4_1_REV5_PROPOSAL.md', 'reference/R3_TARGETED_SPIKE_PLAN.md', 'reference/R3_PLAN_AMENDMENT_R5_R3_001.md', 'reference/R3_ORACLE_MATRIX.json', 'reference/R2-package-lock.json']) {
  const old = execFileSync('unzip', ['-p', join(root, 'inputs/provisioning-v3-original.zip'), path], { maxBuffer: 8 * 1024 * 1024 });
  assert(old.equals(readFileSync(join(root, path))), `FROZEN_CONTRACT_CHANGED:${path}`);
}
checks.push({ check: '234-bindings-15-groups-A-F-B2-original-oracles-and-launcher', status: 'PASS_STATIC' });
for (const row of sourceManifest.fixedSources) assert(sha(readFileSync(join(root, row.path))) === row.sha256, `FIXED_SOURCE:${row.path}`);
for (const row of sourceManifest.baselineRuntimeSources) {
  assert(sha(readFileSync(join(root, row.path))) === row.sha256, `BASELINE:${row.path}`);
  if (row.runtimePath) assert(sha(readFileSync(join(root, row.runtimePath))) === row.runtimeSha256, `RUNTIME:${row.runtimePath}`);
}
for (const row of sourceManifest.apiSources) assert(sha(readFileSync(join(root, row.path))) === row.sha256, `API_EVIDENCE:${row.path}`);
const ajv = new Ajv({ allErrors: true });
for (const [path, schema] of [['R3_FROZEN_COMMAND_MANIFEST.json', 'command-manifest'], ['R3_HARNESS_SOURCE_MANIFEST.json', 'source-manifest'], ['R3_EXECUTION_GATE_STATUS.json', 'gate']]) {
  const validate = ajv.compile(json(`schemas/${schema}.schema.json`)); assert(validate(json(path)), `SCHEMA:${path}:${JSON.stringify(validate.errors)}`);
}
checks.push({ check: 'baseline-runtime-api-evidence-and-manifest-schemas', status: 'PASS_STATIC' });
const launcher = text('src/launcher.mjs');
assert(launcher.includes('throw new Error(\'NOT_AUTHORIZED:') && !launcher.includes('process.env'), 'AUTHORIZATION_BYPASS');
const gate = text('src/gate-owner.mjs');
assert(!/\bawait\b/.test(gate.replace(/\/\/[^\n]*/g, '')), 'AWAIT_IN_GATE');
assert(gate.includes('#claims = new WeakMap()') && gate.includes('#permits = new WeakMap()') && gate.includes('state.pending !== permit'), 'PERMIT_OWNERSHIP');
const cas = text('src/adapters/cas-fault-driver.mjs');
assert(cas.indexOf('beginPendingCAS') < cas.indexOf("pause('ACTIVE_CAS_BEGIN_BEFORE_COMMIT_DECISION'"), 'B2_TRANSACTION_BARRIER');
for (const [path, unit] of units) {
  const visit = node => {
    if (ts.isCallExpression(node)) {
      const expression = node.expression.getText(unit.ast);
      const name = ts.isPropertyAccessExpression(node.expression) ? node.expression.name.text : ts.isIdentifier(node.expression) ? node.expression.text : '';
      assert(!['spawn', 'spawnSync', 'execSync', 'execFile', 'execFileSync', 'chmod', 'chown', 'mount', 'rm', 'rmdir', 'kill'].includes(name), `UNSCOPED_CALL:${path}:${expression}`);
      if (name === 'exec') assert(['this.db.exec', 'store.db.exec'].includes(expression), `EXEC_CALLEE:${path}:${expression}`);
    }
    ts.forEachChild(node, visit);
  }; visit(unit.ast);
}
checks.push({ check: 'NOT_AUTHORIZED-no-env-bypass-gate-no-await-and-direct-operation-scan', status: 'PASS_STATIC', limitation: 'AST source shape is not a dynamic concurrency or OS ownership proof' });
const required = ['R3_DRIVER_INTEGRATION_REPORT.md', 'R3_NATIVE_DRIVER_REPORT.md', 'R3_JOURNAL_RECOVERY_DRIVER_REPORT.md', 'R3_MCP_TRANSPORT_DRIVER_REPORT.md', 'R3_PUBLICATION_GATE_REPORT.md', 'R3_REMAINING_BLOCKERS.md', 'README.md', 'R3_R1_001_FIX_REPORT.md', 'R3_REPLAY_ENTITLEMENT_CONTRACT.md', 'R3_FINDING_DISPOSITION.md', 'R3_R1_001_ORACLE_MATRIX.json'];
for (const path of required) assert(existsSync(join(root, path)), `REPORT:${path}`);
const revision = json('R3_R1_STATIC_REGRESSION.json');
assert(revision.status === 'PASS_STATIC_ONLY' && revision.experimentalImports === 0 && revision.dynamicTests === 0, 'REVISION_STATIC_REGRESSION');
for (const source of revision.inspectedSources) assert(sha(readFileSync(join(root, source.path))) === source.sha256, `REVISION_SOURCE_HASH:${source.path}`);
checks.push({ check: 'R1-major-finding-source-regressions', status: 'PASS_STATIC', oracleExecution: 'NOT_EXECUTED' });
const r1_001 = json('R3_R1_001_STATIC_REGRESSION.json');
assert(r1_001.status === 'PASS_STATIC_ONLY' && r1_001.experimentalImports === 0 && r1_001.oracleExecutions === 0, 'R1_001_STATIC_REGRESSION');
for (const source of r1_001.inspectedSources) assert(sha(readFileSync(join(root, source.path))) === source.sha256, `R1_001_SOURCE:${source.path}`);
const validateMatrix = ajv.compile(json('schemas/r1-001-oracle-matrix.schema.json'));
assert(validateMatrix(json('R3_R1_001_ORACLE_MATRIX.json')), `R1_001_ORACLE_MATRIX:${JSON.stringify(validateMatrix.errors)}`);
checks.push({ check: 'R1-001-source-regressions-and-15-oracle-schema', status: 'PASS_STATIC', completion: 'DESIGN_CLARIFICATION_REQUIRED', oracleExecution: 'NOT_EXECUTED' });
const report = { schemaVersion: 'r3-driver-static-verification/1', status: 'PASS_STATIC_ONLY', integrationStatus: 'PARTIALLY_INTEGRATED', checks, sourceFiles: units.size, bindingCount: rows.length, groups: 15, dynamicTests: 0, importedExperimentalModules: 0, nativeLoaded: false, sdkTransportExecuted: false, crashFaultSignalExecuted: false, executionGate: 'NOT_AUTHORIZED', section4_1: 'BLOCKED', tools: { node: process.version, typescript: ts.version, markdownlint: 'NOT_RUN_NOT_INSTALLED_NO_INSTALL_AUTHORIZED' }, limits: ['No full semantic typecheck of injected JavaScript adapters', 'No dynamic proof of concurrency, ownership, native runtime, transport handshake, durability or Oracle satisfaction'], toolingFailuresResolved: ['capture-api excluded declaration-only .d.ts from transpileModule after diagnostic identified the failing declaration file', 'virtual compiler host now exposes fileExists/readFile for the negative claim/permit type probe; missing virtual import TS2307 is no longer mistaken for the expected TS2345'] };
const currentReport = { ...report, taskRevision: 'R2', completion: 'DESIGN_CLARIFICATION_REQUIRED', replayEntitlement: 'REPLAY_ENTITLEMENT_UNPROVEN' };
writeFileSync(join(root, 'R3_STATIC_VERIFICATION.json'), JSON.stringify(currentReport, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, sources: units.size, bindings: rows.length, groups: 15, experimentalImports: 0 }));
