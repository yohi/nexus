import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { join, dirname, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(resolve(process.cwd(), 'package.json'));
const ts = require('typescript');
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const text = path => readFileSync(join(root, path), 'utf8');
const json = path => JSON.parse(text(path));
const assert = (value, message) => { if (!value) throw new Error(message); };
const manifest = json('R3_FROZEN_COMMAND_MANIFEST.json');
const original = json('reference/prior-command-manifest.json');
const sourceManifest = json('R3_HARNESS_SOURCE_MANIFEST.json');
const rows = [...manifest.bindings, ...manifest.extraBindings];
const oldRows = [...original.bindings, ...original.extraBindings];
const checks = [];
const requiredDocuments = ['R3_ENVIRONMENT_PROVISIONING_REPORT.md', 'R3_ADMIN_PROVISIONING_REQUEST.md', 'R3_HARNESS_IMPLEMENTATION_REPORT.md', 'R3_FROZEN_COMMAND_MANIFEST.json', 'R3_HARNESS_SOURCE_MANIFEST.json', 'R3_PERMISSION_GRANT_MATRIX.md', 'R3_PREFLIGHT_READONLY.json', 'R3_EXECUTION_AUTHORIZATION_REQUEST.md', 'R3_EXECUTION_GATE_STATUS.json', 'R3_EVIDENCE_SCHEMA.md', 'README.md'];
for (const path of requiredDocuments) assert(existsSync(join(root, path)), `REQUIRED_DELIVERABLE:${path}`);
for (const name of readdirSync(join(root, 'preparation')).filter(name => name.endsWith('.mjs'))) execFileSync(process.execPath, ['--check', join(root, 'preparation', name)], { stdio: ['ignore', 'pipe', 'pipe'] });
checks.push({ check: 'required-documents-and-preparation-syntax', status: 'PASS_STATIC', markdownLint: 'NOT_RUN_TOOL_NOT_INSTALLED_NO_INSTALL_AUTHORIZED' });
assert(sha(readFileSync(join(root, 'inputs/original-v2.zip'))) === '8e2205860789b99bb083f384022ea4bbe1d9d2a7e4ab522ccf7ffab7a017fbc1', 'ORIGINAL_ZIP_CHANGED');
checks.push({ check: 'original-zip-hash', status: 'PASS_STATIC' });
assert(rows.length === 234 && new Set(rows.map(row => row.bindingId)).size === 234, 'BINDING_COUNT_OR_UNIQUENESS');
const units = new Map();
for (const source of sourceManifest.sources) {
  const bytes = readFileSync(join(root, source.path));
  assert(sha(bytes) === source.sha256, `SOURCE_HASH:${source.path}`);
  execFileSync(process.execPath, ['--check', join(root, source.path)], { stdio: ['ignore', 'pipe', 'pipe'] });
  const ast = ts.createSourceFile(source.path, bytes.toString(), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const exports = new Set();
  for (const statement of ast.statements) {
    if (!statement.modifiers?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword)) continue;
    if (statement.name) exports.add(statement.name.text);
    if (ts.isVariableStatement(statement)) for (const declaration of statement.declarationList.declarations) if (ts.isIdentifier(declaration.name)) exports.add(declaration.name.text);
  }
  units.set(source.path, { ast, exports });
}
for (const [path, unit] of units) {
  for (const statement of unit.ast.statements) {
    if (!ts.isImportDeclaration(statement)) continue;
    const specifier = statement.moduleSpecifier.text;
    assert(specifier !== 'node:child_process', `PROCESS_LAUNCH_IMPORT_FORBIDDEN:${path}`);
    if (specifier.startsWith('node:')) continue;
    assert(specifier.startsWith('.'), `UNPINNED_EXTERNAL_IMPORT:${path}:${specifier}`);
    const target = relative(root, resolve(root, dirname(path), specifier));
    assert(units.has(target), `MISSING_IMPORT:${path}:${target}`);
    const bindings = statement.importClause?.namedBindings;
    if (bindings && ts.isNamedImports(bindings)) for (const binding of bindings.elements) assert(units.get(target).exports.has((binding.propertyName ?? binding.name).text), `MISSING_EXPORT:${path}:${binding.name.text}`);
  }
}
checks.push({ check: 'syntax-source-hash-import-export', status: 'PASS_STATIC', sources: units.size, experimentImported: false });
for (const file of sourceManifest.fixedSources) assert(sha(readFileSync(join(root, file.path))) === file.sha256, `FIXTURE_HASH:${file.path}`);
for (const row of rows) {
  const old = oldRows.find(old => old.bindingId === row.bindingId);
  assert(old && row.testId === old.testId && row.variant === old.variant && JSON.stringify(row.oracle) === JSON.stringify(old.oracle), `ORACLE_CHANGED:${row.bindingId}`);
  for (const source of row.sources) assert(sha(readFileSync(join(root, source.path))) === source.sha256, `BINDING_SOURCE_HASH:${row.bindingId}`);
  assert(row.argv[1] === 'src/launcher.mjs' && row.argv.at(-1) === row.bindingId && existsSync(join(root, row.argv[1])), 'ARGV_TARGET');
  assert(units.get(row.entryPoint.path).exports.has(row.entryPoint.function), 'MISSING_ENTRYPOINT_EXPORT');
  assert(units.get(row.oracleFunctions.path).exports.has(row.oracleFunctions.function), 'MISSING_ORACLE_EXPORT');
  if (row.caseFunction) for (const name of row.caseFunction.functions) assert(units.get(row.caseFunction.path).exports.has(name), `CASE_EXPORT:${name}`);
  assert(row.status === 'BLOCKED' && row.classification === 'NOT_EXECUTED', 'EXECUTION_STATE_UPGRADE');
}
assert(new Set(rows.map(row => row.testId)).size === 15, 'TEST_GROUP_COUNT');
for (const name of ['caseA', 'caseB', 'caseB2', 'caseC', 'caseD', 'caseE', 'caseF']) assert(units.get('src/cases.mjs').exports.has(name), `MANDATORY_CASE:${name}`);
const oracleAST = units.get('src/oracles.mjs').ast;
const groupDeclaration = oracleAST.statements.filter(ts.isVariableStatement).flatMap(statement => [...statement.declarationList.declarations]).find(declaration => declaration.name.getText(oracleAST) === 'groupRequirements');
assert(groupDeclaration && ts.isObjectLiteralExpression(groupDeclaration.initializer), 'GROUP_ORACLE_REQUIREMENTS_MISSING');
const oracleGroups = new Set(groupDeclaration.initializer.properties.map(property => property.name.text));
for (const id of new Set(rows.map(row => row.testId))) assert(oracleGroups.has(id), `GROUP_ORACLE_MISSING:${id}`);
checks.push({ check: 'binding-oracle-argv-test-case-coverage', status: 'PASS_STATIC', bindings: rows.length, groups: 15, B2: 'SOURCE_PRESENT_NOT_EXECUTED' });
for (const [document, schema] of [
  ['R3_FROZEN_COMMAND_MANIFEST.json', 'command-manifest'], ['R3_HARNESS_SOURCE_MANIFEST.json', 'source-manifest'],
  ['R3_PREFLIGHT_READONLY.json', 'preflight'], ['R3_EXECUTION_GATE_STATUS.json', 'gate'],
]) {
  const validator = ajv.compile(json(`schemas/${schema}.schema.json`));
  assert(validator(json(document)), `SCHEMA:${document}:${JSON.stringify(validator.errors)}`);
  checks.push({ check: `schema:${document}`, status: 'PASS_STATIC' });
}
ajv.compile(json('schemas/event.schema.json'));
checks.push({ check: 'event-schema', status: 'COMPILED_ONLY_NO_RUNTIME_RECORDS' });
const forbidden = [ /\bprocess\.kill\s*\(/, /\b(?:eval|Function)\s*\(/, /\b(?:chmod|chown|mount|unshare)\s*\(/, /\b(?:rm|rmdir)\s*\(/ ];
for (const path of units.keys()) for (const pattern of forbidden) assert(!pattern.test(text(path)), `FORBIDDEN_DIRECT_CALL:${path}:${pattern}`);
for (const [path, unit] of units) {
  const visit = node => {
    if (ts.isCallExpression(node)) {
      const expression = node.expression;
      const name = ts.isPropertyAccessExpression(expression) ? expression.name.text : ts.isIdentifier(expression) ? expression.text : null;
      if (['exec', 'execSync', 'spawn', 'spawnSync'].includes(name)) {
        assert(path === 'src/adapters/sqlite-authority.mjs' && expression.getText(unit.ast) === 'this.db.exec', `FORBIDDEN_PROCESS_CALL:${path}:${expression.getText(unit.ast)}`);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(unit.ast);
}
checks.push({ check: 'direct-unscoped-operation-scan', status: 'PASS_STATIC', scope: 'src only; permitted future effects behind explicit unresolved adapter methods; not a dynamic safety proof' });
const lock = json('reference/R2-package-lock.json');
assert(sha(readFileSync(join(root, 'reference/R2-package-lock.json'))) === manifest.lockfileSha256, 'LOCKFILE_HASH');
for (const [name, version] of [['@lancedb/lancedb', '0.18.2'], ['@modelcontextprotocol/sdk', '1.29.0'], ['@modelcontextprotocol/server', '2.0.0'], ['@modelcontextprotocol/node', '2.0.0']]) assert(lock.packages[`node_modules/${name}`].version === version, `PIN:${name}`);
checks.push({ check: 'dependency-pins-lockfile', status: 'PASS_STATIC', nativeLoaded: false });
writeFileSync(join(root, 'STATIC_VERIFICATION.json'), JSON.stringify({ schemaVersion: 'r3-static-verification/1', verifiedAt: new Date().toISOString(), status: 'PASS_STATIC_ONLY', checks, sourceFiles: units.size, fixedHeadFixtures: sourceManifest.fixedSources.length, importedExperimentalModules: 0, dynamicTests: 0, executionGate: 'NOT_AUTHORIZED', section4_1: 'BLOCKED', priorVerificationFailure: { reason: 'initial regex conflated SQLite DatabaseSync.exec with shell exec', resolution: 'AST callee classification permits only this.db.exec in the independent SQLite adapter; process launch imports forbidden', experimentalSourceExecuted: false }, tools: { node: process.version, ajv: require('ajv/package.json').version, typescript: ts.version } }, null, 2) + '\n');
console.log(JSON.stringify({ status: 'PASS_STATIC_ONLY', sourceFiles: units.size, bindingRecords: rows.length, groups: 15, dynamicTests: 0, checks: checks.length }, null, 2));
