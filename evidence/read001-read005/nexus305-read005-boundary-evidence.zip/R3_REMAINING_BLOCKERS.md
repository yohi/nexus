# Remaining blockers — Option A-R

**PARTIALLY_INTEGRATED**; R3 Execution Gate **NOT_AUTHORIZED**.

- ENV-001: actual ingress TLS/IdP/mTLS verifier, trust root/key/revocation/clock,
  distinct real principals, OS final FD ownership, SQLite WAL/fsync/trusted boot
  and sole-authority write capability are not enrolled.
- AUTHORITY_BINDING_BLOCKED: synchronous owner verifier interfaces exist but no
  authenticated, independent authority/durability/FD receipt provider is bound.
- DES-002: real main SDK dispatch/send completion and final initialize P observers
  are unregistered. Priming is kept PRIVATE until success; actual post-success
  owner/stream/event enrollment must be provided by the venue.
- ENV-002: Web/Node/Bridge routing source is connected. Native Node-to-private-Web
  request conversion, actual external client, registered grant selection and
  main-session context are not implemented venue bindings. Existing raw handler
  exports are trusted owner-internal interfaces, not proven external ingress.
- DES-001: predecessor CAS, permanent tombstone proof and lineage-wide monotonic
  sequence evidence are required. ANCHOR_WITH_NEW_EVENTS across actual SDK stream
  transport incarnations remains specifically unproved; no fake stream transfer.
- DES-003: close-to-EOF, two real reconnects, stale-409 exclusion, main-session
  continuity and independent raw callback/Node-wire observers are NOT_EXECUTED.
- RP-19A/RP-19B and other cells: test/Oracle source exists, but concrete venue
  fixture construction and fault/scenario execution runners are unregistered.
  `executeWithRegisteredBarriers` is an explicit external test binding, not a
  completed adversarial driver. Dynamic tests were prohibited.
- ENV-003: finite private replay is not general unbounded live SSE. Live writer
  fencing/drain ownership must be independently proved before a lease is granted.
- Recovery: failed/unknown invocation leases remain QUARANTINED. Safe recovery
  or lease re-enrollment is not implemented without real resource isolation proof.
- Provenance/Native/remaining S01-S06/T01-T09 scenarios retain R2 blockers; this
  change does not implement complete source/provider enumerators, Native I/O,
  OS mutation routes, crash/powerloss or general journal recovery integration.
- Full semantic JS typechecking and SQL migration execution were not performed.
- Independent implementation review and Execution Gate approval are separate.

R1-001-04 UNRESOLVED; 234 Bindings BLOCKED/NOT_EXECUTED; Section 4.1 BLOCKED;
Implementation Plan/product implementation NOT_APPROVED.
