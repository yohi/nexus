# READ-002 v2／Bridge Initialize の公開 API 制約

判定案: `SDK_API_CONTRACT_BLOCKED`。実 Initialize、実送信、成功 Receipt は生成していません。

## 固定公開 API の根拠

- `reference/api/@modelcontextprotocol/server/dist/createMcpHandler-CLhGwQTn.d.mts:3768–3808`: Factory は HTTP Request ごとに新しい Server を生成します。
- 同 `:3829–3850`: Legacy 設定は `stateless` または `reject`。既存 Stateful wiring を併用する場合は user-land routing が必要です。
- 同 `:3901–3925`: `McpHttpHandler` の公開面は fetch／close／notify／bus。Main Transport、Session Registry、Initialize send Completion の取得面はありません。
- 同 `:3997–4040`: `createMcpHandler` は per-request の serving entry です。
- `reference/api/@modelcontextprotocol/node/dist/index.d.mts:193–249`: `toNodeHandler` は fetch handler を Node Response に転記します。返す関数に Stateful Owner accessor はありません。`req.auth` は pass-through であり検証 Receipt ではありません。
- `reference/fixed-head/src__server__http-v2__v1-runtime-bridge.ts:8–11,32–35,64–73`: Bridge の公開面は Tool handlers／close です。内部 InMemoryTransport と Client は Main HTTP Session Owner を公開しません。
- 固定 SDK 1.29.0 の Web Transport は sessionId／handleRequest／close／Session Callback を公開します。Callback は Server Result Completion や Final P の証明ではありません。

実装コードの読取補助資料として、既存 installed server／node 2.0.0 の公開配布ソースを `api-evidence/` に保存しました。
原本固定宣言とのバイト一致、R2 Lock Entry の version／integrity との一致を確認しています。
配布 Tarball 自体の再検証や SDK module の実行は行っていません。これは Harness の新原本ではありません。

- `api-evidence/server-2.0.0-index.mjs:966–1035`: 各 POST で fresh Factory／Transport、`sessionIdGenerator: void 0`。GET／DELETE は405、Exchange終了時 teardown。
- 同 `:1205–1373`: Legacy handler は stateless fallback、Modern は fresh Factory＋invoke、返却面は fetch／notify／bus／close。
- `api-evidence/node-2.0.0-index.mjs:270–314`: Node wrapper は `handler.fetch` の Response を `writeHead/write/end` に転記するのみです。
- 固定 Bridge の実 Source は上記 `reference/fixed-head` のファイルです。

Capture Hash と出典境界は `FROZEN_API_SOURCE_CAPTURE.json` に記録しています。

## 最小反例

既存 `createMcpHandler(factory)` に Initialize を入力しても、Legacy fallback は stateless です。
次 Request は fresh serving unit となり、初回の Main Stateful Object と同一参照を取得・再使用できません。
その返却 Response や Bridge Tool 成功を、別途 SDK 1.29.0 で作成した Main Owner の ACTIVE Receipt に対応付けると、異なる Transport の成功を流用する反例になります。

`preparation/verify-frozen-api.mjs` は固定宣言だけをコンパイルしました。
存在しない `McpHttpHandler.getMainTransport` と Node wrapper の同 accessor は TS2339、
`CreateMcpHandlerOptions.sessionIdGenerator` は TS2353 になります。
通常の SDK public API probe は診断なしです。詳細と宣言ハッシュは `FROZEN_API_STATIC_VERIFICATION.json` にあります。
Captured declaration の依存には `skipLibCheck` を適用しており、SDK 実装全体の型証明ではありません。

## fail-closed と最小設計疑義

`actualV2Driver.routeNode/capture` は SDK_API_CONTRACT_BLOCKED で停止します。
`actualBridgeDriver` は Bridge Client を接続する前に停止します。別 Main Receipt の借用も許可しません。
旧 `OWNER_INITIALIZE_RECEIPTS_ROUTE_REQUIRED` を成功分岐に置き換えていません。
`onsessioninitialized` だけを ACTIVE とする変更はありません。

公開 API には、手動の Stateful Web Transport と `isLegacyRequest` を組み合わせる構成余地があります。
ただし、これは現在の `toNodeHandler(createMcpHandler(...))` 内部 Main Owner の取得とは異なります。
本判定は固定された既存ルートについての制約であり、SDK の全公開 API が Stateful serving を禁止するという主張ではありません。
その別構成が T06／T07 の固定 Acceptance を満たすかは Requirements／Design Owner の判断が必要です。
今回、依存、Rev5、R3 Plan、製品コードは変更していません。
